

<?php

	$is_ajax = $_REQUEST['is_ajax'];
	if(isset($is_ajax) && $is_ajax)
	{
		$username = $_REQUEST['username'];
		$password = $_REQUEST['password'];
		
		$con = mysql_connect("TU_SERVIDOR", "TU_USUARIO", "TU_PASSWORD");
		if (!$con){die('Error de conexi�n: ' . mysql_error());}
		mysql_select_db("iwohs", $con);
		$sql="SELECT email, nombre, password, nconsultor FROM users WHERE email='".$username."'";
		$result = mysql_query($sql, $con);

		if($row = mysql_fetch_array($result)) {
		
			if($row["password"] == $password) {
	
			setcookie("usEmail", $row["email"], time()+7776000,"/");
			setcookie("usNombre", $row["nombre"], time()+7776000,"/");
			setcookie("usNConsultor", $row["nconsultor"], time()+7776000,"/");
			
			echo "success";
		
			}
		}

		mysql_free_result($result); 
		mysql_close($con);
	}
	
?>