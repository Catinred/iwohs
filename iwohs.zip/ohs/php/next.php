<?php
//PHP Console***********************************************
//require_once('phpConsole/PhpConsole.php');
//PhpConsole::start();
// test
	//debug('Mensaje de prueba');
	//debug('SELECT * FROM users', 'sql');
	//unkownFunction($unkownVar);
//**********************************************************

	header('Content-type: application/json; charset=UTF-8');
	
	//$is_ajax = $_REQUEST['is_ajax'];
	//if(isset($is_ajax) && $is_ajax)
	//{
		$usuario = $_REQUEST['usuario'];
		$n = $_REQUEST['n'];
		
		$con = mysql_connect("TU_SERVIDOR", "TU_USUARIO", "TU_PASSWORD");
		if (!$con){die('Error de conexión: ' . mysql_error());}
		mysql_select_db("iwohs", $con);
		//echo "Conectado";
		
		//Consulto el nconsultor del usuario
		$sql="SELECT nconsultor FROM users WHERE email='".$usuario."'";
		$result = mysql_query($sql);
		if($row = mysql_fetch_array($result)){
					//debug('Usuario: '.$usuario);
					//echo "1 consulta";
					//echo $row["nconsultor"];
					//extraigo la ayuda del usuario
			$nuevonayuda = $row["nconsultor"] + $n;
			
			$sql2="SELECT ayuda FROM consultor WHERE nayuda='".$nuevonayuda."'";
			$result2 = mysql_query($sql2);	
			if($row2 = mysql_fetch_array($result2)){
							//debug('NAyuda: '.$nuevonayuda);
							//debug('Ayuda: '.$row2["ayuda"]);
							//echo "2 consulta";

				$respuesta='{"numpag" : '.$nuevonayuda.', "ayuda" : "'.utf8_encode($row2["ayuda"]).'"}';
				 
				 echo $respuesta;

				//Actualizo el número de ayuda en la Base de Datos
				//echo $nuevonayuda;
				$sql3 = "UPDATE users SET nconsultor = ". $nuevonayuda ." WHERE email='".$usuario."'";
				mysql_query($sql3);
							//debug('Respuesta de NEXT.PHP');
							//echo "success";
			} else {echo "Falla 2 consulta";};
		} else {echo "Falla 1 consulta";};

		mysql_free_result($result); 
		mysql_close($con);
	//}	
?>