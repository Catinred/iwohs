
<?php

echo $_COOKIE["usNombre"];

setlocale(LC_ALL,"es_ES@euro","es_ES","esp");
echo "<br /><br /><div style='font-size:9px'>" . strftime("%d de %B de %Y")."</div>";
//echo "<br />" . strftime("%A, %d de %B del %Y");

//header('Location: /Gestion.html');

?> 
