

function showAyuda()

{
/*if (str=="")
  {
  document.getElementById("Login").innerHTML="Error!!";
  return;
  }*/
if (window.XMLHttpRequest)
  {// code for IE7+, Firefox, Chrome, Opera, Safari
  xmlhttp=new XMLHttpRequest();
  }
/*else
  {// code for IE6, IE5
  xmlhttp=new ActiveXObject("Microsoft.XMLHTTP");
  }*/
xmlhttp.onreadystatechange=function()
  {
  if (xmlhttp.readyState==4 && xmlhttp.status==200)
    {
    document.getElementById("nombreusuario").innerHTML=xmlhttp.responseText;
	apprise(xmlhttp.responseText, {'verify':true, 'textYes':'Implantación!', 'textNo':'Uso de One'}, function(r)
    {if(r){
        // user clicked 'Yes'
        }
    else
        {
        // user clicked 'No'
        }
	});
    }
  }
xmlhttp.open("GET","js/consultor.php",true);
xmlhttp.send();
}