//DESLOGUEARTE Y SALIR DE LA APLICACIÓN

$(document).ready(function() {
	$("#botonLogout").click(function() {
        $.ajax({
            type: "POST",
            url: "php/logout.php",
            success: function(){
				setTimeout('window.location.href="../index.html" ', 1000);
				window.close();
				}
		});
	});
//inicio();
});

//¿ESTÁS LOGUEADO?

function logueado () {

$('#usuario').html(getCookie('usEmail'));//indico el usuario registrado en la web	
	
var is_chrome = navigator.userAgent.toLowerCase().indexOf('chrome/') > -1; 
//Compruebo que está usando Chrome

if (!is_chrome) //Compruebo si el navegador tiene cookies de este sitio.
	{ setTimeout('window.location.href="../chrome.html"', 1000);};
if (getCookie('usNombre')===null) //Compruebo si el navegador tiene cookies de este sitio.
	{ setTimeout('window.location.href="../ingresar.html"', 1000);};
	//alert("Comprobado el acceso");
}


//FUNCIONES ESTANDAR DE INTERNET - LE PASO EL NOMBRE DE LA COOKIE Y ME DEVUELVE EL VALOR
function getCookie(name) {
	var dc = document.cookie;
	var prefix = name + "=";
	var begin = dc.indexOf("; " + prefix);
	if (begin == -1) {
		begin = dc.indexOf(prefix);
		if (begin != 0) return null;
	} else {
		begin += 2;
	};
	var end = document.cookie.indexOf(";", begin);
	if (end == -1) {
		end = dc.length;
	};
	return unescape(dc.substring(begin + prefix.length, end));
}

function setCookie(name, value, expires, path, domain, secure) {
  document.cookie = name + "=" + escape(value) + 
  ((expires == null) ? "" : "; expires=" + expires.toGMTString()) +
  ((path == null) ? "" : "; path=" + path) +
  ((domain == null) ? "" : "; domain=" + domain) +
  ((secure == null) ? "" : "; secure");
}




//ESTAS FUNCIONES NO SE UTILIZAN PARA NADA - SOLO INFORMACIÓN EN USO DE COOKIES
function cargarcookies() {
     document.cookie = "cookie1=webintenta;";
     document.cookie = "cookie2=blog;";
     alert(document.cookie);
}

function borrarcookie(){
      var d = new Date();
      document.cookie = "cookie1=1;expires=" + d.toGMTString() + ";" + ";";
      alert(document.cookie);
 }
