//BASE DE DATOS ISOWIN ONE

    var db;	
	var aDataSet = [
				['Trident','Internet Explorer 4.0','Win 95+','TRUE','X'],
				['Other browsers','All others','-','FALSE','U']
			];	
	
	/*Bases de datos creadas:
	db = openDatabase("DB Prueba 3", "0.1", "Database Prueba 2", 200000);
	db = openDatabase("DBIW1", "0.1", "Database Isowin One", 200000);
	*/
	
		
	function showData(users,nombreTabla) {
		nombreDiv = "Div"+nombreTabla
		var place = document.getElementById(nombreDiv);
		if (place.getElementsByTagName("ul").length > 0 )
			place.removeChild(place.getElementsByTagName("ul")[0]);
		var list = document.createElement("ul");
		
		document.getElementById(nombreDiv).innerHTML ="Tabla: "+nombreTabla;

		for ( var i = 0; i < users.length; i++) {
			var item = document.createElement("li");
			item.innerHTML += "<b>" + users[i][0] + "</b>";
			for (var j = 1; j < users[i].length; j++) {item.innerHTML += ">" + users[i][j] };
			list.appendChild(item);
		}
		place.appendChild(list);
	}
	
	var tablas = ["tareas", "apuntes", "notas", "documentos", "registros", "indicadores", "proveedores", "ncprovs", "puestos", "personas", "cursos", "cursospersonas", "equipos", "calibraciones","maquinas", "mantenimientos", "marevs", "controles", "propcliente", "disenos", "direvs", "encuestas", "reclamaciones", "estudios", "clientes", "productos", "ncs", "acps", "auditorias", "objetivos", "acciones", "requisitos", "procesos"];
	//alert(tablas.length);
	
	function listTablas() {
		for (var j=0; j < tablas.length; j++)  {
			var consulta = "SELECT * FROM " + tablas[j];
			//alert("SELECT * FROM "+tablas[j] +" :: "+ j);
			ConsultaTabla (consulta, tablas[j]);
			//setTimeout("alert('hello')", 1000);
		//document.getElementById("usersDiv").innerHTML ="Tabla TAREAS";
			};
			
			var consulta = "SELECT * FROM tareas t INNER JOIN auditorias a ON t.idtarea = a.idtarea";
			ConsultaTabla (consulta, "auditorias");

			}
					
	function ConsultaTabla (consulta, tabla) {
		var db;
		db = openDatabase("DBIW1", "0.1", "Database Isowin One", 5 * 1024 * 1024);
		if (db) {
		//alert("Conectado!");
		db.transaction( function(tx) {
			tx.executeSql(consulta, [],
				function(tx, result){
					var output = [];
					//alert("Datos en la tabla: "+result.rows.length);
		
					for(var i=0; i < result.rows.length; i++) {
						//alert(i +"/"+ result.rows.length);
						if (tabla == "tareas") {output.push([result.rows.item(i)['idtarea'], result.rows.item(i)['tarea'], result.rows.item(i)['fchinicio'], result.rows.item(i)['fchfin'], result.rows.item(i)['descripcion'], result.rows.item(i)['prioridad'], result.rows.item(i)['trazabilidad']])};
						//idtarea integer primary key autoincrement, tarea text, fchinicio datetime, fchfin datetime, descripcion longtext, prioridad integer
						if (tabla == "apuntes") {output.push([result.rows.item(i)['apunte'], result.rows.item(i)['idx']])};
						if (tabla == "notas") {output.push([result.rows.item(i)['idnota'], result.rows.item(i)['nota']])};
						
						if (tabla == "documentos") {output.push([result.rows.item(i)['iddocumento'], result.rows.item(i)['coddocumento'], result.rows.item(i)['documento'], result.rows.item(i)['revision'], result.rows.item(i)['fchpublic'], result.rows.item(i)['link'], result.rows.item(i)['estado'], result.rows.item(i)['proceso']])};
						//iddocumento integer primary key autoincrement, coddocumento text, documento text, revision text, fchpublic datetime, link longtext)
						if (tabla == "registros") {output.push([result.rows.item(i)['idregistro'], result.rows.item(i)['codregistro'], result.rows.item(i)['registro'], result.rows.item(i)['revision'], result.rows.item(i)['fchpublic'], result.rows.item(i)['link'], result.rows.item(i)['anos'], result.rows.item(i)['lugar'], result.rows.item(i)['estado'], result.rows.item(i)['proceso']])};
						//idregistro integer primary key autoincrement, codregistro text, registro text, revision text, fchpublic datetime, link longtext, anos text, lugar longtext
						if (tabla == "indicadores") {output.push([result.rows.item(i)['idindicador'], result.rows.item(i)['serie'], result.rows.item(i)['mes'], result.rows.item(i)['valor']])};
						//idindicador text, serie text, mes integer, valor double
						if (tabla == "proveedores")	{output.push([result.rows.item(i)['idproveedor'], result.rows.item(i)['proveedor'], result.rows.item(i)['cif'], result.rows.item(i)['contacto'], result.rows.item(i)['mail'], result.rows.item(i)['direccion'], result.rows.item(i)['fchinicial'], result.rows.item(i)['fcheval'], result.rows.item(i)['fchprox'], result.rows.item(i)['eval1'], result.rows.item(i)['eval2'], result.rows.item(i)['eval3'], result.rows.item(i)['eval4'], result.rows.item(i)['eval5'], result.rows.item(i)['eval6'], result.rows.item(i)['valoracion'], result.rows.item(i)['obs']])};
						//idproveedor integer primary key autoincrement, proveedor text, cif text, fchinicial datetime, fcheval datetime, eval1 integer, eval2 integer, eval3 integer, eval4 integer, eval5 integer, valoracion double
						if (tabla == "ncprovs") {output.push([result.rows.item(i)['idncprov'], result.rows.item(i)['ncprov'], result.rows.item(i)['fchinicio'], result.rows.item(i)['fchfin'], result.rows.item(i)['responsable'], result.rows.item(i)['estado'], result.rows.item(i)['descripcion'], result.rows.item(i)['correccion'], result.rows.item(i)['idproveedor']])};								
						//idncprov integer primary key autoincrement, ncprov text, codncprov text, fchinicio datetime, fchfin datetime, responsable text, idproveedor integer, descripcion text, correccion text, codacp text
						if (tabla == "disenos"){output.push([result.rows.item(i)['iddiseno'], result.rows.item(i)['diseno'], result.rows.item(i)['responsable'], result.rows.item(i)['equipotrabajo'], result.rows.item(i)['linkplan'], result.rows.item(i)['cambiosplan'], result.rows.item(i)['reqlegal'], result.rows.item(i)['reqfuncion'], result.rows.item(i)['linkrequisitos'], result.rows.item(i)['criteriosacept'], result.rows.item(i)['resultados'], result.rows.item(i)['obs']])};
						//iddiseno integer primary key autoincrement, diseno text, responsable text, equipotrabajo text, linkplan text, cambiosplan text, reqlegal text, reqfuncion text, linkrequisitos text, criteriosacept text, resultados text, obs text
						if (tabla == "direvs") {output.push([result.rows.item(i)['iddirev'], result.rows.item(i)['iddiseno'], result.rows.item(i)['tipo'], result.rows.item(i)['fchplan'], result.rows.item(i)['fchreal'], result.rows.item(i)['resultados'], result.rows.item(i)['acciones']])};								
						//idrev, iddiseno, tipo, fchplan, fchreal, resultados, acciones
						if (tabla == "maquinas"){output.push([result.rows.item(i)['idmaquina'], result.rows.item(i)['maquina'], result.rows.item(i)['marca'], result.rows.item(i)['modelo'], result.rows.item(i)['sn'], result.rows.item(i)['fchfabricacion'], result.rows.item(i)['valor'], result.rows.item(i)['linkdocs'],result.rows.item(i)['obs']])};
						if (tabla == "mantenimientos"){output.push([result.rows.item(i)['idman'], result.rows.item(i)['idmaquina'], result.rows.item(i)['mantenimiento'], result.rows.item(i)['periodicidad'], result.rows.item(i)['operaciones'], result.rows.item(i)['responsable'], result.rows.item(i)['prioridad'], result.rows.item(i)['linkdocs'], result.rows.item(i)['fchprox'], result.rows.item(i)['obs']])};
						if (tabla == "marevs") {output.push([result.rows.item(i)['idmarev'], result.rows.item(i)['idman'], result.rows.item(i)['fchrev'], result.rows.item(i)['resultado'], result.rows.item(i)['por'], result.rows.item(i)['linkdocs'], result.rows.item(i)['obs']])};								
																																																												
						if (tabla == "controles") {output.push([result.rows.item(i)['idcontrol'], result.rows.item(i)['control'], result.rows.item(i)['codcontrol'], result.rows.item(i)['valorlimite'], result.rows.item(i)['idresponsable'], result.rows.item(i)['periodo'], result.rows.item(i)['idproducto'], result.rows.item(i)['idcliente'], result.rows.item(i)['idequipo'], result.rows.item(i)['iddocumento']])};								
						if (tabla == "propcliente") {output.push([result.rows.item(i)['idpc'], result.rows.item(i)['material'], result.rows.item(i)['idcliente'], result.rows.item(i)['ubicacion'], result.rows.item(i)['uso'], result.rows.item(i)['responsable'], result.rows.item(i)['vulnerabilidad'], result.rows.item(i)['proteccion'], result.rows.item(i)['fchcaducidad'], result.rows.item(i)['obs']])};								
						//
						if (tabla == "puestos"){output.push([result.rows.item(i)['idpuesto'], result.rows.item(i)['puesto'], result.rows.item(i)['requisitos'], result.rows.item(i)['funciones'], result.rows.item(i)['idpadre']])};
						//puesto, requisitos, funciones, idpadre
						if (tabla == "personas"){output.push([result.rows.item(i)['idpersona'], result.rows.item(i)['nombre'], result.rows.item(i)['apellidos'], result.rows.item(i)['dni'], result.rows.item(i)['fchnac'], result.rows.item(i)['fchalta'], result.rows.item(i)['fchbaja'], result.rows.item(i)['linkcv'], result.rows.item(i)['idpuesto'], result.rows.item(i)['esresp']])};
						//personas
						if (tabla == "cursos") {output.push([result.rows.item(i)['idcurso'], result.rows.item(i)['curso'], result.rows.item(i)['codcurso'], result.rows.item(i)['objetivos'], result.rows.item(i)['estado'], result.rows.item(i)['alumnos'], result.rows.item(i)['fchinicio'], result.rows.item(i)['fchfin'], result.rows.item(i)['horario'], result.rows.item(i)['nhoras'], result.rows.item(i)['valalumnos'], result.rows.item(i)['valformador'], result.rows.item(i)['valjefe'], result.rows.item(i)['fchvaljefe'], result.rows.item(i)['linkdocs'], result.rows.item(i)['obs']])};								
						if (tabla == "cursospersonas") {output.push([result.rows.item(i)['idcurso'], result.rows.item(i)['idpersona'], result.rows.item(i)['valoracion'], result.rows.item(i)['fchvaloracion'], result.rows.item(i)['linkdiploma'], result.rows.item(i)['obs']])};								
						
						//CALIBRACIONES
						if (tabla == "equipos"){output.push([result.rows.item(i)['idequipo'], result.rows.item(i)['equipo'], result.rows.item(i)['marca'], result.rows.item(i)['modelo'], result.rows.item(i)['sn'], result.rows.item(i)['rango'], result.rows.item(i)['escalon'], result.rows.item(i)['uso'], result.rows.item(i)['umax'], result.rows.item(i)['fchprox'], result.rows.item(i)['estado'], result.rows.item(i)['obs']])};
						if (tabla == "calibraciones") {output.push([result.rows.item(i)['idcal'], result.rows.item(i)['idequipo'], result.rows.item(i)['tipo'], result.rows.item(i)['u'], result.rows.item(i)['fchcal'], result.rows.item(i)['linkcert'], result.rows.item(i)['obs']])};								
						
						//SATISFACCCIÓN DE CLIENTE
						if (tabla == "reclamaciones") {output.push([result.rows.item(i)['idreclamacion'], result.rows.item(i)['codreclamacion'], result.rows.item(i)['reclamacion'], result.rows.item(i)['fchalta'], result.rows.item(i)['descripcion'], result.rows.item(i)['correccion'], result.rows.item(i)['fchcierre'], result.rows.item(i)['conforme'], result.rows.item(i)['idcliente'], result.rows.item(i)['estado']])};								
						if (tabla == "estudios"){output.push([result.rows.item(i)['idestudio'], result.rows.item(i)['estudio'], result.rows.item(i)['fchinicio'], result.rows.item(i)['fchfin'], result.rows.item(i)['objetivos'], result.rows.item(i)['estado'], result.rows.item(i)['responsable'], result.rows.item(i)['resultado'], result.rows.item(i)['valoracion'], result.rows.item(i)['pr1'], result.rows.item(i)['pr2'], result.rows.item(i)['pr3'], result.rows.item(i)['pr4'], result.rows.item(i)['pr5'], result.rows.item(i)['pr6'], result.rows.item(i)['pr7'], result.rows.item(i)['pr8'], result.rows.item(i)['pr9'], result.rows.item(i)['pr10']])};
						if (tabla == "encuestas"){output.push([result.rows.item(i)['idencuesta'], result.rows.item(i)['idestudio'], result.rows.item(i)['idcliente'], result.rows.item(i)['estado'], result.rows.item(i)['fchalta'], result.rows.item(i)['eval1'], result.rows.item(i)['eval2'], result.rows.item(i)['eval3'], result.rows.item(i)['eval4'], result.rows.item(i)['eval5'], result.rows.item(i)['eval6'], result.rows.item(i)['eval7'], result.rows.item(i)['eval8'], result.rows.item(i)['eval9'], result.rows.item(i)['eval10'], result.rows.item(i)['resultado']])};
						
						//CLIENTES
						if (tabla == "clientes") {output.push([result.rows.item(i)['idcliente'], result.rows.item(i)['cliente'], result.rows.item(i)['codcliente'], result.rows.item(i)['cif'], result.rows.item(i)['direccion'], result.rows.item(i)['tlf'], result.rows.item(i)['fchalta'], result.rows.item(i)['contacto'], result.rows.item(i)['tlfcontacto'], result.rows.item(i)['mailcontacto'], result.rows.item(i)['obs']])};								
						if (tabla == "productos") {output.push([result.rows.item(i)['idproducto'], result.rows.item(i)['producto'], result.rows.item(i)['codproducto'], result.rows.item(i)['descripcion'], result.rows.item(i)['responsable'], result.rows.item(i)['obs']])};								

						if (tabla == "objetivos") {output.push([result.rows.item(i)['idobjetivo'], result.rows.item(i)['objetivo'], result.rows.item(i)['descripcion'], result.rows.item(i)['responsable'], result.rows.item(i)['recursos']])};
						if (tabla == "acciones") {output.push([result.rows.item(i)['idaccion'], result.rows.item(i)['accion'], result.rows.item(i)['adescripcion'], result.rows.item(i)['aresponsable'], result.rows.item(i)['arecursos'], result.rows.item(i)['fchinicio'], result.rows.item(i)['fchfin'], result.rows.item(i)['valorultrev'], result.rows.item(i)['fchultrev'], result.rows.item(i)['idobjetivo'], result.rows.item(i)['color']])};
						
						if (tabla == "ncs"){output.push([result.rows.item(i)['idnc'], result.rows.item(i)['nc'], result.rows.item(i)['codnc'], result.rows.item(i)['proceso'], result.rows.item(i)['origen'], result.rows.item(i)['fchinicio'], result.rows.item(i)['fchfin'], result.rows.item(i)['responsable'], result.rows.item(i)['descripcion'], result.rows.item(i)['causas'], result.rows.item(i)['correccion'], result.rows.item(i)['codacp']])};
						
						//AUDITORIAS Y ACPS
						if (tabla == "acps") {output.push([result.rows.item(i)['idacp'], result.rows.item(i)['acp'], result.rows.item(i)['codacp'], result.rows.item(i)['tipo'], result.rows.item(i)['origen'], result.rows.item(i)['fchalta'], result.rows.item(i)['responsable'], result.rows.item(i)['equipo'], result.rows.item(i)['estado'], result.rows.item(i)['acciones'], result.rows.item(i)['fchprevista'], result.rows.item(i)['seguimiento'], result.rows.item(i)['fchcierre'], result.rows.item(i)['eficacia'], result.rows.item(i)['fcheficacia'], result.rows.item(i)['codtrz']])};								
						if (tabla == "auditorias") {output.push([result.rows.item(i)['idauditoria'], result.rows.item(i)['auditoria'], result.rows.item(i)['codauditoria'], result.rows.item(i)['estado'], result.rows.item(i)['fchinicio'], result.rows.item(i)['fchfin'], result.rows.item(i)['auditorjefe'], result.rows.item(i)['auditores'], result.rows.item(i)['observadores'], result.rows.item(i)['alcance'], result.rows.item(i)['nnc'], result.rows.item(i)['ndl'], result.rows.item(i)['nam'], result.rows.item(i)['linkplanificacion'], result.rows.item(i)['linkinforme'], result.rows.item(i)['linkpac'], result.rows.item(i)['distribucion'], result.rows.item(i)['obs']])};
						
						if (tabla == "requisitos") {output.push([result.rows.item(i)['idrequisito'], result.rows.item(i)['requisito'], result.rows.item(i)['codrequisito'], result.rows.item(i)['trazabilidad'], result.rows.item(i)['referencia'], result.rows.item(i)['link'], result.rows.item(i)['fchinicio'], result.rows.item(i)['vigente'], result.rows.item(i)['revision'], result.rows.item(i)['estado'], result.rows.item(i)['obs']])};
						
						if (tabla == "procesos") {output.push([result.rows.item(i)['idproceso'], result.rows.item(i)['proceso'], result.rows.item(i)['mision'], result.rows.item(i)['alcance'], result.rows.item(i)['entradas'], result.rows.item(i)['salidas'], result.rows.item(i)['recursos'], result.rows.item(i)['responsable'], result.rows.item(i)['requisitos'], result.rows.item(i)['controles'], result.rows.item(i)['i1'], result.rows.item(i)['i2'], result.rows.item(i)['i3'], result.rows.item(i)['i4']])};
						
						}
					//alert ("consulta SQL realizada, "+  output[i]);
					showData(output, tabla);
					//alert ("Resultados mostrados");
					});});};
		}
		

	function listData() {
		
		 listTablas()
		
		}
		
 //CUIDADO CON LOS ALERT NO FUNCIONAN LOS EXECUTESQL!!!
					
function crearBD() {
	    var db;
        db = openDatabase("DBIW1", "0.1", "Database Isowin One", 5 * 1024 * 1024);
		if(!db)     alert("Failed to connect to database.");
        if (db) {
            // Database opened
			db.transaction( function(tx) {
tx.executeSql("CREATE TABLE IF NOT EXISTS documentos(iddocumento integer primary key autoincrement, coddocumento text, documento text, revision text, fchpublic datetime, link longtext, estado text, proceso integer)");
tx.executeSql("CREATE TABLE IF NOT EXISTS registros(idregistro integer primary key autoincrement, codregistro text, registro text, revision text, fchpublic datetime, link longtext, anos text, lugar longtext, estado text, proceso integer)");
tx.executeSql("CREATE TABLE IF NOT EXISTS tareas(idtarea integer primary key autoincrement, tarea text, fchinicio datetime, fchfin datetime, descripcion longtext, prioridad integer, trazabilidad text)");
tx.executeSql("CREATE TABLE IF NOT EXISTS indicadores(idindicador text, serie text, mes integer, valor double)");

tx.executeSql("CREATE TABLE IF NOT EXISTS proveedores(idproveedor integer primary key autoincrement, proveedor text, cif text, contacto text, mail text, direccion text, fchinicial datetime, fcheval datetime, fchprox datetime, eval1 integer, eval2 integer, eval3 integer, eval4 integer, eval5 integer, eval6 integer, valoracion double, obs text)");
tx.executeSql("CREATE TABLE IF NOT EXISTS ncprovs(idncprov integer primary key autoincrement, ncprov text, codncprov text, fchinicio datetime, fchfin datetime, responsable text, estado text, descripcion text, correccion text, idproveedor integer)");
tx.executeSql("CREATE TABLE IF NOT EXISTS ncs(idnc integer primary key autoincrement, nc text, codnc text, proceso integer, origen text, fchinicio datetime, fchfin datetime, responsable text, descripcion text, causas text, correccion text, codacp text)");

tx.executeSql("CREATE TABLE IF NOT EXISTS acps(idacp integer primary key autoincrement, acp text, codacp text, tipo text, origen text, fchalta datetime, responsable text, equipo text, estado text, acciones text, fchprevista datetime, seguimiento text, fchcierre datetime, eficacia text, fcheficacia datetime, codtrz text)");
tx.executeSql("CREATE TABLE IF NOT EXISTS auditorias (idauditoria integer primary key autoincrement, auditoria text, codauditoria text, estado text, fchinicio datetime, fchfin datetime, auditorjefe text, auditores text, observadores text, alcance text, nnc integer, ndl integer, nam integer, linkplanificacion text, linkinforme text, linkpac text, distribucion text, obs text)");

tx.executeSql("CREATE TABLE IF NOT EXISTS puestos(idpuesto integer primary key autoincrement, puesto text, requisitos text, funciones text, idpadre integer)");
tx.executeSql("CREATE TABLE IF NOT EXISTS personas(idpersona integer primary key autoincrement, nombre text, apellidos text, dni text, fchnac text, fchalta text, fchbaja text, linkcv text, idpuesto integer, esresp text)");
tx.executeSql("CREATE TABLE IF NOT EXISTS cursospersonas(idcurso integer, idpersona integer, valoracion text, fchvaloracion datetime, linkdiploma text, obs text)");
tx.executeSql("CREATE TABLE IF NOT EXISTS cursos(idcurso integer primary key autoincrement, curso text, codcurso text, objetivos text, estado text, alumnos text, fchinicio datetime, fchfin datetime, horario text, nhoras integer, valalumnos text, valformador text, valjefe text, fchvaljefe datetime, linkdocs text, obs text)");
tx.executeSql("CREATE TABLE IF NOT EXISTS equipos(idequipo integer primary key autoincrement, equipo text, marca text, modelo text, sn text, rango text, escalon text, uso text, umax double, fchprox datetime, estado text, obs text)");
tx.executeSql("CREATE TABLE IF NOT EXISTS calibraciones(idcal integer primary key autoincrement, idequipo integer, tipo text, u double, fchcal datetime, linkcert text, obs text)");

tx.executeSql("CREATE TABLE IF NOT EXISTS maquinas (idmaquina integer primary key autoincrement, maquina text, marca text, modelo text, sn text, fchfabricacion datetime, valor text, linkdocs text, fchprox datetime, obs text)");
tx.executeSql("CREATE TABLE IF NOT EXISTS mantenimientos (idman integer primary key autoincrement, idmaquina integer, mantenimiento text, periodicidad text, operaciones text, responsable text, prioridad text, linkdocs text, fchprox datetime, obs text)");
tx.executeSql("CREATE TABLE IF NOT EXISTS marevs (idmarev integer primary key autoincrement, idman integer, fchrev datetime, resultado text, por text, linkdocs text, obs text)");

tx.executeSql("CREATE TABLE IF NOT EXISTS controles (idcontrol integer primary key autoincrement, control text, codcontrol text, valorlimite text, idresponsable integer, periodo text, idproducto integer, idcliente integer, idequipo integer, iddocumento integer)");
tx.executeSql("CREATE TABLE IF NOT EXISTS propcliente (idpc integer primary key autoincrement, material text, idcliente integer, ubicacion text, uso text, responsable text, vulnerabilidad text, proteccion text, fchcaducidad text, obs text)");

tx.executeSql("CREATE TABLE IF NOT EXISTS disenos (iddiseno integer primary key autoincrement, diseno text, responsable text, equipotrabajo text, linkplan text, cambiosplan text, reqlegal text, reqfuncion text, linkrequisitos text, criteriosacept text, resultados text, obs text)");
tx.executeSql("CREATE TABLE IF NOT EXISTS direvs (iddirev integer primary key autoincrement, iddiseno integer, tipo text, fchplan datetime, fchreal datetime, resultados text, acciones text)");

tx.executeSql("CREATE TABLE IF NOT EXISTS reclamaciones (idreclamacion integer primary key autoincrement, codreclamacion text, reclamacion text, fchalta datetime, descripcion text, correccion text, fchcierre datetime, conforme text, idcliente integer, estado text)");
tx.executeSql("CREATE TABLE IF NOT EXISTS estudios (idestudio integer primary key autoincrement, estudio text, fchinicio datetime, fchfin datetime, objetivos text, estado text, responsable text, resultado double, valoracion text, pr1 text, pr2 text, pr3 text, pr4 text, pr5 text, pr6 text, pr7 text, pr8 text, pr9 text, pr10 text)");
tx.executeSql("CREATE TABLE IF NOT EXISTS encuestas (idencuesta integer primary key autoincrement, idestudio integer, idcliente integer, estado text, fchalta datetime, eval1 integer, eval2 integer, eval3 integer, eval4 integer, eval5 integer, eval6 integer, eval7 integer, eval8 integer, eval9 integer, eval10 integer, resultado double)");

tx.executeSql("CREATE TABLE IF NOT EXISTS clientes (idcliente integer primary key autoincrement, cliente text, codcliente text, cif text, direccion text, tlf text, fchalta datetime, contacto text, tlfcontacto text, mailcontacto text, obs text)");
tx.executeSql("CREATE TABLE IF NOT EXISTS productos (idproducto integer primary key autoincrement, producto text, codproducto text, descripcion text, responsable text, obs text)");
tx.executeSql("CREATE TABLE IF NOT EXISTS requisitos (idrequisito integer primary key autoincrement, requisito text, codrequisito text, trazabilidad text, referencia text, link text, fchinicio datetime, vigente text, revision text, estado text, obs text)");

tx.executeSql("CREATE TABLE IF NOT EXISTS objetivos(idobjetivo integer primary key autoincrement, objetivo text, descripcion text, responsable text, recursos text )");
tx.executeSql("CREATE TABLE IF NOT EXISTS acciones(idaccion integer primary key autoincrement, accion text, adescripcion text, aresponsable text, arecursos text, fchinicio datetime, fchfin datetime, valorultrev text, fchultrev datetime, idobjetivo integer, color text)");

tx.executeSql("CREATE TABLE IF NOT EXISTS apuntes(apunte text, prioridad integer, idx text)");
tx.executeSql("CREATE TABLE IF NOT EXISTS notas(idnota integer primary key autoincrement, nota text)");
tx.executeSql("CREATE TABLE IF NOT EXISTS procesos(idproceso integer, proceso text, mision text, alcance text, entradas text, salidas text, recursos text, responsable text, requisitos text, controles text, i1 text, i2 text, i3 text, i4 text)");
//tx.executeSql("CREATE TABLE IF NOT EXISTS auditorias(idtarea primary key, alcance text, estado text, nncs text, linkinforme text, linkpac text, FOREIGN KEY (idtarea) REFERENCES tareas (idtarea) ON UPDATE CASCADE ON DELETE CASCADE)");
			
			});
			
		alert("Tabla/s y creada/s");
			}
	  }	
	  
function ingresarBD () {
	    var db;
        db = openDatabase("DBIW1", "0.1", "Database Isowin One", 5 * 1024 * 1024);
		if(db){	
		db.transaction( function(tx) {
tx.executeSql("INSERT INTO documentos(coddocumento, documento, revision, fchpublic, link, estado, proceso) VALUES(?,?,?,?,?,?,?)", ["PR001","Documento de Prueba", "1.5","12/12/2012","c:/docs", "Aprobado", 1]);
tx.executeSql("INSERT INTO registros(codregistro, registro, revision, fchpublic, link, anos, lugar, estado, proceso) VALUES(?,?,?,?,?,?,?,?,?)", ["REG001", "Registro de Prueba", "1.5","12/12/2012","c:/regs",3,"c:/docs/obsoletos", "Obsoleto", 1]);
tx.executeSql("INSERT INTO indicadores(idindicador, serie, mes, valor) VALUES(?,?,?,?)",["I1", "2012", 2, 5]);	

tx.executeSql("INSERT INTO proveedores(proveedor, cif, contacto, mail, direccion, fchinicial, fcheval, fchprox, eval1, eval2, eval3, eval4, eval5, eval6, valoracion, obs) VALUES(?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)",["Telnet", "A50608295", "Jorge tolosana", "jtolosana@telnet-ri.es","Buenos Aires 18 Zaragoza, España", "01/03/2010", "11/08/2011", "11/3/2012", 3, 2, 3, 2, 3, 2, 2.5, "Ninguna observación"]);	
tx.executeSql("INSERT INTO ncprovs(ncprov, codncprov, fchinicio, fchfin, responsable, estado, descripcion, correccion, idproveedor) VALUES(?,?,?,?,?,?,?,?,?)",["Retraso en entrega", "NCP-01", "01/03/2012", "14/04/2012", "Tomas Misser", "Pendiente", "Ha retrasado la entrega del material en dos semanas", "Penalización económica", 1]);	
tx.executeSql("INSERT INTO ncs(nc, codnc, proceso, origen, fchinicio, fchfin, responsable, descripcion, causas, correccion, codacp) VALUES(?,?,?,?,?,?,?,?,?,?,?)",["Falta aprobación","NC-2","GES","N/A","06/07/2012","06/01/2013",1,"Sin descripcion","Pendiente analizar las causas","Se firma","ACP-22"]);

tx.executeSql("INSERT INTO acps(acp, codacp, tipo, origen, fchalta, responsable, equipo, estado, acciones, fchprevista, seguimiento, fchcierre, eficacia, fcheficacia, codtrz) VALUES(?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)",["Sistema de Seguridad intrusión","AC-12","ac","NC-1214","10/01/2013","David Santamaria","Javier Sanchez, Francisco Lera","En proceso","Varias","12/01/2013","Vamos en tiempo","21/01/2013","Eficacia probada","21/02/2013","rc1"]);
tx.executeSql("INSERT INTO auditorias (auditoria, codauditoria, estado, fchinicio, fchfin, auditorjefe, auditores, observadores, alcance, nnc, ndl, nam, linkplanificacion, linkinforme, linkpac, distribucion, obs) VALUES(?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)",["auditoría Interna","2013-1","Planificada","12/02/2012","15/02/2012","David Santolaria", "Pablo Colón", "Ninguno", "SG Calidad - Cables", 3, 5, 6, "c:/auditoria/plan", "c:/auditoria/informe", "c:/auditoria/pac", "Dirección general", "-"]);

tx.executeSql("INSERT INTO puestos(puesto, requisitos, funciones, idpadre) VALUES(?,?,?,?)",["Operario","EGB","Colocar un tornillo",0]);
tx.executeSql("INSERT INTO personas(nombre, apellidos, dni, fchnac, fchalta, fchbaja, linkcv, idpuesto, esresp) VALUES(?,?,?,?,?,?,?,?,?)",["David","Santolaria Bellosta","252423123Z","28/09/1982", "14/09/2013", "", "c:/cvs/personal", 2, "Si"]);
tx.executeSql("INSERT INTO cursos(curso, codcurso, objetivos, estado, alumnos, fchinicio, fchfin, horario, nhoras, valalumnos, valformador, valjefe, fchvaljefe, linkdocs, obs) VALUES(?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)",["PVDs","F-01", "Reducir problemas musculares","Finalizado","Administrativos","2012-03-08","2012-03-21","8:00 a 14:00",20,"8","7","6","2012-05-20", "c:/formación/cursos", "-"]);
tx.executeSql("INSERT INTO cursospersonas (idcurso, idpersona, valoracion, fchvaloracion, linkdiploma, obs) VALUES(?,?,?,?,?,?)",[2,2,"Aprovechado","2012-03-08","c:/diplomas","Sin comentarios"]);

tx.executeSql("INSERT INTO equipos(equipo, marca, modelo, sn, rango, escalon, uso, umax, fchprox, estado, obs) VALUES(?,?,?,?,?,?,?,?,?,?,?)",["OTDR","EXFO","B-300","1232-tr12","1-100","0,1","en campo",0.1,"03/04/2012","Fuera de Uso", "fue reparado"]);
tx.executeSql("INSERT INTO calibraciones(idequipo, tipo, u, fchcal, linkcert, obs) VALUES(?,?,?,?,?,?)",["2", "Calibración","0,01","05-07-2012","c/certificados de calibración","No coments"]);

tx.executeSql("INSERT INTO maquinas (maquina, marca, modelo, sn, fchfabricacion, valor, linkdocs, obs) VALUES(?,?,?,?,?,?,?,?)",["Extrusora","Mainfer","JFK","1232-tr12","01/05/2005","5.000 euros","c:/mantenimientos","Sin comentarios"]);
tx.executeSql("INSERT INTO mantenimientos (idmaquina, mantenimiento, periodicidad, operaciones, responsable, prioridad, linkdocs, fchprox, obs) VALUES(?,?,?,?,?,?,?,?,?)",[2,"Engrasado general","1/mes","engrasar partes móviles","Depto Mantenimiento","Media","c:/mantenimientos","09/11/2012","Sin comentarios"]);
tx.executeSql("INSERT INTO marevs (idman, fchrev, resultado, por, linkdocs, obs) VALUES(?,?,?,?,?,?)",[1, "10-07-2012","Todo ok","Daniel Sena","c:/resultados de mantenimiemto/","No more coments"]);

tx.executeSql("INSERT INTO controles (control, codcontrol, valorlimite, idresponsable, periodo, idproducto, idcliente, idequipo, iddocumento) VALUES(?,?,?,?,?,?,?,?,?)",["Espesor R3", "E-R3", "4.3", 1, "Todos", 1, 2, 3, 4]);
tx.executeSql("INSERT INTO propcliente ( material, idcliente, ubicacion, uso, responsable, vulnerabilidad, proteccion, fchcaducidad, obs) VALUES(?,?,?,?,?,?,?,?,?)",["Fibra óptica especial", 1,"Sala de Ultravioleta","Curado de fibra","Gabriel Ordovas","Golpes, agua, sol, fuego","Armario RF90","01/04/2013","en palet europeo"]);

tx.executeSql("INSERT INTO disenos (diseno, responsable, equipotrabajo, linkplan, cambiosplan, reqlegal, reqfuncion, linkrequisitos, criteriosacept, resultados, obs) VALUES(?,?,?,?,?,?,?,?,?,?,?)",["Monoposte","Ignacio Mesa","Antonio gil, Alejandro sanchis","c:/planificaciones","Sin cambios","Ley del viento","UNE-12-32EX","c:/requisitos","H>6.2","Montaje correcto","Sin comentarios"]);
tx.executeSql("INSERT INTO direvs (iddiseno, tipo, fchplan, fchreal, resultados, acciones) VALUES(?,?,?,?,?,?)",[2,"rev","13/12/2013","20/12/2013","Todo correcto","ninguna"]);

tx.executeSql("INSERT INTO reclamaciones (codreclamacion, reclamacion, fchalta, descripcion, correccion, fchcierre, conforme, idcliente, estado) VALUES(?,?,?,?,?,?,?,?,?)",["RC-023","Producto mal estado","02/03/2013","El equipo ha llegado mojado","cambio del equipo","12/03/2012","El cliente está conforme",1,"Cerrada"]);
tx.executeSql("INSERT INTO estudios (estudio, fchinicio, fchfin, objetivos, estado, responsable, resultado, valoracion, pr1, pr2, pr3, pr4, pr5, pr6, pr7, pr8, pr9, pr10) VALUES(?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)",["Encuestas anuales","20/01/2013","31/01/2013","Aumentar la satisfacción de los clientes","Pendiente","Depto. Comercial",8.3,"Mejor que 2012","¿Pregunta 1?","¿Pregunta 2?","¿Pregunta 4?","¿Pregunta 3?","¿Pregunta 5?","¿Pregunta 6?","¿Pregunta 7?","¿Pregunta 8?","¿Pregunta 9?","¿Pregunta 10?"]);
tx.executeSql("INSERT INTO encuestas (idestudio, idcliente, estado, fchalta, eval1, eval2, eval3, eval4, eval5, eval6, eval7, eval8, eval9, eval10, resultado) VALUES(?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)",[1,1,"En proceso","12/02/2013",3,2,3,6,5,1,2,3,4,5,6.1]);

tx.executeSql("INSERT INTO clientes (cliente, codcliente, cif, direccion, tlf, fchalta, contacto, tlfcontacto, mailcontacto, obs) VALUES(?,?,?,?,?,?,?,?,?,?)",["Telefónica", "CLI-1", "A50324456","Moraleja 43","912002030","01/11/2012","Mariano Alierta","912003454", "malierta@telefonica.es","Sin observaciones"]);
tx.executeSql("INSERT INTO productos (producto, codproducto, descripcion, responsable, obs) VALUES(?,?,?,?,?)",["GPON Tester", "GPONT1", "Medidor de Redes GPON barato","Octavio Benedi","Sin observaciones"]);

tx.executeSql("INSERT INTO objetivos(objetivo, descripcion, responsable, recursos) VALUES(?,?,?,?)",["Optimización de la producción", "detalle...", "Emilio Lisbona", "Depto. Producción"]);
tx.executeSql("INSERT INTO acciones(accion, adescripcion, aresponsable, arecursos, fchinicio, fchfin, valorultrev, fchultrev, idobjetivo, color) VALUES(?,?,?,?,?,?,?,?,?,?)",["Analisis fuentes de consumo","Analizar principales fuentes de consumo", "Daniel Monreal", "Depto. Administración","05/18/2012", "09/10/2012", "13%", "01/08/2012", 1, "ganttRed"]);

tx.executeSql("INSERT INTO tareas(tarea, fchinicio, fchfin, descripcion, prioridad, trazabilidad) VALUES(?,?,?,?,?,?)",["TareaPrueba", "01/02/2013", "03/02/2013", "Descripcion de la tarea de prueba",0,""]);	
tx.executeSql("INSERT INTO apuntes(apunte, prioridad, idx) VALUES(?,?,?)",["Comprar pan", 2,"?x?"]);
tx.executeSql("INSERT INTO notas(nota) VALUES(?)",["Nota de prueba"]);
tx.executeSql("INSERT INTO requisitos(requisito, codrequisito, trazabilidad, referencia, link, fchinicio, vigente, revision, estado, obs) VALUES(?,?,?,?,?,?,?,?,?,?)",["Plazo de entrega una semana", "REQ-1", "C1", "LEY 3922", "c:/leyes/", "11/04/2012", "true", "1.1", "Identificada", "Sin observaciones"]);

//Tablas conectadas
//tx.executeSql("INSERT INTO auditorias(idtarea, alcance, estado, nncs, linkinforme, linkpac) VALUES(?,?,?,?,?,?)",[25, "ISO 9001", "Planificada", "0 NCs", "c:/informes/auditorias",  "c:/auditorias/PACs"]);
			
		});
		alert("Datos de ejemplo introducidos");}; 
		}
		
	
function limpiarTabla () {
	var tabla = prompt("¿nombre de tabla a limpiar?", "")
	var db = openDatabase("DBIW1", "0.1", "Database Isowin One", 5 * 1024 * 1024);
		if(db){db.transaction( function(tx) {tx.executeSql("DELETE FROM "+tabla);
			});};
			}
			
function limpiarTodasTabla () {
	//alert(tablas.length);
	
	var db = openDatabase("DBIW1", "0.1", "Database Isowin One", 5 * 1024 * 1024);
		if(db){db.transaction ( function(tx) {
			for(var i=0; i < tablas.length; i++) {
				tx.executeSql ("DELETE FROM "+tablas[i]);};
				}
			)};
		}
			
function eliminarTabla () {
	var tabla = prompt("¿nombre de tabla a eliminar?", "")
	var db = openDatabase("DBIW1", "0.1", "Database Isowin One", 5 * 1024 * 1024);
		if(db){db.transaction( function(tx) {tx.executeSql("DROP TABLE "+tabla);
			});};
			}
			
function eliminarTodasTabla () {
	//alert(tablas.length);
	
	var db = openDatabase("DBIW1", "0.1", "Database Isowin One", 5 * 1024 * 1024);
		if(db){db.transaction ( function(tx) {
			for(var i=0; i < tablas.length; i++) {
				tx.executeSql ("DROP TABLE "+tablas[i]);};
				}
			)};
		}
			
//__________________________________________________________________________________________			
			
function desplegarBD () {
	
	//CREACIÓN DE BD	
	crearBD();	
	
	//CREACIÓN DE PROCESOS
	var db;
        db = openDatabase("DBIW1", "0.1", "Database Isowin One", 5 * 1024 * 1024);
		if(db){	
		db.transaction( function(tx) {

tx.executeSql("INSERT INTO procesos(idproceso, proceso, mision, alcance, entradas, salidas, recursos, responsable, requisitos, controles, i1, i2, i3, i4) VALUES(?,?,?,?,?,?,?,?,?,?,?,?,?,?)",[1, "Control Documentación y Registros", "", "", "", "", "", "", "", "", "Indicador 1", "Indicador 2", "Indicador 3", "Indicador 4"]);
tx.executeSql("INSERT INTO procesos(idproceso, proceso, mision, alcance, entradas, salidas, recursos, responsable, requisitos, controles, i1, i2, i3, i4) VALUES(?,?,?,?,?,?,?,?,?,?,?,?,?,?)",[2, "Compras", "", "", "", "", "", "", "", "", "Indicador 1", "Indicador 2", "Indicador 3", "Indicador 4"]);
tx.executeSql("INSERT INTO procesos(idproceso, proceso, mision, alcance, entradas, salidas, recursos, responsable, requisitos, controles, i1, i2, i3, i4) VALUES(?,?,?,?,?,?,?,?,?,?,?,?,?,?)",[3, "Diseño", "", "", "", "", "", "", "", "", "Indicador 1", "Indicador 2", "Indicador 3", "Indicador 4"]);
tx.executeSql("INSERT INTO procesos(idproceso, proceso, mision, alcance, entradas, salidas, recursos, responsable, requisitos, controles, i1, i2, i3, i4) VALUES(?,?,?,?,?,?,?,?,?,?,?,?,?,?)",[4, "NC, AC/P y Auditorías", "", "", "", "", "", "", "", "", "Indicador 1", "Indicador 2", "Indicador 3", "Indicador 4"]);
tx.executeSql("INSERT INTO procesos(idproceso, proceso, mision, alcance, entradas, salidas, recursos, responsable, requisitos, controles, i1, i2, i3, i4) VALUES(?,?,?,?,?,?,?,?,?,?,?,?,?,?)",[5, "Satisfacción, reclamaciones y postventa", "", "", "", "", "", "", "", "", "Indicador 1", "Indicador 2", "Indicador 3", "Indicador 4"]);
tx.executeSql("INSERT INTO procesos(idproceso, proceso, mision, alcance, entradas, salidas, recursos, responsable, requisitos, controles, i1, i2, i3, i4) VALUES(?,?,?,?,?,?,?,?,?,?,?,?,?,?)",[6, "Ofertas y pedidos", "", "", "", "", "", "", "", "", "Indicador 1", "Indicador 2", "Indicador 3", "Indicador 4"]);
tx.executeSql("INSERT INTO procesos(idproceso, proceso, mision, alcance, entradas, salidas, recursos, responsable, requisitos, controles, i1, i2, i3, i4) VALUES(?,?,?,?,?,?,?,?,?,?,?,?,?,?)",[7, "Producción / Fabricación", "", "", "", "", "", "", "", "", "Indicador 1", "Indicador 2", "Indicador 3", "Indicador 4"]);
tx.executeSql("INSERT INTO procesos(idproceso, proceso, mision, alcance, entradas, salidas, recursos, responsable, requisitos, controles, i1, i2, i3, i4) VALUES(?,?,?,?,?,?,?,?,?,?,?,?,?,?)",[8, "Logística", "", "", "", "", "", "", "", "", "Indicador 1", "Indicador 2", "Indicador 3", "Indicador 4"]);
tx.executeSql("INSERT INTO procesos(idproceso, proceso, mision, alcance, entradas, salidas, recursos, responsable, requisitos, controles, i1, i2, i3, i4) VALUES(?,?,?,?,?,?,?,?,?,?,?,?,?,?)",[9, "Calibración y Mantenimiento", "", "", "", "", "", "", "", "", "Indicador 1", "Indicador 2", "Indicador 3", "Indicador 4"]);
tx.executeSql("INSERT INTO procesos(idproceso, proceso, mision, alcance, entradas, salidas, recursos, responsable, requisitos, controles, i1, i2, i3, i4) VALUES(?,?,?,?,?,?,?,?,?,?,?,?,?,?)",[10, "RR.HH. y Formación", "", "", "", "", "", "", "", "", "Indicador 1", "Indicador 2", "Indicador 3", "Indicador 4"]);
tx.executeSql("INSERT INTO procesos(idproceso, proceso, mision, alcance, entradas, salidas, recursos, responsable, requisitos, controles, i1, i2, i3, i4) VALUES(?,?,?,?,?,?,?,?,?,?,?,?,?,?)",[11, "Planificación y objetivos", "", "", "", "", "", "", "", "", "Objetivo 1", "Objetivo 2", "Objetivo 3", "Objetivo 4"]);

			});
			
		alert("Isowin One Desplegado");
			}
	  }

			