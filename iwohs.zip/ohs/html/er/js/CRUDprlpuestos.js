//REQUISITOS DE CLIENTE Y PRODUCTO (52 y 53)

	var idseleccionado52;
	var idseleccionado53;
	var idseleccionado52b;
	var nuevosclientes; //Listado de clientes para COMBOBOX
	var idseleccionado52c;
	var aseleccionado52c = [];
	var nuevosepis = "{0:'Please select...', 1:'hola', 2:'due', 3:'traix'}"; //Listado de epis para COMBOBOX
	var idseleccionado52x;
				
//TABLAS PRLPUESTOS_____________________________________________________________________________________________________________

function mostrarPRLPuestos() {
	sacarPRLPuestos ();
	setTimeout('listPRLPuestos();',500);
	}
	
//TABLA PRLPUESTOS _____________________________________________________________________________________________________________
function listPRLPuestos() {
		$(document).ready(			
			function () {
				$('#dynamic52').html( '<table cellpadding="0" cellspacing="0" border="0" class="display" id="example52"></table>' );
				$('#example52').dataTable( {
					"aaData": aDataSet52,
						
					"aoColumns": [
						{ "sTitle": "Id PRL Puesto"/*, "bSearchable": false, "bVisible": false*/ },
						{ "sTitle": "PRL Puesto" },
						{ "sTitle": "LAEQD" },
						{ "sTitle": "Pico"  },
						{ "sTitle": "Fecha Ruido"},
						{ "sTitle": "Luxes" },
						{ "sTitle": "Fecha Luz"},
						{ "sTitle": "Humedad"  },
						{ "sTitle": "Fecha Humedad"},
						{ "sTitle": "T Seca" },
						{ "sTitle": "T Humeda"  },
						{ "sTitle": "T Globo" },
						{ "sTitle": "WBGT" },
						{ "sTitle": "Fecha Temp."},
						{ "sTitle": "Vel. Aire"  },
						{ "sTitle": "Fecha Vel."},
						{ "sTitle": "Observaciones", "bSearchable": false, "bVisible": false}
						],
					
					"sScrollY": "600px",
					"bPaginate": false,
					"bScrollCollapse": true,
						
					"sDom": 'lfrtip<"clear spacer">T',
					/*"sDom": 'T<"clear">lfrtip<"clear spacer">T',*/ //Muestra los botones de copy,print...
					"oTableTools": {
						"sRowSelect": "single","aButtons": ["select"], //Solo me muestra el boton select para poder seleccionar las filas.
							
					"aoColumnDefs": [ {
						"sClass": "center",
						"aTargets": [ -1, -2 ]
						} ]
						
				}});

				sacarEPIs2 (); //Cargo el COMBOBOX de los EPIs


				});
	//Cargar datos del equipo para editar en formulario	
		$(document).ready(
			function() {
    			$('#example52 tbody td').click( function () {
				
        		/* Get the position of the current data from the node */
				var aPos52 = oTable52.fnGetPosition( this );
         
        		/* Get the data array for this row */
				var aData52 = oTable52.fnGetData( aPos52[0] );
				/*alert("Ok "+aData[0]);*/
				idseleccionado52 =  aData52[0];
				document.getElementById("txtpp").value = aData52[1];
				document.getElementById("txtpplaeqd").value = aData52[2];
				document.getElementById("txtpppico").value = aData52[3];
				document.getElementById("txtppfchr").value = aData52[4];
				document.getElementById("txtppluxes").value = aData52[5];
				document.getElementById("txtppfchl").value = aData52[6];
				document.getElementById("txtpph").value = aData52[7];
				document.getElementById("txtppfchh").value = aData52[8];
				document.getElementById("txtppts").value = aData52[9];
				document.getElementById("txtppth").value = aData52[10];
				document.getElementById("txtpptg").value = aData52[11];
				document.getElementById("txtppwbgt").value = aData52[12];
				document.getElementById("txtppfcht").value = aData52[13];
				document.getElementById("txtppvel").value = aData52[14];
				document.getElementById("txtppfchv").value = aData52[15];
				document.getElementById("txtppobs").value = aData52[16];
			
				
				
				//Visualizo la ER y los EPIs de este PRLPuesto
				DatosBDERs(idseleccionado52);
				datosBDEPIs (idseleccionado52);
				setTimeout('listERs(); listEPIs();',200);

				cargarChecksER (idseleccionado52);
				cargarChecksProtocolos (idseleccionado52);
				cargarChecksFormaciones (idseleccionado52);

				VnV52 (1, 0, 0, 1, 0);
				VnVEprlp (1);//No ver botones update y delete
				
				});
     
			/* Init DataTables */
			oTable52= $('#example52').dataTable();
			}
		);
		
	}
	
//DATOS PRLPUESTOS_________________________________________________

function sacarPRLPuestos (){
	var db;
        db = openDatabase("DBIWOHS", "0.1", "Database Isowin OHS", 5 * 1024 * 1024);	
		//alert ("Estoy dentro");					
	if(db){
		db.transaction( function(tx) {
			tx.executeSql("SELECT * FROM prlpuestos", [],
				function(tx, result){
					aDataSet52 = [];
					for(var i=0; i < result.rows.length; i++) {	
						aDataSet52.push([result.rows.item(i)['idprlpuesto'],
								result.rows.item(i)['prlpuesto'],
								result.rows.item(i)['laeqd'],
								result.rows.item(i)['pico'],
								result.rows.item(i)['fchr'],
								result.rows.item(i)['luxes'],
								result.rows.item(i)['fchl'],
								result.rows.item(i)['h'],
								result.rows.item(i)['fchh'],
								result.rows.item(i)['ts'],
								result.rows.item(i)['th'],
								result.rows.item(i)['tg'],
								result.rows.item(i)['wbgt'],
								result.rows.item(i)['fcht'],
								result.rows.item(i)['vel'],
								result.rows.item(i)['fchv'],
								result.rows.item(i)['obs']
								]);
					};			
				});
		});	
	};
}
	

//TABLA ERS_____________________________________________________________________________________________________________

function listERs() {
		$(document).ready(			
			function () {
				$('#dynamic52b').html( '<table cellpadding="0" cellspacing="0" border="0" class="display" id="example52b"></table>' );
				$('#example52b').dataTable( {
					"aaData": aDataSet52b,
					
					"aoColumns": [
						{ "sTitle": "Id", "sWidth": "10px" },
						{ "sTitle": "Eval. Riesgos" },
						{ "sTitle": "Fecha Evaluación", "sWidth": "30px" },
						{ "sTitle": "Vigente", "bSearchable": false, "bVisible": false },						
						{ "sTitle": "Estado", "sWidth": "30px" },
						{ "sTitle": "Tipo", "bSearchable": false, "bVisible": false },
						{ "sTitle": "Documento" },
						{ "sTitle": "FSname", "bSearchable": false, "bVisible": false },
						{ "sTitle": "FSlink", "bSearchable": false, "bVisible": false },
						{ "sTitle": "Cambios Prox.", "bSearchable": false, "bVisible": false },
						{ "sTitle": "Resultados", "bSearchable": false, "bVisible": false },
						{ "sTitle": "Observaciones", "bSearchable": false, "bVisible": false },
						{ "sTitle": "Id PRLPuesto", "bSearchable": false, "bVisible": false },
						{ "sTitle": "Id X", "bSearchable": false, "bVisible": false }
						],
						
					"sScrollY": "250px",
        			"bPaginate": false,
        			"bScrollCollapse": true,
						
					"sDom": 'lfrtip<"clear spacer">T',
					/*"sDom": 'T<"clear">lfrtip<"clear spacer">T',*/ //Muestra los botones de copy,print...
					"oTableTools": {
						"sRowSelect": "single","aButtons": ["select"], //Solo me muestra el boton select para poder seleccionar las filas.
							
					"aoColumnDefs": [ {
						"sClass": "center",
						"aTargets": [ -1, -2 ]
						} ]
						
				}});
				
				});
	//Cargar datos de la calibración para editar en formulario	
		$(document).ready(
		function() {
    			$('#example52b tbody td').click( function () {
			
        		/* Get the position of the current data from the node */
        		var aPos52b = oTable52b.fnGetPosition( this );
         
        		/* Get the data array for this row */
        		var aData52b = oTable52b.fnGetData( aPos52b[0] );
				/*alert("Ok "+aData[0]);*/
				//requisito, codrequisito, idcliente, referencia, link, fchinicio, vigente, revision, estado, obs
					
				idseleccionado52b =  aData52b[0];
				document.getElementById("txter").value = aData52b[1];
				document.getElementById("txterfcheval").value = aData52b[2];
				document.getElementById("comboervigente").value = aData52b[3];
				document.getElementById("comboerestado").value = aData52b[4];
				document.getElementById("comboertipo").value = aData52b[5];
				document.getElementById("txtercambiosprox").value = aData52b[9];
				document.getElementById("txterresult").value = aData52b[10];
				document.getElementById("txterobs").value = aData52b[11];
				//El IdPRLPuesto no lo saco. aData52b[12]
				//El IdX no lo saco. aData52b[13].

				//File System-----------------------------------------------------------
					if (aData52b[8]) {document.getElementById("FSER").innerHTML = "<a class='doc' href='"+aData52b[8]+"' target='_blank'>"+aData52b[7]+"</a> <img src='img/miniboton.jpg' style='vertical-align:middle' onclick='deleteFSER();' />"; 
							nombreFS=aData52b[7]; rutaFS=aData52b[8]}
					else {document.getElementById("FSER").innerHTML = "<input type='file' id='myER' />";};
				//----------------------------------------------------------------------
				
				VnV52 (1, 0, 1, 0, 0);
				VnVEer (1);//No ver botones update y delete
         
    			});
			
			//Cargo el COMBOBOX de responsables del formulario NCs------------
				setTimeout('$("#comboacpresp4").html(nuevosresponsables);',200);
				//--------------------------------------------------
     
   				 /* Init DataTables */
			oTable52b= $('#example52b').dataTable();
		});
		
	}

//DATOS ER FILTRADOS POR PRLPUESTO______________________________________________________________________
		
function DatosBDERs (idseleccionado) {
	
	var db;
        db = openDatabase("DBIWOHS", "0.1", "Database Isowin OHS", 5 * 1024 * 1024);
		if(db){	
		db.transaction( function(tx) {
			tx.executeSql("SELECT * FROM ers WHERE idprlpuesto=?", [idseleccionado],
				function(tx, result){
					aDataSet52b = [];
					for(var i=0; i < result.rows.length; i++) {

						var linknull = "";//File System
						if (result.rows.item(i)['fsname']) {linknull = result.rows.item(i)['fsname'];};

						aDataSet52b.push([result.rows.item(i)['ider'],
								result.rows.item(i)['er'],
								result.rows.item(i)['fcheval'],
								result.rows.item(i)['vigente'],
								result.rows.item(i)['estado'],
								result.rows.item(i)['tipo'],
								"<a href='"+result.rows.item(i)['fslink']+"' target='_blank'>"+linknull+"</a>",
								result.rows.item(i)['fsname'],
								result.rows.item(i)['fslink'],
								result.rows.item(i)['cambiosprox'],
								result.rows.item(i)['resultados'],
								result.rows.item(i)['obs'],
								result.rows.item(i)['idprlpuesto'],
								result.rows.item(i)['idx']
								]);
				}		
   				 /* Init DataTables */
   				 oTable52b = $('#example52b').dataTable();				
				 
				});
				
				
		});
		
	}}
	

//=========================================================================================================					
/*NUEVO PRLPUESTO*/
	
	function addPRLPuesto (prlpuesto, laeqd, pico, fchr, luxes, fchl, h, fchh, ts, th, tg, wbgt, fcht, vel, fchv, obs) {
		//alert("Inside");
		var db;
		db = openDatabase("DBIWOHS", "0.1", "Database Isowin OHS", 5 * 1024 * 1024);
		if(db){	
		  db.transaction( function(tx) {
			tx.executeSql("INSERT INTO prlpuestos (prlpuesto, laeqd, pico, fchr, luxes, fchl, h, fchh, ts, th, tg, wbgt, fcht, vel, fchv, obs) VALUES(?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)", [prlpuesto, laeqd, pico, fchr, luxes, fchl, h, fchh, ts, th, tg, wbgt, fcht, vel, fchv, obs]);	
		  });
		  
		  apprise('El PRL Puesto ha sido guardado');
		};
		addIdX (idseleccionado52, prlpuesto);
		setTimeout('mostrarPRLPuestos()',500);
		  VnV52(0, 1, 0, 0, 0);
	}
	
/*ACTUALIZAR PRLPUESTO*/
	function updatePRLPuesto (prlpuesto, laeqd, pico, fchr, luxes, fchl, h, fchh, ts, th, tg, wbgt, fcht, vel, fchv, obs) {
		
		var db;
        db = openDatabase("DBIWOHS", "0.1", "Database Isowin OHS", 5 * 1024 * 1024);
		if(db){	
		  db.transaction( function(tx) {
			tx.executeSql("UPDATE prlpuestos SET prlpuesto=?, laeqd=?, pico=?, fchr=?, luxes=?, fchl=?, h=?, fchh=?, ts=?, th=?, tg=?, wbgt=?, fcht=?, vel=?, fchv=?, obs=? WHERE idprlpuesto=?", [prlpuesto, laeqd, pico, fchr, luxes, fchl, h, fchh, ts, th, tg, wbgt, fcht, vel, fchv, obs, idseleccionado52]);
			tx.executeSql("DELETE FROM ersx WHERE idprlpuesto=?",[idseleccionado52]);	
		});
		addIdX (idseleccionado52, prlpuesto);	
		apprise('El PRL Puesto ha sido modificado');
		};
		setTimeout('mostrarPRLPuestos()',500);
	}					

/*BORRAR PRLPUESTO*/
	function removePRLPuesto() {
		apprise('¿Eliminar el PRL Puesto?', {'verify': true}, function(r) {
			if(r) {
				var db;
				db = openDatabase("DBIWOHS", "0.1", "Database Isowin OHS", 5 * 1024 * 1024);
				if(db){	
					db.transaction(function(tx) {
						tx.executeSql("DELETE FROM prlpuestos WHERE idprlpuesto=?",[idseleccionado52]);
						tx.executeSql("DELETE FROM ers WHERE idprlpuesto=?",[idseleccionado52]); //limpia las ERs asociadas a este PRL Puesto.
						tx.executeSql("DELETE FROM ersx WHERE idprlpuesto=?",[idseleccionado52]); //limpia las ERs asociadas a este PRL Puesto.
						apprise('El PRL Puesto ha sido borrado');

					});
				};
			};

		setTimeout('mostrarPRLPuestos()',500);
		 VnV52(0, 1, 0, 0, 0);
		});
	}

//=========================================================================================================					
/*IDX*/

	function addIdX (idprlpuesto, prlpuesto) {

	var txt1 = "Pendiente la evaluación de riesgos general del puesto: " + prlpuesto;
	var txt2 = "Pendiente la evaluación de ruido ambiental del puesto: " + prlpuesto;
	var txt3 = "Pendiente la evaluación de riesgo higiénico por gases, humos o vapores del puesto: " + prlpuesto;
	var txt4 = "Pendiente la evaluación de riesgos biológicos del puesto: " + prlpuesto;
	var txt5 = "Pendiente la evaluación de PVDs del puesto: " + prlpuesto;
	var txt6 = "Pendiente la evaluación de riesgos ergonómicos del puesto: " + prlpuesto;
	var txt7 = "Pendiente la evaluación de riesgos psicosociales del puesto: " + prlpuesto;
	var txt8 = "Pendiente la evaluación de riesgos por radiación del puesto: " + prlpuesto;
	
	if (document.getElementById('chk1').checked) {var idx1 = idprlpuesto + "x1"; };
	if (document.getElementById('chk2').checked) {var idx2 = idprlpuesto + "x2"; };
	if (document.getElementById('chk3').checked) {var idx3 = idprlpuesto + "x3"; };
	if (document.getElementById('chk4').checked) {var idx4 = idprlpuesto + "x4"; };
	if (document.getElementById('chk5').checked) {var idx5 = idprlpuesto + "x5"; };
	if (document.getElementById('chk6').checked) {var idx6 = idprlpuesto + "x6"; };
	if (document.getElementById('chk7').checked) {var idx7 = idprlpuesto + "x7"; };
	if (document.getElementById('chk8').checked) {var idx8 = idprlpuesto + "x8"; };	
	var db;
        db = openDatabase("DBIWOHS", "0.1", "Database Isowin OHS", 5 * 1024 * 1024);
		if(db){

	db.transaction(function(tx) {tx.executeSql("DELETE FROM ersx WHERE idprlpuesto=?",[idprlpuesto]);});
	db.transaction(function(tx) {tx.executeSql("DELETE FROM prlpuestoprotocolo WHERE idprlpuesto=?",[idprlpuesto]);});
	db.transaction(function(tx) {tx.executeSql("DELETE FROM prlpuestoformacion WHERE idprlpuesto=?",[idprlpuesto]);});
						
	if (document.getElementById('chk1').checked) {db.transaction( function(tx) {tx.executeSql("INSERT INTO ersx (idprlpuesto, idx, txt) VALUES(?,?,?)", [idprlpuesto,idx1,txt1]);});};
	if (document.getElementById('chk2').checked) {db.transaction( function(tx) {tx.executeSql("INSERT INTO ersx (idprlpuesto, idx, txt) VALUES(?,?,?)", [idprlpuesto,idx2,txt2]);});};
	if (document.getElementById('chk3').checked) {db.transaction( function(tx) {tx.executeSql("INSERT INTO ersx (idprlpuesto, idx, txt) VALUES(?,?,?)", [idprlpuesto,idx3,txt3]);});};
	if (document.getElementById('chk4').checked) {db.transaction( function(tx) {tx.executeSql("INSERT INTO ersx (idprlpuesto, idx, txt) VALUES(?,?,?)", [idprlpuesto,idx4,txt4]);});};
	if (document.getElementById('chk5').checked) {db.transaction( function(tx) {tx.executeSql("INSERT INTO ersx (idprlpuesto, idx, txt) VALUES(?,?,?)", [idprlpuesto,idx5,txt5]);});};
	if (document.getElementById('chk6').checked) {db.transaction( function(tx) {tx.executeSql("INSERT INTO ersx (idprlpuesto, idx, txt) VALUES(?,?,?)", [idprlpuesto,idx6,txt6]);});};
	if (document.getElementById('chk7').checked) {db.transaction( function(tx) {tx.executeSql("INSERT INTO ersx (idprlpuesto, idx, txt) VALUES(?,?,?)", [idprlpuesto,idx7,txt7]);});};
	if (document.getElementById('chk8').checked) {db.transaction( function(tx) {tx.executeSql("INSERT INTO ersx (idprlpuesto, idx, txt) VALUES(?,?,?)", [idprlpuesto,idx8,txt8]);});};		
			
	if (document.getElementById('chkp1').checked) {db.transaction( function(tx) {tx.executeSql("INSERT INTO prlpuestoprotocolo (idprlpuesto, idprotocolo) VALUES(?,?)", [idprlpuesto,1]);});};			
	if (document.getElementById('chkp2').checked) {db.transaction( function(tx) {tx.executeSql("INSERT INTO prlpuestoprotocolo (idprlpuesto, idprotocolo) VALUES(?,?)", [idprlpuesto,2]);});};			
	if (document.getElementById('chkp3').checked) {db.transaction( function(tx) {tx.executeSql("INSERT INTO prlpuestoprotocolo (idprlpuesto, idprotocolo) VALUES(?,?)", [idprlpuesto,3]);});};			
	if (document.getElementById('chkp4').checked) {db.transaction( function(tx) {tx.executeSql("INSERT INTO prlpuestoprotocolo (idprlpuesto, idprotocolo) VALUES(?,?)", [idprlpuesto,4]);});};			
	if (document.getElementById('chkp5').checked) {db.transaction( function(tx) {tx.executeSql("INSERT INTO prlpuestoprotocolo (idprlpuesto, idprotocolo) VALUES(?,?)", [idprlpuesto,5]);});};			
	if (document.getElementById('chkp6').checked) {db.transaction( function(tx) {tx.executeSql("INSERT INTO prlpuestoprotocolo (idprlpuesto, idprotocolo) VALUES(?,?)", [idprlpuesto,6]);});};			
	if (document.getElementById('chkp7').checked) {db.transaction( function(tx) {tx.executeSql("INSERT INTO prlpuestoprotocolo (idprlpuesto, idprotocolo) VALUES(?,?)", [idprlpuesto,7]);});};			
	if (document.getElementById('chkp8').checked) {db.transaction( function(tx) {tx.executeSql("INSERT INTO prlpuestoprotocolo (idprlpuesto, idprotocolo) VALUES(?,?)", [idprlpuesto,8]);});};			
	if (document.getElementById('chkp9').checked) {db.transaction( function(tx) {tx.executeSql("INSERT INTO prlpuestoprotocolo (idprlpuesto, idprotocolo) VALUES(?,?)", [idprlpuesto,9]);});};			
	if (document.getElementById('chkp10').checked) {db.transaction( function(tx) {tx.executeSql("INSERT INTO prlpuestoprotocolo (idprlpuesto, idprotocolo) VALUES(?,?)", [idprlpuesto,10]);});};			
	if (document.getElementById('chkp11').checked) {db.transaction( function(tx) {tx.executeSql("INSERT INTO prlpuestoprotocolo (idprlpuesto, idprotocolo) VALUES(?,?)", [idprlpuesto,11]);});};			
	if (document.getElementById('chkp12').checked) {db.transaction( function(tx) {tx.executeSql("INSERT INTO prlpuestoprotocolo (idprlpuesto, idprotocolo) VALUES(?,?)", [idprlpuesto,12]);});};			
	if (document.getElementById('chkp13').checked) {db.transaction( function(tx) {tx.executeSql("INSERT INTO prlpuestoprotocolo (idprlpuesto, idprotocolo) VALUES(?,?)", [idprlpuesto,13]);});};			
	if (document.getElementById('chkp14').checked) {db.transaction( function(tx) {tx.executeSql("INSERT INTO prlpuestoprotocolo (idprlpuesto, idprotocolo) VALUES(?,?)", [idprlpuesto,14]);});};			
	if (document.getElementById('chkp15').checked) {db.transaction( function(tx) {tx.executeSql("INSERT INTO prlpuestoprotocolo (idprlpuesto, idprotocolo) VALUES(?,?)", [idprlpuesto,15]);});};			
	if (document.getElementById('chkp16').checked) {db.transaction( function(tx) {tx.executeSql("INSERT INTO prlpuestoprotocolo (idprlpuesto, idprotocolo) VALUES(?,?)", [idprlpuesto,16]);});};	
			
	if (document.getElementById('chkf1').checked) {db.transaction( function(tx) {tx.executeSql("INSERT INTO prlpuestoformacion (idprlpuesto, idformacion) VALUES(?,?)", [idprlpuesto,1]);});};			
	if (document.getElementById('chkf2').checked) {db.transaction( function(tx) {tx.executeSql("INSERT INTO prlpuestoformacion (idprlpuesto, idformacion) VALUES(?,?)", [idprlpuesto,2]);});};			
	if (document.getElementById('chkf3').checked) {db.transaction( function(tx) {tx.executeSql("INSERT INTO prlpuestoformacion (idprlpuesto, idformacion) VALUES(?,?)", [idprlpuesto,3]);});};			
	if (document.getElementById('chkf4').checked) {db.transaction( function(tx) {tx.executeSql("INSERT INTO prlpuestoformacion (idprlpuesto, idformacion) VALUES(?,?)", [idprlpuesto,4]);});};			
	if (document.getElementById('chkf5').checked) {db.transaction( function(tx) {tx.executeSql("INSERT INTO prlpuestoformacion (idprlpuesto, idformacion) VALUES(?,?)", [idprlpuesto,5]);});};			
	if (document.getElementById('chkf6').checked) {db.transaction( function(tx) {tx.executeSql("INSERT INTO prlpuestoformacion (idprlpuesto, idformacion) VALUES(?,?)", [idprlpuesto,6]);});};			
	if (document.getElementById('chkf7').checked) {db.transaction( function(tx) {tx.executeSql("INSERT INTO prlpuestoformacion (idprlpuesto, idformacion) VALUES(?,?)", [idprlpuesto,7]);});};			
	if (document.getElementById('chkf8').checked) {db.transaction( function(tx) {tx.executeSql("INSERT INTO prlpuestoformacion (idprlpuesto, idformacion) VALUES(?,?)", [idprlpuesto,8]);});};			
	if (document.getElementById('chkf9').checked) {db.transaction( function(tx) {tx.executeSql("INSERT INTO prlpuestoformacion (idprlpuesto, idformacion) VALUES(?,?)", [idprlpuesto,9]);});};			
	if (document.getElementById('chkf10').checked) {db.transaction( function(tx) {tx.executeSql("INSERT INTO prlpuestoformacion (idprlpuesto, idformacion) VALUES(?,?)", [idprlpuesto,10]);});};			
	if (document.getElementById('chkf11').checked) {db.transaction( function(tx) {tx.executeSql("INSERT INTO prlpuestoformacion (idprlpuesto, idformacion) VALUES(?,?)", [idprlpuesto,11]);});};			
	if (document.getElementById('chkf12').checked) {db.transaction( function(tx) {tx.executeSql("INSERT INTO prlpuestoformacion (idprlpuesto, idformacion) VALUES(?,?)", [idprlpuesto,12]);});};			
		};
	}

	function cargarChecksER (idprlpuesto) {

		document.getElementById('chk1').checked=0; document.getElementById('chk2').checked=0;
		document.getElementById('chk3').checked=0; document.getElementById('chk4').checked=0;
		document.getElementById('chk5').checked=0; document.getElementById('chk6').checked=0;
		document.getElementById('chk7').checked=0; document.getElementById('chk8').checked=0;

		var db;
        db = openDatabase("DBIWOHS", "0.1", "Database Isowin OHS", 5 * 1024 * 1024);
		if(db){	
		db.transaction( function(tx) {
			tx.executeSql("SELECT * FROM ersx WHERE idprlpuesto=?", [idprlpuesto],
				function(tx, result){
					for(var i=0; i < result.rows.length; i++) {
						if (result.rows.item(i)['idx']==(idprlpuesto+"x1")){document.getElementById('chk1').checked=1; i++;};
						if (result.rows.item(i)['idx']==(idprlpuesto+"x2")){document.getElementById('chk2').checked=1; i++;};
						if (result.rows.item(i)['idx']==(idprlpuesto+"x3")){document.getElementById('chk3').checked=1; i++;};
						if (result.rows.item(i)['idx']==(idprlpuesto+"x4")){document.getElementById('chk4').checked=1; i++;};
						if (result.rows.item(i)['idx']==(idprlpuesto+"x5")){document.getElementById('chk5').checked=1; i++;};
						if (result.rows.item(i)['idx']==(idprlpuesto+"x6")){document.getElementById('chk6').checked=1; i++;};
						if (result.rows.item(i)['idx']==(idprlpuesto+"x7")){document.getElementById('chk7').checked=1; i++;};
						if (result.rows.item(i)['idx']==(idprlpuesto+"x8")){document.getElementById('chk8').checked=1; i++;};
					}		
				});	
		});	
	}}

	function cargarChecksProtocolos (idprlpuesto) {

		document.getElementById('chkp1').checked=0; document.getElementById('chkp2').checked=0;
		document.getElementById('chkp3').checked=0; document.getElementById('chkp4').checked=0;
		document.getElementById('chkp5').checked=0; document.getElementById('chkp6').checked=0;
		document.getElementById('chkp7').checked=0; document.getElementById('chkp8').checked=0;
		document.getElementById('chkp9').checked=0; document.getElementById('chkp10').checked=0;
		document.getElementById('chkp11').checked=0; document.getElementById('chkp12').checked=0;
		document.getElementById('chkp13').checked=0; document.getElementById('chkp14').checked=0;
		document.getElementById('chkp15').checked=0; document.getElementById('chkp16').checked=0;

		var db;
        db = openDatabase("DBIWOHS", "0.1", "Database Isowin OHS", 5 * 1024 * 1024);
		if(db){	
		db.transaction( function(tx) {
			tx.executeSql("SELECT * FROM prlpuestoprotocolo WHERE idprlpuesto=?", [idprlpuesto],
				function(tx, result){
					for(var i=0; i < result.rows.length; i++) {
						if (result.rows.item(i)['idprotocolo']==1){document.getElementById('chkp1').checked=1; i++;};
						if (result.rows.item(i)['idprotocolo']==2){document.getElementById('chkp2').checked=1; i++;};
						if (result.rows.item(i)['idprotocolo']==3){document.getElementById('chkp3').checked=1; i++;};
						if (result.rows.item(i)['idprotocolo']==4){document.getElementById('chkp4').checked=1; i++;};
						if (result.rows.item(i)['idprotocolo']==5){document.getElementById('chkp5').checked=1; i++;};
						if (result.rows.item(i)['idprotocolo']==6){document.getElementById('chkp6').checked=1; i++;};
						if (result.rows.item(i)['idprotocolo']==7){document.getElementById('chkp7').checked=1; i++;};
						if (result.rows.item(i)['idprotocolo']==8){document.getElementById('chkp8').checked=1; i++;};
						if (result.rows.item(i)['idprotocolo']==9){document.getElementById('chkp9').checked=1; i++;};
						if (result.rows.item(i)['idprotocolo']==10){document.getElementById('chkp10').checked=1; i++;};
						if (result.rows.item(i)['idprotocolo']==11){document.getElementById('chkp11').checked=1; i++;};
						if (result.rows.item(i)['idprotocolo']==12){document.getElementById('chkp12').checked=1; i++;};
						if (result.rows.item(i)['idprotocolo']==13){document.getElementById('chkp13').checked=1; i++;};
						if (result.rows.item(i)['idprotocolo']==14){document.getElementById('chkp14').checked=1; i++;};
						if (result.rows.item(i)['idprotocolo']==15){document.getElementById('chkp15').checked=1; i++;};
						if (result.rows.item(i)['idprotocolo']==16){document.getElementById('chkp16').checked=1; i++;};

					}		
				});	
		});	
	}}

	function cargarChecksFormaciones (idprlpuesto) {

		document.getElementById('chkf1').checked=0; document.getElementById('chkf2').checked=0;
		document.getElementById('chkf3').checked=0; document.getElementById('chkf4').checked=0;
		document.getElementById('chkf5').checked=0; document.getElementById('chkf6').checked=0;
		document.getElementById('chkf7').checked=0; document.getElementById('chkf8').checked=0;
		document.getElementById('chkf9').checked=0; document.getElementById('chkf10').checked=0;
		document.getElementById('chkf11').checked=0; document.getElementById('chkf12').checked=0;

		var db;
        db = openDatabase("DBIWOHS", "0.1", "Database Isowin OHS", 5 * 1024 * 1024);
		if(db){	
		db.transaction( function(tx) {
			tx.executeSql("SELECT * FROM prlpuestoformacion WHERE idprlpuesto=?", [idprlpuesto],
				function(tx, result){
					for(var i=0; i < result.rows.length; i++) {
						if (result.rows.item(i)['idformacion']==1){document.getElementById('chkf1').checked=1; i++;};
						if (result.rows.item(i)['idformacion']==2){document.getElementById('chkf2').checked=1; i++;};
						if (result.rows.item(i)['idformacion']==3){document.getElementById('chkf3').checked=1; i++;};
						if (result.rows.item(i)['idformacion']==4){document.getElementById('chkf4').checked=1; i++;};
						if (result.rows.item(i)['idformacion']==5){document.getElementById('chkf5').checked=1; i++;};
						if (result.rows.item(i)['idformacion']==6){document.getElementById('chkf6').checked=1; i++;};
						if (result.rows.item(i)['idformacion']==7){document.getElementById('chkf7').checked=1; i++;};
						if (result.rows.item(i)['idformacion']==8){document.getElementById('chkf8').checked=1; i++;};
						if (result.rows.item(i)['idformacion']==9){document.getElementById('chkf9').checked=1; i++;};
						if (result.rows.item(i)['idformacion']==10){document.getElementById('chkf10').checked=1; i++;};
						if (result.rows.item(i)['idformacion']==11){document.getElementById('chkf11').checked=1; i++;};
						if (result.rows.item(i)['idformacion']==12){document.getElementById('chkf12').checked=1; i++;};

					}		
				});	
		});	
	}}
		
//=========================================================================================================					
//=========================================================================================================	
//=========================================================================================================					
//=========================================================================================================	

	
function mostrarERs() {
	DatosBDERs (idseleccionado52);
	setTimeout('listERs()',500);
	}
	
/*NUEVO ER*/
	function addER (er, fcheval, vigente, estado, tipo, cambiosprox, resultados, obs) {
		var idx = idseleccionado52+"x"+tipo;//Código X
		var db;
		FSError = false; nombreFS=null; rutaFS=null;//FileSystem 
		addFile("myER");//FileSystem
		db = openDatabase("DBIWOHS", "0.1", "Database Isowin OHS", 5 * 1024 * 1024);
		if(db){	
		  db.transaction( function(tx) {
			tx.executeSql("INSERT INTO ers (er, fcheval, vigente, estado, tipo, cambiosprox, resultados, obs, idprlpuesto, idx) VALUES(?,?,?,?,?,?,?,?,?,?)", [er, fcheval, vigente, estado, tipo, cambiosprox, resultados, obs, idseleccionado52, idx]);
			tx.executeSql("SELECT * FROM ers ORDER BY ider DESC", [], function(tx, result){
				idseleccionado52b = result.rows.item(0)["ider"];
				if (!FSError) {apprise('La evaluación de riesgos ha sido guardada');};
			});
		})};
		setTimeout('updateFSERs()',200);
		setTimeout('mostrarERs()',400);
		VnV52 (1, 0, 0, 1, 0);
	}
	
/*ACTUALIZO ER*/
		function updateER (er, fcheval, vigente, estado, tipo, cambiosprox, resultados, obs) {
		var idx = idseleccionado52+"x"+tipo;//Código X
		var db;
		FSError = false; nombreFS=null; rutaFS=null;//FileSystem 
		addFile("myER");//FileSystem
		db = openDatabase("DBIWOHS", "0.1", "Database Isowin OHS", 5 * 1024 * 1024);
		if(db){	
		  db.transaction( function(tx) {
			tx.executeSql("UPDATE ers SET er=?, fcheval=?, vigente=?, estado=?, tipo=?, cambiosprox=?, resultados=?, obs=?, idprlpuesto=?, idx=? WHERE ider=?", [er, fcheval, vigente, estado, tipo, cambiosprox, resultados, obs, idseleccionado52, idx, idseleccionado52b]);
			if (!FSError) {apprise('La evaluación de riesgos ha sido modificada');};
		})};
		setTimeout('updateFSERs()',200);
		setTimeout('mostrarERs()',400);
		VnV52 (1, 0, 0, 1, 0);
	}

/*ACTUALIZAR ARCHIVOS*/
function updateFSERs() {
var db;
db = openDatabase("DBIWOHS", "0.1", "Database Isowin OHS", 5 * 1024 * 1024);
		if(db){	
		db.transaction( function(tx) {
			if (nombreFS!=null) {tx.executeSql("UPDATE ers SET fsname=?, fslink=? WHERE ider=?", [nombreFS, rutaFS, idseleccionado52b]);
								document.getElementById("FSER").innerHTML = "<a class='doc' href='"+rutaFS+"' target='_blank'>"+nombreFS+"</a> <img src='img/miniboton.jpg' style='vertical-align:middle' onclick='deleteFSER();' />";};
			});
		};
}					

/*BORRO ER */
	function removeER () {
		apprise('¿Eliminar la evaluación de riesgos?', {'verify': true}, function(r) {
			if(r) {
			var db;
			deleteFile();//FileSystem
			db = openDatabase("DBIWOHS", "0.1", "Database Isowin OHS", 5 * 1024 * 1024);
			if(db){	
				db.transaction(function(tx) {
					tx.executeSql("DELETE FROM ers WHERE ider=?",[idseleccionado52b]);
					if (!FSError) {apprise('La evaluación de riesgos ha sido borrada');};
				})};};
				
				mostrarERs();
				VnV52 (1, 0, 0, 1, 0);
		});
	}

	/*BORRAR ARCHIVOS*/
	function deleteFSER() {
		deleteLinkFile('ers');
		document.getElementById("FSER").innerHTML = "<input type='file' id='myER' />";
		setTimeout('mostrarERs();',500);
	}
	
//=========================================================================================================					
/*NUEVA APC52*/
	function addACP52 (acp, codacp, tipo, fchalta, responsable, equipo, acciones, fchprevista) {

		var codtrz = "pp"+idseleccionado52;
		addMiniACP(acp, codacp, tipo, origen, fchalta, responsable, equipo, acciones, fchprevista, codtrz);
	}
	
	
//=========================================================================================================
/* VER NO VER*/
var verNCL= 0; var verLCL= 1; var verNRCL= 0; var verLRCL= 0; var verNAC4= 0;

function VnV52 (Vncl, Vlcl, Vnrcl, Vlrcl, Vnac4) { 
	if (verNCL!=Vncl) {$("#newprlpuesto").toggle(200); verNCL=Vncl; $("#txtcl").focus();};
	if (verLCL!=Vlcl) {$("#listaprlpuestos").toggle(200); verLCL=Vlcl;};
	if (verNRCL!=Vnrcl) {$("#newer").toggle(200); verNRCL=Vnrcl; $("#txtrcl").focus();};
	if (verLRCL!=Vlrcl) {$("#listaers").toggle(200); verLRCL=Vlrcl;};
	if (verNAC4!=Vnac4) {$("#newacp4").toggle(200); verNAC4=Vnac4; $("#txtacp4").focus();};
}

/* VER NO VER EDIT (Update+Delete)*/
var verEER=0;var verEPRLP=0;
function VnVEer (Veer) {if (verEER!=Veer) {$("#editer").toggle(200); verEER=Veer;};}
function VnVEprlp (Veprlp) {if (verEPRLP!=Veprlp) {$("#editprlp").toggle(200); verEPRLP=Veprlp;};}

//=========================================================================================================
//=========================================================================================================
//=========================================================================================================
				
//TABLA EPIS ____________________________________________________________________________________________________

function listEPIs() {
//alert("Dentroo");	
		$(document).ready( function () {
				$('#dynamic52c').html( '<table cellpadding="0" cellspacing="0" border="0" class="display" id="example52c"></table>' );
				$('#example52c').dataTable( {
					"aaData": aDataSet52c,	
					"aoColumns": [
						{ "sTitle": "Id PRLpEPI", "bSearchable": false, "bVisible": false },
						{"sTitle": "EPI"},{"sTitle": "Uso"}],
					"sDom": 'frtip',
					//lfrtip<"clear spacer">T
					"oTableTools": {
						/*"sRowSelect": "single","aButtons": ["select"],*///Solo me muestra el boton select para poder seleccionar las filas.
						"aoColumnDefs": [ {"sClass": "center","aTargets": [ -1, -2 ]}]
					},
				"bSort": false,
				})
				
				//EDITAR DIRECTAMENTE LAS TABLAS
				.makeEditable ({
                    		"aoColumns": [
                    {event: 'click', indicator: 'Saving CSS Grade...', tooltip: 'Click to select CSS Grade', loadtext: 'loading...',
						type: 'select', onblur: 'submit', data: nuevosepis,
						sUpdateURL: function(value, settings){updatePRLPuestoEPI (value); return value;}
					},
					{onblur: 'submit',
						sUpdateURL: function(value, settings){updatePRLPuestoEPI (); return value;}
					}                  ]									

				});
				
			});
			
		//Obtengo el ID de la fila que estoy editando	
		$(document).ready( function() {
    			$('#example52c tbody td').click( function () {
				var aPos52c = oTable52c.fnGetPosition( this );
				var aData52c = oTable52c.fnGetData( aPos52c[0] );
				idseleccionado52c =  aData52c[0];
				aseleccionado52c = aData52c;
			});
			oTable52c= $('#example52c').dataTable();
			
		});		
			
	} 
	
		
function datosBDEPIs (idseleccionado){
	//alert("inside");
	var db;
        db = openDatabase("DBIWOHS", "0.1", "Database Isowin OHS", 5 * 1024 * 1024);	
	if(db){
		db.transaction( function(tx) {
			tx.executeSql("SELECT * FROM prlpuestoepi LEFT JOIN epis ON prlpuestoepi.idepi=epis.idepi  WHERE idprlpuesto=?", [idseleccionado],//
				function(tx, result){
					//Creo un array
					/*var output = [];*/
					//Guardo en cada elemento i del vector, un objeto documento.
					aDataSet52c = [];
					for(var i=0; i < result.rows.length; i++) {	
						aDataSet52c.push([
								result.rows.item(i)['id'],
								result.rows.item(i)['epi'],
								result.rows.item(i)['uso']
								]);
					};			
				 
			});
		});
		
		
	};
}
//=========================================================================================================					
//=========================================================================================================					

function mostrarEPIs() {
	datosBDEPIs (idseleccionado52);
	setTimeout('listEPIs()',500);
	}

//=========================================================================================================					
/*CREAR NUEVO CONTROL*/
	function addPRLPuestoEPI() {
	//alert("Inside!");	
	
	//Primera opcion
		//$('#example25').dataTable().fnAddData([,"nuevo",,,,,,,,]); 
	
	//Segunda opción
		var db;
		db = openDatabase("DBIWOHS", "0.1", "Database Isowin OHS", 5 * 1024 * 1024);
		if(db){ db.transaction( function(tx) {
			tx.executeSql("INSERT INTO prlpuestoepi (idprlpuesto, idepi, uso) VALUES(?,?,?)", [idseleccionado52,,""]);
			});
			setTimeout('mostrarEPIs();',500);
			apprise('Haz doble click sobre los campos para introducir la información'); 
	};
	}

/*ACTUALIZAR CONTROL*/
	function updatePRLPuestoEPI (value) {
		//alert("dentrode: " + aseleccionado25[2]);
	var db;
        db = openDatabase("DBIWOHS", "0.1", "Database Isowin OHS", 5 * 1024 * 1024);
		if(db){ db.transaction( function(tx) {
			if (value) {tx.executeSql("UPDATE prlpuestoepi SET idepi=? WHERE id=? ", [value, idseleccionado52c])}
			else{tx.executeSql("UPDATE prlpuestoepi SET uso=? WHERE id=? ", [aseleccionado52c[2], idseleccionado52c])};
			apprise('EPI actualizado'); //alert("Estudio ha cambiado: "+ estudio + " - " + idseleccionado18);
		});
	};
		//alert("Guardado");
		//setTimeout('mostrarEstudios()',500);
	}
	
/*BORRAR CONTROL*/
	function removePRLPuestoEPI() {
		if(idseleccionado52c) { 
		apprise('¿Eliminar EPI asignado?', {'verify': true}, function(r) {
			if(r) { 
				var db;
				db = openDatabase("DBIWOHS", "0.1", "Database Isowin OHS", 5 * 1024 * 1024);
				if(db){	
					db.transaction(function(tx) {
					tx.executeSql("DELETE FROM prlpuestoepi WHERE id=?",[idseleccionado52c]);
					apprise('EPI borrado'); //alert("Persona borrada: "+ idseleccionado15);
					});
				};
				setTimeout('mostrarEPIs()',500);
			}
		});
		};
	}

//=========================================================================================================					
/*COMBOBOX DE RESPONSABLES*/

function sacarEPIs2 (){
	var db;
    db = openDatabase("DBIWOHS", "0.1", "Database Isowin OHS", 5 * 1024 * 1024);					
	if(db){
		db.transaction( function(tx) {
			tx.executeSql("SELECT * FROM epis", [], function(tx, result){
				nuevosepis = "{0:'' ";
				for(var i=0; i < result.rows.length; i++) {nuevosepis = nuevosepis +", " + parseInt(result.rows.item(i)['idepi']) + ":'" + result.rows.item(i)['epi'] + "' ";};
				nuevosepis = nuevosepis + "}";
			});
		});	
	};
	//setTimeout('alert(nuevosepis);', 500);
}

//=========================================================================================================					

//TABLA ERS X_____________________________________________________________________________________________________________

function mostrarERsX() {
	DatosBDERsX ();
	setTimeout('listERsX()',500);
	}

function listERsX() {
		$(document).ready(			
			function () {
				$('#dynamic52x').html( '<table cellpadding="0" cellspacing="0" border="0" class="display" id="example52x"></table>' );
				$('#example52x').dataTable( {
					"aaData": aDataSet52x,
					
					"aoColumns": [
						{ "sTitle": "Id"/*, "bSearchable": false, "bVisible": false*/ },
						{ "sTitle": "Eval. Riesgos" },
						{ "sTitle": "Fecha Evaluación" },
						{ "sTitle": "Vigente", "bSearchable": false, "bVisible": false },						
						{ "sTitle": "Estado" },
						{ "sTitle": "Tipo", "bSearchable": false, "bVisible": false },
						{ "sTitle": "link", "bSearchable": false, "bVisible": false },
						{ "sTitle": "Cambios Prox.", "bSearchable": false, "bVisible": false },
						{ "sTitle": "Resultados", "bSearchable": false, "bVisible": false },
						{ "sTitle": "Observaciones", "bSearchable": false, "bVisible": false },
						{ "sTitle": "Id PRLPuesto", "bSearchable": false, "bVisible": false },
						{ "sTitle": "Id X" },
						{ "sTitle": "Txt" }
						],
						
					"sScrollY": "250px",
        			"bPaginate": false,
        			"bScrollCollapse": true,
						
					"sDom": 'lfrtip<"clear spacer">T',
					/*"sDom": 'T<"clear">lfrtip<"clear spacer">T',*/ //Muestra los botones de copy,print...
					"oTableTools": {
						"sRowSelect": "single","aButtons": ["select"], //Solo me muestra el boton select para poder seleccionar las filas.
							
					"aoColumnDefs": [ {
						"sClass": "center",
						"aTargets": [ -1, -2 ]
						} ]			
				}});
				});	
	}

//DATOS ER FILTRADOS POR PRLPUESTO______________________________________________________________________
		
function DatosBDERsX () {
	
	var db;
        db = openDatabase("DBIWOHS", "0.1", "Database Isowin OHS", 5 * 1024 * 1024);
		if(db){	
		db.transaction( function(tx) {
			tx.executeSql("SELECT * FROM ersx LEFT JOIN ers ON ersx.idx=ers.idx WHERE ers.ider is null ", [],
				function(tx, result){
					aDataSet52x = [];
					for(var i=0; i < result.rows.length; i++) {
						aDataSet52x.push([result.rows.item(i)['ider'],
								result.rows.item(i)['er'],
								result.rows.item(i)['fcheval'],
								result.rows.item(i)['vigente'],
								result.rows.item(i)['estado'],
								result.rows.item(i)['tipo'],
								result.rows.item(i)['link'],
								result.rows.item(i)['cambiosprox'],
								result.rows.item(i)['resultados'],
								result.rows.item(i)['obs'],
								result.rows.item(i)['idprlpuesto'],
								result.rows.item(i)['idx'],
								result.rows.item(i)['txt']
								]);
				}

				/* Init DataTables */
   				 oTable52x = $('#example52x').dataTable();				
				 
				});
				
				
		});
		
	}}
	
