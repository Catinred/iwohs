//PERSONAS (15)

	var idseleccionado15;
	var intEstado15;
	var INTcolor15 = 0; //Color del semaforo en verde
				
	
//TABLA PERSONAS (15)_____________________________________________________________________________________________________________

function mostrarPersonas(intEst15) {
	intEstado15=intEst15;
	sacarPersonas (intEstado15);
	setTimeout('listPersonas()',500);
	Vb15(intEst15);
	}

function listPersonas() {
		$(document).ready(			
			function () {
				$('#dynamic15').html( '<table cellpadding="0" cellspacing="0" border="0" class="display" id="example15"></table>' );
				$('#example15').dataTable( {
					"aaData": aDataSet15,
						
					"aoColumns": [
						{ "sTitle": "Id"/*, "bSearchable": false, "bVisible": false*/ },
						{ "sTitle": "Nombre" },
						{ "sTitle": "Apelllidos" },
						{ "sTitle": "dni" },
						{ "sTitle": "Fecha Nacimiento" },
						{ "sTitle": "Fecha de Alta", "bSearchable": false, "bVisible": false },
						{ "sTitle": "Fecha de Baja", "bSearchable": false, "bVisible": false },
						{ "sTitle": "Link CV", "bSearchable": false, "bVisible": false},
						{ "sTitle": "Puesto de Trabajo", "bSearchable": false, "bVisible": false },
						{ "sTitle": "Es Responsable", "bSearchable": false, "bVisible": false }
						],
						
					"sScrollY": "600px",
        			"bPaginate": false,
        			"bScrollCollapse": true,
						
					"sDom": 'lfrtip<"clear spacer">T',
					/*"sDom": 'T<"clear">lfrtip<"clear spacer">T',*/ //Muestra los botones de copy,print...
					"oTableTools": {
						"sRowSelect": "single","aButtons": ["select"], //Solo me muestra el boton select para poder seleccionar las filas.
							
					"aoColumnDefs": [ {
						"sClass": "center",
						"aTargets": [ -1, -2 ]
						} ]
						
				}});
				
			}
		);
			
	//Cargar datos del equipo para editar en formulario	
		$(document).ready(
			function() {
    			$('#example15 tbody td').click( function () {
        		/* Get the position of the current data from the node */
        		var aPos15 = oTable15.fnGetPosition( this );
         
        		/* Get the data array for this row */
        		var aData15 = oTable15.fnGetData( aPos15[0] );
				/*alert("Ok "+aData[0]);*/
				
				idseleccionado15 =  aData15[0];
				document.getElementById("txtpnombre").value = aData15[1];
				document.getElementById("txtpapellidos").value = aData15[2];
				document.getElementById("txtpdni").value = aData15[3];
				document.getElementById("txtpfchnac").value = aData15[4];
				document.getElementById("txtpfchalta").value = aData15[5];
				document.getElementById("txtpfchbaja").value = aData15[6];
				document.getElementById("txtplinkcv").value = aData15[7];
				document.getElementById("comboidpuesto").value = parseInt(aData15[8]);
				document.getElementById("comboesresp").value = aData15[9];
				
			
			DatosBDCursosPersona (idseleccionado15);
			setTimeout(' listCursosPersona()',200);				
			
			VnV15 (0, 0, 1, 1);
         
    			});
     
			/* Init DataTables */
			oTable15= $('#example15').dataTable();
			});
		
	}

function sacarPersonas (intEstado15){
	var db;
        db = openDatabase("DBIW1", "0.1", "Database Isowin One", 200000);	
		//alert ("Estoy dentro");					
	var estado15="WHERE fchbaja='' ";
	if (intEstado15==1) {estado15="WHERE fchbaja!='' ";};
	if(db){
		db.transaction( function(tx) {
			tx.executeSql("SELECT * FROM personas " + estado15, [],
				function(tx, result){
					aDataSet15 = [];
					for(var i=0; i < result.rows.length; i++) {	
						aDataSet15.push([result.rows.item(i)['idpersona'],
								result.rows.item(i)['nombre'],
								result.rows.item(i)['apellidos'],
								result.rows.item(i)['dni'],
								result.rows.item(i)['fchnac'],
								result.rows.item(i)['fchalta'],
								result.rows.item(i)['fchbaja'],
								result.rows.item(i)['linkcv'],
								result.rows.item(i)['idpuesto'],
								result.rows.item(i)['esresp'],
								]);
					}			
				});
		});	
	};
}
	
//TABLA CURSOS REALIZADOS POR TRABAJADOR__________________________________________________________________________________________

function listCursosPersona() {
		$(document).ready(			
			function () {
				$('#dynamic15b').html( '<table cellpadding="0" cellspacing="0" border="0" class="display" id="example15b"></table>' );
				$('#example15b').dataTable( {
					"aaData": aDataSet15b,
						
					"aoColumns": [
						{ "sTitle": "Id"/*, "bSearchable": false, "bVisible": false*/ },
						{ "sTitle": "Codigo Curso", "bSearchable": false, "bVisible": false },
						{ "sTitle": "Curso" },
						{ "sTitle": "Estado" },
						{ "sTitle": "Fecha inicio", "bSearchable": false, "bVisible": false },
						{ "sTitle": "Fecha fin", "bSearchable": false, "bVisible": false },
						{ "sTitle": "Horas", "bSearchable": false, "bVisible": false },
						],
						
					"sScrollY": "250px",
					"bPaginate": false,
					"bScrollCollapse": true,
						
					"oTableTools": {
							
					"aoColumnDefs": [{
						"sClass": "center",
						"aTargets": [ -1, -2 ]
						}]		
					}
				});
				
			}
		);
		
	}

//DATOS DE CURSOS REALIZADOS POR TRABAJADOR______________________________________________________________________
		
function DatosBDCursosPersona (idseleccionado15) {
	var db;
        db = openDatabase("DBIW1", "0.1", "Database Isowin One", 200000);
		if(db){	
		db.transaction( function(tx) {
			tx.executeSql("SELECT * FROM cursos JOIN cursospersonas ON cursos.idcurso=cursospersonas.idcurso WHERE idpersona=?", [idseleccionado15],
				function(tx, result){
					aDataSet15b = [];
					for(var i=0; i < result.rows.length; i++) {		
						aDataSet15b.push([result.rows.item(i)['idcurso'],
								result.rows.item(i)['codcurso'],
								result.rows.item(i)['curso'],
								result.rows.item(i)['estado'],
								result.rows.item(i)['fchinicio'],
								result.rows.item(i)['fchfin'],
								result.rows.item(i)['nhoras']
							]); 
						//alert(result.rows.item(i)['curso']);
						//alert(result.rows.length);
					};	
					//oTable15b = $('#example15b').dataTable();	
				});	
			});
		}; 
	}

	

//=========================================================================================================					
/*NUEVA PERSONA*/
	
	function addPersona (nombre, apellidos, dni, fchnac, fchalta, fchbaja, linkcv, idpuesto, esresp) {

		var db;
		db = openDatabase("DBIW1", "0.1", "Database Isowin One", 200000);
		if(db){	
		  db.transaction( function(tx) {
			tx.executeSql("INSERT INTO personas (nombre, apellidos, dni, fchnac, fchalta, fchbaja, linkcv, idpuesto, esresp) VALUES(?,?,?,?,?,?,?,?,?)", [nombre, apellidos, dni, fchnac, fchalta, fchbaja, linkcv, idpuesto, esresp]);
			tx.executeSql("SELECT * FROM personas", [], function(tx, result){
				nuevoId = result.rows.item(result.rows.length-1)["idpersona"];
				CEXaddCita("Nueva incorporación: " + nombre, fchalta, fchalta, "Nueva incorporación: " + nombre + " " + apellidos + " (" + dni + ")", "RHP" + nuevoId);
				});
			apprise('Persona guardada'); //alert("Trabajador guardado: "+ dni);
		})};
		//DatosBDpersonas();
		setTimeout('mostrarPersonas(intEstado15)',500);
		NVnewpersona(); Vlistapuestos();
	}
	
/*ACTUALIZAR PERSONA*/
	function updatePersona (nombre, apellidos, dni, fchnac, fchalta, fchbaja, linkcv, idpuesto, esresp) {
	
		var db;
        db = openDatabase("DBIW1", "0.1", "Database Isowin One", 200000);
		if(db){	
		  db.transaction( function(tx) {
			tx.executeSql("UPDATE personas SET nombre=?, apellidos=?, dni=?, fchnac=?, fchalta=?, fchbaja=?, linkcv=?, idpuesto=?, esresp=?  WHERE idpersona=?", [nombre, apellidos, dni, fchnac, fchalta, fchbaja, linkcv, idpuesto, esresp, idseleccionado15]);
			CEXupdateCita( "Nuevo trabajador: " + nombre, fchalta, fchalta, "Nueva incorporación: " + nombre + " " + apellidos + " (" + dni + ")", "RHP" + idseleccionado15);
			apprise('Persona modificada'); //alert("Trabajador ha cambiado: "+dni + " - " + idseleccionado15);
		})};
		//DatosBDpersona();
		setTimeout('mostrarPersonas(intEstado15)',500);
	}					

/*BORRAR PERSONA*/
	function removePersona() {
		apprise('¿Eliminar persona?', {'verify': true}, function(r) {
			if(r) { 
				var db;
				db = openDatabase("DBIW1", "0.1", "Database Isowin One", 200000);
				if(db){	
					db.transaction(function(tx) {
					tx.executeSql("DELETE FROM personas WHERE idpersona=?",[idseleccionado15]);
					CEXdeleteCita("RHP" + idseleccionado15);
					apprise('Persona borrada'); //alert("Persona borrada: "+ idseleccionado15);
					});
				};
				setTimeout('mostrarPersonas(intEstado15)',500);
			}
		});
		NVnewpersona(); Vlistapuestos();
	}
	
//=========================================================================================================
/* VER NO VER PERSONAS */
var vernewpersona = 0;
var verlistapersonas= 1;
function Vnewpersona() { if (vernewpersona==0) {$("#newpersona").toggle(200); vernewpersona=1; $("#txtpnombre").focus();};}
function NVnewpersona() { if (vernewpersona==1) {$("#newpersona").toggle(200); vernewpersona=0;};}
function Vlistapersonas () {if (verlistapersonas==0) {$("#listapersonas").toggle(200); verlistapersonas=1;};}
function NVlistapersonas () {if (verlistapersonas==1) {$("#listapersonas").toggle(200); verlistapersonas=0;};}	

//=========================================================================================================
/* VER NO VER*/
var verNPU= 0; var verLPU= 1; var verNPE= 0; var verLPE= 1;

function VnV15 (Vnpu, Vlpu, Vnpe, Vlpe) { 
	if (verNPU!=Vnpu) {$("#newpuesto").toggle(200); verNPU=Vnpu; $("#txtpupuesto").focus();};
	if (verLPU!=Vlpu) {$("#listapuestos").toggle(200); verLPU=Vlpu;};
	if (verNPE!=Vnpe) {$("#newpersona").toggle(200); verNPE=Vnpe; $("#txtpnombre").focus();};
	if (verLPE!=Vlpe) {$("#listapersonas").toggle(200); verLPE=Vlpe;};
}
//=========================================================================================================
	
//VER BOTON SEMAFORO_______________________________________________________________________

//Funcion de inicializaci�n de la pesta�a, ocultando el bot�n rojo.
function VbInit15() {document.getElementById('botonrojo15').style.display = 'none';}
//valor 1 se pone rojo, valor 0 se pone verde.	
function Vb15(intColor15) {
	if (INTcolor15!=intColor15) {$("#botonrojo15").toggle(200); $("#botonverde15").toggle(200); INTcolor15=intColor15;};
	}
//__________________________________________________________________________________________