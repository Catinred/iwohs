//SUBCONTRATAS (16)

	var idseleccionado16;
	var idseleccionado16b;
	var nuevassubcontratas;
				
				
//TABLA SUBCONTRATAS_____________________________________________________________________________________________________________

function mostrarSubcontratas() {
	sacarSubcontratas ();
	setTimeout('listSubcontratas()',600);
	}

function listSubcontratas() {
		$(document).ready(			
			function () {
				$('#dynamic16').html( '<table cellpadding="0" cellspacing="0" border="0" class="display" id="example16"></table>' );
				$('#example16').dataTable({
					"aaData": aDataSet16,
						
					"aoColumns": [
						{ "sTitle": "Puesto" },//Se muestra si o si al agrupar
						{ "sTitle": "Id Subcontratado", "bSearchable": false, "bVisible": false },
						{ "sTitle": "Nombre", "bSearchable": false, "bVisible": false },
						{ "sTitle": "Apellidos", "bSearchable": false, "bVisible": false },
						{ "sTitle": "Subcontrata", "bSearchable": false, "bVisible": false },
						{ "sTitle": "Trabajador" },
						{ "sTitle": "DNI" },
						{ "sTitle": "Teléfono" }
						],

					"sScrollY": "100%",
					"sScrollX": "100%",
					"sScrollXInner": "100%",
					"bScrollCollapse": true,
					"bPaginate": false,
					"aaSortingFixed": [[4, 'asc']], //Ordena las filas por el campo de agrupación
					"aoColumnDefs": [{ "bVisible": false, "aTargets": [4] }],//Oculto el valor de agrupación de la tabla de las columnas visibles!

					//Para poder seleccionar las filas de la tabla
					"sDom": 'lfrtip<"clear spacer">T',
					"oTableTools": {"sRowSelect": "single","aButtons": ["select"], //Solo me muestra el boton select para poder seleccionar las filas.	
									"aoColumnDefs": [{"sClass": "center", "aTargets": [ -1, -2 ]}]}
				});
	
				});
			//carga las subcontratas en el COMBOBOX de la ficha del trabajador
			sacarSubcontratas2 ();
			setTimeout('$("#combosubtidsubcontrata").html(nuevassubcontratas);',100);
			
				

	//Cargar datos del equipo para editar en formulario	
		$(document).ready(function() {

    		$('#example16 tbody td').click( function () {

        		var aPos16 = oTable16.fnGetPosition( this );
        		var aData16 = oTable16.fnGetData( aPos16[0] );

				document.getElementById("txtsubtpuesto").value = aData16[0];
				idseleccionado16 =  aData16[1];
				document.getElementById("txtsubtnombre").value = aData16[2];
				document.getElementById("txtsubtapell").value = aData16[3];
				document.getElementById("txtsubtdni").value = aData16[6];
				document.getElementById("txtsubttlf").value = aData16[7];
				idseleccionado16b = aData16[8];
				document.getElementById("combosubtidsubcontrata").value = aData16[8];
				document.getElementById("txtsubtmail").value = aData16[9];
				document.getElementById("txtsubtfsfch1").value = aData16[12];
				document.getElementById("txtsubtfsfch2").value = aData16[15];
				document.getElementById("txtsubtfsfch3").value = aData16[18];
				document.getElementById("txtsubtfsfch4").value = aData16[21];
				document.getElementById("combosubtactivo").value = aData16[22];
				document.getElementById("txtsubtobs").value = aData16[23];

				//File System-----------------------------------------------------------
					if (aData16[11]) {document.getElementById("FSSUBT1").innerHTML = "<a class='doc' href='"+aData16[11]+"' target='_blank'>"+aData16[10]+"</a> <img src='img/miniboton.jpg' style='vertical-align:middle' onclick='deleteFSSUBT(1);' />"; 
							nombreFS=aData16[10]; rutaFS=aData16[11]}
					else {document.getElementById("FSSUBT1").innerHTML = "<input type='file' id='mySUBT1' />";};
					if (aData16[14]) {document.getElementById("FSSUBT2").innerHTML = "<a class='doc' href='"+aData16[14]+"' target='_blank'>"+aData16[13]+"</a> <img src='img/miniboton.jpg' style='vertical-align:middle' onclick='deleteFSSUBT(2);' />"; 
							nombreFS2=aData16[13]; rutaFS2=aData16[14]}
					else {document.getElementById("FSSUBT2").innerHTML = "<input type='file' id='mySUBT2' />";};
					if (aData16[17]) {document.getElementById("FSSUBT3").innerHTML = "<a class='doc' href='"+aData16[17]+"' target='_blank' >"+aData16[16]+"</a> <img src='img/miniboton.jpg' style='vertical-align:middle' onclick='deleteFSSUBT(3);' />"; 
							nombreFS3=aData16[16]; rutaFS3=aData16[17]}
					else {document.getElementById("FSSUBT3").innerHTML = "<input type='file' id='mySUBT3' />";};
					if (aData16[20]) {document.getElementById("FSSUBT4").innerHTML = "<a class='doc' href='"+aData16[20]+"' target='_blank' >"+aData16[19]+"</a> <img src='img/miniboton.jpg' style='vertical-align:middle' onclick='deleteFSSUBT(4);' />"; 
							nombreFS3=aData16[19]; rutaFS3=aData16[20]}
					else {document.getElementById("FSSUBT4").innerHTML = "<input type='file' id='mySUBT4' />";};
				//----------------------------------------------------------------------
	
				formularioSubcontratas ();

				VnV15 (1, 1, 0, 0, 0, 1);
				VnVEsubs (1);//No ver botones update y delete
         
    		});
   				 /* Init DataTables */
   			oTable16= $('#example16').dataTable();

		});

//AGRUPAR filas de la tabla
$(document).ready(function() {
	new FixedColumns( oTable16, {
		"fnDrawCallback": function ( left, right ) {
			var oSettings = oTable16.fnSettings();
			if ( oSettings.aiDisplay.length == 0 )
			{
				return;
			}

			var nGroup, nCell, iIndex, sGroup;
			var sLastGroup = "", iCorrector=0;
			var nTrs = $('#example16 tbody tr');
			var iColspan = nTrs[0].getElementsByTagName('td').length;

			for ( var i=0 ; i<nTrs.length ; i++ )
			{
				iIndex = oSettings._iDisplayStart + i;
				sGroup = oSettings.aoData[ oSettings.aiDisplay[iIndex] ]._aData[4];//Nº de columna del Valor de agrupación
				
				if ( sGroup != sLastGroup )
				{
					/* Cell to insert into main table */
					nGroup = document.createElement( 'tr' );
					nCell = document.createElement( 'td' );
					nCell.colSpan = iColspan;
					nCell.className = "group";
					nCell.innerHTML = "&nbsp;";
					nGroup.appendChild( nCell );
					nTrs[i].parentNode.insertBefore( nGroup, nTrs[i] );

					/* Cell to insert into the frozen columns */
					nGroup = document.createElement( 'tr' );
					nCell = document.createElement( 'td' );
					nCell.className = "group";
					nCell.innerHTML = sGroup;
					nGroup.appendChild( nCell );
					$(nGroup).insertBefore( $('tbody tr:eq('+(i+iCorrector)+')', left.body)[0] );

					iCorrector++;
					sLastGroup = sGroup;
				}
			}
		} 
	} );});

		
	}

function sacarSubcontratas (){
	var db;
        db = openDatabase("DBIWOHS", "0.1", "Database Isowin OHS", 5 * 1024 * 1024);	
		//alert ("Estoy dentro");					
	if(db){
		db.transaction( function(tx) {
			tx.executeSql("SELECT subcontratados.*, subcontratas.subcontrata FROM subcontratas LEFT JOIN subcontratados ON subcontratas.idsubcontrata=subcontratados.idsubcontrata ", [],
				function(tx, result){
					aDataSet16 = [];
					
					for(var i=0; i < result.rows.length; i++) {

						//Junto apellidos y nombre para mostrarlos en la tabla
						var apellidosnombre = "Sin trabajadores";
						if (result.rows.item(i)['apellidos']) {apellidosnombre=result.rows.item(i)['apellidos']+", "+result.rows.item(i)['nombre']};
						
						aDataSet16.push([
							result.rows.item(i)['puesto'],
							result.rows.item(i)['idsubcontratado'],
							result.rows.item(i)['nombre'],
							result.rows.item(i)['apellidos'],
							result.rows.item(i)['subcontrata'],
							apellidosnombre,
							result.rows.item(i)['dni'],
							result.rows.item(i)['tlf'],
							result.rows.item(i)['idsubcontrata'],
							result.rows.item(i)['mail'],
							result.rows.item(i)['fsname'],
							result.rows.item(i)['fslink'],
							result.rows.item(i)['fsfch'],
							result.rows.item(i)['fsname2'],
							result.rows.item(i)['fslink2'],
							result.rows.item(i)['fsfch2'],
							result.rows.item(i)['fsname3'],
							result.rows.item(i)['fslink3'],
							result.rows.item(i)['fsfch3'],
							result.rows.item(i)['fsname4'],
							result.rows.item(i)['fslink4'],
							result.rows.item(i)['fsfch4'],
							result.rows.item(i)['activo'],
							result.rows.item(i)['obs']
						]);
					}			
				});
		});	
	
	};
}

function formularioSubcontratas (){
	var db;
        db = openDatabase("DBIWOHS", "0.1", "Database Isowin OHS", 5 * 1024 * 1024);	
		//alert ("Estoy dentro");					
	if(db){
		db.transaction( function(tx) {
			tx.executeSql("SELECT * FROM subcontratas WHERE idsubcontrata=? ", [idseleccionado16b],
				function(tx, result){
					//alert(result.rows.item(0)['contacto']);
					document.getElementById("txtsubempresa").value = result.rows.item(0)['subcontrata'];
					document.getElementById("txtsubcif").value = result.rows.item(0)['cif'];
					document.getElementById("combosubett").value = result.rows.item(0)['ett'];
					document.getElementById("txtsubdireccion").value = result.rows.item(0)['direccion'];
					document.getElementById("txtsubcontacto").value = result.rows.item(0)['contacto'];
					document.getElementById("txtsubtlf").value = result.rows.item(0)['tlf'];
					document.getElementById("txtsubfax").value = result.rows.item(0)['fax'];
					document.getElementById("txtsubmail").value = result.rows.item(0)['mail'];
					document.getElementById("txtsubactividad").value = result.rows.item(0)['actividad'];
					document.getElementById("txtsubmutua").value = result.rows.item(0)['mutua'];
					document.getElementById("txtsubtlfasistencia").value = result.rows.item(0)['tlfasistencia'];
					document.getElementById("txtsubfsfch1").value = result.rows.item(0)['fsfch'];
					document.getElementById("txtsubfsfch2").value = result.rows.item(0)['fsfch2'];
					document.getElementById("txtsubfsfch3").value = result.rows.item(0)['fsfch3'];
					document.getElementById("txtsubfsfch4").value = result.rows.item(0)['fsfch4'];
					document.getElementById("combosubactiva").value = result.rows.item(0)['activa'];
					document.getElementById("txtsubobs").value = result.rows.item(0)['obs'];

				//File System-----------------------------------------------------------
					if (result.rows.item(0)['fslink']) {document.getElementById("FSSUB1").innerHTML = "<a class='doc' href='"+result.rows.item(0)['fslink']+"' target='_blank'>"+result.rows.item(0)['fsname']+"</a> <img src='img/miniboton.jpg' style='vertical-align:middle' onclick='deleteFSSUB(1);' />"; 
							nombreFS=result.rows.item(0)['fsname']; rutaFS=result.rows.item(0)['fslink']}
					else {document.getElementById("FSSUB1").innerHTML = "<input type='file' id='mySUBT1' />";};
					if (result.rows.item(0)['fslink2']) {document.getElementById("FSSUB2").innerHTML = "<a class='doc' href='"+result.rows.item(0)['fslink2']+"' target='_blank'>"+result.rows.item(0)['fsname2']+"</a> <img src='img/miniboton.jpg' style='vertical-align:middle' onclick='deleteFSSUB(2);' />"; 
							nombreFS2=result.rows.item(0)['fsname2']; rutaFS2=result.rows.item(0)['fslink2']}
					else {document.getElementById("FSSUB2").innerHTML = "<input type='file' id='mySUBT2' />";};
					if (result.rows.item(0)['fslink3']) {document.getElementById("FSSUB3").innerHTML = "<a class='doc' href='"+result.rows.item(0)['fslink3']+"' target='_blank' >"+result.rows.item(0)['fsname3']+"</a> <img src='img/miniboton.jpg' style='vertical-align:middle' onclick='deleteFSSUB(3);' />"; 
							nombreFS3=result.rows.item(0)['fsname3']; rutaFS3=result.rows.item(0)['fslink3']}
					else {document.getElementById("FSSUB3").innerHTML = "<input type='file' id='mySUBT3' />";};
					if (result.rows.item(0)['fslink4']) {document.getElementById("FSSUB4").innerHTML = "<a class='doc' href='"+result.rows.item(0)['fslink4']+"' target='_blank' >"+result.rows.item(0)['fsname4']+"</a> <img src='img/miniboton.jpg' style='vertical-align:middle' onclick='deleteFSSUB(4);' />"; 
							nombreFS4=result.rows.item(0)['fsname4']; rutaFS4=result.rows.item(0)['fslink4']}
					else {document.getElementById("FSSUB4").innerHTML = "<input type='file' id='mySUBT4' />";};
				//----------------------------------------------------------------------

								
				});
		});	
	
	};

}	

//=========================================================================================================					
/*NUEVA SUBCONTRATA*/
var nombreFS2=null; var rutaFS2=null; var nombreFS3=null; var rutaFS3=null; var nombreFS4=null; var rutaFS4=null;//FileSystem
	
	function addSubcontrata(subcontrata, cif, ett, direccion, contacto, tlf, fax, mail, actividad, mutua, tlfasistencia, fsfch1, fsfch2, fsfch3, fsfch4, activa, obs) {
		var db;
		FSError = false; nombreFS=null; rutaFS=null; nombreFS2=null; rutaFS2=null; nombreFS3=null; rutaFS3=null; nombreFS4=null; rutaFS4=null;//FileSystem
		addFile("mySUB1"); add2File("mySUB2", 2); add2File("mySUB3", 3); add2File("mySUB4", 4); //FileSystem
		db = openDatabase("DBIWOHS", "0.1", "Database Isowin OHS", 5 * 1024 * 1024);
		if(db){	
		  db.transaction( function(tx) {
			tx.executeSql("INSERT INTO subcontratas (subcontrata, cif, ett, direccion, contacto, tlf, fax, mail, actividad, mutua, tlfasistencia, fsfch, fsfch2, fsfch3, fsfch4, activa, obs) VALUES(?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)", [subcontrata, cif, ett, direccion, contacto, tlf, fax, mail, actividad, mutua, tlfasistencia, fsfch1, fsfch2, fsfch3, fsfch4, activa, obs]);
			
			tx.executeSql("SELECT * FROM subcontratas ORDER BY idsubcontrata DESC", [], function(tx, result){
				idseleccionado16b = result.rows.item(0)["idsubcontrata"];
				if (!FSError) {apprise('Nueva subcontrata registrada');};
				});
		})};
		setTimeout('updateFSSubcontratas()',300);
		setTimeout('mostrarSubcontratas()',500);
	}
	
/*ACTUALIZAR SUBCONTRATA*/
	function updateSubcontrata (subcontrata, cif, ett, direccion, contacto, tlf, fax, mail, actividad, mutua, tlfasistencia, fsfch1, fsfch2, fsfch3, fsfch4, activa, obs) {	
	var db;
		FSError = false; nombreFS=null; rutaFS=null; nombreFS2=null; rutaFS2=null; nombreFS3=null; rutaFS3=null; nombreFS4=null; rutaFS4=null;//FileSystem
		addFile("mySUB1"); add2File("mySUB2", 2); add2File("mySUB3", 3); add2File("mySUB4", 4); //FileSystem
        db = openDatabase("DBIWOHS", "0.1", "Database Isowin OHS", 5 * 1024 * 1024);
		if(db){	
		  db.transaction( function(tx) {
			tx.executeSql("UPDATE subcontratas SET subcontrata=?, cif=?, ett=?, direccion=?, contacto=?, tlf=?, fax=?, mail=?, actividad=?, mutua=?, tlfasistencia=?, fsfch=?, fsfch2=?, fsfch3=?, fsfch4=?, activa=?, obs=?  WHERE idsubcontrata=?", [subcontrata, cif, ett, direccion, contacto, tlf, fax, mail, actividad, mutua, tlfasistencia, fsfch1, fsfch2, fsfch3, fsfch4, activa, obs, idseleccionado16b]);
			if (!FSError) {apprise('Subcontrata modificada');};
		});};
		setTimeout('updateFSSubcontratas()',300);
		setTimeout('mostrarSubcontratas()',500);
	}	

/*ACTUALIZAR ARCHIVOS*/
function updateFSSubcontratas() {
var db;
db = openDatabase("DBIWOHS", "0.1", "Database Isowin OHS", 5 * 1024 * 1024);
		if(db){	
		db.transaction( function(tx) {
			if (nombreFS!=null) {tx.executeSql("UPDATE subcontratas SET fsname=?, fslink=? WHERE idsubcontrata=?", [nombreFS, rutaFS, idseleccionado16b]);};
			if (nombreFS2!=null) {tx.executeSql("UPDATE subcontratas SET fsname2=?, fslink2=? WHERE idsubcontrata=?", [nombreFS2, rutaFS2, idseleccionado16b]);};
			if (nombreFS3!=null) {tx.executeSql("UPDATE subcontratas SET fsname3=?, fslink3=? WHERE idsubcontrata=?", [nombreFS3, rutaFS3, idseleccionado16b]);};
			if (nombreFS4!=null) {tx.executeSql("UPDATE subcontratas SET fsname4=?, fslink4=? WHERE idsubcontrata=?", [nombreFS4, rutaFS4, idseleccionado16b]);};
			if (nombreFS!=null) {document.getElementById("FSSUB1").innerHTML = "<a class='doc' href='"+rutaFS+"' target='_blank'>"+nombreFS+"</a> <img src='img/miniboton.jpg' style='vertical-align:middle' onclick='deleteFSSUB(1);' />";};
			if (nombreFS2!=null) {document.getElementById("FSSUB2").innerHTML = "<a class='doc' href='"+rutaFS2+"' target='_blank'>"+nombreFS2+"</a> <img src='img/miniboton.jpg' style='vertical-align:middle' onclick='deleteFSSUB(2);' />";};
			if (nombreFS3!=null) {document.getElementById("FSSUB3").innerHTML = "<a class='doc' href='"+rutaFS3+"' target='_blank'>"+nombreFS3+"</a> <img src='img/miniboton.jpg' style='vertical-align:middle' onclick='deleteFSSUB(3);' />";};
			if (nombreFS4!=null) {document.getElementById("FSSUB4").innerHTML = "<a class='doc' href='"+rutaFS4+"' target='_blank'>"+nombreFS4+"</a> <img src='img/miniboton.jpg' style='vertical-align:middle' onclick='deleteFSSUB(4);' />";};
			});
		};
}				

/*BORRAR SUBCONTRATA*/
	function removeSubcontrata() {
		apprise('¿Eliminar subcontrata?', {'verify': true}, function(r) {
			if(r) { 
				var db;
				deleteFile(); delete2File(nombreFS2); delete2File(nombreFS3); delete2File(nombreFS4);//FileSystem
				db = openDatabase("DBIWOHS", "0.1", "Database Isowin OHS", 5 * 1024 * 1024);
				if(db){	
					db.transaction(function(tx) {
					tx.executeSql("DELETE FROM subcontratas WHERE idsubcontrata=?",[idseleccionado16b]);
					if (!FSError) {apprise('Subcontrata borrada');};
					});
				};
			setTimeout('mostrarSubcontratas()',500);
			};
		});
	}

	/*BORRAR ARCHIVOS*/
	function deleteFSSUB(ndoc) {
		delete2LinkFile('subcontratas', ndoc);
		if (ndoc==1) {document.getElementById("FSSUB1").innerHTML = "<input type='file' id='mySUB1' />";};
		if (ndoc==2) {document.getElementById("FSSUB2").innerHTML = "<input type='file' id='mySUB2' />";};
		if (ndoc==3) {document.getElementById("FSSUB3").innerHTML = "<input type='file' id='mySUB3' />";};
		if (ndoc==4) {document.getElementById("FSSUB4").innerHTML = "<input type='file' id='mySUB4' />";};
	}

//=========================================================================================================					
/*NUEVO SUBCONTRATADO*/
	
	function addSubcontratado (nombre, apellidos, dni, idsubcontrata, puesto, tlf, mail, fsfch1, fsfch2, fsfch3, fsfch4, activo, obs) {
	if (document.getElementById("combosubtidsubcontrata").value != "") {
		var db;
		FSError = false; nombreFS=null; rutaFS=null; nombreFS2=null; rutaFS2=null; nombreFS3=null; rutaFS3=null; nombreFS4=null; rutaFS4=null;//FileSystem
		addFile("mySUBT1"); add2File("mySUBT2", 2); add2File("mySUBT3", 3); add2File("mySUBT4", 4); //FileSystem
		db = openDatabase("DBIWOHS", "0.1", "Database Isowin OHS", 5 * 1024 * 1024);
		if(db){	
		  db.transaction( function(tx) {
			tx.executeSql("INSERT INTO subcontratados (nombre, apellidos, dni, idsubcontrata, puesto, tlf, mail, fsfch, fsfch2, fsfch3, fsfch4, activo, obs) VALUES(?,?,?,?,?,?,?,?,?,?,?,?,?)", [nombre, apellidos, dni, idsubcontrata, puesto, tlf, mail, fsfch1, fsfch2, fsfch3, fsfch4, activo, obs]);
			
			tx.executeSql("SELECT * FROM subcontratados ORDER BY idsubcontratado DESC", [], function(tx, result){
				idseleccionado16 = result.rows.item(0)["idsubcontratado"];
				if (!FSError) {apprise('Nuevo trabajador registrado');};
				});	
		});};
		setTimeout('updateFSSubcontratado()',300);
		setTimeout('mostrarSubcontratas()',500);
	} else {apprise('Debes indicar a que empresa pertenece');};
	}
	
/*ACTUALIZAR SUBCONTRATADO*/
	function updateSubcontratado (nombre, apellidos, dni, idsubcontrata, puesto, tlf, mail, fsfch1, fsfch2, fsfch3, fsfch4, activo, obs) {	
	if (document.getElementById("combosubtidsubcontrata").value != "") {
		var db;
		FSError = false; nombreFS=null; rutaFS=null; nombreFS2=null; rutaFS2=null; nombreFS3=null; rutaFS3=null; nombreFS4=null; rutaFS4=null;//FileSystem
		addFile("mySUBT1"); add2File("mySUBT2", 2); add2File("mySUBT3", 3); add2File("mySUBT4", 4); //FileSystem
        db = openDatabase("DBIWOHS", "0.1", "Database Isowin OHS", 5 * 1024 * 1024);
		if(db){	
		  db.transaction( function(tx) {
			tx.executeSql("UPDATE subcontratados SET nombre=?, apellidos=?, dni=?, idsubcontrata=?, puesto=?, tlf=?, mail=?, fsfch=?, fsfch2=?, fsfch3=?, fsfch4=?, activo=?, obs=?  WHERE idsubcontratado=?", [nombre, apellidos, dni, idsubcontrata, puesto, tlf, mail, fsfch1, fsfch2, fsfch3, fsfch4, activo, obs, idseleccionado16]);
			
			if (!FSError) {apprise('Trabajador modificado');};
		});};
		setTimeout('updateFSSubcontratado()',300);
		setTimeout('mostrarSubcontratas()',500);
	} else {apprise('Debes indicar a que empresa pertenece');};
	}

/*ACTUALIZAR ARCHIVOS*/
function updateFSSubcontratado() {
var db;
db = openDatabase("DBIWOHS", "0.1", "Database Isowin OHS", 5 * 1024 * 1024);
		if(db){	
		db.transaction( function(tx) {
			if (nombreFS!=null) {tx.executeSql("UPDATE subcontratados SET fsname=?, fslink=? WHERE idsubcontratado=?", [nombreFS, rutaFS, idseleccionado16]);};
			if (nombreFS2!=null) {tx.executeSql("UPDATE subcontratados SET fsname2=?, fslink2=? WHERE idsubcontratado=?", [nombreFS2, rutaFS2, idseleccionado16]);};
			if (nombreFS3!=null) {tx.executeSql("UPDATE subcontratados SET fsname3=?, fslink3=? WHERE idsubcontratado=?", [nombreFS3, rutaFS3, idseleccionado16]);};
			if (nombreFS4!=null) {tx.executeSql("UPDATE subcontratados SET fsname4=?, fslink4=? WHERE idsubcontratado=?", [nombreFS4, rutaFS4, idseleccionado16]);};
			if (nombreFS!=null) {document.getElementById("FSSUBT1").innerHTML = "<a class='doc' href='"+rutaFS+"' target='_blank'>"+nombreFS+"</a> <img src='img/miniboton.jpg' style='vertical-align:middle' onclick='deleteFSSUBT(1);' />";};
			if (nombreFS2!=null) {document.getElementById("FSSUBT2").innerHTML = "<a class='doc' href='"+rutaFS2+"' target='_blank'>"+nombreFS2+"</a> <img src='img/miniboton.jpg' style='vertical-align:middle' onclick='deleteFSSUBT(2);' />";};
			if (nombreFS3!=null) {document.getElementById("FSSUBT3").innerHTML = "<a class='doc' href='"+rutaFS3+"' target='_blank'>"+nombreFS3+"</a> <img src='img/miniboton.jpg' style='vertical-align:middle' onclick='deleteFSSUBT(3);' />";};
			if (nombreFS4!=null) {document.getElementById("FSSUBT4").innerHTML = "<a class='doc' href='"+rutaFS4+"' target='_blank'>"+nombreFS4+"</a> <img src='img/miniboton.jpg' style='vertical-align:middle' onclick='deleteFSSUBT(4);' />";};
			});
		};
}					

/*BORRAR SUBCONTRATADO*/
	function removeSubcontratado() {
		apprise('¿Eliminar trabajador de subcontrata?', {'verify': true}, function(r) {
			if(r) { 
				var db;
				deleteFile(); delete2File(nombreFS2); delete2File(nombreFS3); delete2File(nombreFS4);//FileSystem
				db = openDatabase("DBIWOHS", "0.1", "Database Isowin OHS", 5 * 1024 * 1024);
				if(db){	
					db.transaction(function(tx) {
					tx.executeSql("DELETE FROM subcontratados WHERE idsubcontratado=?",[idseleccionado16]);
					if (!FSError) {apprise('Trabajador borrado');};
					});
				};
			setTimeout('mostrarSubcontratas()',500);
			};
		});
	}

	/*BORRAR ARCHIVOS*/
	function deleteFSSUBT(ndoc) {
		delete2LinkFile('subcontratados', ndoc);
		if (ndoc==1) {document.getElementById("FSSUBT1").innerHTML = "<input type='file' id='mySUBT1' />";};
		if (ndoc==2) {document.getElementById("FSSUBT2").innerHTML = "<input type='file' id='mySUBT2' />";};
		if (ndoc==3) {document.getElementById("FSSUBT3").innerHTML = "<input type='file' id='mySUBT3' />";};
		if (ndoc==4) {document.getElementById("FSSUBT4").innerHTML = "<input type='file' id='mySUBT4' />";};
	}

//=========================================================================================================
/* VER NO VER*/

//Está definido en CRUDTRABAJOS.JS

//=========================================================================================================					
/*COMBOBOX DE RESPONSABLES*/

function sacarSubcontratas2 (){
	var db;
        db = openDatabase("DBIWOHS", "0.1", "Database Isowin OHS", 5 * 1024 * 1024);	
		//alert ("Estoy dentro");					
	if(db){
		db.transaction( function(tx) {
			tx.executeSql("SELECT * FROM subcontratas", [],
				function(tx, result){
					nuevassubcontratas = "<option selected></option>";
					for(var i=0; i < result.rows.length; i++) {	
						nuevassubcontratas = nuevassubcontratas + "<option value='" +result.rows.item(i)['idsubcontrata']+"'>"+ result.rows.item(i)['subcontrata'] + " (" + result.rows.item(i)['cif'] + ") " + "</option> ";
					}			
				});
		});	
	
	};
}
//=========================================================================================================		