$(function() {$(".editable_textarea").editable
	(function(value, settings) { 
			db = openDatabase("DBIW1", "0.1", "Database Isowin One", 200000);
		var idProcess = 6; //Indico el proceso al que pertenece la informaci�n que voy a imcluir.
			if(db){
				if (this.id=='P1') {db.transaction( function(tx) {tx.executeSql ("UPDATE procesos SET mision=?  WHERE idproceso=?", [value, idProcess])})};
				if (this.id=='P2') {db.transaction( function(tx) {tx.executeSql ("UPDATE procesos SET alcance=?  WHERE idproceso=?", [value, idProcess])})};
				if (this.id=='P3') {db.transaction( function(tx) {tx.executeSql ("UPDATE procesos SET entradas=?  WHERE idproceso=?", [value, idProcess])})};
				if (this.id=='P4') {db.transaction( function(tx) {tx.executeSql ("UPDATE procesos SET salidas=?  WHERE idproceso=?", [value, idProcess])})};
				if (this.id=='P5') {db.transaction( function(tx) {tx.executeSql ("UPDATE procesos SET responsable=?  WHERE idproceso=?", [value, idProcess])})};
				if (this.id=='P6') {db.transaction( function(tx) {tx.executeSql ("UPDATE procesos SET recursos=?  WHERE idproceso=?", [value, idProcess])})};
				if (this.id=='P7') {db.transaction( function(tx) {tx.executeSql ("UPDATE procesos SET requisitos=?  WHERE idproceso=?", [value, idProcess])})};
				if (this.id=='P8') {db.transaction( function(tx) {tx.executeSql ("UPDATE procesos SET controles=?  WHERE idproceso=?", [value, idProcess])})};
				if (this.id=='I1') {db.transaction( function(tx) {tx.executeSql ("UPDATE procesos SET i1=?  WHERE idproceso=?", [value, idProcess])})};
				if (this.id=='I2') {db.transaction( function(tx) {tx.executeSql ("UPDATE procesos SET i2=?  WHERE idproceso=?", [value, idProcess])})};
				if (this.id=='I3') {db.transaction( function(tx) {tx.executeSql ("UPDATE procesos SET i3=?  WHERE idproceso=?", [value, idProcess])})};
				if (this.id=='I4') {db.transaction( function(tx) {tx.executeSql ("UPDATE procesos SET i4=?  WHERE idproceso=?", [value, idProcess])})};

				apprise('El cambio se ha guardado');//alert("modificado" + this.id + value);
				
				};
			return(value);
			},
		
		{
		type   : 'textarea', 
		select : true, 
		submit : '<div class="sprite ok">', 
		cancel : '<div class="sprite ko">',
		height  : "auto",
		cssclass : "editable"}
	);
});

