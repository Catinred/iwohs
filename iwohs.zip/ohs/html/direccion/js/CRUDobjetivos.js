//OBJETIVOS (20)

	var idseleccionado20;
	var idseleccionado20b;
	var color;
	var vernewobjetivo=0;
	var vernewaccion=0;

//GANTT OBJETIVOS_____________________________________________________________________________________________________________

function mostrarGantt() {
	aDataSet20 = [];
	sacarGantt (aDataSet20);
	setTimeout('showGantt()',500);
	//showGantt ();
	}
	

function showGantt () {
	$(document).ready(			
		function() {
			
			//alert(Date(1322611200000));
			//alert(Date.parse ('11/15/2012'));
			"use strict";

			$(".gantt").gantt({
				source: aDataSet20,
				navigate: "scroll",
				scale: "weeks",
				maxScale: "months",
				minScale: "days",
				itemsPerPage: 20,
				 months: ["Enero", "Febrero", "Marzo", "Abril", "Mayo", "Junio", "Julio", "Agosto", "Septiembre", "Octubre", "Noviembre", "Diciembre"],
				dow: ["D", "L", "M", "X", "J", "V", "S"],
				//waitText: "Espere, por favor..." // Si se conecta esto, se jode todo
				onItemClick: function(data) {
					
					VnV20 (1, 0, 1);
					
					//alert(data[0]);
					idseleccionado20b = data[0];
					document.getElementById("txtccaccion").value = data[1];
					document.getElementById("txtccdescripcion").value = data[2];
					document.getElementById("comboccresponsable").value = parseInt(data[3]);
					document.getElementById("txtccrecursos").value = data[4];
					document.getElementById("txtccresultado").value = data[5];
					document.getElementById("txtccvaloracion").value = data[6];
					document.getElementById("txtccfchinicio").value = changeFch (data[7]);
					document.getElementById("txtccfchfin").value = changeFch (data[8]);
					document.getElementById("txtccvalorultrev").value = data[9];
					document.getElementById("txtccfchultrev").value = data[10];
					document.getElementById("txtcccolor").value = data[11];
					idseleccionado20 = data[12];
					document.getElementById("txtobobjetivo").value = data[13];
					document.getElementById("txtobdescripcion").value = data[14];
					document.getElementById("comboobresponsable").value = parseInt(data[15]);
					document.getElementById("txtobrecursos").value = data[16];
					document.getElementById("txtobresultado").value = data[17];
					document.getElementById("txtobvaloracion").value = data[18];
					//alert("Item clicked - show some details");
					
					//Cargo el COMBOBOX de responsables del formulario NCs------------
					setTimeout('$("#comboccresponsable").html(nuevosresponsables);',200);
					setTimeout('$("#comboobresponsable").html(nuevosresponsables);',200);
					//--------------------------------------------------

					VnVEobj (1);//No ver botones update y delete
					VnVEacc (1);//No ver botones update y delete	
				},
				onAddClick: function(dt, rowId) {
					$(':text').val('');$('#txtccdescripcion').val('');$('#txtccrecursos').val('');$('#txtccvalorultrev').val('');$('#txtobdescripcion').val('');$('#txtobrecursos').val('');
					VnV20 (1, 0, 1);
					
					 idseleccionado20 = rowId;
					
					DatosObjetivo(rowId);
					
					//Cargo el COMBOBOX de responsables del formulario NCs------------
					setTimeout('$("#comboccresponsable").html(nuevosresponsables);',200);
					setTimeout('$("#comboobresponsable").html(nuevosresponsables);',200);
					//--------------------------------------------------

					VnVEobj (1);//No ver botones update y delete	
					
					return;
				},
				onRender: function() {
					if (window.console && typeof console.log === "function") {
						console.log("chart rendered");
					}
				}
			});

			$(".gantt").popover({
				selector: ".bar",
				title: "I'm a popover",
				content: "And I'm the content of said popover."
			});

			prettyPrint();

		});
		
	}
	
	
function sacarGantt (aObjetivos){
	var db;
        db = openDatabase("DBIWOHS", "0.1", "Database Isowin OHS", 5 * 1024 * 1024);	
		//alert ("Estoy dentro");					
	if(db){
		//alert("conectado");	
		db.transaction( function(tx) {
			tx.executeSql("SELECT * FROM objetivos LEFT JOIN acciones ON objetivos.idobjetivo=acciones.idobjetivo ORDER BY objetivos.idobjetivo", [],
				function(tx, result){
					
					
					var idobjetivoAnterior = 0;
					var nexti=0;
														//alert("Numero de objetivos-acciones: "+result.rows.length);
					for(var i=0; i < result.rows.length; i++) {
						
						var aAcciones = [];
						var idobjetivoActual =  result.rows.item(i)['idobjetivo'];
						
														//alert("Id Objetivo: " + result.rows.item(i)['idobjetivo'] + "(i: " +  i + ") "+ "(j: " +  j + ") " + result.rows.item(i)['objetivo']);
						
						for(var j=nexti; idobjetivoActual == result.rows.item(j)['idobjetivo']; j++) {
														//alert("AcciÃ³n: " +  i + ":" +  j + " : " +  result.rows.item(j)['accion']);
							if (result.rows.item(j)['accion'] != null) {
								
								var fchinicioAux2 = result.rows.item(j)['fchinicio'];				//alert(Parse(Date(1330011200000)));
								var fchfinAux2 = result.rows.item(j)['fchfin'];
								var fchinicioAux = new Date(fchinicioAux2); //"/Date(1336611200000)/"//"/Date('2012/09/12')/"; //1330011200000; //Date.parse ('mm/dd/yyyy'); 
								var fchfinAux =   new Date(fchfinAux2); // "/Date(1349711200000)/"//"/Date('2012/11/12')/";
								var fchinicio = fchinicioAux.getTime();
								var fchfin =   fchfinAux.getTime(); 
								var idFila = i+1; //Lo uso para poder crear una acciÃ³n en el objetivo seleccionado con un click.
								
														//alert(result.rows.item(j)['idobjetivo'] + ">>" + idFila);
														//alert( '10/05/2012' + "<>" + fchinicio +"<>"+Date(fchinicio));
														//alert(fchinicio + ">>" + fchfin);
								aAcciones.push({
									//from: "/Date(1336611200000)/",
									//to: "/Date(1349711200000)/",
									from: "/Date(" + fchinicio + ")/",
									to: "/Date(" + fchfin + ")/",
									"label" :  result.rows.item(j)['accion'],
									"customClass" : result.rows.item(j)['color'],
									"dataObj" : [
										result.rows.item(j)['idaccion'],
										result.rows.item(j)['accion'],
										result.rows.item(j)['adescripcion'],
										result.rows.item(j)['aresponsable'],
										result.rows.item(j)['arecursos'],
										result.rows.item(j)['aresultado'],
										result.rows.item(j)['avaloracion'],
										result.rows.item(j)['fchinicio'],
										result.rows.item(j)['fchfin'],
										result.rows.item(j)['valorultrev'],
										result.rows.item(j)['fchultrev'],
										result.rows.item(j)['color'],
										result.rows.item(j)['idobjetivo'],
										result.rows.item(j)['objetivo'],
										result.rows.item(j)['descripcion'],
										result.rows.item(j)['responsable'],
										result.rows.item(j)['recursos'],
										result.rows.item(j)['resultado'],
										result.rows.item(j)['valoracion'],
										idFila,
									]
								});
												//alert("from: " + Date(1330011200000) + "::" + result.rows.item(j)['fchinicio']);
							
							};
							//};
							if ((j+1) == result.rows.length) {break;}; //Para incluir el último objetivo correctamente.
						};
						
					nexti=j; //Evita publicar de nuevo acciones correspondientes a objetivos anteriores.	
						
										//alert("<<<<Objetivo actual " + result.rows.item(i)['idobjetivo'] + " VS Objetivo Anterior " + idobjetivoAnterior);
						
					if (result.rows.item(i)['idobjetivo'] != idobjetivoAnterior) {aObjetivos.push({"id" : result.rows.item(i)['idobjetivo'],"name" : "Objetivo", "desc" : result.rows.item(i)['objetivo'], "values" : aAcciones,});};
					idobjetivoAnterior = result.rows.item(i)['idobjetivo'];
					
										//alert("******Fin de i = " + i + "********");
						
					//Cargo el COMBOBOX de responsables del formulario NCs------------
					setTimeout('$("#comboccresponsable").html(nuevosresponsables);',200);
					setTimeout('$("#comboobresponsable").html(nuevosresponsables);',200);
					//--------------------------------------------------	
						
					}
				}
			)
		})
	};
						
	}
	
//DATOS OBJETIVO SELECCIONADO___________________________________________________________________________________________

	function DatosObjetivo(rowId) {
		var db;
        db = openDatabase("DBIWOHS", "0.1", "Database Isowin OHS", 5 * 1024 * 1024);
		if(db){	
		db.transaction( function(tx) {
			tx.executeSql("SELECT * FROM objetivos WHERE idobjetivo="+rowId, [],
				function(tx, result){

					idseleccionado20 =rowId;
					document.getElementById("txtobobjetivo").value = result.rows.item(0)['objetivo'];
					document.getElementById("txtobdescripcion").value = result.rows.item(0)['descripcion'];
					document.getElementById("comboobresponsable").value = parseInt(result.rows.item(0)['responsable']);
					document.getElementById("txtobrecursos").value = result.rows.item(0)['recursos'];
					document.getElementById("txtobresultado").value = result.rows.item(0)['resultado'];
					document.getElementById("txtobvaloracion").value = result.rows.item(0)['valoracion'];			
				 
				});	
		});
	};}
		
//=========================================================================================================					
/*NUEVO OBJETIVO*/
	function addObjetivo (objetivo, descripcion, responsable, recursos, resultado, valoracion) {
		var db;
		db = openDatabase("DBIWOHS", "0.1", "Database Isowin OHS", 5 * 1024 * 1024);
		if(db){	
		  db.transaction( function(tx) {
			tx.executeSql("INSERT INTO objetivos (objetivo, descripcion, responsable, recursos, resultado, valoracion) VALUES(?,?,?,?,?,?)", [objetivo, descripcion, responsable, recursos, resultado, valoracion]);
			apprise('El objetivo ha sido guardado'); //alert("Objetivo guardado: "+ objetivo);
		})};
		mostrarGantt();
		VnV20 (0, 1, 0);
	}
	
/*ACTUALIZAR OBJETIVO*/
	function updateObjetivo (objetivo, descripcion, responsable, recursos, resultado, valoracion) {
		var db;
        db = openDatabase("DBIWOHS", "0.1", "Database Isowin OHS", 5 * 1024 * 1024);
		if(db){	
		  db.transaction( function(tx) {
			tx.executeSql("UPDATE objetivos SET objetivo=?, descripcion=?, responsable=?, recursos=?, resultado=?, valoracion=?  WHERE idobjetivo=?", [objetivo, descripcion, responsable, recursos, resultado, valoracion, idseleccionado20]);
			apprise('El objetivo ha sido modificado'); //alert("El objetivo ha cambiado: "+ objetivo + " - " + idseleccionado20);
		})};
		mostrarGantt();
		VnV20 (0, 1, 0);
	}					

/*BORRAR OBJETIVO*/
	function removeObjetivo() {
		apprise('¿Eliminar Objetivo?', {'verify': true}, function(r) {
			if(r) { 
		var db;
        db = openDatabase("DBIWOHS", "0.1", "Database Isowin OHS", 5 * 1024 * 1024);
		if(db){	
		  db.transaction(function(tx) {
			tx.executeSql("DELETE FROM objetivos WHERE idobjetivo=?",[idseleccionado20]);
			apprise('El objetivo ha sido eliminado'); //alert("Objetivo borrado: "+ idseleccionado20);

		});};};
		mostrarGantt();
		VnV20 (0, 1, 0);
		});
	}
	
//=========================================================================================================					
/*NUEVA ACCION*/
	function addAccion (accion, descripcion, responsable, recursos, resultado, valoracion, fchinicio, fchfin, valorultrev, fchultrev, color) {
		var db;
		//Cambio a formato americano las fechas
		var fchinicioAux = changeFch (fchinicio);
		var fchfinAux = changeFch (fchfin);
		
		db = openDatabase("DBIWOHS", "0.1", "Database Isowin OHS", 5 * 1024 * 1024);
		if(db){	
		  db.transaction( function(tx) {
			tx.executeSql("INSERT INTO acciones (accion, adescripcion, aresponsable, arecursos, aresultado, avaloracion, fchinicio, fchfin, valorultrev, fchultrev, idobjetivo, color) VALUES(?,?,?,?,?,?,?,?,?,?,?,?)", [accion, descripcion, responsable, recursos, resultado, valoracion, fchinicioAux, fchfinAux, valorultrev, fchultrev,  idseleccionado20, color]);
			apprise('La acción ha sido guardada'); //alert("AcciÃ³n guardada: "+ accion);
		})};
		mostrarGantt();
		VnV20 (0, 1, 0);
	}
	
/*ACTUALIZAR ACCION*/
	function updateAccion (accion, descripcion, responsable, recursos, resultado, valoracion, fchinicio, fchfin, valorultrev, fchultrev, color) {
		var db;
		//Cambio a formato americano las fechas
		var fchinicioAux = changeFch (fchinicio);
		var fchfinAux = changeFch (fchfin);
		
        db = openDatabase("DBIWOHS", "0.1", "Database Isowin OHS", 5 * 1024 * 1024);
		if(db){	
		  db.transaction( function(tx) {
			tx.executeSql("UPDATE acciones SET accion=?, adescripcion=?, aresponsable=?, arecursos=?, aresultado=?, avaloracion=?, fchinicio=?, fchfin=?, valorultrev=?, fchultrev=?, color=?  WHERE idaccion=?", [accion, descripcion, responsable, recursos, resultado, valoracion, fchinicioAux, fchfinAux, valorultrev, fchultrev, color, idseleccionado20b]);
			apprise('La acción ha sido modificada'); 
		})};
		mostrarGantt();
		VnV20 (0, 1, 0);
	}					

/*BORRAR ACCION*/
	function removeAccion() {
		apprise('¿Eliminar Acción?', {'verify': true}, function(r) {
			if(r) {
		var db;
        db = openDatabase("DBIWOHS", "0.1", "Database Isowin OHS", 5 * 1024 * 1024);
		if(db){	
			db.transaction(function(tx) {
			tx.executeSql("DELETE FROM acciones WHERE idaccion=?",[idseleccionado20b]);
			apprise('La acción ha sido eliminada');

			});
		};
		};
		
		mostrarGantt();
		VnV20 (0, 1, 0);
		});
	}
//=========================================================================================================
/* FORMATO DE FECHA*/
function changeFch (fch) {
	//Cambio el orden del dÃ­a y del mes.		
	var newfch =   fch.substring(3, 5) + "/" +  fch.substring(0, 2) + "/" + fch.substring(6, 10); 
	return newfch
	}
	
//=========================================================================================================
/* VER NO VER*/
var verNOB= 0; var verGANTT= 1; var verNAC= 0;

function VnV20 (Vnob, Vgantt, Vnac) { 
	if (verNOB!=Vnob) {$("#newobjetivo").toggle(200); verNOB=Vnob; $("#txtobobjetivo").focus();};
	if (verGANTT!=Vgantt) {$("#listaobjetivos").toggle(200); verGANTT=Vgantt;};
	if (verNAC!=Vnac) {$("#newaccion").toggle(200); verNAC=Vnac; $("#txtccaccion").focus();};
	}


/* VER NO VER EDIT (Update+Delete)*/
var verEOBJ=0;var verEACC=0;
function VnVEobj (Veobj) {if (verEOBJ!=Veobj) {$("#editobj").toggle(200); verEOBJ=Veobj;};}
function VnVEacc (Veacc) {if (verEACC!=Veacc) {$("#editacc").toggle(200); verEACC=Veacc;};}


//__________________________________________________________________________________________