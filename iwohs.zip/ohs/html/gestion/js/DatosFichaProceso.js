$(function() {$(".editable_textarea").editable
	(function(value, settings) { 
			db = openDatabase("DBIWOHS", "0.1", "Database Isowin OHS", 5 * 1024 * 1024);
		var idProcess = 1; //Indico el proceso al que pertenece la informaci�n que voy a imcluir.
			if(db){
				if (this.id=='I1') {db.transaction( function(tx) {tx.executeSql ("UPDATE procesos SET i1=?  WHERE idproceso=?", [value, idProcess])})};
				if (this.id=='I2') {db.transaction( function(tx) {tx.executeSql ("UPDATE procesos SET i2=?  WHERE idproceso=?", [value, idProcess])})};
				if (this.id=='I3') {db.transaction( function(tx) {tx.executeSql ("UPDATE procesos SET i3=?  WHERE idproceso=?", [value, idProcess])})};
				if (this.id=='I4') {db.transaction( function(tx) {tx.executeSql ("UPDATE procesos SET i4=?  WHERE idproceso=?", [value, idProcess])})};

				apprise('El cambio se ha guardado');//alert("modificado" + this.id + value);
				
				};
			return(value);
			},
		
		{
		type   : 'textarea', 
		select : true, 
		submit : '<div class="sprite ok">', 
		cancel : '<div class="sprite ko">',
		height  : "auto",
		cssclass : "editable"}
	);
});

