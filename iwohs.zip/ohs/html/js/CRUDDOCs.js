//DOCUMENTOS y REGISTROS (1 y 2)

	var idseleccionado;
	var idseleccionado2;
	var intProceso; var intEstado;
	var INTcolor = 0; //Color del semaforo en verde
		
//TABLA DOCUMENTOS___________________________________________________________________________________________

function mostrarDOCsREGs(intProc, intEst) {
	intProceso=intProc; intEstado=intEst;
	sacarDOCsREGs (intProceso, intEstado);
	setTimeout('listDOCs(); listREGs()',500);
	Vb(intEst);
	}


function listDOCs() {
			$(document).ready(			
			function () {
				$('#dynamic').html( '<table cellpadding="0" cellspacing="0" border="0" class="display" id="example"></table>' );
				$('#example').dataTable( {
					"aaData": aDataSet,

					
					"aoColumns": [
						{ "sTitle": "Id", "sWidth": "10px" },
						{ "sTitle": "Codigo", "sWidth": "30px" },
						{ "sTitle": "Documento" },
						{ "sTitle": "Revision", "sWidth": "10px"},
						{ "sTitle": "Fecha Publicacion", "sWidth": "30px" },
						{ "sTitle": "Estado", "sWidth": "30px"},
						{ "sTitle": "Link"}
						],
					
					
					//"sScrollY": "200px",//Altura de la tabla
					"bPaginate": false,//No pagina la tabla
					"bScrollCollapse": true,//Aparece el scroll vertical cuando se llenan los 200px.
					
					"sDom": 'lfrtip<"clear spacer">T',	
					
					/*"sDom": 'T<"clear">lfrtip<"clear spacer">T',*/ //Muestra los botones de copy,print...
					"oTableTools": {"sRowSelect": "single","aButtons": ["select"],} //Solo me muestra el boton select para poder seleccionar las filas.
				});
				});
				
			$(document).ready(
				function() {
					$('#example tbody td').click( function () {
					/* Get the position of the current data from the node */
					var aPos = oTable.fnGetPosition( this );
					/* Get the data array for this row */
					var aData = oTable.fnGetData( aPos[0] );
						/*alert("Ok "+aData[0]);*/
				
						idseleccionado =  aData[0];
						document.getElementById("txtcoddocumento").value = aData[1];
						document.getElementById("txtdocumento").value = aData[2];
						document.getElementById("txtrevision").value = aData[3];
						document.getElementById("txtfchpublic").value = aData[4];
						document.getElementById("combodocestado").value = aData[5];
						document.getElementById("txtlink").value = aData[9];
						
						//File System-----------------------------------------------------------
						if (aData[8]) {document.getElementById("FS").innerHTML = "<a class='doc' href='"+aData[8]+"' target='_blank'>"+aData[7]+"</a> <img src='img/miniboton.jpg' style='vertical-align:middle' onclick='deleteFS();' />"; 
										nombreFS=aData[7]; rutaFS=aData[8]}
						else {document.getElementById("FS").innerHTML = "<input type='file' id='myfile' />";};
						//----------------------------------------------------------------------
				
				VnVEdoc (1);//No ver botones update y delete

				});	
     

			oTable = $('#example').dataTable( );

			});
}


//TABLA REGISTROS___________________________________________________________________________________________


function listREGs() {
		$(document).ready(			
			function () {
				$('#dynamic2').html( '<table cellpadding="0" cellspacing="0" border="0" class="display" id="example2"></table>' );
				$('#example2').dataTable( {
					"aaData": aDataSet2,
					"aoColumns": [
						{ "sTitle": "Id", "sWidth": "10px" },
						{ "sTitle": "Codigo", "sWidth": "30px" },
						{ "sTitle": "Registro" },
						{ "sTitle": "Revisión"},
						{ "sTitle": "Fecha Publicación", "sWidth": "30px" },
						{ "sTitle": "Distribución"},
						{ "sTitle": "Años", "sWidth": "10px"},
						{ "sTitle": "Lugar"},
						{ "sTitle": "Estado", "sWidth": "30px"},
						{ "sTitle": "Link"}
						],
						
					//"sScrollY": "200px",
        			"bPaginate": false,
        			"bScrollCollapse": true,
						
					"sDom": 'lfrtip<"clear spacer">T',
					/*"sDom": 'T<"clear">lfrtip<"clear spacer">T',*/ //Muestra los botones de copy,print...
					"oTableTools": {
					"sRowSelect": "single","aButtons": ["select"], //Solo me muestra el boton select para poder seleccionar las filas.
				
				}});
				
				});
				
			$(document).ready(
				function () {
    			$('#example2 tbody td').click( function () {
        		/* Get the position of the current data from the node */
        		var aPos2 = oTable2.fnGetPosition( this );
         
        		/* Get the data array for this row */
        		var aData2 = oTable2.fnGetData( aPos2[0] );
				/*alert("Ok "+aData[0]);*/
				
				idseleccionado2 =  aData2[0];
				document.getElementById("txtcodregistro").value = aData2[1];
				document.getElementById("txtregistro").value = aData2[2];
				document.getElementById("txtrevreg").value = aData2[3];
				document.getElementById("txtfchpublicreg").value = aData2[4];
				document.getElementById("txtlinkreg").value = aData2[5];
				document.getElementById("txtanos").value = aData2[6];
				document.getElementById("txtlugar").value = aData2[7];
				document.getElementById("comboregestado").value = aData2[8];

				//File System-----------------------------------------------------------
					if (aData2[11]) {document.getElementById("FS2").innerHTML = "<a class='doc' href='"+aData2[11]+"' target='_blank'>"+aData2[10]+"</a> <img src='img/miniboton.jpg' style='vertical-align:middle' onclick='deleteFS2();' />"; 
							nombreFS=aData2[10]; rutaFS=aData2[11]}
					else {document.getElementById("FS2").innerHTML = "<input type='file' id='myfile2' />";};
				//----------------------------------------------------------------------
         		
				VnVEreg (1);//No ver botones update y delete

    			});
     
   				 /* Init DataTables */
   				 oTable2 = $('#example2').dataTable();
				});			
}

//______________________________________________________________________________________________________
function sacarDOCsREGs (intProceso, intEstado){
	var db;
        db = openDatabase("DBIWOHS", "0.1", "Database Isowin OHS", 5 * 1024 * 1024);	
									//alert ("Estoy dentro");
	var estado="WHERE estado!='Obsoleto' AND proceso=" + parseInt(intProceso);
	if (intEstado==1) {estado="WHERE estado='Obsoleto' AND proceso=" + parseInt(intProceso);};	
	if(db){
		db.transaction( function(tx) {
			tx.executeSql("SELECT * FROM documentos " + estado, [],
				function(tx, result){
					aDataSet = [];
					for(var i=0; i < result.rows.length; i++) {

						var linknull = "";//File System
						if (result.rows.item(i)['fsname']) {linknull = result.rows.item(i)['fsname'];};

						aDataSet.push([result.rows.item(i)['iddocumento'],
								result.rows.item(i)['coddocumento'],
								result.rows.item(i)['documento'],
								result.rows.item(i)['revision'],
								result.rows.item(i)['fchpublic'],
								result.rows.item(i)['estado'],
								"<a href='"+result.rows.item(i)['fslink']+"' target='_blank'>"+linknull+"</a>",
								result.rows.item(i)['fsname'],
								result.rows.item(i)['fslink'],
								result.rows.item(i)['link']
								]);						
					}					
			});

			tx.executeSql("SELECT * FROM registros " + estado, [],
				function(tx, result){
					aDataSet2 = [];
					for(var i=0; i < result.rows.length; i++) {

						var linknull2 = "";//File System
						if (result.rows.item(i)['fsname']) {linknull2 = result.rows.item(i)['fsname'];};
								
						aDataSet2.push([result.rows.item(i)['idregistro'],
								result.rows.item(i)['codregistro'],
								result.rows.item(i)['registro'],
								result.rows.item(i)['revision'],
								result.rows.item(i)['fchpublic'],
								result.rows.item(i)['link'],
								result.rows.item(i)['anos'],
								result.rows.item(i)['lugar'],
								result.rows.item(i)['estado'],
								"<a href='"+result.rows.item(i)['fslink']+"' target='_blank'>"+linknull2+"</a>",
								result.rows.item(i)['fsname'],
								result.rows.item(i)['fslink']]);						
					};
			});
		});	
	};
}

//=========================================================================================================				
/*NUEVO DOCUMENTO*/
	function addDoc(txtcoddocumento, txtdocumento, txtrevision, txtfchpublic, txtlink, txtestado) {
		var db;
		FSError = false; nombreFS=null; rutaFS=null;//FileSystem 
		addFile("myfile");//FileSystem
        db = openDatabase("DBIWOHS", "0.1", "Database Isowin OHS", 5 * 1024 * 1024);
		if(db){
			db.transaction( function(tx) {
			tx.executeSql("INSERT INTO documentos(coddocumento, documento, revision, fchpublic, link, estado, proceso) VALUES(?,?,?,?,?,?,?)", 
										[txtcoddocumento, txtdocumento, txtrevision, txtfchpublic, txtlink, txtestado,  intProceso]);
			tx.executeSql("SELECT * FROM documentos ORDER BY iddocumento DESC", [], function(tx, result){
				idseleccionado = result.rows.item(0)["iddocumento"];
				if (!FSError) {apprise('El documento ha sido guardado');};
			});
			
			});

		setTimeout('updateFSDOCs()',300);
		setTimeout('mostrarDOCsREGs(intProceso, intEstado)',500);
		};

		 //$("#updateuser").toggle(200);
		 $(":text").val("");
	}
/*ACTUALIZAR DOCUMENTO*/
	function updateDoc(txtcoddocumento, txtdocumento, txtrevision, txtfchpublic, txtlink, txtestado) {
		var db;
		FSError = false; nombreFS=null; rutaFS=null;//FileSystem 
		addFile("myfile");//FileSystem
		db = openDatabase("DBIWOHS", "0.1", "Database Isowin OHS", 5 * 1024 * 1024);
		if(db){	
			db.transaction( function(tx) {
			tx.executeSql("UPDATE documentos SET coddocumento=?, documento=?, revision=?, fchpublic=?, link=?, estado=? WHERE iddocumento=?", 
										[txtcoddocumento, txtdocumento, txtrevision, txtfchpublic, txtlink, txtestado, idseleccionado]);
			if (!FSError) {apprise('El documento ha sido modificado');};
			});
		setTimeout('updateFSDOCs()',300);
		setTimeout('mostrarDOCsREGs(intProceso, intEstado)',500);
		};
		 $(":text").val("");				
	}

/*ACTUALIZAR ARCHIVOS*/
function updateFSDOCs() {
var db;
db = openDatabase("DBIWOHS", "0.1", "Database Isowin OHS", 5 * 1024 * 1024);
		if(db){	
		db.transaction( function(tx) {
			if (nombreFS!=null) {tx.executeSql("UPDATE documentos SET fsname=?, fslink=? WHERE iddocumento=?", [nombreFS, rutaFS, idseleccionado]);
								document.getElementById("FS").innerHTML = "<a class='doc' href='"+rutaFS+"' target='_blank'>"+nombreFS+"</a> <img src='img/miniboton.jpg' style='vertical-align:middle' onclick='deleteFS();' />";};
			});
		};
}
		
/*BORRAR DOCUMENTO*/
	function removeDoc() {
		apprise('¿Eliminar documento?', {'verify': true}, function(r) {
			if(r) {
				deleteFile();//FileSystem
				var db;
				db = openDatabase("DBIWOHS", "0.1", "Database Isowin OHS", 5 * 1024 * 1024);
				if(db){	
					db.transaction(function(tx) {
					tx.executeSql("DELETE FROM documentos WHERE iddocumento=?",[idseleccionado]);
					});
					if (!FSError) {apprise('El documento ha sido borrado');};
				};
			setTimeout('mostrarDOCsREGs(intProceso, intEstado)',500);
			$(":text").val("");
			};
		
		});
	}

/*BORRAR ARCHIVO*/
	function deleteFS() {
		deleteLinkFile('documentos');
		document.getElementById("FS").innerHTML = "<input type='file' id='myfile' />";
		setTimeout('mostrarDOCsREGs(intProceso, intEstado)',500);
	}
	
//=========================================================================================================					
/*NUEVO REGISTRO*/
	function addReg(txtcodregistro, txtregistro, txtrevreg, txtfchpublicreg, txtlinkreg, txtanos, txtlugar, txtestado) {
		var db;
		FSError = false; nombreFS=null; rutaFS=null;//FileSystem 
		addFile("myfile2");//FileSystem
        db = openDatabase("DBIWOHS", "0.1", "Database Isowin OHS", 5 * 1024 * 1024);
		if(db){	
		  db.transaction( function(tx) {
			tx.executeSql("INSERT INTO registros(codregistro, registro, revision, fchpublic, link, anos, lugar, estado, proceso) VALUES(?,?,?,?,?,?,?,?,?)", 
									[txtcodregistro, txtregistro, txtrevreg, txtfchpublicreg, txtlinkreg, txtanos, txtlugar, txtestado,  intProceso]);
			tx.executeSql("SELECT * FROM registros ORDER BY idregistro DESC", [], function(tx, result){
				idseleccionado2 = result.rows.item(0)["idregistro"];
				if (!FSError) {apprise('El registro ha sido guardado');};
			});
		});
		setTimeout('updateFSREGs()',300);
		setTimeout('mostrarDOCsREGs(intProceso, intEstado)',500);
		};		
		//Incluyo el documento en la tabla
		//$('#example2').dataTable().fnAddData( ["Nuevo",txtcodregistro, txtregistro, txtrevreg, txtfchpublicreg, txtlinkreg, txtanos, textlugar] );
		 $(":text").val("");
		 //$("#updateuserreg").toggle(200);
	}
/*ACTUALIZAR REGISTRO*/
	function updateReg(txtcodregistro, txtregistro, txtrevreg, txtfchpublicreg, txtlinkreg, txtanos, txtlugar, txtestado) {
		var db;
		FSError = false; nombreFS=null; rutaFS=null;//FileSystem 
		addFile("myfile2");//FileSystem
		db = openDatabase("DBIWOHS", "0.1", "Database Isowin OHS", 5 * 1024 * 1024);
		if(db){	
			db.transaction( function(tx) {
			tx.executeSql("UPDATE registros SET codregistro=?, registro=?, revision=?, fchpublic=?, link=?, anos=?, lugar=?, estado=?  WHERE idregistro=?", 
									[txtcodregistro, txtregistro, txtrevreg, txtfchpublicreg, txtlinkreg, txtanos, txtlugar, txtestado, idseleccionado2]);
			if (!FSError) {apprise('El registro ha sido modificado');};
			});
		};
		setTimeout('updateFSREGs()',300);
		setTimeout('mostrarDOCsREGs(intProceso, intEstado)',500);
		 $(":text").val("");$(":date").val("");	
	}	

/*ACTUALIZAR ARCHIVOS*/
function updateFSREGs() {
var db;
db = openDatabase("DBIWOHS", "0.1", "Database Isowin OHS", 5 * 1024 * 1024);
		if(db){	
		db.transaction( function(tx) {
			if (nombreFS!=null) {tx.executeSql("UPDATE registros SET fsname=?, fslink=? WHERE idregistro=?", [nombreFS, rutaFS, idseleccionado2]);
								document.getElementById("FS2").innerHTML = "<a class='doc' href='"+rutaFS+"' target='_blank'>"+nombreFS+"</a> <img src='img/miniboton.jpg' style='vertical-align:middle' onclick='deleteFS2();' />";};
			});
		};
}		

/*BORRAR REGISTRO*/
	function removeReg() {
		apprise('¿Eliminar registro?', {'verify': true}, function(r) {
			if(r) {
				var db;
				deleteFile();//FileSystem
				db = openDatabase("DBIWOHS", "0.1", "Database Isowin OHS", 5 * 1024 * 1024);
				if(db){	
					db.transaction(function(tx) {
					tx.executeSql("DELETE FROM registros WHERE idregistro=?",[idseleccionado2]);
					if (!FSError) {apprise('El registro ha sido borrado');};
					});
				};
				setTimeout('mostrarDOCsREGs(intProceso, intEstado)',500);
				$(":text").val("");
			};
		 });
	}

/*BORRAR ARCHIVOS*/
	function deleteFS2() {
		deleteLinkFile('registros');
		document.getElementById("FS2").innerHTML = "<input type='file' id='myfile2' />";
		setTimeout('mostrarDOCsREGs(intProceso, intEstado)',500);
	}

//VER BOTON SEMAFORO__________________________________________________________________________________________

//Funcion de inicialización de la pestaña, ocultando el botón rojo.
function VbInit() {document.getElementById('botonrojo').style.display = 'none';}
//valor 1 se pone rojo, valor 0 se pone verde.	
function Vb(intColor) {
	if (INTcolor!=intColor) {$("#botonrojo").toggle(200); $("#botonverde").toggle(200); INTcolor=intColor;};
	}

//__________________________________________________________________________________________
/* VER NO VER EDIT (Update+Delete)*/
var verEDOC=0;var verEREG=0;
function VnVEdoc (Vedoc) {if (verEDOC!=Vedoc) {$("#editdoc").toggle(200); verEDOC=Vedoc;};}
function VnVEreg (Vereg) {if (verEREG!=Vereg) {$("#editreg").toggle(200); verEREG=Vereg;};}

//__________________________________________________________________________________________
//FILE SYSTEM_______________________________________________________________________________

window.requestFileSystem = window.requestFileSystem || window.webkitRequestFileSystem;
var fs = null;
var FSError = false;//Utilizada para no mostrar mensajes de aceptación, mostrando únicamente el mensaje de error.

//Gestor de errores
	function errorHandler(e) {
        var msg = '';
        switch (e.code) {
          case FileError.QUOTA_EXCEEDED_ERR: msg = 'QUOTA_EXCEEDED_ERR'; break;
          case FileError.NOT_FOUND_ERR: msg = 'NOT_FOUND_ERR';break;
          case FileError.SECURITY_ERR: msg = 'SECURITY_ERR'; break;
          case FileError.INVALID_MODIFICATION_ERR: msg = 'INVALID_MODIFICATION_ERR';
          	rutaFS = null; nombreFS = null;
          	apprise('Existe un archivo con el mismo nombre en la aplicación. Por favor, cambia el nombre y vuelve a intentarlo.');
          	break;
          case FileError.INVALID_STATE_ERR: msg = 'INVALID_STATE_ERR'; break;
          default: msg = 'Unknown Error'; break;
        };
        FSError = true;
        console.log ('ErrorHandler dice: ' + msg);
      }
//Inicialización del FileSystem PERSISTENT
      function initFSPersistent() {
        navigator.webkitPersistentStorage.requestQuota(500*1024*1024, function(grantedBytes) {
          window.requestFileSystem(PERSISTENT, grantedBytes, function (filesystem) {
            fs = filesystem; 
            console.log('Opened file system: ' + fs.name);
          }, errorHandler);}, 
        function(e) {console.log('Error', e);});
      }
      // Initiate filesystem on page load.
      if (window.requestFileSystem) {
        initFSPersistent();
      }
//_______________________________________________________________________________
// FILESYSTEM: Creates a file if it doesn't exist.
// Throws an error if a file already exists with the same name.
var rutaFS = null; var nombreFS = null;

var writeFile = function(parentDirectory, file) {
parentDirectory.getFile(file.name, {create: true, exclusive: true},
function(fileEntry) {
		nombreFS = fileEntry.name;
		rutaFS = fileEntry.toURL();
	fileEntry.createWriter(function(fileWriter) {
		fileWriter.write(file);
		//console.log("Ruta del archivo en FileSystem:" + rutaFS);
		}, errorHandler);
	}, errorHandler);
};

function addFile(myfile) {
if (document.getElementById(myfile)) { //Elimina errores por no estar visualizandose el selector de archivo.
//if (document.getElementById(myfile).value != null) {//Evita sobreescribir la ruta de un archivo con código blanco.
	var file = document.getElementById(myfile).files[0];
	if (file) {writeFile(fs.root, file);};
	document.getElementById(myfile).value = null;
	};//};
}

function deleteFile() {
 fs.root.getFile(nombreFS, {create: false}, function(fileEntry) {
    	fileEntry.remove(function() {
      		//console.log('Archivo borrado: '+nombreFS);
    	}, errorHandler);
  }, errorHandler);
}

//FILESYSTEM: Ampliación a gestión de varios archivos en un único formulario................................

var write2File = function(parentDirectory, file, ndoc) {
parentDirectory.getFile(file.name, {create: true, exclusive: true},
function(fileEntry) {
		//Actualizo variables según el número de documento a subir.
		if (ndoc==2) {nombreFS2 = fileEntry.name; rutaFS2 = fileEntry.toURL();};
		if (ndoc==3) {nombreFS3 = fileEntry.name; rutaFS3 = fileEntry.toURL();};
		if (ndoc==4) {nombreFS4 = fileEntry.name; rutaFS4 = fileEntry.toURL();};

	fileEntry.createWriter(function(fileWriter) {
		fileWriter.write(file);
		//console.log("write2File: Ruta del archivo en FileSystem:" + fileEntry.toURL());
		}, errorHandler);
	}, errorHandler);
};

function add2File(myfile2, ndoc) {
if (document.getElementById(myfile2)) {//Elimina errores por no estar visualizandose el selector de archivo.
//if (document.getElementById(myfile2).value != null) {//Evita sobreescribir la ruta de un archivo con código blanco.
	var file = document.getElementById(myfile2).files[0];
	if (file) {write2File(fs.root, file, ndoc);};
	document.getElementById(myfile2).value = null;
	};//};
}

function delete2File(nombre) {
 fs.root.getFile(nombre, {create: false}, function(fileEntry) {
    	fileEntry.remove(function() {
      		//console.log('delete2File: Archivo borrado: '+ nombre);
    	}, errorHandler);
  }, errorHandler);
}

//Funcionalidad del botón (minibotón) que hay al lado del link al documento.....................................
function deleteLinkFile(tabla) {
	var db;//Elimino las referencias en la base de datos
	db = openDatabase("DBIWOHS", "0.1", "Database Isowin OHS", 5 * 1024 * 1024);
	if(db){	
		db.transaction( function(tx) {
		tx.executeSql("UPDATE "+ tabla +" SET fsname=?, fslink=? WHERE fsname=?", [null, null, nombreFS]);
		});
	};
	deleteFile();//Borro el archivo del FileSystem

    //console.log('deleteLinkFile: Archivo borrado: '+ nombreFS);
}

function delete2LinkFile(tabla, ndoc) {

	var nombreFSaux; var fsnameaux; var fslinkaux;

	if (ndoc==1) {nombreFSaux = nombreFS; fsnameaux='fsname'; fslinkaux='fslink';};
	if (ndoc==2) {nombreFSaux = nombreFS2; fsnameaux='fsname2'; fslinkaux='fslink2';};
	if (ndoc==3) {nombreFSaux = nombreFS3; fsnameaux='fsname3'; fslinkaux='fslink3';};
	if (ndoc==4) {nombreFSaux = nombreFS3; fsnameaux='fsname4'; fslinkaux='fslink4';};

	var db;//Elimino las referencias en la base de datos
	db = openDatabase("DBIWOHS", "0.1", "Database Isowin OHS", 5 * 1024 * 1024);
	if(db){	
		db.transaction( function(tx) {
		tx.executeSql("UPDATE "+ tabla +" SET "+ fsnameaux +"=?, "+ fslinkaux +"=? WHERE "+ fsnameaux +"=?", [null, null, nombreFSaux]);
		});
	};
	delete2File(nombreFSaux);//Borro el archivo del FileSystem

    //console.log('delete2LinkFile: Archivo borrado: '+ nombreFSaux);
    //console.log("UPDATE "+ tabla +" SET "+ fsnameaux +"=?, "+ fslinkaux +"=? WHERE "+ fsnameaux +"=?");
}
//__________________________________________________________________________________________