//CALIBRACIONES (10 y 11)

	var idseleccionado10;
	var idseleccionado11;
	var intEstado10;
	var INTcolor10 = 0; //Color del semaforo en verde
				
				
//TABLA EQUIPOS_____________________________________________________________________________________________________________

function mostrarEquipos(intEst10) {
	intEstado10=intEst10;
	sacarEquipos (intEstado10);
	setTimeout('listEquipos()',500);
	Vb10(intEst10);
	}

function listEquipos() {
		$(document).ready(			
			function () {
				$('#dynamic10').html( '<table cellpadding="0" cellspacing="0" border="0" class="display" id="example10"></table>' );
				$('#example10').dataTable( {
					"aaData": aDataSet10,
						
					
					"aoColumns": [
						{ "sTitle": "Id"/*, "bSearchable": false, "bVisible": false*/ },
						{ "sTitle": "Equipo" },
						{ "sTitle": "Marca" },
						{ "sTitle": "Modelo" },
						{ "sTitle": "S/N" },
						{ "sTitle": "Rango", "bSearchable": false, "bVisible": false },
						{ "sTitle": "Escalon", "bSearchable": false, "bVisible": false},
						{ "sTitle": "Uso", "bSearchable": false, "bVisible": false },
						{ "sTitle": "umax" },
						{ "sTitle": "fchprox", "bSearchable": false, "bVisible": false },
						{ "sTitle": "Estado", "bSearchable": false, "bVisible": false },
						{ "sTitle": "Observaciones", "bSearchable": false, "bVisible": false }
						],
						
					"sScrollY": "600px",
        			"bPaginate": false,
        			"bScrollCollapse": true,
						
					"sDom": 'lfrtip<"clear spacer">T',
					/*"sDom": 'T<"clear">lfrtip<"clear spacer">T',*/ //Muestra los botones de copy,print...
					"oTableTools": {
						"sRowSelect": "single","aButtons": ["select"], //Solo me muestra el boton select para poder seleccionar las filas.
							
					"aoColumnDefs": [ {
						"sClass": "center",
						"aTargets": [ -1, -2 ]
						} ]
						
				}});
				
				});
	//Cargar datos del equipo para editar en formulario	
			$(document).ready(
				function() {
    			$('#example10 tbody td').click( function () {
        		/* Get the position of the current data from the node */
        		var aPos10 = oTable10.fnGetPosition( this );
         
        		/* Get the data array for this row */
        		var aData10 = oTable10.fnGetData( aPos10[0] );
				/*alert("Ok "+aData[0]);*/
				
				idseleccionado10 =  aData10[0];
				document.getElementById("txtequipo").value = aData10[1];
				document.getElementById("txtemarca").value = aData10[2];
				document.getElementById("txtemodelo").value = aData10[3];
				document.getElementById("txtesn").value = aData10[4];
				document.getElementById("txterango").value = aData10[5];
				document.getElementById("txteescalon").value = aData10[6];
				document.getElementById("txteuso").value = aData10[7];
				document.getElementById("txteumax").value = aData10[8];
				document.getElementById("txtefchprox").value = aData10[9];
				document.getElementById("comboeestado").value = aData10[10];
				document.getElementById("txteobs").value = aData10[11];
			
			DatosBDcals(idseleccionado10);
			setTimeout('listCals()',200);				
			
			VnV10 (1, 0, 0, 1);
         
    			});
     
   				 /* Init DataTables */
   				 oTable10= $('#example10').dataTable();
				});
		
	}

//DATOS EQUIPOS_________________________________________________

function sacarEquipos (intEstado10){
	var db;
        db = openDatabase("DBIW1", "0.1", "Database Isowin One", 200000);	
	
	var estado10="WHERE estado!='Fuera de Uso' ";
	if (intEstado10==1) {estado10="WHERE estado='Fuera de Uso' ";};

	if(db){
		db.transaction( function(tx) {
			tx.executeSql("SELECT * FROM equipos " + estado10, [],
				function(tx, result){
					//Creo un array
					/*var output = [];*/
					//Guardo en cada elemento i del vector, un objeto documento.
					aDataSet10 = [];
					for(var i=0; i < result.rows.length; i++) {
/*						output.push([result.rows.item(i)['iddocumento'],
								result.rows.item(i)['documento'],
								result.rows.item(i)['revision']]);*/		
						aDataSet10.push([result.rows.item(i)['idequipo'],
								result.rows.item(i)['equipo'],
								result.rows.item(i)['marca'],
								result.rows.item(i)['modelo'],
								result.rows.item(i)['sn'],
								result.rows.item(i)['rango'],
								result.rows.item(i)['escalon'],
								result.rows.item(i)['uso'],
								result.rows.item(i)['umax'],
								result.rows.item(i)['fchprox'],
								result.rows.item(i)['estado'],
								result.rows.item(i)['obs'],
								]);
					};						
				});
		});	
	};
}
	
//TABLA CALIBRACIONES_____________________________________________________________________________________________________________

function listCals() {
		$(document).ready(			
			function () {
				$('#dynamic11').html( '<table cellpadding="0" cellspacing="0" border="0" class="display" id="example11"></table>' );
				$('#example11').dataTable( {
					"aaData": aDataSet11,
						
					"aoColumns": [
						{ "sTitle": "Id"/*, "bSearchable": false, "bVisible": false*/ },
						{ "sTitle": "IdEquipo", "bSearchable": false, "bVisible": false },
						{ "sTitle": "Accion" },
						{ "sTitle": "U" },
						{ "sTitle": "Fecha calibración" },
						{ "sTitle": "Link Certificado", "bSearchable": false, "bVisible": false },
						{ "sTitle": "Observaciones", "bSearchable": false, "bVisible": false }
						],
						
					"sScrollY": "250px",
        			"bPaginate": false,
        			"bScrollCollapse": true,
						
					"sDom": 'lfrtip<"clear spacer">T',
					/*"sDom": 'T<"clear">lfrtip<"clear spacer">T',*/ //Muestra los botones de copy,print...
					"oTableTools": {
						"sRowSelect": "single","aButtons": ["select"], //Solo me muestra el boton select para poder seleccionar las filas.
							
					"aoColumnDefs": [ {
						"sClass": "center",
						"aTargets": [ -1, -2 ]
						} ]
						
				}});
				
				});
	//Cargar datos de la calibración para editar en formulario	
		$(document).ready(
				function() {
    			$('#example11 tbody td').click( function () {
        		/* Get the position of the current data from the node */
        		var aPos11 = oTable11.fnGetPosition( this );
         
        		/* Get the data array for this row */
        		var aData11 = oTable11.fnGetData( aPos11[0] );
				/*alert("Ok "+aData[0]);*/
				
				idseleccionado11 =  aData11[0];
				//el aData9[1] es el idDiseno
				document.getElementById("txtcaltipo").value = aData11[2];
				document.getElementById("txtcalu").value = aData11[3];
				document.getElementById("txtcalfchcal").value = aData11[4];
				document.getElementById("txtcallinkcert").value = aData11[5];
				document.getElementById("txtcalobs").value = aData11[6];
				
				VnV10 (1, 0, 1, 1);
         
    			});
     
   				 /* Init DataTables */
   				 oTable11= $('#example11').dataTable();
				});
		
	}

//DATOS CALIBRACIONES FILTRADAS POR EQUIPO______________________________________________________________________
		
function DatosBDcals(idseleccionado10) {
	var db;
        db = openDatabase("DBIW1", "0.1", "Database Isowin One", 200000);
		if(db){	
		db.transaction( function(tx) {
			tx.executeSql("SELECT * FROM calibraciones WHERE idequipo=?", [idseleccionado10],
				function(tx, result){
					//Creo un array
					/*var output = [];*/
					//Guardo en cada elemento i del vector, un objeto documento.
					aDataSet11 = [];
					for(var i=0; i < result.rows.length; i++) {
/*						output.push([result.rows.item(i)['iddocumento'],
								result.rows.item(i)['documento'],
								result.rows.item(i)['revision']]);*/
								
						aDataSet11.push([result.rows.item(i)['idcal'],
								result.rows.item(i)['idequipo'],
								result.rows.item(i)['tipo'],
								result.rows.item(i)['u'],
								result.rows.item(i)['fchcal'],
								result.rows.item(i)['linkcert'],
								result.rows.item(i)['obs']]);
												
				}		
   				 /* Init DataTables */
   				 oTable11 = $('#example11').dataTable();				
				 
				});
				
				
		});
		
	}}

	

//=========================================================================================================					
/*NUEVO EQUIPO*/
	
	function addEquipo(equipo, marca, modelo, sn, rango, escalon, uso, umax, fchprox, estado, obs) {
			
		var db;
		db = openDatabase("DBIW1", "0.1", "Database Isowin One", 200000);
		if(db){	
		  db.transaction( function(tx) {
			tx.executeSql("INSERT INTO equipos (equipo, marca, modelo, sn, rango, escalon, uso, umax, fchprox, estado, obs) VALUES(?,?,?,?,?,?,?,?,?,?,?)", [equipo, marca, modelo, sn, rango, escalon, uso, umax, fchprox, estado, obs]);
			tx.executeSql("SELECT * FROM equipos", [], function(tx, result){
				nuevoId = result.rows.item(result.rows.length-1)["idequipo"];
				
				CEXaddCita( "Calibración: " + equipo, fchprox, fchprox, "Calibrar el equipo " + equipo + " (" + marca + ", " + modelo + ") con Nº Serie: " + sn, "ECA" + nuevoId);
				apprise('El equipo ha sido guardado'); //alert("Equipo guardado: "+ equipo);
				});
			});
		};
		setTimeout('mostrarEquipos(intEstado10);',500);
		VnV10 (0, 1, 0, 0);
	}
	
/*ACTUALIZAR EQUIPO*/
	function updateEquipo (equipo, marca, modelo, sn, rango, escalon, uso, umax, fchprox, estado, obs) {
		
		var db;
		db = openDatabase("DBIW1", "0.1", "Database Isowin One", 200000);
		if(db){	
			db.transaction( function(tx) {
				tx.executeSql("UPDATE equipos SET equipo=?, marca=?, modelo=?, sn=?, rango=?, escalon=?, uso=?, umax=?, fchprox=?, estado=?, obs=?   WHERE idequipo=?", [equipo, marca, modelo, sn, rango, escalon, uso, umax, fchprox, estado, obs, idseleccionado10]);
				CEXupdateCita("Calibración: " + equipo, fchprox, fchprox, "Calibrar el equipo " + equipo + " (" + marca + ", " + modelo + ") con Nº Serie: " + sn, "ECA" + idseleccionado10);
				apprise('El equipo ha sido modificado'); //alert("Equipo ha cambiado: "+ equipo + " - " + idseleccionado10);
			});
		};
		setTimeout('mostrarEquipos(intEstado10)',500);
	}					

/*BORRAR EQUIPO*/
	function removeEquipo() {
		apprise('¿Eliminar el equipo?', {'verify': true}, function(r) {
			if(r) { 
				var db;
				db = openDatabase("DBIW1", "0.1", "Database Isowin One", 200000);
				if(db){	
					db.transaction(function(tx) {
						tx.executeSql("DELETE FROM equipos WHERE idequipo=?",[idseleccionado10]);
						tx.executeSql("DELETE FROM calibraciones WHERE idequipo=?",[idseleccionado10]); //limpia calibraciones asociadas.
						});
					CEXdeleteCita("ECA" + idseleccionado10);
					apprise('El equipo ha sido borrado'); //alert("Equipo borrado: "+ idseleccionado10);
				};
			setTimeout('mostrarEquipos(intEstado10)',500);
			};
		});
		 VnV10 (0, 1, 0, 0);
	}
	
//=========================================================================================================					
/*NUEVA CALIBRACIÓN*/
	
	function addCal (tipo, u, fchcal, linkcert, obs) {
		
		var db;
		db = openDatabase("DBIW1", "0.1", "Database Isowin One", 200000);
		if(db){	
		  db.transaction( function(tx) {
			tx.executeSql("INSERT INTO calibraciones (idequipo, tipo, u, fchcal, linkcert, obs) VALUES(?,?,?,?,?,?)", [ idseleccionado10, tipo, u, fchcal, linkcert, obs]);
			apprise('Calibración guardada'); //alert("Calibración guardada: "+ fchcal);
		})};
		
		DatosBDcals(idseleccionado10);
		setTimeout('listCals()',200);
	}
	
/*ACTUALIZAR CALIBRACIÓN*/
	function updateCal (tipo, u, fchcal, linkcert, obs) {
		var db;
		db = openDatabase("DBIW1", "0.1", "Database Isowin One", 200000);
		if(db){	
		  db.transaction( function(tx) {
			tx.executeSql("UPDATE calibraciones SET idequipo=?, tipo=?, u=?, fchcal=?, linkcert=?, obs=?  WHERE idcal=?", [ idseleccionado10, tipo, u, fchcal, linkcert, obs, idseleccionado11]);
			apprise('La calibración ha sido modificada'); //alert("La calibración ha cambiado: "+ fchcal + " - " + idseleccionado11);
		})};
		
		DatosBDcals(idseleccionado10);
		setTimeout('listCals()',200);	
	}

/*BORRAR CALIBRACIÓN*/
	function removeCal () {
		var answer = confirm ("¿Eliminar calibración?");
		if (answer) {
			var db;
			db = openDatabase("DBIW1", "0.1", "Database Isowin One", 200000);
			if(db){	
				db.transaction(function(tx) {
					tx.executeSql("DELETE FROM calibraciones WHERE idcal=?",[idseleccionado11]);
					apprise('La calibración ha sido borrada'); //alert("Calibración borrada: "+ idseleccionado11);
				});
			};
		};
		DatosBDcals(idseleccionado10);
		setTimeout('listCals()',200);
	}

//=========================================================================================================
/* VER NO VER*/
var verNEQ= 0; var verLEQ= 1; var verNCA= 0; var verLCA= 0;

function VnV10 (Vneq, Vleq, Vnca, Vlca) { 
	if (verNEQ!=Vneq) {$("#newequipo").toggle(200); verNEQ=Vneq; $("#txtequipo").focus();};
	if (verLEQ!=Vleq) {$("#listaequipos").toggle(200); verLEQ=Vleq;};
	if (verNCA!=Vnca) {$("#newcal").toggle(200); verNCA=Vnca; $("#txtcaltipo").focus();};
	if (verLCA!=Vlca) {$("#listacals").toggle(200); verLCA=Vlca;};
}
//=========================================================================================================	

//VER BOTON SEMAFORO_______________________________________________________________________

//Funcion de inicializaci�n de la pesta�a, ocultando el bot�n rojo.
function VbInit10() {document.getElementById('botonrojo10').style.display = 'none';}
//valor 1 se pone rojo, valor 0 se pone verde.	
function Vb10(intColor10) {
	if (INTcolor10!=intColor10) {$("#botonrojo10").toggle(200); $("#botonverde10").toggle(200); INTcolor10=intColor10;};
	}
//__________________________________________________________________________________________

	