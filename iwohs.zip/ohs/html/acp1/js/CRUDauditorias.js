//AUDITORIAS (17)

	
	var idseleccionado17;
	var idseleccionado17b;			
				
//TABLA AUDITORIAS_________________________________________________________________________________________________________

function mostrarAuditorias() {
	sacarAuditorias ();
	setTimeout('listAuditorias()', 500);
	}

function listAuditorias() {
			$(document).ready(			
			function () {
				$('#dynamic17').html( '<table cellpadding="0" cellspacing="0" border="0" class="display" id="example17"></table>' );
				$('#example17').dataTable( {
					"aaData": aDataSet17,
						
					"aoColumns": [
						{ "sTitle": "Id"/*, "bSearchable": false, "bVisible": false*/ },
						{ "sTitle": "Auditoría" },
						{ "sTitle": "Cod Auditoría", "bSearchable": false, "bVisible": false },
						{ "sTitle": "Estado"},
						{ "sTitle": "F. Inicio"},
						{ "sTitle": "F. Fin" },
						{ "sTitle": "Auditor Jefe", "bSearchable": false, "bVisible": false  },
						{ "sTitle": "Auditores", "bSearchable": false, "bVisible": false },
						{ "sTitle": "Observadores", "bSearchable": false, "bVisible": false },
						{ "sTitle": "Alcance", "bSearchable": false, "bVisible": false },
						{ "sTitle": "NC" },
						{ "sTitle": "DL" },
						{ "sTitle": "AM" },
						{ "sTitle": "Link Planificacion", "bSearchable": false, "bVisible": false },
						{ "sTitle": "Link Informe", "bSearchable": false, "bVisible": false },
						{ "sTitle": "Link PAC", "bSearchable": false, "bVisible": false },
						{ "sTitle": "Distribución", "bSearchable": false, "bVisible": false },
						{ "sTitle": "Obs", "bSearchable": false, "bVisible": false },
						],
						
				"sScrollY": "430px",
        			"bPaginate": false,
        			"bScrollCollapse": true,
						
					"sDom": 'lfrtip<"clear spacer">T',
					/*"sDom": 'T<"clear">lfrtip<"clear spacer">T',*/ //Muestra los botones de copy,print...
					"oTableTools": {
						"sRowSelect": "single","aButtons": ["select"], //Solo me muestra el boton select para poder seleccionar las filas.
							
					"aoColumnDefs": [ {
						"sClass": "center",
						"aTargets": [ -1, -2 ]
						} ]
						
						}
					});
					
				//Cargo el COMBOBOX de responsables en el formulario ACP------------
				setTimeout('$("#comboauauditorjefe").html(nuevosresponsables); $("#comboauauditor").html(nuevosresponsables); $("#comboauobservador").html(nuevosresponsables); $("#comboauncresp").html(nuevosresponsables); $("#comboauacpresp2").html(nuevosresponsables);',200);
				//--------------------------------------------------
				
				});
	//Cargar datos de proveedor para editar en formulario	
			$(document).ready(
				function() {
    			$('#example17 tbody td').click( function () {
        		var aPos17 = oTable17.fnGetPosition( this );
        		var aData17 = oTable17.fnGetData( aPos17[0] );
				
				idseleccionado17 =  aData17[0];
				document.getElementById("txtauauditoria").value = aData17[1];
				document.getElementById("txtaucodauditoria").value = aData17[2];
				document.getElementById("txtauestado").value = aData17[3];
				document.getElementById("txtaufchinicio").value = aData17[4];
				document.getElementById("txtaufchfin").value = aData17[5];
				document.getElementById("comboauauditorjefe").value = aData17[6];
				document.getElementById("comboauauditor").value = aData17[7];
				document.getElementById("comboauobservador").value = aData17[8];
				document.getElementById("txtaualcance").value = aData17[9];
				document.getElementById("txtaunnc").value = aData17[10];
				document.getElementById("txtaundl").value = aData17[11];
				document.getElementById("txtaunam").value = aData17[12];
				document.getElementById("txtaulinkplanificacion").value = aData17[13];
				document.getElementById("txtaulinkinforme").value = aData17[14];
				document.getElementById("txtaulinkpac").value = aData17[15];
				document.getElementById("txtaudistribucion").value = aData17[16];
				document.getElementById("txtauobs").value = aData17[17];
				
			DatosBDAuNCs(idseleccionado17);
			setTimeout('listAuNCs();', 200);
			
    			});
     
   				 /* Init DataTables */
   				 oTable17 = $('#example17').dataTable();
				});
		
	}	
	
function sacarAuditorias (){
	var db;
        db = openDatabase("DBIW1", "0.1", "Database Isowin One", 200000);	
	if(db){
		db.transaction( function(tx) {
			tx.executeSql("SELECT * FROM auditorias", [], function(tx, result){
					aDataSet17 = [];
					for(var i=0; i < result.rows.length; i++) {		
						aDataSet17.push([result.rows.item(i)['idauditoria'],
								result.rows.item(i)['auditoria'],
								result.rows.item(i)['codauditoria'],
								result.rows.item(i)['estado'],
								result.rows.item(i)['fchinicio'],
								result.rows.item(i)['fchfin'],
								result.rows.item(i)['auditorjefe'],
								result.rows.item(i)['auditores'],
								result.rows.item(i)['observadores'],
								result.rows.item(i)['alcance'],
								result.rows.item(i)['nnc'],
								result.rows.item(i)['ndl'],
								result.rows.item(i)['nam'],
								result.rows.item(i)['linkplanificacion'],
								result.rows.item(i)['linkinforme'],
								result.rows.item(i)['linkpac'],
								result.rows.item(i)['distribucion'],
								result.rows.item(i)['obs'],
								]);
					}			
				 
			});
		});
		
		
	};
}

//=========================================================================================================					
/*NUEVA AUDITORIA*/
	function addAuditoria(auditoria, codauditoria, estado, fchinicio, fchfin, auditorjefe, auditores, observadores, alcance, nnc, ndl, nam, linkplanificacion, linkinforme, linkpac, distribucion, obs) {
		var db; var nuevoId = "vacio";
		db = openDatabase("DBIW1", "0.1", "Database Isowin One", 200000);
		if(db){	
			db.transaction( function(tx) {
			tx.executeSql("INSERT INTO auditorias (auditoria, codauditoria, estado, fchinicio, fchfin, auditorjefe, auditores, observadores, alcance, nnc, ndl, nam, linkplanificacion, linkinforme, linkpac, distribucion, obs) VALUES(?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)", [auditoria, codauditoria, estado, fchinicio, fchfin, auditorjefe, auditores, observadores, alcance, nnc, ndl, nam, linkplanificacion, linkinforme, linkpac, distribucion, obs]);
			tx.executeSql("SELECT * FROM auditorias", [], function(tx, result){
					nuevoId = result.rows.item(result.rows.length-1)["idauditoria"];
					CEXaddCita("Auditor�a" + codauditoria, fchinicio, fchfin, auditoria, "AU"+nuevoId);
					apprise('La auditor�a ha sido guardada');
				});
			});
		};
		setTimeout('mostrarAuditorias()',500);
	}
	
/*ACTUALIZAR AUDITORIA*/
		function updateAuditoria(auditoria, codauditoria, estado, fchinicio, fchfin, auditorjefe, auditores, observadores, alcance, nnc, ndl, nam, linkplanificacion, linkinforme, linkpac, distribucion, obs) {
		var db;
		db = openDatabase("DBIW1", "0.1", "Database Isowin One", 200000);
		if(db){	
		db.transaction( function(tx) {
			tx.executeSql("UPDATE auditorias SET auditoria=?, codauditoria=?, estado=?, fchinicio=?, fchfin=?, auditorjefe=?, auditores=?, observadores=?, alcance=?, nnc=?, ndl=?, nam=?, linkplanificacion=?, linkinforme=?, linkpac=?, distribucion=?, obs=?  WHERE idauditoria=?", [auditoria, codauditoria, estado, fchinicio, fchfin, auditorjefe, auditores, observadores, alcance, nnc, ndl, nam, linkplanificacion, linkinforme, linkpac, distribucion, obs, idseleccionado17]);
			 CEXupdateCita("Auditor�a" + codauditoria, fchinicio, fchfin, auditoria, "AU"+ idseleccionado17);
			apprise('La auditor�a ha sido actualizada');//alert("Auditoría modificada: "+ idseleccionado17);
			});
		};
		setTimeout('mostrarAuditorias()',500);
	}					

/*BORRAR AUDITORIA*/
	function removeAuditoria() {
		apprise('¿Eliminar la Auditor�a?', {'verify': true}, function(r) {
			if(r) { 
				var db;
				db = openDatabase("DBIW1", "0.1", "Database Isowin One", 200000);
				if(db){	
					db.transaction(function(tx) {
					tx.executeSql("DELETE FROM auditorias WHERE idauditoria=?",[idseleccionado17]); 	//Borro al Padre
					tx.executeSql("DELETE FROM ncs WHERE origen=?",[idseleccionado17]); 	// Borro a los hijos
					CEXdeleteCita("AU"+idseleccionado17);								//Borro al espíritu santo
					apprise('La auditor�a ha sido borrada');//alert("Auditoría borrada: "+ idseleccionado17);
					});
				};
			setTimeout('mostrarAuditorias()',500);
			};
		});
	}

//============================================================================================================================================================================			

//TABLA NCS de AUDITORIAS_________________________________________________________________________________________________________

function mostrarAuNCs() {
	DatosBDAuNCs(idseleccionado17);
	setTimeout('listAuNCs()', 500);
	}
	
	function listAuNCs() {
			$(document).ready(			
			function () {
				$('#dynamic17b').html( '<table cellpadding="0" cellspacing="0" border="0" class="display" id="example17b"></table>' );
				$('#example17b').dataTable( {
					"aaData": aDataSet17b,
						
					"aoColumns": [
						{ "sTitle": "Id"/*, "bSearchable": false, "bVisible": false*/ },
						{ "sTitle": "No Conformidad" },
						{ "sTitle": "Cod N.C.P." },
						{ "sTitle": "Proceso" },
						{ "sTitle": "Origen" },
						{ "sTitle": "F. Creacion"},
						{ "sTitle": "F. Cierre" },
						{ "sTitle": "Responsable", "bSearchable": false, "bVisible": false },
						{ "sTitle": "Descripcion", "bSearchable": false, "bVisible": false },
						{ "sTitle": "Causas", "bSearchable": false, "bVisible": false },
						{ "sTitle": "Correccion", "bSearchable": false, "bVisible": false },
						{ "sTitle": "Cod A.C." }
						],
						
					"sScrollY": "430px",
        			"bPaginate": false,
        			"bScrollCollapse": true,
						
					"sDom": 'lfrtip<"clear spacer">T',
					/*"sDom": 'T<"clear">lfrtip<"clear spacer">T',*/ //Muestra los botones de copy,print...
					"oTableTools": {
						"sRowSelect": "single","aButtons": ["select"], //Solo me muestra el boton select para poder seleccionar las filas.
							
					"aoColumnDefs": [ {
						"sClass": "center",
						"aTargets": [ -1, -2 ]
						} ]
						
				}});
				
				});
	//Cargar datos de proveedor para editar en formulario	
			$(document).ready(
				function() {
    			$('#example17b tbody td').click( function () {
        		/* Get the position of the current data from the node */
        		var aPos17b = oTable17b.fnGetPosition( this );
         
        		/* Get the data array for this row */
        		var aData17b = oTable17b.fnGetData( aPos17b[0] );
				/*alert("Ok "+aData[0]);*/
				
				idseleccionado17b =  aData17b[0];
				document.getElementById("txtaunc").value = aData17b[1];
				document.getElementById("txtaucodnc").value = aData17b[2];
				document.getElementById("txtauncorigen").value = aData17b[4];
				document.getElementById("txtauncfchinicio").value = aData17b[5];
				document.getElementById("txtauncfchfin").value = aData17b[6];
				document.getElementById("comboauncresp").value = aData17b[7];
				document.getElementById("txtauncdescripcion").value = aData17b[8];
				document.getElementById("txtaunccausas").value = aData17b[9];
				document.getElementById("txtaunccorreccion").value = aData17b[10];
				document.getElementById("txtaunccodacp").value = aData17b[11];
				
         
    			});
     
   				 /* Init DataTables */
   				 oTable17b = $('#example17b').dataTable();
				});
		
	}	

//DATOS AuNC FILTRADAS POR AUDITORIA______________________________________________________________________
		
function DatosBDAuNCs(idseleccionado17) {
	var db;
        db = openDatabase("DBIW1", "0.1", "Database Isowin One", 200000);
		if(db){	
		db.transaction( function(tx) {
			tx.executeSql("SELECT * FROM ncs WHERE proceso=?", [idseleccionado17],
				function(tx, result){
					aDataSet17b = [];
					for(var i=0; i < result.rows.length; i++) {
								
						aDataSet17b.push([result.rows.item(i)['idnc'],
								result.rows.item(i)['nc'],
								result.rows.item(i)['codnc'],
								result.rows.item(i)['proceso'],
								result.rows.item(i)['origen'],
								result.rows.item(i)['fchinicio'],
								result.rows.item(i)['fchfin'],
								result.rows.item(i)['responsable'],
								result.rows.item(i)['descripcion'],
								result.rows.item(i)['causas'],
								result.rows.item(i)['correccion'],
								result.rows.item(i)['codacp']]);
												
				}		
   				 /* Init DataTables */
   				 oTable17b = $('#example17b').dataTable();				
				 
				});
				
				
		});
		
	}}
	
//=========================================================================================================					
/*NUEVA AuNC*/
	function addAuNC(nc, codnc, origen, fchinicio, fchfin, responsable, descripcion, causas, correccion, codacp) {
		var db;
		db = openDatabase("DBIW1", "0.1", "Database Isowin One", 200000);
		if(db){	
		  db.transaction( function(tx) {
			tx.executeSql("INSERT INTO ncs(nc, codnc, proceso, origen, fchinicio, fchfin, responsable, descripcion, causas, correccion, codacp) VALUES(?,?,?,?,?,?,?,?,?,?,?)", [nc, codnc, idseleccionado17, origen, fchinicio, fchfin, responsable, descripcion, causas, correccion, codacp]);
			apprise('La No Conformidad ha sido guardada');//alert("NC guardada: "+ nc);
		})};
		setTimeout('mostrarAuNCs()',1000);
	}
	
/*ACTUALIZAR AuNC*/
		function updateAuNC(nc, codnc, origen, fchinicio, fchfin, responsable, descripcion, causas, correccion, codacp) {
		var db;
        db = openDatabase("DBIW1", "0.1", "Database Isowin One", 200000);
		if(db){	
		  db.transaction( function(tx) {
			tx.executeSql("UPDATE ncs SET nc=?, codnc=?, proceso=?, origen=?, fchinicio=?, fchfin=?, responsable=?, descripcion=?, causas=?, correccion=?, codacp=?  WHERE idnc=?", [nc, codnc,  idseleccionado17, origen, fchinicio, fchfin, responsable, descripcion, causas, correccion, codacp, idseleccionado17b]);
			apprise('La No Conformidad ha sido actualizada');//alert("NC ha cambiado: "+ nc + " - " + idseleccionado17b);
		})};
		setTimeout('mostrarAuNCs()',1000);}					

/*BORRAR AuNC*/
	function removeAuNC() {
		apprise('¿Eliminar la No Conformidad?', {'verify': true}, function(r) {
			if(r) { 
				var db;
				db = openDatabase("DBIW1", "0.1", "Database Isowin One", 200000);
				if(db){	
					db.transaction(function(tx) {
					tx.executeSql("DELETE FROM ncs WHERE idnc=?",[idseleccionado17b]);
					apprise('La No Conformidad ha sido borrada');//alert("NC Prov borrada: "+ idseleccionado17b);
					});
				};
			setTimeout('mostrarAuNCs()',1000);	
			};
		});
	}
	

//=========================================================================================================					
/*NUEVA APC17*/
	function addACP17 (acp, codacp, tipo, fchalta, responsable, equipo, acciones, fchprevista) {
		var origen =  "La No Conformidad: " +  idseleccionado17b + " de la Auditoría: " +  idseleccionado17;
		var codtrz = "au"+ idseleccionado17b;
		addMiniACP(acp, codacp, tipo, origen, fchalta, responsable, equipo, acciones, fchprevista, codtrz);
	}
	
//=========================================================================================================
/* VER NO VER*/
var verNAU= 1; var verLAU= 1; var verNNC= 0; var verLNC= 0; var verNAC2= 0;

function VnV17 (Vnau, Vlau, Vnnc, Vlnc, Vnac2) { 
	if (verNAU!=Vnau) {$("#newauditoria").toggle(200); verNAU=Vnau; $("#txtauauditoria").focus();};
	if (verLAU!=Vlau) {$("#listaauditorias").toggle(200); verLAU=Vlau;};
	if (verNNC!=Vnnc) {$("#newaunc").toggle(200); verNNC=Vnnc; $("#txtaunc").focus();};
	if (verLNC!=Vlnc) {$("#listaauncs").toggle(200); verLNC=Vlnc;};
	if (verNAC2!=Vnac2) {$("#newauacp").toggle(200); verNAC2=Vnac2; $("#txtauacp2").focus();};
}
//=========================================================================================================		
/*COMBOBOX DE RESPONSABLES*/

//nuevosresponsables est� definido en CRUDNCs.js
//sacarResponsables() est� definida en CRUDNCs.js

//=========================================================================================================