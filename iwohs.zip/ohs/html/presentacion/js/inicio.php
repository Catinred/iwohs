<?php

if (isset($_COOKIE['usNombre'])) {echo "Bienvenido " . $_COOKIE['usNombre'];}

?>