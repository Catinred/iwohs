//NOTAS (50)

	var idseleccionado50;
	var aseleccionado50 = [];
		
				
//TABLA CONTROLES_____________________________________________________________________________________________________________

function mostrarNotas() {
	//alert("el primer");
	sacarNotas ();
	setTimeout('listNotas()', 500);
	}
	
function listNotas() {
//alert("Dentroo");	
		$(document).ready( function () {
				$('#dynamic50').html( '<table cellpadding="0" cellspacing="0" border="0" class="display" id="example50"></table>' );
				$('#example50').dataTable( {
					"aaData": aDataSet50,	
					
					//CAMBIO DE COLOR DEL FONDO DE LAS LINEAS
					"fnRowCallback": function( nRow, aaData, iDisplayIndex ) {	
						 if (lineaGris==0) {$('td:eq(0)', nRow).addClass( 'whiterow' ); lineaGris=1;}
								else{$('td:eq(0)', nRow).addClass( 'greyrow' ); lineaGris=0;}
					return nRow;
        				}, 
					
					"aoColumns": [
						{ "sTitle": "Id Nota", "bSearchable": false, "bVisible": false },{ "sTitle": "Notas" }],
					"sDom": 'frtip',
					//lfrtip<"clear spacer">T
					"oTableTools": {
						/*"sRowSelect": "single","aButtons": ["select"],*///Solo me muestra el boton select para poder seleccionar las filas.
						"aoColumnDefs": [ {"sClass": "center","aTargets": [ -1, -2 ]}]
					},
				"bSort": false,
				})
				
				//EDITAR DIRECTAMENTE LAS TABLAS
				.makeEditable ({
                    		"aoColumns": [{type: 'textarea', onblur: 'submit', sUpdateURL: function(value, settings){updateNota(); return value;}}]									
				});
			});
			
		//Obtengo el ID de la fila que estoy editando	
		$(document).ready( function() {
    			$('#example50 tbody td').click( function () {
				var aPos50 = oTable50.fnGetPosition( this );
				var aData50 = oTable50.fnGetData( aPos50[0] );
				idseleccionado50 =  aData50[0];
				aseleccionado50 = aData50;
			});
			oTable50= $('#example50').dataTable();
			
		});		
			
	} 
	

			
function sacarNotas (){
	//alert("inside");
	var db;
        db = openDatabase("DBIW1", "0.1", "Database Isowin One", 200000);	
	if(db){
		db.transaction( function(tx) {
			tx.executeSql("SELECT * FROM notas", [],
				function(tx, result){
					//Creo un array
					/*var output = [];*/
					//Guardo en cada elemento i del vector, un objeto documento.
					aDataSet50 = [];
					for(var i=0; i < result.rows.length; i++) {	
						aDataSet50.push([result.rows.item(i)['idnota'],
								result.rows.item(i)['nota']
								]);
					}			
				 
			});
		});
		
		
	};
}
//=========================================================================================================					
/*CREAR NUEVA NOTA*/
	function addNota() {
	//alert("Inside!");	
	//Segunda opción
		var db;
		db = openDatabase("DBIW1", "0.1", "Database Isowin One", 200000);
		if(db){ db.transaction( function(tx) {
			tx.executeSql("INSERT INTO notas (nota) VALUES(?)", ["Nueva nota"]);
			setTimeout('mostrarNotas();',500);
			apprise('Pulsa sobre la nueva nota para editarla'); //alert("Estudio ha cambiado: "+ estudio + " - " + idseleccionado18);
		});};
	}

/*ACTUALIZAR NOTA*/
	function updateNota () {
		//alert("dentrode: " + aseleccionado25[2]);
		var db;
		db = openDatabase("DBIW1", "0.1", "Database Isowin One", 200000);
		if(db){db.transaction( function(tx) {
			tx.executeSql("UPDATE notas SET nota=? WHERE idnota=?", [aseleccionado50[1], idseleccionado50]);
			//apprise('El control ha sido modificado'); //alert("Estudio ha cambiado: "+ estudio + " - " + idseleccionado18);
			});
		};
		//setTimeout('mostrarEstudios()',500);
	}
	
/*BORRAR NOTA*/
	function removeNota() {
		if(idseleccionado50) { 
		apprise('¿Eliminar nota?', {'verify': true}, function(r) {
			if(r) { 
				var db;
				db = openDatabase("DBIW1", "0.1", "Database Isowin One", 200000);
				if(db){	
					db.transaction(function(tx) {
					tx.executeSql("DELETE FROM notas WHERE idnota=?",[idseleccionado50]);
					apprise('Nota borrada'); //alert("Persona borrada: "+ idseleccionado15);
					});
				};
				setTimeout('mostrarNotas()',500);
			};
		});
		};
	}

//=========================================================================================================					

//=========================================================================================================					

