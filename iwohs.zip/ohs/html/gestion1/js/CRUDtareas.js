//TAREAS
	var idseleccionado5;
	var renderizar = 1;
	var lineaGris = 0;
				
//TABLA TAREAS_____________________________________________________________________________________________________________
function mostrarTareas() {
	if ( renderizar == 1) {
	sacarTareas ();
	setTimeout('listTareas()',500);
	renderizar = 0; //Renderizo s�lo una vez, cuando cargo la p�gina.
	};}


function listTareas() {
		$(document).ready(			
			function () {
				$('#dynamic5').html( '<table cellpadding="0" cellspacing="0" border="0" class="display" id="example5"></table>' );
				$('#example5').dataTable( {
					"aaData": aDataSet5,
					
					//"bJQueryUI": true, //Carga un tema de JQuery UI
					//CAMBIO DE COLOR DEL FONDO DE LAS LINEAS
					"fnRowCallback": function( nRow, aaData, iDisplayIndex ) {	
					 if (lineaGris==0) {$('td:eq(0)', nRow).addClass( 'whiterow' );$('td:eq(1)', nRow).addClass( 'whiterow' );$('td:eq(2)', nRow).addClass( 'whiterow' );$('td:eq(3)', nRow).addClass( 'whiterow' ); lineaGris=1;}
								else{$('td:eq(0)', nRow).addClass( 'greyrow' );$('td:eq(1)', nRow).addClass( 'greyrow' );$('td:eq(2)', nRow).addClass( 'whiterow' );$('td:eq(3)', nRow).addClass( 'whiterow' ); lineaGris=0;}
						 //$('td:eq(0)', nRow).draggable;
						//$('div').addClass( 'external-event' );	
						return nRow;
        				}, 
						
					"aoColumns": [
						{ "sTitle": "Tarea", sWidth: "80%" },
						{ "sTitle": "Prioridad", sWidth: "20%"},
						//{ "sTitle": "Editar"}
						],

					"sDom": 'frtip',
					//lfrtip<"clear spacer">T
					"oTableTools": {
						/*"sRowSelect": "single","aButtons": ["select"],*///Solo me muestra el boton select para poder seleccionar las filas.

					"aoColumnDefs": [ {
						"sClass": "center",
						"aTargets": [ -1, -2 ]
						} ]
				},
				
				//Elimina la ordenación de la tabla
				"bSort": false,
				
				})//EDITAR DIRECTAMENTE LAS TABLAS
				.makeEditable ({
                    		"aoColumns": [
                    			{onblur: 'submit',
						sUpdateURL: function(value, settings){updateApunte (); return value;}
					},
                    			null
                                       ]									

				});
				
				
				//.rowReordering(); //Permite reordenar draggable
				
				/* 
				* Example init
				
				$(document).ready(function(){
					$('#example5').dataTable()
						.rowReordering();
				});*/

						
		//EDITAR LINEAS DIRECTAMENTE!!
				
				var oTable5 = $('#example5').dataTable();
				
				var nEditing = null;
				
				//CREAR
				$('#crearTarea').click( function (e) {
				e.preventDefault();
				 
				var aiNew = oTable5.fnAddData( [ '', '' , 
				'<a class="edit" href="">Edit</a>' ] );
				var nRow5 = oTable5.fnGetNodes( aiNew[0] );
				editRow( oTable5, nRow5 );
				$("#txtApunte").focus();
				nEditing = nRow5;
				//document.getElementById("crearTarea").style.display='none';
				} );
				
				//GUARDAR
				$('#example5 select.guardar').live('change', function (e) {
				e.preventDefault();
		
				var nRow5 = $(this).parents('tr')[0];
				if ( nEditing == nRow5 ) {
				
				//This row is being edited and should be saved 
				saveRow( oTable5, nEditing );
				nEditing = null;
				}
				
				} );
	
				//BORRAR
				$('#example5 a.delete').live('click', function (e) {
				e.preventDefault();
				//Selecciono la fila a eliminar
				var nRow5 = $(this).parents('tr')[0];
				//Borrar de la BD
				borrarApunteBD (nRow5);
				//Borrar de la tabla	
				oTable5.fnDeleteRow( nRow5 );
				
				} );
				
 
 				//EDITAR
    			$('#example5 a.edit').live('click', function (e) {
        			e.preventDefault();
         
       			 // Get the row as a parent of the link that was clicked on 
        		var nRow5 = $(this).parents('tr')[0];
         
        		if ( nEditing !== null && nEditing != nRow5 ) {
            	// A different row is being edited - the edit should be cancelled and this row edited 
            	restoreRow( oTable5, nEditing );
            	editRow( oTable5, nRow5 );
            	nEditing = nRow5;
        		}
        		else if ( nEditing == nRow5 && this.innerHTML == "Save" ) {
            	// This row is being edited and should be saved 
            	saveRow( oTable5, nEditing );
            	nEditing = null;
        		}
        		else {
            	// No row currently being edited 
            	editRow( oTable5, nRow5 );
            	nEditing = nRow5;
        		};
			
    			});
		});		
				
				
				
//Función de prueba para la revisión por dirección en pestaña 3			
/*$(function() {
 $('.selecteditable').editable('', { 
     data   : " {'E':'Letter E','F':'Letter F','G':'Letter G', 'selected':'F'}",
     type   : 'select',
     submit : 'OK'
	  });});*/
				
}

function sacarTareas (){
	var db;
        db = openDatabase("DBIW1", "0.1", "Database Isowin One", 200000);	
		//alert ("Estoy dentro");					
	if(db){
		db.transaction( function(tx) {
			tx.executeSql("SELECT * FROM apuntes", [],
				function(tx, result){

					aDataSet5 = [];
					
					var htmlPrioridad;
					
					for(var i=0; i < result.rows.length; i++) {
						
						if (result.rows.item(i)['prioridad']==1) {htmlPrioridad = '<a class="delete" href=""><div class="sprite alta"></div></a>'};
						if (result.rows.item(i)['prioridad']==2) {htmlPrioridad = '<a class="delete" href=""><div class="sprite media"></div></a>'};
						if (result.rows.item(i)['prioridad']==3) {htmlPrioridad = '<a class="delete" href=""><div class="sprite baja"></div></a>'};

						
						aDataSet5.push([result.rows.item(i)['apunte'],
								htmlPrioridad
								]);
						
		
					}
					
   				 // Init DataTables
   				 oTable5 = $('#example5').dataTable();				
				
			});
		});	
	};
}			

				

//=========================================================================================================					

//ReStore Node
function restoreRow ( oTable, nRow )
{
	var aData = oTable.fnGetData(nRow);
	var jqTds = $('>td', nRow);
	
	for ( var i=0, iLen=jqTds.length ; i<iLen ; i++ ) {
		oTable.fnUpdate( aData[i], nRow, i, false );
	}
	
	oTable.fnDraw();
}

//EDITAR TAREA
function editRow ( oTable, nRow )
{
    var aData = oTable.fnGetData(nRow);
    var jqTds = $('>td', nRow);

	oTable.fnPageChange( 'last' );
    jqTds[0].innerHTML = '<input id="txtApunte" type="text" value="'+aData[0]+'">';
    jqTds[1].innerHTML = '<select class="guardar"><option value=0>Elegir...<option value=1>Alta<option value=2>Media<option value=3>Baja</select>';
    //jqTds[2].innerHTML = '<a class="edit" href="">Save</a>';
	//alert(document.getElementById(aData[1]).value);
}
//GUARDAR TAREA
function saveRow ( oTable, nRow )
{ 
    var jqInputs = $('input', nRow);
    var jqSelect = $('select', nRow);
	//alert(jqInputs[0].value);
    oTable.fnUpdate( jqInputs[0].value, nRow, 0, false );
    if ( jqSelect[0].value==1) {oTable.fnUpdate('<a class="delete"><div class="sprite alta"></div></a>', nRow, 1, false )};
    if ( jqSelect[0].value==2) {oTable.fnUpdate('<a class="delete"><div class="sprite media"></div></a>', nRow, 1, false )};
    if ( jqSelect[0].value==3) {oTable.fnUpdate('<a class="delete"><div class="sprite baja"></div></a>', nRow, 1, false )};
    //oTable.fnUpdate( '<a class="edit" href="">'+jqInputs[0].value+'</a>', nRow, 2, false );
    //document.getElementById("newTarea").style.display='inherit';
    guardarApunteBD(jqInputs[0].value, jqSelect[0].value);
    //alert(jqInputs[0].value + jqSelect[0].value);
    oTable.fnDraw();
    //alert(document.getElementById(aData[1]).value);
    
}

function guardarApunteBD (apunte, prioridad) {
	var db = openDatabase("DBIW1", "0.1", "Database Isowin One", 200000);
	if(db){db.transaction( function(tx) {tx.executeSql("INSERT INTO apuntes (apunte, prioridad) VALUES(?,?)", [apunte, prioridad]);});}; 
	}
	
function borrarApunteBD (linea) {
	//Extraigo el texto de la "tarea" o "apunte" que usare como identificador de la linea a eliminar.
	var jqTds2 = $('td', linea);
	apunte = jqTds2[0].innerHTML;
	
	var db = openDatabase("DBIW1", "0.1", "Database Isowin One", 200000);
	if(db){db.transaction(function(tx) {tx.executeSql("DELETE FROM apuntes WHERE apunte=?",[apunte]);})};
	} 

/*ACTUALIZAR APUNTE*/
	function updateApunte () {
		//alert("dentrode: " + aseleccionado5[2]);
	var db;
        db = openDatabase("DBIW1", "0.1", "Database Isowin One", 200000);
		if(db){ db.transaction( function(tx) {
			tx.executeSql("UPDATE apuntes SET apunte=?, prioridad=? WHERE idapunte=?", [aseleccionado5[1], aseleccionado5[2], idseleccionado5]);
			//apprise('El apunte ha sido modificado'); //alert("Estudio ha cambiado: "+ estudio + " - " + idseleccionado18);
		});};
		//setTimeout('mostrarApuntes()',500);
	}

//XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX
//XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX	
//XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX
// "X" INTELIGENCE ________________________________________________________________________________________________

function AddApuntesX () {
	
	DeleteApuntesX ();

	AddXer (1);
	AddXrm2 (1);

	sacarTareas ();
	setTimeout('listTareas()',500);
	apprise('Tareas pendientes chequeadas');
	}

	function DeleteApuntesX () {
	var db = openDatabase("DBIW1", "0.1", "Database Isowin One", 200000);
	if(db){db.transaction(function(tx) {tx.executeSql("DELETE FROM apuntes WHERE idx is not null",[]);})};
	} 

//XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX	

//EVALUACIONES DE RIESGO PENDIENTES________________________
function AddXer (priority) {
	var db; db = openDatabase("DBIW1", "0.1", "Database Isowin One", 200000);
	if(db){	db.transaction( function(tx) {
			tx.executeSql("SELECT * FROM ersx LEFT JOIN ers ON ersx.idx=ers.idx WHERE ers.ider is null", [],
				function(tx, result){for(var i=0; i < result.rows.length; i++) {
					tx.executeSql("INSERT INTO apuntes (apunte, prioridad,idx) VALUES(?,?,?)", [result.rows.item(i)['txt'], priority, result.rows.item(i)['idx']]);		
   	};});});}}			

//RECONOCIMIENTOS M�DICOS PENDIENTES________________________
function AddXrm2 (priority) {
	var apunte;var idx;
	var db; db = openDatabase("DBIW1", "0.1", "Database Isowin One", 200000);
	if(db){	db.transaction( function(tx) {
			tx.executeSql("SELECT * FROM personas LEFT JOIN rms ON personas.idpersona=rms.idpersona WHERE idrm is null", [],
				function(tx, result){for(var i=0; i < result.rows.length; i++) {
						apunte="RM pendiente de: " + result.rows.item(i)['apellidos'] + ", " + result.rows.item(i)['nombre'];
						idx="RMx"+result.rows.item(i)['idpersona'];
					tx.executeSql("INSERT INTO apuntes (apunte, prioridad,idx) VALUES(?,?,?)", [apunte, priority, idx]);		
   	};});});}}		

//XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX
//XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX	
//XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX