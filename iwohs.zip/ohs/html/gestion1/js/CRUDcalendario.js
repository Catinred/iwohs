

<!--Calendario JQuery-->

var idcitaseleccionada;

	$(document).ready(function() {
	
		var date = new Date();
		var d = date.getDate();
		var m = date.getMonth();
		var y = date.getFullYear();
		var evento = {title: "Prueba", start: "13/12/2013", end: "20/12/2013"};
		
	function Cargar(){
		var db;
		var fchInicioAUX;
		var fchFinAUX;

        db = openDatabase("DBIW1", "0.1", "Database Isowin One", 200000);
		if(db){		
			db.transaction( function(tx) {
			    tx.executeSql("SELECT * FROM tareas", [],
				function(tx, result){
					for(var i=0; i < result.rows.length; i++) {

					fchInicioAUX = changeFch (result.rows.item(i)['fchinicio']);
					fchFinAUX = changeFch (result.rows.item(i)['fchfin']);
						
					  $('#calendar').fullCalendar('renderEvent',
						   {title: result.rows.item(i)['tarea'],
							start: fchInicioAUX,
							end: fchFinAUX,
							id: result.rows.item(i)['idtarea'],
							description: result.rows.item(i)['descripcion']},
						false /*make the event "stick". Evita que se dupliquen los eventos*/);				
					};
					})});
					
			db.transaction( function(tx) {
			tx.executeSql("SELECT * FROM apuntes", [],
				function(tx, result){

					divs="";
					
					for(var i=0; i < result.rows.length; i++) {
						
						divs+="<div class='external-event'>"+result.rows.item(i)['apunte']+"</div>"
		
					};
									
				 $('#external').html(divs);
					
				});
			});
					
					
					}};
			
		/* initialize the external events
		-----------------------------------------------------------------*/
	
		$('td').each(function() {
		
			// create an Event Object (http://arshaw.com/fullcalendar/docs/event_data/Event_Object/)
			// it doesn't need to have a start or end
			var eventObject = {
				title: $.trim($(this).text()) // use the element's text as the event title
			};
			// store the Event Object in the DOM element so we can get to it later
			$(this).data('eventObject', eventObject);
			
			// make the event draggable using jQuery UI
			$(this).draggable({
				zIndex: 999,
				revert: true,      // will cause the event to go back to its
				revertDuration: 0  //  original position after the drag
			});
			
		});		
		
$('#calendar').fullCalendar({
			theme: true,
			firstDay:1,
			header: {
				left: 'prev,next today',
				center: 'title',
				right: 'month,agendaWeek,agendaDay'
			},
			editable: true,
			
			
events:
			function (){$('#calendar').fullCalendar('renderEvent', evento ,true); 
								Cargar();
							
								},

			
			/*Guarda cambios de fechas de eventos en la base de datos*/
eventDrop: 
			function(event, delta) {
				
/*				var inicio = event.start.getDay()+"/"+event.start.getMonth()+"/"+event.start.getFullYear();
				var fin = event.end.getDay()+"/"+event.end.getMonth()+"/"+event.end.getFullYear();
				alert(event.start+inicio);*/
				
				//alert(event.title + ' was moved ' + delta + ' days\n' + '(should probably update your database) '+'-'+event.start+"-"+event.end+"-"+'-'+event.id);
				
				updateCitaDROP(event.start,event.end,event.id);
							
			},
			
loading: function(bool) {
				if (bool) $('#loading').show();
				else $('#loading').hide();
			},
			
/*Borrar un evento*/

eventClick: 
		function(calEvent, jsEvent, view) {
			if ($(document.getElementById("txtinicio").value)) {VnV1 (1, 0);};
			
			var fchInicioAUX = changeFch2 (calEvent.start);
			var fchFinAUX = changeFch2 (calEvent.end);
			
			document.getElementById("txtcita").value = calEvent.title;
			document.getElementById("txtinicio").value = fchInicioAUX;
			if (fchFinAUX == null) {document.getElementById("txtfin").value = fchInicioAUX;}
				else {document.getElementById("txtfin").value = fchFinAUX;};
			document.getElementById("txtdescripcion").value = calEvent.description;
			idcitaseleccionada = calEvent.id;
		
				
		/* Para eliminar eventos a saco: $('#calendar').fullCalendar( 'removeEvents' [, idOrFilter] );*/
        // change the border color just for fun
        /*(this).css('border-color', 'red'),*/
		    },
						
/*Permite seleccionar celdas del calendario*/
			selectable: true,
			
/*Ventana de creación de evento*/
selectHelper: 	true,

select: 		function(start, end, allDay) {
				//var title = prompt('Event Title:');
				id=Date();
				var fchInicioAUX;
				var fchFinAUX;
				//var inicio = $('#calendar').fullCalendar.formatDate( start, 'dd/MM/yyyy' );
				//alert(start);
				VnV1 (1, 0);
				
				fchInicioAUX = changeFch2 (start);
				fchFinAUX = changeFch2 (end);
				
				document.getElementById("txtinicio").value = fchInicioAUX;
				document.getElementById("txtfin").value = fchFinAUX;
				idcitaseleccionada = "";
				
				
				
				//document.getElementById('newcita').toggle(200);
				
				
/*				if ($("#textevento").value) {
					$('#calendar').fullCalendar('renderEvent',
						{
							title: $("#textevento").value,
							start: start,
							end: end,
							allDay: allDay,
						},
						
						true // make the event "stick"
					);
				
					 
		/*De mi cosecha
		var db;
		db = openDatabase("DBIW1", "0.1", "Database Isowin One", 200000);
		if (db) {
		db.transaction( function(tx) {
			tx.executeSql("INSERT INTO tareas(tarea, fchinicio, fchfin) VALUES(?,?,?)", [title, start, end]);
			alert("tarea guardada: "+ title);});}
				}*/
				calendar.fullCalendar('unselect');
			},
			
/*Arrastrar eventos del exterior y soltarlos dentro*/
			editable: true,
			droppable: true, // this allows things to be dropped onto the calendar !!!
			drop: function(date, allDay) { // this function is called when something is dropped
			
				// retrieve the dropped element's stored Event Object
				var originalEventObject = $(this).data('eventObject');
				
				// we need to copy it, so that multiple events don't have a reference to the same object
				var copiedEventObject = $.extend({}, originalEventObject);
				
				// assign it the date that was reported
				copiedEventObject.start = date;
				copiedEventObject.allDay = allDay;
				
				// render the event on the calendar
   				 // the last `true` argument determines if the event "sticks" 			               (http://arshaw.com/fullcalendar/docs/event_rendering/renderEvent/)
				$('#calendar').fullCalendar('renderEvent', copiedEventObject, true);
				
		var db;
		db = openDatabase("DBIW1", "0.1", "Database Isowin One", 200000);
		if (db) {
		db.transaction( function(tx) {
			tx.executeSql("INSERT INTO tareas(tarea, fchinicio, fchfin) VALUES(?,?,?)", [copiedEventObject.title, copiedEventObject.start, copiedEventObject.end]);
			alert("tarea guardada: "+ copiedEventObject.title);});};
			
				
				// is the "remove after drop" checkbox checked?
				if ($('#drop-remove').is(':checked')) {
					// if so, remove the element from the "Draggable Events" list
					$(this).remove();
				}
				
			}
			
			
			
			
			
		});
		
	});

/*NUEVA CITA*/
	function addCita(txtcita, txtinicio, txtfin, txtdescripcion) {
		//alert("Estoy dentro");
			if (txtcita != "") {

				var db;
				var idAux = new Date();
				
		db = openDatabase("DBIW1", "0.1", "Database Isowin One", 200000);
		if (db) {
		db.transaction( function(tx) {
			tx.executeSql("INSERT INTO tareas(tarea, fchinicio, fchfin, descripcion, prioridad) VALUES(?,?,?,?,?)", [txtcita, txtinicio, txtfin, txtdescripcion,0]);
			});
/*		//Necesito sacar el ID de la nueva cita en la base de datos para poder hacer cambios de fecha en un elemento recien creado
		db.transaction( function(tx) {
			tx.executeSql("SELECT MAX(idtarea) FROM tareas", [], function(tx, result2){idAux = result2.rows.item(0)['idtarea'];});
			});
			alert(result2[0]);*/	
			}};
			
			//alert("tarea guardada: "+ txtevento);
		//calendar.fullCalendar('unselect');		
		$(':text').val('');
			
		var fchInicioAUX = changeFch (txtinicio);
		var fchFinAUX = changeFch (txtfin);
			//alert(fchInicioAUX);
		
		$('#calendar').fullCalendar('renderEvent',
						{
							title: txtcita,
							start: fchInicioAUX,
							end: fchFinAUX,
							id: idAux,
						},
						true // make the event "stick"
					);
		VnV1 (0, 1);
	}
				
/*ELIMINA CITA*/			
function deleteCita(){
	if (idcitaseleccionada) {			
			apprise('¿Eliminar la cita?', {'verify': true}, function(r) {
			if(r) { 
				var db;
				db = openDatabase("DBIW1", "0.1", "Database Isowin One", 200000);
				if(db){		
				db.transaction( function(tx) {
			   	 tx.executeSql("DELETE FROM tareas WHERE idtarea=?", [idcitaseleccionada] );})}
													
				//$(this).remove();
				$('#calendar').fullCalendar('removeEvents',idcitaseleccionada);
				
				};
			});
		};
	VnV1 (0, 1);
}

/*ACTUALIZAR CITA*/

function updateCita(nuevacita, nuevoinicio, nuevofin){
	var db;
	db = openDatabase("DBIW1", "0.1", "Database Isowin One", 200000);
	if (db) {
		var fchInicioAUX = changeFch2 (nuevoinicio);
			var fchFinAUX = changeFch2 (nuevofin);
			idInt = parseInt(idcitaseleccionada);
			db.transaction( function(tx) {
				tx.executeSql("UPDATE tareas SET tarea=? fchinicio=?, fchfin=? WHERE idtarea=?", [nuevacita, fchInicioAUX, fchFinAUX, idInt]);
			});
	VnV1 (0, 1);
	};
}
function updateCitaDROP(nuevoinicio, nuevofin, idcita){
	var db;
	db = openDatabase("DBIW1", "0.1", "Database Isowin One", 200000);
	if (db) {
		var fchInicioAUX = changeFch2 (nuevoinicio);
			var fchFinAUX = changeFch2 (nuevofin);
			idInt = parseInt(idcita);
			db.transaction( function(tx) {
				tx.executeSql("UPDATE tareas SET fchinicio=?, fchfin=? WHERE idtarea=?", [fchInicioAUX, fchFinAUX, idInt]);
			});
	VnV1 (0, 1);
	};
}


//=========================================================================================================
/* VER NO VER*/
var verNCI= 0;

function VnV1 (Vnci, Vaco) { 
	if (verNCI!=Vnci) {$("#newcita").toggle(200); verNCI=Vnci; $("#txtcita").focus();};
	//if (Vaco!="nada") {
		if (Vaco==0) {
			$( "#accordion" ).accordion( "option", "collapsible", true );
			$( "#accordion" ).accordion( "option", "active", false );
			}else{
			$( "#accordion" ).accordion( "option", "collapsible", false );
			$( "#accordion" ).accordion( "option", "active", 0 );
			};
		//};
	}
//=========================================================================================================

