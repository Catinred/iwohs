//REQUISITOS DE CLIENTE Y PRODUCTO (52 y 53)

	var idseleccionado52;
	var idseleccionado53;
	var idseleccionado52b;
	var nuevosclientes; //Listado de clientes para COMBOBOX
				
//TABLAS CLIENTES Y PRODUCTOS_____________________________________________________________________________________________________________

function mostrarClientesyProductos() {
	sacarClientes ();		
	sacarProductos ();
	setTimeout('listClientes(); listProductos();',500);
	}
	
//TABLA CLIENTES _____________________________________________________________________________________________________________
function listClientes() {
		$(document).ready(			
			function () {
				$('#dynamic52').html( '<table cellpadding="0" cellspacing="0" border="0" class="display" id="example52"></table>' );
				$('#example52').dataTable( {
					"aaData": aDataSet52,
						
					"aoColumns": [
						{ "sTitle": "Id"/*, "bSearchable": false, "bVisible": false*/ },
						{ "sTitle": "Cliente" },
						{ "sTitle": "Codigo Cliente", "bSearchable": false, "bVisible": false },
						{ "sTitle": "CIF" },
						{ "sTitle": "Dirección", "bSearchable": false, "bVisible": false },
						{ "sTitle": "Tlf" },
						{ "sTitle": "Fecha de Alta", "bSearchable": false, "bVisible": false},
						{ "sTitle": "Contacto" },
						{ "sTitle": "Tlf Contacto" },
						{ "sTitle": "Mail contacto"},
						{ "sTitle": "Observaciones", "bSearchable": false, "bVisible": false}
						],
					
					"sScrollY": "600px",
					"bPaginate": false,
					"bScrollCollapse": true,
						
					"sDom": 'lfrtip<"clear spacer">T',
					/*"sDom": 'T<"clear">lfrtip<"clear spacer">T',*/ //Muestra los botones de copy,print...
					"oTableTools": {
						"sRowSelect": "single","aButtons": ["select"], //Solo me muestra el boton select para poder seleccionar las filas.
							
					"aoColumnDefs": [ {
						"sClass": "center",
						"aTargets": [ -1, -2 ]
						} ]
						
				}});
				
				});
	//Cargar datos del equipo para editar en formulario	
		$(document).ready(
			function() {
    			$('#example52 tbody td').click( function () {
				
        		/* Get the position of the current data from the node */
				var aPos52 = oTable52.fnGetPosition( this );
         
        		/* Get the data array for this row */
				var aData52 = oTable52.fnGetData( aPos52[0] );
				/*alert("Ok "+aData[0]);*/
				idseleccionado52 =  aData52[0];
				document.getElementById("txtcl").value = aData52[1];
				document.getElementById("txtclcod").value = aData52[2];
				document.getElementById("txtclcif").value = aData52[3];
				document.getElementById("txtcldireccion").value = aData52[4];
				document.getElementById("txtcltlf").value = aData52[5];
				document.getElementById("txtclfchalta").value = aData52[6];
				document.getElementById("txtclcontacto").value = aData52[7];
				document.getElementById("txtcltlfcon").value = aData52[8];
				document.getElementById("txtclmailcon").value = aData52[9];
				document.getElementById("txtclobs").value = aData52[10];
			
				//Limpio la selección de PRODUCTO
				idseleccionado53 =  null;
				
				//Visualizo los requisitos en la lista de requisitos
				DatosBDrequisitos("C", idseleccionado52);
				setTimeout('listRequisitos();',200);	
		
			
				VnV52 (1, 0, 0, 0, 1, 0);
				
				});
     
			/* Init DataTables */
			oTable52= $('#example52').dataTable();
			}
		);
		
	}
	
//DATOS CLIENTES_________________________________________________

function sacarClientes (){
	var db;
        db = openDatabase("DBIW1", "0.1", "Database Isowin One", 200000);	
		//alert ("Estoy dentro");					
	if(db){
		db.transaction( function(tx) {
			tx.executeSql("SELECT * FROM clientes", [],
				function(tx, result){
					aDataSet52 = [];
					for(var i=0; i < result.rows.length; i++) {	
						aDataSet52.push([result.rows.item(i)['idcliente'],
								result.rows.item(i)['cliente'],
								result.rows.item(i)['codcliente'],
								result.rows.item(i)['cif'],
								result.rows.item(i)['direccion'],
								result.rows.item(i)['tlf'],
								result.rows.item(i)['fchalta'],
								result.rows.item(i)['contacto'],
								result.rows.item(i)['tlfcontacto'],
								result.rows.item(i)['mailcontacto'],
								result.rows.item(i)['obs']
								]);
					};			
				});
		});	
	};
}

//TABLA PRODUCTOS_____________________________________________________________________________________________________________
function listProductos() {
		$(document).ready(			
			function () {
				$('#dynamic53').html( '<table cellpadding="0" cellspacing="0" border="0" class="display" id="example53"></table>' );
				$('#example53').dataTable( {
					"aaData": aDataSet53,
						
					"aoColumns": [
						{ "sTitle": "Id"/*, "bSearchable": false, "bVisible": false*/ },
						{ "sTitle": "Producto" },
						{ "sTitle": "Codigo Producto" },
						{ "sTitle": "Descripción"  },
						{ "sTitle": "Responsable", "bSearchable": false, "bVisible": false },
						{ "sTitle": "Observaciones", "bSearchable": false, "bVisible": false}
						],
					
					"sScrollY": "600px",
					"bPaginate": false,
					"bScrollCollapse": true,
						
					"sDom": 'lfrtip<"clear spacer">T',
					/*"sDom": 'T<"clear">lfrtip<"clear spacer">T',*/ //Muestra los botones de copy,print...
					"oTableTools": {
						"sRowSelect": "single","aButtons": ["select"], //Solo me muestra el boton select para poder seleccionar las filas.
							
					"aoColumnDefs": [ {
						"sClass": "center",
						"aTargets": [ -1, -2 ]
						} ]
						
				}});
				
				//Cargo el COMBOBOX de responsables del formulario NCs------------
				setTimeout('$("#combopdresponsable").html(nuevosresponsables);',200);
				//--------------------------------------------------	
				
				});
	//Cargar datos del equipo para editar en formulario	
		$(document).ready(
			function() {
    			$('#example53 tbody td').click( function () {
				
        		/* Get the position of the current data from the node */
				var aPos53 = oTable53.fnGetPosition( this );
         
        		/* Get the data array for this row */
				var aData53 = oTable53.fnGetData( aPos53[0] );
				/*alert("Ok "+aData[0]);*/
				idseleccionado53 =  aData53[0];
				document.getElementById("txtpd").value = aData53[1];
				document.getElementById("txtpdcod").value = aData53[2];
				document.getElementById("txtpddescripcion").value = aData53[3];
				document.getElementById("combopdresponsable").value = aData53[4];
				document.getElementById("txtpdobs").value = aData53[5];
				
				//Limpio la selección de CLIENTE
				idseleccionado52 =  null;
				
				//Visualizo los requisitos en la lista de requisitos
				DatosBDrequisitos("P", idseleccionado53);
				setTimeout('listRequisitos();',200);	
			
				
				VnV52 (0, 1, 0, 0, 1, 0);
				
				});
     
			/* Init DataTables */
			oTable53= $('#example53').dataTable();
			});
		
	}
	
//DATOS PRODUCTOS_________________________________________________

function sacarProductos (){
	var db;
        db = openDatabase("DBIW1", "0.1", "Database Isowin One", 200000);	
		//alert ("Estoy dentro");					
	if(db){
		db.transaction( function(tx) {
			tx.executeSql("SELECT * FROM productos", [],
				function(tx, result){
					aDataSet53 = [];
					for(var i=0; i < result.rows.length; i++) {	
						aDataSet53.push([result.rows.item(i)['idproducto'],
								result.rows.item(i)['producto'],
								result.rows.item(i)['codproducto'],
								result.rows.item(i)['descripcion'],
								result.rows.item(i)['responsable'],
								result.rows.item(i)['obs']
								]);
					};			
				});
		});	
	};
}
	
//TABLA REQUISITOS_____________________________________________________________________________________________________________

function listRequisitos() {
		$(document).ready(			
			function () {
				$('#dynamic52b').html( '<table cellpadding="0" cellspacing="0" border="0" class="display" id="example52b"></table>' );
				$('#example52b').dataTable( {
					"aaData": aDataSet52b,
					
					"aoColumns": [
						{ "sTitle": "Id"/*, "bSearchable": false, "bVisible": false*/ },
						{ "sTitle": "Requisito" },
						{ "sTitle": "Cod Requisito", "bSearchable": false, "bVisible": false },
						{ "sTitle": "Trazabilidad", "bSearchable": false, "bVisible": false },
						{ "sTitle": "Referencia", "bSearchable": false, "bVisible": false },
						{ "sTitle": "link", "bSearchable": false, "bVisible": false },
						{ "sTitle": "Fecha Inicio", "bSearchable": false, "bVisible": false },
						{ "sTitle": "Vigente" },
						{ "sTitle": "Revisión", "bSearchable": false, "bVisible": false },
						{ "sTitle": "Estado" },
						{ "sTitle": "Observaciones", "bSearchable": false, "bVisible": false }
						],
						
					"sScrollY": "250px",
        			"bPaginate": false,
        			"bScrollCollapse": true,
						
					"sDom": 'lfrtip<"clear spacer">T',
					/*"sDom": 'T<"clear">lfrtip<"clear spacer">T',*/ //Muestra los botones de copy,print...
					"oTableTools": {
						"sRowSelect": "single","aButtons": ["select"], //Solo me muestra el boton select para poder seleccionar las filas.
							
					"aoColumnDefs": [ {
						"sClass": "center",
						"aTargets": [ -1, -2 ]
						} ]
						
				}});
				
				});
	//Cargar datos de la calibración para editar en formulario	
		$(document).ready(
		function() {
    			$('#example52b tbody td').click( function () {
			
        		/* Get the position of the current data from the node */
        		var aPos52b = oTable52b.fnGetPosition( this );
         
        		/* Get the data array for this row */
        		var aData52b = oTable52b.fnGetData( aPos52b[0] );
				/*alert("Ok "+aData[0]);*/
				//requisito, codrequisito, idcliente, referencia, link, fchinicio, vigente, revision, estado, obs
					
				idseleccionado52b =  aData52b[0];
				document.getElementById("txtrcl").value = aData52b[1];
				document.getElementById("txtrclcod").value = aData52b[2];
				//El IdCliente no lo enseño
				document.getElementById("txtrclfchalta").value = aData52b[4];
				document.getElementById("txtrclref").value = aData52b[5];
				document.getElementById("txtrcllink").value = aData52b[6];
				document.getElementById("comborclvigente").value = aData52b[7];
				document.getElementById("txtrclrevision").value = aData52b[8];
				document.getElementById("comborclestado").value = aData52b[9];
				document.getElementById("txtrclobs").value = aData52b[10];
				
				if (idseleccionado52) { VnV52 (1, 0, 0, 1, 0, 0)};
				if (idseleccionado53) { VnV52 (0, 1, 0, 1, 0, 0)};
         
    			});
			
			//Cargo el COMBOBOX de responsables del formulario NCs------------
				setTimeout('$("#comboacpresp4").html(nuevosresponsables);',200);
				//--------------------------------------------------
     
   				 /* Init DataTables */
			oTable52b= $('#example52b').dataTable();
		});
		
	}

//DATOS REQUISITOS FILTRADOS POR CLIENTE______________________________________________________________________
		
function DatosBDrequisitos (letra, idseleccionado) {
	
	//Es un requisito de CLIENTE o de PRODUCTO
	var trz = letra +  idseleccionado; 
	//alert(idseleccionado + ">>" + trz);
	var db;
        db = openDatabase("DBIW1", "0.1", "Database Isowin One", 200000);
		if(db){	
		db.transaction( function(tx) {
			tx.executeSql("SELECT * FROM requisitos WHERE trazabilidad=?", [trz],
				function(tx, result){
					aDataSet52b = [];
					for(var i=0; i < result.rows.length; i++) {
						aDataSet52b.push([result.rows.item(i)['idrequisito'],
								result.rows.item(i)['requisito'],
								result.rows.item(i)['codrequisito'],
								result.rows.item(i)['trazabilidad'],
								result.rows.item(i)['referencia'],
								result.rows.item(i)['link'],
								result.rows.item(i)['fchinicio'],
								result.rows.item(i)['vigente'],
								result.rows.item(i)['revision'],
								result.rows.item(i)['estado'],
								result.rows.item(i)['obs']
								]);
				}		
   				 /* Init DataTables */
   				 oTable52b = $('#example52b').dataTable();				
				 
				});
				
				
		});
		
	}}
	

//=========================================================================================================					
/*NUEVO CLIENTE*/
	
	function addCliente (cliente, codcliente, cif, direccion, tlf, fchalta, contacto, tlfcontacto, mailcontacto, obs) {
		
		var db;
		db = openDatabase("DBIW1", "0.1", "Database Isowin One", 200000);
		if(db){	
		  db.transaction( function(tx) {
			tx.executeSql("INSERT INTO clientes (cliente, codcliente, cif, direccion, tlf, fchalta, contacto, tlfcontacto, mailcontacto, obs) VALUES(?,?,?,?,?,?,?,?,?,?)", [cliente, codcliente, cif, direccion, tlf, fchalta, contacto, tlfcontacto, mailcontacto, obs]);
			apprise('El cliente ha sido guardado');
		  });
		};
		
		setTimeout('mostrarClientesyProductos()',500);
		  VnV52(0, 0, 1, 0, 0, 0);
	}
	
/*ACTUALIZAR CLIENTE*/
	function updateCliente (cliente, codcliente, cif, direccion, tlf, fchalta, contacto, tlfcontacto, mailcontacto, obs) {
		
		var db;
        db = openDatabase("DBIW1", "0.1", "Database Isowin One", 200000);
		if(db){	
		  db.transaction( function(tx) {
			tx.executeSql("UPDATE clientes SET cliente=?, codcliente=?, cif=?, direccion=?, tlf=?, fchalta=?, contacto=?, tlfcontacto=?, mailcontacto=?, obs=?   WHERE idcliente=?", [cliente, codcliente, cif, direccion, tlf, fchalta, contacto, tlfcontacto, mailcontacto, obs, idseleccionado52]);
			apprise('El cliente ha sido modificado');
		})};
		setTimeout('mostrarClientesyProductos()',500);
	}					

/*BORRAR CLIENTE*/
	function removeCliente() {
		apprise('¿Eliminar el cliente?', {'verify': true}, function(r) {
			if(r) {
				var db;
				db = openDatabase("DBIW1", "0.1", "Database Isowin One", 200000);
				if(db){	
					db.transaction(function(tx) {
						tx.executeSql("DELETE FROM clientes WHERE idcliente=?",[idseleccionado52]);
						tx.executeSql("DELETE FROM requisitos WHERE trazabilidad=?",["C"+idseleccionado52]); //limpia calibraciones asociadas.
						apprise('El cliente ha sido borrado');

					});
				};
			};

		setTimeout('mostrarClientesyProductos()',500);
		 VnV52(0, 0, 1, 0, 0, 0);
		});
	}
	
//=========================================================================================================					
				
/*NUEVO PRODUCTO*/
	
	function addProducto (producto, codproducto, descripcion, responsable, obs) {
		
		var db;
		db = openDatabase("DBIW1", "0.1", "Database Isowin One", 200000);
		if(db){	
		  db.transaction( function(tx) {
			tx.executeSql("INSERT INTO productos (producto, codproducto, descripcion, responsable, obs) VALUES(?,?,?,?,?)", [producto, codproducto, descripcion, responsable, obs]);
			apprise('El producto ha sido guardado');
		  });
		};
		
		setTimeout('mostrarClientesyProductos()',500);
		  VnV52(0, 0, 1, 0, 0, 0);
	}
	
/*ACTUALIZAR PRODUCTO*/
	function updateProducto (producto, codproducto, descripcion, responsable, obs) {
		
		var db;
        db = openDatabase("DBIW1", "0.1", "Database Isowin One", 200000);
		if(db){	
		  db.transaction( function(tx) {
			tx.executeSql("UPDATE productos SET producto=?, codproducto=?, descripcion=?, responsable=?, obs=?   WHERE idproducto=?", [producto, codproducto, descripcion, responsable, obs, idseleccionado53]);
			apprise('El producto ha sido modificado');
		})};
		setTimeout('mostrarClientesyProductos()',500);
	}					

/*BORRAR PRODUCTO*/
	function removeProducto() {
		apprise('¿Eliminar el cliente?', {'verify': true}, function(r) {
			if(r) {
				var db;
				db = openDatabase("DBIW1", "0.1", "Database Isowin One", 200000);
				if(db){	
					db.transaction(function(tx) {
						tx.executeSql("DELETE FROM productos WHERE idproducto=?",[idseleccionado53]);
						tx.executeSql("DELETE FROM requisitos WHERE trazabilidad=?",["P"+ idseleccionado53]); //limpia calibraciones asociadas.
						apprise('El producto ha sido borrado');

					});
				};
			};

		setTimeout('mostrarClientesyProductos()',500);
		 VnV52(0, 0, 1, 0, 0, 0);
		});
	}
	
//=========================================================================================================					
//=========================================================================================================	

	
function mostrarRequisitos() {
	DatosBDrequisitos (idseleccionado52);
	setTimeout('listRequisitos()',500);
	}
	
//=========================================================================================================					
/*NUEVO REQUISITO*/
	function addRequisito (requisito, codrequisito, referencia, link, fchinicio, vigente, revision, estado, obs) {
		
		//Es un requisito de CLIENTE o de PRODUCTO
		var trz; 
		if (idseleccionado52) {trz = "C" + idseleccionado52;} else {trz = "P" + idseleccionado53;};
		
		var db;
		db = openDatabase("DBIW1", "0.1", "Database Isowin One", 200000);
		if(db){	
		  db.transaction( function(tx) {
			tx.executeSql("INSERT INTO requisitos (requisito, codrequisito,trazabilidad, referencia, link, fchinicio, vigente, revision, estado, obs) VALUES(?,?,?,?,?,?,?,?,?,?)", [requisito, codrequisito, trz , referencia, link, fchinicio, vigente, revision, estado, obs]);
			apprise('El requisito legal ha sido guardado'); //alert("ReclamaciÃ³n guardada: "+ codreclamacion);
		})};
		mostrarRequisitos();
		VnV52 (1, 0, 0, 0, 1, 0);
	}
	
/*ACTUALIZO REQUISITO*/
		function updateRequisito (requisito, codrequisito, referencia, link, fchinicio, vigente, revision, estado, obs) {
		
		//Es un requisito de CLIENTE o de PRODUCTO
		var trz; 
		if (idseleccionado52) {trz = "C" + idseleccionado52;} else {trz = "P" + idseleccionado53;};
		
		var db;
		db = openDatabase("DBIW1", "0.1", "Database Isowin One", 200000);
		if(db){	
		  db.transaction( function(tx) {
			tx.executeSql("UPDATE requisitos SET requisito=?, codrequisito=?, trazabilidad=?, referencia=?, link=?, fchinicio=?, vigente=?, revision=?, estado=?, obs=? WHERE idrequisito=?", [requisito, codrequisito, trz , referencia, link, fchinicio, vigente, revision, estado, obs, idseleccionado52b]);
			apprise('El requisito legal ha sido modificado'); //alert("La reclamaciÃ³n ha cambiado: "+ codreclamacion + " - " + idseleccionado19);
		})};
		mostrarRequisitos(); 
		VnV52 (1, 0, 0, 0, 1, 0);
	}					

/*BORRO REQUISITO */
	function removeRequisito() {
		apprise('¿Eliminar el requisito legal?', {'verify': true}, function(r) {
			if(r) {
			var db;
			db = openDatabase("DBIW1", "0.1", "Database Isowin One", 200000);
			if(db){	
				db.transaction(function(tx) {
					tx.executeSql("DELETE FROM requisitos WHERE idrequisito=?",[idseleccionado52b]);
					apprise('El requisito legal ha sido borrado');
				})};};
				
				mostrarRequisitos();
				VnV52 (1, 0, 0, 0, 1, 0);
		});
	}
	
//=========================================================================================================					
/*NUEVA APC52*/
	function addACP52o53 (acp, codacp, tipo, fchalta, responsable, equipo, acciones, fchprevista) {
		
		//Es un requisito de CLIENTE o de PRODUCTO
		var trz; var origen;
		if (idseleccionado52) {trz = "C" + idseleccionado52;
						origen = "El requisito de cliente: " +   trz;} 
					else {trz = "P" + idseleccionado53;
						origen = "El requisito de producto: " +   trz;};

		var codtrz = "rcl"+trz;
		addMiniACP(acp, codacp, tipo, origen, fchalta, responsable, equipo, acciones, fchprevista, codtrz);
	}
	
	
//=========================================================================================================
/* VER NO VER*/
var verNCL= 0; var verNPD= 0; var verLCL= 1; var verNRCL= 0; var verLRCL= 0; var verNAC4= 0;

function VnV52 (Vncl, Vnpd, Vlcl, Vnrcl, Vlrcl, Vnac4) { 
	if (verNCL!=Vncl) {$("#newcliente").toggle(200); verNCL=Vncl; $("#txtcl").focus();};
	if (verNPD!=Vnpd) {$("#newproducto").toggle(200); verNPD=Vnpd; $("#txtpd").focus();};
	if (verLCL!=Vlcl) {$("#listaclientes").toggle(200); verLCL=Vlcl;};
	if (verNRCL!=Vnrcl) {$("#newrequisito").toggle(200); verNRCL=Vnrcl; $("#txtrcl").focus();};
	if (verLRCL!=Vlrcl) {$("#listarequisitos").toggle(200); verLRCL=Vlrcl;};
	if (verNAC4!=Vnac4) {$("#newacp4").toggle(200); verNAC4=Vnac4; $("#txtacp4").focus();};
}
	
function VnV52a () {
	if (idseleccionado52) {VnV52 (1, 0, 0, 0, 1, 0);} else {VnV52 (0, 1, 0, 0, 1, 0);};
}
function VnV52b () {
	if (idseleccionado52) {VnV52 (1, 0, 0, 1, 0, 0);} else {VnV52 (0, 1, 0, 1, 0, 0);};
}