//CONTROLES DE PRODUCCION (25)

	var idseleccionado25;
	var aseleccionado25 = [];
	var nuevosclientes = "{'':'Please select...', 1:'hola',2:2,3:3}"; //Listado de clientes para COMBOBOX
		
				
//TABLA CONTROLES_____________________________________________________________________________________________________________

function mostrarControles() {
	//alert("el primer");
	sacarProductos2 (); //Cargo el COMBOBOX de productos
	sacarClientes2 ();  //Cargo el COMBOBOX de clientes
	sacarResponsables2 (); //Cargo el COMBOBOX de responsables
	sacarEquipos2 (); //Cargo el COMBOBOX de equipos de medida
	sacarDocumentos2 (); //Cargo el COMBOBOX de documentos
	//setTimeout('sacarControles()', 200);
	sacarControles ();
	setTimeout('listControles()', 500);
	}
	
function listControles() {
//alert("Dentroo");	
		$(document).ready( function () {
				$('#dynamic25').html( '<table cellpadding="0" cellspacing="0" border="0" class="display" id="example25"></table>' );
				$('#example25').dataTable( {
					"aaData": aDataSet25,	
					"aoColumns": [
						{ "sTitle": "Id Control", "bSearchable": false, "bVisible": false },{ "sTitle": "Control" },{ "sTitle": "Cod Control"},{"sTitle": "Valor Límite"},
						{"sTitle": "Responsable"},{ "sTitle": "Periodo" },{ "sTitle": "Producto"},{"sTitle": "Cliente"},
						{"sTitle": "Equipo"},{"sTitle": "Documento"}],
					"sDom": 'frtip',
					//lfrtip<"clear spacer">T
					"oTableTools": {
						/*"sRowSelect": "single","aButtons": ["select"],*///Solo me muestra el boton select para poder seleccionar las filas.
						"aoColumnDefs": [ {"sClass": "center","aTargets": [ -1, -2 ]}]
					},
				"bSort": false,
				})
				
				//EDITAR DIRECTAMENTE LAS TABLAS
				.makeEditable ({
                    		"aoColumns": [
                    			{onblur: 'submit',
						sUpdateURL: function(value, settings){updateControl (); return value;}
					},
                    			{onblur: 'submit',
						sUpdateURL: function(value, settings){updateControl (); return value;}
					},
                    			{onblur: 'submit',
						sUpdateURL: function(value, settings){updateControl (); return value;}
					},
                    			{event: 'click', indicator: 'Saving CSS Grade...', tooltip: 'Click to select CSS Grade', loadtext: 'loading...',
						type: 'select', onblur: 'submit', data: nuevosresponsables,
						sUpdateURL: function(value, settings){updateControl (); return value;}
					},
					{onblur: 'submit',
						sUpdateURL: function(value, settings){updateControl (); return value;}
					},
					{event: 'click', indicator: 'Saving CSS Grade...', tooltip: 'Click to select CSS Grade', loadtext: 'loading...',
						type: 'select', onblur: 'submit', data: nuevosproductos,
						sUpdateURL: function(value, settings){updateControl (); return value;}
					},
                    			{event: 'click', indicator: 'Saving CSS Grade...', tooltip: 'Click to select CSS Grade', loadtext: 'loading...',
						type: 'select', onblur: 'submit', data: nuevosclientes,
						sUpdateURL: function(value, settings){updateControl (); return value;}
					},
					{event: 'click', indicator: 'Saving CSS Grade...', tooltip: 'Click to select CSS Grade', loadtext: 'loading...',
						type: 'select', onblur: 'submit', data: nuevosequipos,
						sUpdateURL: function(value, settings){updateControl (); return value;}
					},
					{event: 'click', indicator: 'Saving CSS Grade...', tooltip: 'Click to select CSS Grade', loadtext: 'loading...',
						type: 'select', onblur: 'submit', data: nuevosdocumentos,
						sUpdateURL: function(value, settings){updateControl (); return value;}
					}
                                       ]									

				});
				
			});
			
		//Obtengo el ID de la fila que estoy editando	
		$(document).ready( function() {
    			$('#example25 tbody td').click( function () {
				var aPos25 = oTable25.fnGetPosition( this );
				var aData25 = oTable25.fnGetData( aPos25[0] );
				idseleccionado25 =  aData25[0];
				aseleccionado25 = aData25;
			});
			oTable25= $('#example25').dataTable();
			
		});		
			
	} 
	

			
function sacarControles (){
	//alert("inside");
	var db;
        db = openDatabase("DBIW1", "0.1", "Database Isowin One", 200000);	
	if(db){
		db.transaction( function(tx) {
			tx.executeSql("SELECT * FROM controles", [],
				function(tx, result){
					//Creo un array
					/*var output = [];*/
					//Guardo en cada elemento i del vector, un objeto documento.
					aDataSet25 = [];
					for(var i=0; i < result.rows.length; i++) {	
						aDataSet25.push([result.rows.item(i)['idcontrol'],
								result.rows.item(i)['control'],
								result.rows.item(i)['codcontrol'],
								result.rows.item(i)['valorlimite'],
								result.rows.item(i)['idresponsable'],
								result.rows.item(i)['periodo'],
								result.rows.item(i)['idproducto'],
								result.rows.item(i)['idcliente'],
								result.rows.item(i)['idequipo'],
								result.rows.item(i)['iddocumento']
								]);
					}			
				 
			});
		});
		
		
	};
}
//=========================================================================================================					
/*CREAR NUEVO CONTROL*/
	function addControl() {
	//alert("Inside!");	
	
	//Primera opcion
		//$('#example25').dataTable().fnAddData([,"nuevo",,,,,,,,]); 
	
	//Segunda opción
		var db;
		db = openDatabase("DBIW1", "0.1", "Database Isowin One", 200000);
		if(db){ db.transaction( function(tx) {
			tx.executeSql("INSERT INTO controles (control, codcontrol, valorlimite, idresponsable, periodo, idproducto, idcliente, idequipo, iddocumento) VALUES(?,?,?,?,?,?,?,?,?)", ["Nuevo","","","","","","","",""]);
			setTimeout('mostrarControles();',500);
			apprise('El control ha sido incluido'); //alert("Estudio ha cambiado: "+ estudio + " - " + idseleccionado18);
		});};
	}

/*ACTUALIZAR CONTROL*/
	function updateControl () {
		//alert("dentrode: " + aseleccionado25[2]);
	var db;
        db = openDatabase("DBIW1", "0.1", "Database Isowin One", 200000);
		if(db){ db.transaction( function(tx) {
			tx.executeSql("UPDATE controles SET control=?, codcontrol=?, valorlimite=?, idresponsable=?, periodo=?, idproducto=?, idcliente=?, idequipo=?, iddocumento=? WHERE idcontrol=?", [aseleccionado25[1], aseleccionado25[2], aseleccionado25[3], aseleccionado25[4], aseleccionado25[5], aseleccionado25[6], aseleccionado25[7], aseleccionado25[8], aseleccionado25[9], idseleccionado25]);
			//apprise('El control ha sido modificado'); //alert("Estudio ha cambiado: "+ estudio + " - " + idseleccionado18);
		});};
		//setTimeout('mostrarEstudios()',500);
	}
	
/*BORRAR CONTROL*/
	function removeControl() {
		if(idseleccionado25) { 
		apprise('¿Eliminar control?', {'verify': true}, function(r) {
			if(r) { 
				var db;
				db = openDatabase("DBIW1", "0.1", "Database Isowin One", 200000);
				if(db){	
					db.transaction(function(tx) {
					tx.executeSql("DELETE FROM controles WHERE idcontrol=?",[idseleccionado25]);
					apprise('Control borrado'); //alert("Persona borrada: "+ idseleccionado15);
					});
				};
				setTimeout('mostrarControles()',500);
			}
		});
		};
	}

//=========================================================================================================					
/*COMBOBOX DE RESPONSABLES*/

function sacarResponsables2 (){
	var db;
        db = openDatabase("DBIW1", "0.1", "Database Isowin One", 200000);					
	if(db){db.transaction( function(tx) {
			tx.executeSql("SELECT * FROM personas WHERE esresp=?", ["Si"], function(tx, result){
				nuevosresponsables = "{0:'' ";
				for(var i=0; i < result.rows.length; i++) {nuevosresponsables = nuevosresponsables +", " + result.rows.item(i)['idpersona']+":'"+result.rows.item(i)['apellidos'] + ", " + result.rows.item(i)['nombre'] + "' ";};
				nuevosresponsables = nuevosresponsables + "}";});
		});	
	};
	//setTimeout('alert(nuevosresponsables);', 500);
}
//=========================================================================================================					
/*COMBOBOX DE PRODUCTOS*/

function sacarProductos2 (){
	var db;
        db = openDatabase("DBIW1", "0.1", "Database Isowin One", 200000);					
	if(db){db.transaction( function(tx) {
			tx.executeSql("SELECT * FROM productos", [], function(tx, result){
				nuevosproductos = "{0:'' ";
				for(var i=0; i < result.rows.length; i++) {nuevosproductos = nuevosproductos +", " + result.rows.item(i)['idproducto']+":'"+result.rows.item(i)['producto']+"' ";};
				nuevosproductos = nuevosproductos + "}";});
		});	
	};
	//setTimeout('alert(nuevosclientes);', 500);
}
//=========================================================================================================					
/*COMBOBOX DE CLIENTES*/

function sacarClientes2 (){
	var db;
        db = openDatabase("DBIW1", "0.1", "Database Isowin One", 200000);					
	if(db){db.transaction( function(tx) {
			tx.executeSql("SELECT * FROM clientes", [], function(tx, result){
				nuevosclientes = "{0:'' ";
				for(var i=0; i < result.rows.length; i++) {nuevosclientes = nuevosclientes +", " + result.rows.item(i)['idcliente']+":'"+result.rows.item(i)['cliente']+"' ";};
				nuevosclientes = nuevosclientes + "}";});
		});	
	};
	//setTimeout('alert(nuevosclientes);', 500);
}
//=========================================================================================================					
/*COMBOBOX DE EQUIPOS*/
NuevoDiam
function sacarEquipos2 (){
	var db;
        db = openDatabase("DBIW1", "0.1", "Database Isowin One", 200000);					
	if(db){db.transaction( function(tx) {
			tx.executeSql("SELECT * FROM equipos", [], function(tx, result){
				nuevosequipos = "{0:'' ";
				for(var i=0; i < result.rows.length; i++) {nuevosequipos = nuevosequipos +", " + result.rows.item(i)['idequipo']+":'"+result.rows.item(i)['equipo']+"' ";};
				nuevosequipos = nuevosequipos + "}";});
		});	
	};
	//setTimeout('alert(nuevosclientes);', 500);
}
//=========================================================================================================					
/*COMBOBOX DE DOCUMENTOS*/

function sacarDocumentos2 (){
	var db;
        db = openDatabase("DBIW1", "0.1", "Database Isowin One", 200000);					
	if(db){db.transaction( function(tx) {
			tx.executeSql("SELECT * FROM documentos", [], function(tx, result){
				nuevosdocumentos = "{0:'' ";
				for(var i=0; i < result.rows.length; i++) {nuevosdocumentos = nuevosdocumentos +", " + result.rows.item(i)['iddocumento']+":'"+result.rows.item(i)['coddocumento']+ " "+result.rows.item(i)['documento']+"' ";};
				nuevosdocumentos = nuevosdocumentos + "}";});
		});	
	};
	//setTimeout('alert(nuevosdocumentos);', 500);
}
//=========================================================================================================					

