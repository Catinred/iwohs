//PROPIEDAD DEL CLIENTE (17)

	var idseleccionado17;
	var nuevosclientes; //Listado de clientes para COMBOBOX
				
				
//TABLA PROPIEDAD DEL CLIENTE_____________________________________________________________________________________________________________

function mostrarPropiedades() {
	sacarPropiedades ();
	sacarResponsables ();
	setTimeout('listPropiedades()', 500);
	}
	
function listPropiedades() {
			$(document).ready(			
			function () {
				$('#dynamic17').html( '<table cellpadding="0" cellspacing="0" border="0" class="display" id="example17"></table>' );
				$('#example17').dataTable( {
					"aaData": aDataSet17,
						
					"aoColumns": [
						{ "sTitle": "Id"/*, "bSearchable": false, "bVisible": false*/ },
						{ "sTitle": "Material" },
						{ "sTitle": "Cliente" },
						{ "sTitle": "Ubicación", "bSearchable": false, "bVisible": false },
						{ "sTitle": "Utilización", "bSearchable": false, "bVisible": false },
						{ "sTitle": "Responsable" },
						{ "sTitle": "Vulnerabilidad", "bSearchable": false, "bVisible": false },
						{ "sTitle": "Protección", "bSearchable": false, "bVisible": false },
						{ "sTitle": "Caducidad"},
						{ "sTitle": "Observaciones", "bSearchable": false, "bVisible": false }
						],
						
					"sScrollY": "430px",
					"bPaginate": false,
					"bScrollCollapse": true,
						
					"sDom": 'lfrtip<"clear spacer">T',
					/*"sDom": 'T<"clear">lfrtip<"clear spacer">T',*/ //Muestra los botones de copy,print...
					"oTableTools": {
						"sRowSelect": "single","aButtons": ["select"], //Solo me muestra el boton select para poder seleccionar las filas.
							
					"aoColumnDefs": [ {
						"sClass": "center",
						"aTargets": [ -1, -2 ]
						} ]
					}
				});
				
			//Cargo el COMBOBOX de clientes ------------
			sacarClientes ();
			setTimeout('$("#combopccliente").html(nuevosclientes);',200);
			//--------------------------------------------------
			//Cargo el COMBOBOX de responsables del formulario NCs------------
			setTimeout('$("#combopcresp").html(nuevosresponsables);',200);
			//--------------------------------------------------	
			
			});
			
	
				
	//Cargar datos de proveedor para editar en formulario	
			$(document).ready(
				function() {
    			$('#example17 tbody td').click( function () {
			
        		/* Get the position of the current data from the node */
        		var aPos17 = oTable17.fnGetPosition( this );
         
        		/* Get the data array for this row */
        		var aData17 = oTable17.fnGetData( aPos17[0] );
				/*alert("Ok "+aData[0]);*/
				
				idseleccionado17 =  aData17[0];
				document.getElementById("txtpcmaterial").value = aData17[1];
				document.getElementById("combopccliente").value = aData17[2];
				document.getElementById("txtpcubicacion").value = aData17[3];
				document.getElementById("txtpcutilizacion").value = aData17[4];
				document.getElementById("txtpcresponsable").value = aData17[5];
				document.getElementById("txtpcvulnerabilidad").value = aData17[6];
				document.getElementById("txtpcproteccion").value = aData17[7];
				document.getElementById("txtpcfchcaducidad").value = aData17[8];
				document.getElementById("txtpcobs").value = aData17[9];
         
    			});
     
   				 /* Init DataTables */
   				 oTable17 = $('#example17').dataTable();
				});
		
	}	

function sacarPropiedades (){
	var db;
        db = openDatabase("DBIW1", "0.1", "Database Isowin One", 200000);	
	if(db){
		db.transaction( function(tx) {
			tx.executeSql("SELECT * FROM propcliente", [],
				function(tx, result){
					//Creo un array
					/*var output = [];*/
					//Guardo en cada elemento i del vector, un objeto documento.
					aDataSet17 = [];
					for(var i=0; i < result.rows.length; i++) {
/*						output.push([result.rows.item(i)['iddocumento'],
								result.rows.item(i)['documento'],
								result.rows.item(i)['revision']]);*/		
						aDataSet17.push([result.rows.item(i)['idpc'],
								result.rows.item(i)['material'],
								result.rows.item(i)['idcliente'],
								result.rows.item(i)['ubicacion'],
								result.rows.item(i)['uso'],
								result.rows.item(i)['responsable'],
								result.rows.item(i)['vulnerabilidad'],
								result.rows.item(i)['proteccion'],
								result.rows.item(i)['fchcaducidad'],
								result.rows.item(i)['obs'],
								]);
					}			
				 
			});
		});
		
		
	};
}
	
//=========================================================================================================					
/*NUEVA PROPIEDAD*/
	function addPropiedad (material, cliente, ubicacion, uso, responsable, vulnerabilidad, proteccion, fchcaducidad, obs) {
		var db;
		db = openDatabase("DBIW1", "0.1", "Database Isowin One", 200000);
		if(db){	
		  db.transaction( function(tx) {
			tx.executeSql("INSERT INTO propcliente (material, idcliente, ubicacion, uso, responsable, vulnerabilidad, proteccion, fchcaducidad, obs) VALUES(?,?,?,?,?,?,?,?,?)", [material, cliente, ubicacion, uso, responsable, vulnerabilidad, proteccion, fchcaducidad, obs]);
			tx.executeSql("SELECT * FROM propcliente", [], function(tx, result){
				nuevoId = result.rows.item(result.rows.length-1)["idpc"];
				CEXaddCita("Devolución a cliente ", fchcaducidad, fchcaducidad, "Devolver el " + material, "PCL" + nuevoId);
				apprise('La propiedad del cliente ha sido guardada');
			});
		});
		};
		setTimeout('mostrarPropiedades',500);
	}
	
/*ACTUALIZAR PROPIEDAD*/
	function updatePropiedad (material, cliente, ubicacion, uso, responsable, vulnerabilidad, proteccion, fchcaducidad, obs) {
		var db;
		//alert("dentro");
        db = openDatabase("DBIW1", "0.1", "Database Isowin One", 200000);
		if(db){	
		  db.transaction( function(tx) {
			tx.executeSql("UPDATE propcliente SET material=?, idcliente=?, ubicacion=?, uso=?, responsable=?, vulnerabilidad=?, proteccion=?, fchcaducidad=?, obs=?  WHERE idpc=?", [material, cliente, ubicacion, uso, responsable, vulnerabilidad, proteccion, fchcaducidad, obs, idseleccionado17]);
			CEXupdateCita("Devolución a cliente ", fchcaducidad, fchcaducidad, "Devolver el " + material, "PCL" + idseleccionado17);
			apprise('La propiedad del cliente ha cambiada');

		})};
		setTimeout('mostrarPropiedades',500);
		}					

/*BORRAR PROPIEDAD*/
	function removePropiedad() {
		apprise('¿Eliminar la Propiedad?', {'verify': true}, function(r) {
			if(r) { 
		var db;
        db = openDatabase("DBIW1", "0.1", "Database Isowin One", 200000);
		if(db){	
		  db.transaction(function(tx) {
			tx.executeSql("DELETE FROM propcliente WHERE idpc=?",[idseleccionado17]);
			CEXdeleteCita("PCL" + idseleccionado17);
			apprise('La propiedad del cliente ha sido borrada');

		});};};
		setTimeout('mostrarPropiedades',500);
		});
	}

//=========================================================================================================					
/*COMBOBOX DE CLIENTES*/

function sacarClientes (){
	var db;
        db = openDatabase("DBIW1", "0.1", "Database Isowin One", 200000);	
		//alert ("Estoy dentro");					
	if(db){
		db.transaction( function(tx) {
			tx.executeSql("SELECT * FROM clientes", [],
				function(tx, result){
					nuevosclientes = "<option selected></option>";
					for(var i=0; i < result.rows.length; i++) {	
						nuevosclientes = nuevosclientes + "<option value='" +result.rows.item(i)['idcliente']+"'>"+result.rows.item(i)['cliente']+"</option> ";
					}			
				});
		});	
	
	};
}
