//PUESTOS (16)

	var idseleccionado16;
	var idseleccionado16a;
	var idseleccionado16b;
	var nuevosdatos;
	var nuevosprlpuestos = "{0:'Please select...', 1:'hola', 2:'due', 3:'traix'}"; //Listado de epis para COMBOBOX
				
//TABLA PUESTOS_____________________________________________________________________________________________________________

function mostrarPuestos() {
	sacarPuestos ();
	setTimeout('listPuestos()',500);
	}

function listPuestos() {
		$(document).ready(			
			function () {
				$('#dynamic16').html( '<table cellpadding="0" cellspacing="0" border="0" class="display" id="example16"></table>' );
				$('#example16').dataTable( {
					"aaData": aDataSet16,
						
					"aoColumns": [
						{ "sTitle": "Id"/*, "bSearchable": false, "bVisible": false*/ },
						{ "sTitle": "Puesto" },
						{ "sTitle": "Requisitos", "bSearchable": false, "bVisible": false },
						{ "sTitle": "Funciones", "bSearchable": false, "bVisible": false},
						{ "sTitle": "Id Padre", "bSearchable": false, "bVisible": false }
						],
						
					"sScrollY": "600px",
        			"bPaginate": false,
        			"bScrollCollapse": true,
						
					"sDom": 'lfrtip<"clear spacer">T',
					/*"sDom": 'T<"clear">lfrtip<"clear spacer">T',*/ //Muestra los botones de copy,print...
					"oTableTools": {
						"sRowSelect": "single","aButtons": ["select"], //Solo me muestra el boton select para poder seleccionar las filas.
							
					"aoColumnDefs": [ {
						"sClass": "center",
						"aTargets": [ -1, -2 ]
						} ]
						
				}});

				sacarPRLPuestos2 (); //Cargo el COMBOBOX de los PRLPuestos
				
				});

			//carga los puestos de trabajo en el COMBOBOX de la ficha de personas	
			$("#comboidpuesto").html(nuevosdatos);
			$("#combopuidpadre").html(nuevosdatos);
				
	//Cargar datos del equipo para editar en formulario	
			$(document).ready(function() {
    			$('#example16 tbody td').click( function () {
        		/* Get the position of the current data from the node */
        		var aPos16 = oTable16.fnGetPosition( this );
         
        		/* Get the data array for this row */
        		var aData16 = oTable16.fnGetData( aPos16[0] );
				/*alert("Ok "+aData[0]);*/
				
				idseleccionado16 =  aData16[0];
				document.getElementById("txtpupuesto").value = aData16[1];
				document.getElementById("txtpurequisitos").value = aData16[2];
				document.getElementById("txtpufunciones").value = aData16[3];
				document.getElementById("combopuidpadre").value = aData16[4];
			
			datosBDPersonasPuesto (idseleccionado16);
			datosBDPRLPuestosPuestos (idseleccionado16);
			setTimeout('listPersonasPuesto(); listPRLPuestosPuestos()',200);//				
			
			VnV15 (1, 1, 0, 0);
			VnVEpue (1);//No ver botones update y delete
         
    			});
     
   				 /* Init DataTables */
   				 oTable16= $('#example16').dataTable();
				});
		
	}

function sacarPuestos (){
	var db;
        db = openDatabase("DBIWOHS", "0.1", "Database Isowin OHS", 5 * 1024 * 1024);	
		//alert ("Estoy dentro");					
	if(db){
		db.transaction( function(tx) {
			tx.executeSql("SELECT * FROM puestos", [],
				function(tx, result){
					aDataSet16 = [];
					nuevosdatos = "";
					
					for(var i=0; i < result.rows.length; i++) {	
						aDataSet16.push([result.rows.item(i)['idpuesto'],
								result.rows.item(i)['puesto'],
								result.rows.item(i)['requisitos'],
								result.rows.item(i)['funciones'],
								result.rows.item(i)['idpadre'],
								]);
						nuevosdatos = nuevosdatos + "<option value='" +result.rows.item(i)['idpuesto']+"'>"+result.rows.item(i)['puesto']+"</option> ";
					}			
				});
		});	
	
	};
}
	
//TABLA PERSONAS DEL PUESTO__________________________________________________________________________________________________________

function listPersonasPuesto() {
		$(document).ready(			
			function () {
				$('#dynamic16b').html( '<table cellpadding="0" cellspacing="0" border="0" class="display" id="example16b"></table>' );
				$('#example16b').dataTable( {
					"aaData": aDataSet16b,
						
					"aoColumns": [
						{ "sTitle": "Id"/*, "bSearchable": false, "bVisible": false*/ },
						{ "sTitle": "Nombre" },
						{ "sTitle": "Apelllidos" },
						{ "sTitle": "dni" }
						],
						
					"sScrollY": "250px",
        			"bPaginate": false,
        			"bScrollCollapse": true,
						
					"sDom": 'lfrtip<"clear spacer">T',
					/*"sDom": 'T<"clear">lfrtip<"clear spacer">T',*/ //Muestra los botones de copy,print...
					"oTableTools": {
						"sRowSelect": "single","aButtons": ["select"], //Solo me muestra el boton select para poder seleccionar las filas.
							
					"aoColumnDefs": [ {
						"sClass": "center",
						"aTargets": [ -1, -2 ]
						} ]
						
				}});
				
				});
	//Cargar datos de la calibración para editar en formulario	
		$(document).ready(
				function() {
    			$('#example16b tbody td').click( function () {
        		/* Get the position of the current data from the node */
        		var aPos16b = oTable16b.fnGetPosition( this );
         
        		/* Get the data array for this row */
        		var aData16b = oTable16b.fnGetData( aPos16b[0] );
				/*alert("Ok "+aData[0]);*/
				
				idseleccionado16b =  aData16b[0];
				document.getElementById("txtpnombre").value = aData16b[1];
				document.getElementById("txtpapellidos").value = aData16b[2];
				document.getElementById("txtpdni").value = aData16b[3];
				document.getElementById("txtpfchnac").value = aData16b[4];
				document.getElementById("txtpfchalta").value = aData16b[5];
				document.getElementById("txtpfchbaja").value = aData16b[6];
				document.getElementById("txtplinkcv").value = aData16b[7];
				document.getElementById("comboidpuesto").value = parseInt(aData16b[8]);
				document.getElementById("comboesresp").value = aData16b[9];
				document.getElementById("txtptlf").value = aData16b[10];
				document.getElementById("txtpmovil").value = aData16b[11];
				document.getElementById("txtpmail").value = aData16b[12];
				document.getElementById("txtpdireccion").value = aData16b[13];
				document.getElementById("txtpcp").value = aData16b[14];
				document.getElementById("txtppoblacion").value = aData16b[15];
				document.getElementById("txtpprovincia").value = aData16b[16];
				document.getElementById("txtpcontactourg").value = aData16b[17];
				document.getElementById("txtptlfurg").value = aData16b[18];
				document.getElementById("comboesminus").value = aData16b[19];
				document.getElementById("txtpobs").value = aData16b[20];
				
			
			DatosBDCursosPersona (idseleccionado16b);
			DatosBDRMsPersona (idseleccionado16b);
			DatosBDEPIsPersona (idseleccionado16b);
			DatosBDautorizaciones (idseleccionado16b, 0);
			setTimeout('listCursosPersona();listRMsPersona();listEPIsPersona();listAutorizaciones();',300);				
				
			VnV15 (0, 0, 1, 0);
         
    			});
     
   				 /* Init DataTables */
   				 oTable16b= $('#example16b').dataTable();
				});
		
	}

//DATOS PERSONAS FILTRADAS POR PUESTO______________________________________________________________________
		
function datosBDPersonasPuesto (idseleccionado16) {
	var db;
        db = openDatabase("DBIWOHS", "0.1", "Database Isowin OHS", 5 * 1024 * 1024);
		if(db){	
		db.transaction( function(tx) {
			tx.executeSql("SELECT * FROM personas JOIN personas2 ON personas.idpersona=personas2.idpersona WHERE idpuesto=?", [idseleccionado16],
				function(tx, result){
					//Creo un array
					/*var output = [];*/
					//Guardo en cada elemento i del vector, un objeto documento.
					aDataSet16b = [];
					for(var i=0; i < result.rows.length; i++) {
/*						output.push([result.rows.item(i)['iddocumento'],
								result.rows.item(i)['documento'],
								result.rows.item(i)['revision']]);*/
								
						aDataSet16b.push([result.rows.item(i)['idpersona'],
								result.rows.item(i)['nombre'],
								result.rows.item(i)['apellidos'],
								result.rows.item(i)['dni'],
								result.rows.item(i)['fchnac'],
								result.rows.item(i)['fchalta'],
								result.rows.item(i)['fchbaja'],
								result.rows.item(i)['fsname'],
								result.rows.item(i)['idpuesto'],
								result.rows.item(i)['esresp'],
								result.rows.item(i)['tlf'],
								result.rows.item(i)['movil'],
								result.rows.item(i)['mail'],
								result.rows.item(i)['direccion'],
								result.rows.item(i)['cp'],
								result.rows.item(i)['poblacion'],
								result.rows.item(i)['provincia'],
								result.rows.item(i)['contactourg'],
								result.rows.item(i)['tlfurg'],
								result.rows.item(i)['esminus'],
								result.rows.item(i)['obs']
								]);
												
				}		
   				 /* Init DataTables */
   				 oTable16b = $('#example16b').dataTable();				
				 
				});
				
				
		});
		
	}}

//=========================================================================================================					
/*NUEVO PUESTO*/
	
	function addPuesto(puesto, requisitos, funciones, idpadre) {
		
		var db;
		db = openDatabase("DBIWOHS", "0.1", "Database Isowin OHS", 5 * 1024 * 1024);
		if(db){	
		  db.transaction( function(tx) {
			tx.executeSql("INSERT INTO puestos (puesto, requisitos, funciones, idpadre) VALUES(?,?,?,?)", [puesto, requisitos, funciones, idpadre]);
			apprise('Nuevo puesto de trabajo guardado'); //alert("Equipo guardado: "+ equipo);
		})};
		//DatosBDequipos();
		setTimeout('mostrarPuestos()',500);
		
		NVnewpuesto(); Vlistapersonas(); NVnewpersona();
	}
	
/*ACTUALIZAR PUESTO*/
	function updatePuesto (puesto, requisitos, funciones, idpadre) {
		
	var db;
        db = openDatabase("DBIWOHS", "0.1", "Database Isowin OHS", 5 * 1024 * 1024);
		if(db){	
		  db.transaction( function(tx) {
			tx.executeSql("UPDATE puestos SET puesto=?, requisitos=?, funciones=?, idpadre=?   WHERE idpuesto=?", [puesto, requisitos, funciones, idpadre, idseleccionado16]);
			apprise('Puesto de trabajo modificado'); //alert("Equipo ha cambiado: "+ equipo + " - " + idseleccionado10);
		})};
		//DatosBDequipos();
		setTimeout('mostrarPuestos()',500);
		
	}					

/*BORRAR PUESTO*/
	function removePuesto() {
		apprise('�Eliminar puesto de trabajo?', {'verify': true}, function(r) {
			if(r) { 
				var db;
				db = openDatabase("DBIWOHS", "0.1", "Database Isowin OHS", 5 * 1024 * 1024);
				if(db){	
					db.transaction(function(tx) {
					tx.executeSql("DELETE FROM puestos WHERE idpuesto=?",[idseleccionado16]);
					apprise('Puesto de trabajo borrado'); //alert("Equipo borrado: "+ idseleccionado10);
					});
				};
			setTimeout('mostrarPuestos()',500);
			};
		});
	}
	
//=========================================================================================================
/* VER NO VER*/

//Est� definido en PERSONAS

//=========================================================================================================
	
				
//TABLA PRLPUESTOS DEL PUESTO____________________________________________________________________________________________________

function listPRLPuestosPuestos() {
//alert("Dentroo");	
		$(document).ready( function () {
				$('#dynamic16a').html( '<table cellpadding="0" cellspacing="0" border="0" class="display" id="example16a"></table>' );
				$('#example16a').dataTable( {
					"aaData": aDataSet16a,	
					"aoColumns": [
						{ "sTitle": "IdPuesto", "bSearchable": false, "bVisible": false },
						{"sTitle": "PRL Puesto"},{"sTitle": "Observaciones"}],
					"sDom": 'frtip',
					//lfrtip<"clear spacer">T
					"oTableTools": {
						/*"sRowSelect": "single","aButtons": ["select"],*///Solo me muestra el boton select para poder seleccionar las filas.
						"aoColumnDefs": [ {"sClass": "center","aTargets": [ -1, -2 ]}]
					},
				"bSort": false,
				})
				
				//EDITAR DIRECTAMENTE LAS TABLAS
				.makeEditable ({
                    		"aoColumns": [
                    {event: 'click', indicator: 'Saving CSS Grade...', tooltip: 'Click to select CSS Grade', loadtext: 'loading...',
						type: 'select', onblur: 'submit', data: nuevosprlpuestos,
						sUpdateURL: function(value, settings){updatePRLPuestoPuesto (value); return value;}
					},
					{onblur: 'submit',
						sUpdateURL: function(value, settings){updatePRLPuestoPuesto (); return value;}
					}
					]									
				});
				
			});
			
		//Obtengo el ID de la fila que estoy editando	
		$(document).ready( function() {
    			$('#example16a tbody td').click( function () {
				var aPos16a = oTable16a.fnGetPosition( this );
				var aData16a = oTable16a.fnGetData( aPos16a[0] );
				idseleccionado16a =  aData16a[0];
				aseleccionado16a = aData16a;
			});
			oTable16a= $('#example16a').dataTable();
			
		});		
			
	} 
	
		
function datosBDPRLPuestosPuestos (idseleccionado){
	//alert("inside");
	var db;
        db = openDatabase("DBIWOHS", "0.1", "Database Isowin OHS", 5 * 1024 * 1024);	
	if(db){
		db.transaction( function(tx) {
			tx.executeSql("SELECT * FROM prlpuestopuesto LEFT JOIN prlpuestos ON prlpuestopuesto.idprlpuesto=prlpuestos.idprlpuesto  WHERE idpuesto=?", [idseleccionado],//
				function(tx, result){
					//Creo un array
					/*var output = [];*/
					//Guardo en cada elemento i del vector, un objeto documento.
					aDataSet16a = [];
					for(var i=0; i < result.rows.length; i++) {	
						aDataSet16a.push([
								result.rows.item(i)['id'],
								result.rows.item(i)['prlpuesto'],
								result.rows.item(i)['obs']
								]);
					};			
			});
		});
	};
}
//=========================================================================================================					
//=========================================================================================================					

function mostrarPRLPuestosPuestos() {
	datosBDPRLPuestosPuestos (idseleccionado16);
	setTimeout('listPRLPuestosPuestos()',500);
	}

//=========================================================================================================					
/*CREAR NUEVO PRLPUESTO DEL PUESTO*/
	function addPRLPuestoPuesto() {

		var db;
		db = openDatabase("DBIWOHS", "0.1", "Database Isowin OHS", 5 * 1024 * 1024);
		if(db){ db.transaction( function(tx) {
			tx.executeSql("INSERT INTO prlpuestopuesto (idpuesto, obs) VALUES(?,?)", [idseleccionado16,""]);
			});
			setTimeout('mostrarPRLPuestosPuestos();',500);
			apprise('Haz doble click sobre los campos para introducir la informaci�n'); 
		};
	}

/*ACTUALIZAR PRLPUESTO DEL PUESTO*/
	function updatePRLPuestoPuesto (value) {
		//alert("dentrode: " + aseleccionado25[2]);
	var db;
        db = openDatabase("DBIWOHS", "0.1", "Database Isowin OHS", 5 * 1024 * 1024);
		if(db){ db.transaction( function(tx) {
			if (value) {tx.executeSql("UPDATE prlpuestopuesto SET idprlpuesto=? WHERE id=? ", [value, idseleccionado16a])}
			else{tx.executeSql("UPDATE prlpuestopuesto SET obs=? WHERE id=? ", [aseleccionado16a[2], idseleccionado16a])};
			apprise('PRL Puesto actualizado'); //alert("Estudio ha cambiado: "+ estudio + " - " + idseleccionado18);
		});
	};
		//alert("Guardado");
		//setTimeout('mostrarPRLPuestosPuestos()',500);
	}
	
/*BORRAR PRLPUESTO DEL PUESTO*/
	function removePRLPuestoPuesto() {
		if(idseleccionado16a) { 
		apprise('�Eliminar el PRL Puesto asignado?', {'verify': true}, function(r) {
			if(r) { 
				var db;
				db = openDatabase("DBIWOHS", "0.1", "Database Isowin OHS", 5 * 1024 * 1024);
				if(db){	
					db.transaction(function(tx) {
					tx.executeSql("DELETE FROM prlpuestopuesto WHERE id=?",[idseleccionado16a]);
					apprise('PRL Puesto borrado'); //alert("Persona borrada: "+ idseleccionado15);
					});
				};
				setTimeout('mostrarPRLPuestosPuestos()',500);
			}
		});
		};
	}
//=========================================================================================================					
/*COMBOBOX DE PRL PUESTOS*/

function sacarPRLPuestos2 (){
	var db;
    db = openDatabase("DBIWOHS", "0.1", "Database Isowin OHS", 5 * 1024 * 1024);					
	if(db){
		db.transaction( function(tx) {
			tx.executeSql("SELECT * FROM prlpuestos", [], function(tx, result){
				nuevosprlpuestos = "{0:'' ";
				for(var i=0; i < result.rows.length; i++) {nuevosprlpuestos = nuevosprlpuestos +", " + parseInt(result.rows.item(i)['idprlpuesto']) + ":'" + result.rows.item(i)['prlpuesto'] + "' ";};
				nuevosprlpuestos = nuevosprlpuestos + "}";
			});
		});	
	};
	//setTimeout('alert(nuevosprlpuestos);', 500);
}

//=========================================================================================================	