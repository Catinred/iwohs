//PROVEEDORES (3 y 4)

	var idseleccionado3;
	var idseleccionado4;
	var intEstado3;
	var INTcolor3 = 0; //Color del semaforo en verde
				
				
//TABLA PROVEEDORES_____________________________________________________________________________________________________________

function mostrarProvs(intEst3) {
	intEstado3=intEst3;
	sacarProvs (intEstado3);
	setTimeout('listProvs()',500);
	Vb3(intEst3);
	}

function listProvs() {
		$(document).ready(			
			function () {
				$('#dynamic3').html( '<table cellpadding="0" cellspacing="0" border="0" class="display" id="example3"></table>' );
				$('#example3').dataTable( {
					"aaData": aDataSet3,
						
					
					"aoColumns": [
						{ "sTitle": "Id", "bSearchable": false, "bVisible": false },
						{ "sTitle": "Proveedor" },
						{ "sTitle": "C.I.F."},
						{ "sTitle": "Contacto", "bSearchable": false, "bVisible": false },
						{ "sTitle": "Mail del Contacto", "bSearchable": false, "bVisible": false },
						{ "sTitle": "Dirección", "bSearchable": false, "bVisible": false },
						{ "sTitle": "F. Alta" },
						{ "sTitle": "F. Evaluación" },
						{ "sTitle": "F. Próxima" },
						{ "sTitle": "Calidad/Precio" },
						{ "sTitle": "Criticidad" },
						{ "sTitle": "Competencia" },
						{ "sTitle": "Plazos Entrega" },
						{ "sTitle": "Prestigio" },
						{ "sTitle": "Compromiso" },
						{ "sTitle": "Valoracion" },
						{ "sTitle": "Observaciones", "bSearchable": false, "bVisible": false }
						],
						
					"sScrollY": "600px",
					"bPaginate": false,
					"bScrollCollapse": true,
						
					"sDom": 'lfrtip<"clear spacer">T',
					/*"sDom": 'T<"clear">lfrtip<"clear spacer">T',*/ //Muestra los botones de copy,print...
					"oTableTools": {
						"sRowSelect": "single","aButtons": ["select"], //Solo me muestra el boton select para poder seleccionar las filas.
							
					"aoColumnDefs": [ {
						"sClass": "center",
						"aTargets": [ -1, -2 ]
						} ]
						
				}});
				
				});
	//Cargar datos del equipo para editar en formulario	
		$(document).ready(
			function() {
				$('#example3 tbody td').click( function () {
				/* Get the position of the current data from the node */
				var aPos3 = oTable3.fnGetPosition( this );
         
				/* Get the data array for this row */
				var aData3 = oTable3.fnGetData( aPos3[0]);
				/*alert("Ok "+aData[0]);*/
				
				idseleccionado3 =  aData3[0];
				document.getElementById("txtproveedor").value = aData3[1];
				document.getElementById("txtcif").value = aData3[2];
				document.getElementById("txtcontacto").value = aData3[3];
				document.getElementById("txtmail").value = aData3[4];
				document.getElementById("txtdireccion").value = aData3[5];
				document.getElementById("txtfchalta").value = aData3[6];
				document.getElementById("txtfcheval").value = aData3[7];
				document.getElementById("txtfchprox").value = aData3[8];
				document.getElementById("txtobs").value = aData3[16];
			
						
			mostrarGraficoA1 (idseleccionado3);
			DatosBDNCProvs(idseleccionado3);
			setTimeout('listNCProvs()',200);
					
							
			
			VnV3 (1, 0, 0, 1);
         
    			});
   				 /* Init DataTables */
   				 oTable3= $('#example3').dataTable();
		});
		
	}

//DATOS PROVEEDORES_________________________________________________

function sacarProvs (intEstado3){
	var db;
        db = openDatabase("DBIW1", "0.1", "Database Isowin One", 200000);	
		//alert ("Estoy dentro");					
	var estado3="WHERE valoracion>=5 ";
	if (intEstado3==1) {estado3="WHERE valoracion<5 ";};
	if(db){
		db.transaction( function(tx) {
			tx.executeSql("SELECT * FROM proveedores " + estado3, [],
				function(tx, result){
					//Creo un array
					/*var output = [];*/
					//Guardo en cada elemento i del vector, un objeto documento.
					aDataSet3 = [];
					for(var i=0; i < result.rows.length; i++) {
								
						aDataSet3.push([result.rows.item(i)['idproveedor'],
								result.rows.item(i)['proveedor'],
								result.rows.item(i)['cif'],
								result.rows.item(i)['contacto'],
								result.rows.item(i)['mail'],
								result.rows.item(i)['direccion'],
								result.rows.item(i)['fchinicial'],
								result.rows.item(i)['fcheval'],
								result.rows.item(i)['fchprox'],
								result.rows.item(i)['eval1'],
								result.rows.item(i)['eval2'],
								result.rows.item(i)['eval3'],
								result.rows.item(i)['eval4'],
								result.rows.item(i)['eval5'],
								result.rows.item(i)['eval6'],
								result.rows.item(i)['valoracion'],
								result.rows.item(i)['obs']]);
					};			
				});
		});	
	};
}
	
//TABLA SUMINISTROS NO CONFORMES_________________________________________________________________________________________

function listNCProvs() {
		$(document).ready(			
			function () {
				$('#dynamic4').html( '<table cellpadding="0" cellspacing="0" border="0" class="display" id="example4"></table>' );
				$('#example4').dataTable( {
					"aaData": aDataSet4,
						
					"aoColumns": [
						{ "sTitle": "Id"/*, "bSearchable": false, "bVisible": false*/ },
						{ "sTitle": "No Conformidad" },
						{ "sTitle": "Cod N.C.P.", "bSearchable": false, "bVisible": false  },
						{ "sTitle": "F. Creacion"},
						{ "sTitle": "F. Cierre", "bSearchable": false, "bVisible": false },
						{ "sTitle": "Responsable", "bSearchable": false, "bVisible": false  },
						{ "sTitle": "Estado"  },
						{ "sTitle": "Descripcion", "bSearchable": false, "bVisible": false },
						{ "sTitle": "Correccion", "bSearchable": false, "bVisible": false }
						],
						
					"sScrollY": "250px",
					"bPaginate": false,
					"bScrollCollapse": true,
						
					"sDom": 'lfrtip<"clear spacer">T',
					/*"sDom": 'T<"clear">lfrtip<"clear spacer">T',*/ //Muestra los botones de copy,print...
					"oTableTools": {
						"sRowSelect": "single","aButtons": ["select"], //Solo me muestra el boton select para poder seleccionar las filas.
							
					"aoColumnDefs": [ {
						"sClass": "center",
						"aTargets": [ -1, -2 ]
						} ]
						
				}});

			//Cargo el COMBOBOX de responsables del formulario NCs------------
			sacarResponsables ();
			setTimeout('$("#comboncprovresp").html(nuevosresponsables);',200);
			//--------------------------------------------------
				
				});
	//Cargar datos de la calibración para editar en formulario	
		$(document).ready(
				function() {
    			$('#example4 tbody td').click( function () {
        		/* Get the position of the current data from the node */
        		var aPos4 = oTable4.fnGetPosition( this );
         
        		/* Get the data array for this row */
        		var aData4 = oTable4.fnGetData( aPos4[0] );
				/*alert("Ok "+aData[0]);*/
				
				idseleccionado4 =  aData4[0];
				document.getElementById("txtncprov").value = aData4[1];
				document.getElementById("txtcodncprov").value = aData4[2];
				document.getElementById("txtncprovfchinicio").value = aData4[3];
				document.getElementById("txtncprovfchfin").value = aData4[4];
				document.getElementById("comboncprovresp").value = aData4[5];
				document.getElementById("comboncprovestado").value = aData4[6];
				document.getElementById("txtncprovdescripcion").value = aData4[7];
				document.getElementById("txtncprovcorreccion").value = aData4[8];
				
			VnV3 (1, 0, 1, 1);
         
    			});
     
   				 /* Init DataTables */
   				 oTable4= $('#example4').dataTable();
		});
		
	}

//DATOS NCPROVS FILTRADAS POR EQUIPO______________________________________________________________________
		
function DatosBDNCProvs(idseleccionado3) {
	var db;
        db = openDatabase("DBIW1", "0.1", "Database Isowin One", 200000);
		if(db){	
		db.transaction( function(tx) {
			tx.executeSql("SELECT * FROM ncprovs WHERE idproveedor=?", [idseleccionado3],
				function(tx, result){
					//Creo un array
					/*var output = [];*/
					//Guardo en cada elemento i del vector, un objeto documento.
					aDataSet4 = [];
					for(var i=0; i < result.rows.length; i++) {
	
						aDataSet4.push([result.rows.item(i)['idncprov'],
								result.rows.item(i)['ncprov'],
								result.rows.item(i)['codncprov'],
								result.rows.item(i)['fchinicio'],
								result.rows.item(i)['fchfin'],
								result.rows.item(i)['responsable'],
								result.rows.item(i)['estado'],
								result.rows.item(i)['descripcion'],
								result.rows.item(i)['correccion']
								]);
												
					}		
   				 /* Init DataTables */
   				 oTable4 = $('#example4').dataTable();				
				 
				});
				
				
		});
		
	};
}

	

//=========================================================================================================					
/*NUEVO PROVEEDOR*/
	function addProv(proveedor, cif, contacto, mail, direccion, fchinicial, fcheval, fchprox, obs) {
					//alert("Dentro de addProv " + eval1);
		var db;
		var mediaevals = ( eval1 + eval2 + eval3 + eval4 + eval5 + eval6)/6;
		var valor2dec = mediaevals.toFixed(3);
			
		db = openDatabase("DBIW1", "0.1", "Database Isowin One", 200000);
		if(db){	
		  db.transaction( function(tx) {
			tx.executeSql("INSERT INTO proveedores (proveedor, cif, contacto, mail, direccion, fchinicial, fcheval, fchprox, eval1, eval2, eval3, eval4, eval5, eval6, valoracion, obs) VALUES (?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)", [proveedor, cif, contacto, mail, direccion, fchinicial, fcheval, fchprox, eval1, eval2, eval3, eval4, eval5, eval6, valor2dec, obs]);
			tx.executeSql("SELECT * FROM proveedores", [], function(tx, result){
				nuevoId = result.rows.item(result.rows.length-1)["idproveedor"];
				//alert("nuevoId: " + nuevoId);
				CEXaddCita( "Evaluar proveedor: " + proveedor, fchprox, fchprox, "Reevaluar al proveedor " + proveedor, "PRV" + nuevoId);
				apprise('El proveedor ha sido guardado'); //alert("proveedor guardado: "+ txtproveedor +"/"+ ieval1 +"/"+ ieval2 +"/"+ ieval3 +"/"+ ieval4 +"/"+ ieval5);
				});
			});
		};
		setTimeout('mostrarProvs(intEstado3);',500);
		VnV3 (0, 1, 0, 0);
	}

	
/*ACTUALIZAR PROVEEDOR*/
	function updateProv (proveedor, cif, contacto, mail, direccion, fchinicial, fcheval, fchprox, obs) {
		
		var db;
		
		db = openDatabase("DBIW1", "0.1", "Database Isowin One", 200000);
		if(db){	
			db.transaction( function(tx) {
				tx.executeSql("UPDATE proveedores SET proveedor=?, cif=?, contacto=?, mail=?, direccion=?, fchinicial=?, fcheval=?, fchprox=?, obs=?   WHERE idproveedor=?", [proveedor, cif, contacto, mail, direccion, fchinicial, fcheval, fchprox, obs, idseleccionado3]);
				CEXupdateCita( "Evaluar proveedor: " + proveedor, fchprox, fchprox, "Reevaluar al proveedor " + proveedor, "PRV" + idseleccionado3);
				apprise('El proveedor ha sido modificado'); //alert("Equipo ha cambiado: "+ equipo + " - " + idseleccionado10);
			});
		};
		setTimeout('mostrarGraficoA1 (idseleccionado3);',500);
	}	

/*ACTUALIZAR EVALUACIÓN  DE PROVEEDOR*/
	function updateEvalProv () {
		
		var db;
		var mediaevals = ( eval1 + eval2 + eval3 + eval4 + eval5 + eval6)/6;
		var valor2dec = mediaevals.toFixed(3);
		
		db = openDatabase("DBIW1", "0.1", "Database Isowin One", 200000);
		if(db){	
			db.transaction( function(tx) {
				tx.executeSql("UPDATE proveedores SET eval1=?, eval2=?, eval3=?, eval4=?, eval5=?, eval6=?, valoracion=?   WHERE idproveedor=?", [eval1, eval2, eval3, eval4, eval5, eval6, valor2dec, idseleccionado3]);
				apprise('La valoración del proveedor ha sido modificada'); //alert("Equipo ha cambiado: "+ equipo + " - " + idseleccionado10);
			});
		};
		setTimeout('mostrarGraficoA1 (idseleccionado3);',500);
	}	

/*BORRAR PROVEEDOR*/
	function removeProv() {
		apprise('¿Eliminar el proveedor?', {'verify': true}, function(r) {
			if(r) { 
				var db;
				db = openDatabase("DBIW1", "0.1", "Database Isowin One", 200000);
				if(db){	
					db.transaction(function(tx) {
						tx.executeSql("DELETE FROM proveedores WHERE idproveedor=?",[idseleccionado3]);
						tx.executeSql("DELETE FROM ncprovs WHERE idproveedor=?",[idseleccionado3]); //limpia calibraciones asociadas.
						});
					CEXdeleteCita("PRV" + idseleccionado3);
					apprise('El proveedor ha sido borrado'); //alert("Equipo borrado: "+ idseleccionado10);
				};
			setTimeout('mostrarProvs(intEstado3)',500);
			};
		});
		VnV3 (0, 1, 0, 0);
	}
	
//=========================================================================================================					
/*NUEVA NCPROV*/
	
	function addNCProv (ncprov, codncprov, fchinicio, fchfin, responsable, estado, descripcion, correccion) {
		
		var db;
		db = openDatabase("DBIW1", "0.1", "Database Isowin One", 200000);
		if(db){	
		  db.transaction( function(tx) {
			tx.executeSql("INSERT INTO ncprovs(ncprov, codncprov, fchinicio, fchfin, responsable, estado, descripcion, correccion, idproveedor) VALUES(?,?,?,?,?,?,?,?,?)", [ncprov, codncprov, fchinicio, fchfin, responsable, estado, descripcion, correccion, idseleccionado3]);
			apprise('Suministro no conforme guardado'); //alert("Calibración guardada: "+ fchcal);
		})};
		
		DatosBDNCProvs(idseleccionado3);
		setTimeout('listNCProvs();',500);
	}
	
/*ACTUALIZAR NCPROV*/
	function updateNCProv (ncprov, codncprov, fchinicio, fchfin, responsable, estado, descripcion, correccion) {
		var db;
		db = openDatabase("DBIW1", "0.1", "Database Isowin One", 200000);
		if(db){	
		  db.transaction( function(tx) {
			tx.executeSql("UPDATE ncprovs SET ncprov=?, codncprov=?, fchinicio=?, fchfin=?, responsable=?, estado=?, descripcion=?, correccion=?, idproveedor=?  WHERE idncprov=?", [ncprov, codncprov, fchinicio, fchfin, responsable, estado, descripcion, correccion, idseleccionado3, idseleccionado4]);
			apprise('Suministro no conforme modificado'); //alert("La calibración ha cambiado: "+ fchcal + " - " + idseleccionado11);
		})};
		
		DatosBDNCProvs(idseleccionado3);
		setTimeout('listNCProvs();',500);	
	}

/*BORRAR NCPROV*/
	function removeNCProv () {
		apprise('¿Eliminar suministro no conforme?', {'verify': true}, function(r) {
		if(r) { 
			var db;
			db = openDatabase("DBIW1", "0.1", "Database Isowin One", 200000);
			if(db){	
				db.transaction(function(tx) {
					tx.executeSql("DELETE FROM ncprovs WHERE idncprov=?",[idseleccionado4]);
					apprise('Suministro no conforme borrado'); //alert("Calibración borrada: "+ idseleccionado11);
				});
			};
		};
		});
		DatosBDNCProvs(idseleccionado3);
		setTimeout('listNCProvs();',500);
	}
	      
    //=========================================================================================================		
/*VALOR DE LAS STARS*/
	
	var eval1=0; var eval2=0; var eval3=0; var eval4=0; var eval5=0; var eval6=0;
		
	$(function(){	
		$('.star1').rating({callback: function(value, link){eval1 = parseInt(value);}});
		$('.star2').rating({callback: function(value, link){eval2 = parseInt(value);}});
		$('.star3').rating({callback: function(value, link){eval3 = parseInt(value);}});
		$('.star4').rating({callback: function(value, link){eval4 = parseInt(value);}});
		$('.star5').rating({callback: function(value, link){eval5 = parseInt(value);}});
		$('.star6').rating({callback: function(value, link){eval6 = parseInt(value);}});
	})
	
//=========================================================================================================
/* VER NO VER*/
var verNPRO= 0; var verLPRO= 1; var verNNCP= 0; var verLNCP= 0;

function VnV3 (Vnpro, Vlpro, Vnncp, Vlncp) { 
	if (verNPRO!=Vnpro) {$("#newprov").toggle(200); verNPRO=Vnpro; $("#txtproveedor").focus();};
	if (verLPRO!=Vlpro) {$("#listaprovs").toggle(200); verLPRO=Vlpro;};
	if (verNNCP!=Vnncp) {$("#newncprov").toggle(200); verNNCP=Vnncp; $("#txtncprov").focus();};
	if (verLNCP!=Vlncp) {$("#listancprovs").toggle(200); verLNCP=Vlncp;};
}
//=========================================================================================================	
//VER BOTON SEMAFORO_______________________________________________________________________

//Funcion de inicializaci�n de la pesta�a, ocultando el bot�n rojo.
function VbInit3() {document.getElementById('botonrojo3').style.display = 'none';}
//valor 1 se pone rojo, valor 0 se pone verde.	
function Vb3(intColor3) {
	if (INTcolor3!=intColor3) {$("#botonrojo3").toggle(200); $("#botonverde3").toggle(200); INTcolor3=intColor3;};
	}
//__________________________________________________________________________________________
    