
// variables globales
var chartA1; var serieA1 =  [{name: "HolaMajox", data: [3,4,1,2,5,4], pointPlacement: 'on'}]; var serieAuxA1 = []; //Inicializacion de array

var serieAuxA=[];

function sacarserieA1 (idProveedor, serieAuxA){
	
	var db;
	
        db = openDatabase("DBIW1", "0.1", "Database Isowin One", 200000);	
		//alert ("Estoy dentro");	

	var valoresA1 = [];
	var valoresA2 = [];
	
		if(db){
		//alert("conectado");	
			db.transaction( function(tx) {
				tx.executeSql("SELECT * FROM proveedores WHERE idproveedor=?", [idProveedor],
					function(tx, result){
							//alert("Logitud del result: "+result.rows.length);
					var nombreProveedor = result.rows.item(0)['proveedor'];
						
					valoresA1 = [result.rows.item(0)['eval1'], result.rows.item(0)['eval2'], result.rows.item(0)['eval3'], result.rows.item(0)['eval4'], result.rows.item(0)['eval5'], result.rows.item(0)['eval6']]; 
					
						serieAuxA.push({name: nombreProveedor, data: valoresA1, pointPlacement: 'on'});
							//alert("inside: " + valores1[0]);
				});
				
				tx.executeSql("SELECT * FROM proveedores", [],
					function(tx, result2){
					
					var porCriterio = [0,0,0,0,0,0];

					for(var i=0; i < result2.rows.length; i++) {	
					porCriterio[0] = porCriterio[0] + parseInt(result2.rows.item(i)['eval1']);
					porCriterio[1] = porCriterio[1] + parseInt(result2.rows.item(i)['eval2']);
					porCriterio[2] = porCriterio[2] + parseInt(result2.rows.item(i)['eval3']);
					porCriterio[3] = porCriterio[3] + parseInt(result2.rows.item(i)['eval4']);
					porCriterio[4] = porCriterio[4] + parseInt(result2.rows.item(i)['eval5']);
					porCriterio[5] = porCriterio[5] + parseInt(result2.rows.item(i)['eval6']);					
					};
					porCriterio[0] = porCriterio[0]/result2.rows.length;
					porCriterio[1] = porCriterio[1]/result2.rows.length;
					porCriterio[2] = porCriterio[2]/result2.rows.length;
					porCriterio[3] = porCriterio[3]/result2.rows.length;
					porCriterio[4] = porCriterio[4]/result2.rows.length;
					porCriterio[5] = porCriterio[5]/result2.rows.length;
						
					valoresA2 = [porCriterio[0], porCriterio[1], porCriterio[2], porCriterio[3], porCriterio[4], porCriterio[5]]; 
					
					serieAuxA.push({name: "Todos", data: valoresA2, pointPlacement: 'on'});
							//alert("inside: " + valores2[0]);
				});	
							//serieAux = [{name : "proveedor", data : valores1},{name : "Todos", data : valores2}];				
			});	
		};
						
	
	return serieAuxA;	
	//alert("outside: " + valoresA1[0]);				
	}
	
		
function mostrarGraficoA1 (idProveedor) {
		//alert(idProveedor);
	serieA1 = sacarserieA1 (idProveedor, serieAuxA1);
		//alert("sigue");
	setTimeout('showChartA1()',500);
	serieA1.splice(0,5);
	}

function showChartA1(){
	
		window.chartA1 = new Highcharts.Chart({
			chart: {renderTo:  'containerA1', polar: true, type: 'line' /*events: {load: sacarseries()}*/},
			title: {text:  'Evaluación del proveedor', x: -20 /* center */},
			pane: {size: '80%'},
			xAxis: {categories: ['Calidad/Precio', 'Criticidad', 'Competencia', 'Plazos', 'Prestigio', 'Compromiso'], tickmarkPlacement: 'on', lineWidth: 0},
			yAxis: {gridLineInterpolation: 'polygon', lineWidth: 0, min: 0, max: 10},
			tooltip: {shared: true},
			//tooltip: {formatter: function() { return '<b>'+ this.series.name +'</b><br/>'+ this.x +': '+ this.y +''; /* unidades del cada valor de la serie. */}},
			legend: {enabled: false},
			series: serieA1,
			credits: {enabled: false}
		});

	}


				