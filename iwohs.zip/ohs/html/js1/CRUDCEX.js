//COMUNICACIONES EXTERNAS

//=========================================================================================================
//LISTA ACCIONES CORRECTIVAS Y PREVENTIVAS

/*NUEVA ACP*/
//Creaci�n de nuevas ACPs remotas desde la pesta�a de NO CONFORMIDADES de cualquier otro proceso 
//EXCEPTO "ACP" que trabaja con addACP2

	function CEXaddACP(acp, codacp, tipo, origen, fchalta, responsable, equipo, estado, acciones, fchprevista, seguimiento, fchcierre, eficacia, fcheficacia) {
		var db;
		db = openDatabase("DBIW1", "0.1", "Database Isowin One", 200000);
		if(db){	
		  db.transaction( function(tx) {
			tx.executeSql("INSERT INTO acps (acp, codacp, tipo, origen, fchalta, responsable, equipo, estado, acciones, fchprevista, seguimiento, fchcierre, eficacia, fcheficacia) VALUES(?,?,?,?,?,?,?,?,?,?,?,?,?,?)", [acp, codacp, tipo, origen, fchalta, responsable, equipo, estado, acciones, fchprevista, seguimiento, fchcierre, eficacia, fcheficacia]);
			alert("ACP guardada: "+ acp);
		})};
	}
	
//=========================================================================================================
//CALENDARIO
	
/*NUEVA CITA*/
	function CEXaddCita(txtcita, txtinicio, txtfin, txtdescripcion, txttrazabilidad) {
		//alert("Estoy dentro");
			if (txtcita != "") {
				var db;
				var idAux = new Date();
				
				db = openDatabase("DBIW1", "0.1", "Database Isowin One", 200000);
				if (db) {
					db.transaction( function(tx) {
					tx.executeSql("INSERT INTO tareas (tarea, fchinicio, fchfin, descripcion, prioridad, trazabilidad) VALUES(?,?,?,?,?,?)", [txtcita, txtinicio, txtfin, txtdescripcion, 0, txttrazabilidad]);
					});	
				};
			};
	}
				
/*ELIMINA CITA*/			
	function CEXdeleteCita(txttrazabilidad){
		if (txttrazabilidad) {			
			var db;
			db = openDatabase("DBIW1", "0.1", "Database Isowin One", 200000);
			if(db){		
				db.transaction( function(tx) {
				tx.executeSql("DELETE FROM tareas WHERE trazabilidad=?", [txttrazabilidad]);
				});
			};
		};
	}

/*ACTUALIZAR CITA*/

	function CEXupdateCita(txtcita, nuevoinicio, nuevofin, descripcion, txttrazabilidad){
		var db;
			db = openDatabase("DBIW1", "0.1", "Database Isowin One", 200000);
			if (db) {
				db.transaction( function(tx) {	
					tx.executeSql("SELECT * FROM tareas WHERE trazabilidad=?", [txttrazabilidad], function(tx, result){
						if (result.rows.length !=0) {
							tx.executeSql("UPDATE tareas SET tarea=?, fchinicio=?, fchfin=?, descripcion=? WHERE trazabilidad=?", [txtcita, nuevoinicio, nuevofin, descripcion, txttrazabilidad]);
						} else {
							CEXaddCita(txtcita, nuevoinicio, nuevofin, descripcion, txttrazabilidad);
						};
					});					
				});
				//alert("Cita cambiada: " + txtcita);
			};
	}
					
//=========================================================================================================	
//PLANIFICACION
	//CEXTipo: indica de donde viene el objetivo a incluir. ej: CEXtipo = "ACP".
					
/*NUEVO OBJETIVO*/
	function CEXaddObjetivo (CEXtipo, CEXidAccion, CEXaccion, descripcion, responsable, recursos, fchinicio, fchfin, valorultrev, fchultrev, color) {
		var db; 
		var nuevoId;
		var objetivoAUX = CEXtipo + CEXidAccion; 	//Lo utilizo como identificador para luego poder modificar y eliminar la cita
		var fchinicioAUX = changeFch (fchinicio);	//Cambio a formato americano las fechas
		var fchfinAUX = changeFch (fchfin);
										//alert("Voy a crear: "+  objetivoAUX + " CEX Accion: "+  CEXaccion);
		db = openDatabase("DBIW1", "0.1", "Database Isowin One", 200000);
		if(db){	
			db.transaction( function(tx) {
				tx.executeSql("INSERT INTO objetivos (objetivo, descripcion, responsable, recursos) VALUES(?,?,?,?)", 
				[objetivoAUX, descripcion, responsable, recursos]);
				tx.executeSql("SELECT * FROM objetivos", [], function(tx, result){
					nuevoId = result.rows.item(result.rows.length-1)["idobjetivo"];
										//alert("Id del Objetivo que acabo de crear: "+ nuevoId);
					tx.executeSql("INSERT INTO acciones (accion, adescripcion, aresponsable, arecursos, fchinicio, fchfin, valorultrev, fchultrev, idobjetivo, color) VALUES(?,?,?,?,?,?,?,?,?,?)", 
					[CEXaccion, descripcion, responsable, recursos, fchinicioAUX, fchfinAUX, valorultrev, fchultrev,  nuevoId, color]);
					});
			});	
										//alert("Transacci�n hecha: "+  objetivoAUX + " Nuevo ID: "+  nuevoId);
		};
	}
	
/*ACTUALIZAR OBJETIVO*/
	function CEXupdateObjetivo (CEXtipo, CEXidAccion, CEXaccion, descripcion, responsable, recursos, fchinicio, fchfin, valorultrev, fchultrev, color) {
		var db;
		var objetivoAUX = CEXtipo + CEXidAccion;
		var idObjetivoAUX;		
		var fchinicioAUX = changeFch (fchinicio);//Cambio a formato americano las fechas
		var fchfinAUX = changeFch (fchfin);
										//alert(objetivoAUX);
		db = openDatabase("DBIW1", "0.1", "Database Isowin One", 200000);
		if(db){	
			db.transaction( function(tx) {
				tx.executeSql("SELECT * FROM objetivos WHERE objetivo=?", [objetivoAUX], function(tx, result){
					idObjetivoAUX = result.rows.item(0)["idobjetivo"];
										//alert(idObjetivoAUX);
					tx.executeSql("UPDATE objetivos SET descripcion=?, responsable=?, recursos=?  WHERE idobjetivo=?", 
						[descripcion, responsable, recursos, idObjetivoAUX]);
					tx.executeSql("UPDATE acciones SET accion=?, adescripcion=?, aresponsable=?, arecursos=?, fchinicio=?, fchfin=?, valorultrev=?, fchultrev=?, color=?  WHERE idobjetivo=?", 
						[CEXaccion, descripcion, responsable, recursos, fchinicioAUX, fchfinAUX, valorultrev, fchultrev, color, idObjetivoAUX]);
										//alert("Transaccion modificada: " +  objetivoAUX);
				});
			});
		};
	}					
	
/*BORRAR OBJETIVO*/
	function CEXremoveObjetivo(CEXtipo, CEXidAccion) {
		var db;
		var objetivoAUX = CEXtipo + CEXidAccion;
		var idObjetivoAUX;
		
		db = openDatabase("DBIW1", "0.1", "Database Isowin One", 200000);
		if(db){	
			db.transaction(function(tx) {
				tx.executeSql("SELECT * FROM objetivos WHERE objetivo=?", [objetivoAUX], function(tx, result){
					idObjetivoAUX = result.rows.item(0)["idobjetivo"];
					tx.executeSql("DELETE FROM objetivos WHERE idobjetivo=?",[ idObjetivoAUX]);
					tx.executeSql("DELETE FROM acciones WHERE idobjetivo=?",[ idObjetivoAUX]);
					//alert("Transcaccion borrada: "+ objetivoAUX);
				});
			});
		};
	}
	
//=========================================================================================================
//GENERALES	

/* FORMATO DE FECHA*/
function changeFch (fch) {	
	var newfch =   fch.substring(3, 5) + "/" +  fch.substring(0, 2) + "/" + fch.substring(6, 10); 
	return newfch
	}

/* FORMATO DE FECHA DATE*/
function changeFch2 (fch) {
	if (fch!=null) {
		var dia; var mes;
		if (fch.getDate()<10) {dia="0"+fch.getDate()} else {dia=fch.getDate()};
		var mesAUX = fch.getMonth()+1;
		if (fch.getMonth()<10) {mes="0"+mesAUX} else {mes=mesAUX};
		var newfch = dia + "/" + mes  + "/" + fch.getFullYear();
		return newfch};
	}	
					
//=========================================================================================================					

					