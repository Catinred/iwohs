//DOCUMENTOS y REGISTROS (1 y 2)

	var idseleccionado;
	var idseleccionado2;
	var intProceso; var intEstado;
	var INTcolor = 0; //Color del semaforo en verde
		
//TABLA DOCUMENTOS___________________________________________________________________________________________

function mostrarDOCsREGs(intProc, intEst) {
	intProceso=intProc; intEstado=intEst;
	sacarDOCsREGs (intProceso, intEstado);
	setTimeout('listDOCs(); listREGs()',500);
	Vb(intEst);
	}


function listDOCs() {
			$(document).ready(			
			function () {
				$('#dynamic').html( '<table cellpadding="0" cellspacing="0" border="0" class="display" id="example"></table>' );
				$('#example').dataTable( {
					"aaData": aDataSet,

					
					"aoColumns": [
						{ "sTitle": "Id" },
						{ "sTitle": "Codigo" },
						{ "sTitle": "Documento" },
						{ "sTitle": "Revision"},
						{ "sTitle": "Fecha Publicacion" },
						{ "sTitle": "Distribucion"},
						{ "sTitle": "Estado"}
						],
					
					
					//"sScrollY": "200px",//Altura de la tabla
					"bPaginate": false,//No pagina la tabla
					"bScrollCollapse": true,//Aparece el scroll vertical cuando se llenan los 200px.
					
        								
						
					"sDom": 'lfrtip<"clear spacer">T',	
					
					/*"sDom": 'T<"clear">lfrtip<"clear spacer">T',*/ //Muestra los botones de copy,print...
					"oTableTools": {"sRowSelect": "single","aButtons": ["select"],} //Solo me muestra el boton select para poder seleccionar las filas.
				});
				});
				
			$(document).ready(
				function() {
					$('#example tbody td').click( function () {
					/* Get the position of the current data from the node */
					var aPos = oTable.fnGetPosition( this );
					/* Get the data array for this row */
					var aData = oTable.fnGetData( aPos[0] );
						/*alert("Ok "+aData[0]);*/
				
						idseleccionado =  aData[0];
						document.getElementById("txtcoddocumento").value = aData[1];
						document.getElementById("txtdocumento").value = aData[2];
						document.getElementById("txtrevision").value = aData[3];
						document.getElementById("txtfchpublic").value = aData[4];
						document.getElementById("txtlink").value = aData[5];
						document.getElementById("combodocestado").value = aData[6];
				});	
     

			oTable = $('#example').dataTable( );

			});
}


//TABLA REGISTROS___________________________________________________________________________________________


function listREGs() {
		$(document).ready(			
			function () {
				$('#dynamic2').html( '<table cellpadding="0" cellspacing="0" border="0" class="display" id="example2"></table>' );
				$('#example2').dataTable( {
					"aaData": aDataSet2,
					"aoColumns": [
						{ "sTitle": "Id" },
						{ "sTitle": "Codigo" },
						{ "sTitle": "Registro" },
						{ "sTitle": "Revision"},
						{ "sTitle": "Fecha Publicacion" },
						{ "sTitle": "Distribucion"},
						{ "sTitle": "Años"},
						{ "sTitle": "Lugar"},
						{ "sTitle": "Estado"}
						],
						
					//"sScrollY": "200px",
        			"bPaginate": false,
        			"bScrollCollapse": true,
						
					"sDom": 'lfrtip<"clear spacer">T',
					/*"sDom": 'T<"clear">lfrtip<"clear spacer">T',*/ //Muestra los botones de copy,print...
					"oTableTools": {
					"sRowSelect": "single","aButtons": ["select"], //Solo me muestra el boton select para poder seleccionar las filas.
				
				}});
				
				});
				
			$(document).ready(
				function() {
    			$('#example2 tbody td').click( function () {
        		/* Get the position of the current data from the node */
        		var aPos2 = oTable2.fnGetPosition( this );
         
        		/* Get the data array for this row */
        		var aData2 = oTable2.fnGetData( aPos2[0] );
				/*alert("Ok "+aData[0]);*/
				
				idseleccionado2 =  aData2[0];
				document.getElementById("txtcodregistro").value = aData2[1];
				document.getElementById("txtregistro").value = aData2[2];
				document.getElementById("txtrevreg").value = aData2[3];
				document.getElementById("txtfchpublicreg").value = aData2[4];
				document.getElementById("txtlinkreg").value = aData2[5];
				document.getElementById("txtanos").value = aData2[6];
				document.getElementById("txtlugar").value = aData2[7];
				document.getElementById("comboregestado").value = aData2[8];
         
    			});
     
   				 /* Init DataTables */
   				 oTable2 = $('#example2').dataTable();
				});			
}

//______________________________________________________________________________________________________
function sacarDOCsREGs (intProceso, intEstado){
	var db;
        db = openDatabase("DBIW1", "0.1", "Database Isowin One", 200000);	
									//alert ("Estoy dentro");
	var estado="WHERE estado!='Obsoleto' AND proceso=" + parseInt(intProceso);
	if (intEstado==1) {estado="WHERE estado='Obsoleto' AND proceso=" + parseInt(intProceso);};	
	if(db){
		db.transaction( function(tx) {
			tx.executeSql("SELECT * FROM documentos " + estado, [],
				function(tx, result){
					aDataSet = [];
					for(var i=0; i < result.rows.length; i++) {
						aDataSet.push([result.rows.item(i)['iddocumento'],
								result.rows.item(i)['coddocumento'],
								result.rows.item(i)['documento'],
								result.rows.item(i)['revision'],
								result.rows.item(i)['fchpublic'],
								result.rows.item(i)['link'],
								result.rows.item(i)['estado']]);						
					}					
			});

			tx.executeSql("SELECT * FROM registros " + estado, [],
				function(tx, result){
					aDataSet2 = [];
					for(var i=0; i < result.rows.length; i++) {
								
						aDataSet2.push([result.rows.item(i)['idregistro'],
								result.rows.item(i)['codregistro'],
								result.rows.item(i)['registro'],
								result.rows.item(i)['revision'],
								result.rows.item(i)['fchpublic'],
								result.rows.item(i)['link'],
								result.rows.item(i)['anos'],
								result.rows.item(i)['lugar'],
								result.rows.item(i)['estado']]);						
					};
			});
		});	
	};
}

//=========================================================================================================				
/*NUEVO DOCUMENTO*/
	function addDoc(txtcoddocumento, txtdocumento, txtrevision, txtfchpublic, txtlink, txtestado) {
		var db;
        db = openDatabase("DBIW1", "0.1", "Database Isowin One", 200000);
		if(db){	
			db.transaction( function(tx) {
			tx.executeSql("INSERT INTO documentos(coddocumento, documento, revision, fchpublic, link, estado, proceso) VALUES(?,?,?,?,?,?,?)", 
										[txtcoddocumento, txtdocumento, txtrevision, txtfchpublic, txtlink, txtestado,  intProceso]);
			 apprise('El documento ha sido guardado');//alert("doc guardado: "+ txtdocumento);
			});
		setTimeout('mostrarDOCsREGs(intProceso, intEstado)',500);
		};

		 //$("#updateuser").toggle(200);
		 $(":text").val("");
	}
/*ACTUALIZAR DOCUMENTO*/
	function updateDoc(txtcoddocumento, txtdocumento, txtrevision, txtfchpublic, txtlink, txtestado) {
		var db;
		db = openDatabase("DBIW1", "0.1", "Database Isowin One", 200000);
		if(db){	
			db.transaction( function(tx) {
			tx.executeSql("UPDATE documentos SET coddocumento=?, documento=?, revision=?, fchpublic=?, link=?, estado=? WHERE iddocumento=?", 
										[txtcoddocumento, txtdocumento, txtrevision, txtfchpublic, txtlink, txtestado, idseleccionado]);
			apprise('El documento ha sido modificado');//alert("doc cambiado: "+ txtdocumento + " - " + idseleccionado);
			});
		setTimeout('mostrarDOCsREGs(intProceso, intEstado)',500);
		};
		 $(":text").val("");				
	}
		
/*BORRAR DOCUMENTO*/
	function removeDoc() {
		apprise('¿Eliminar documento?', {'verify': true}, function(r) {
			if(r) { 
				var db;
				db = openDatabase("DBIW1", "0.1", "Database Isowin One", 200000);
				if(db){	
					db.transaction(function(tx) {
					tx.executeSql("DELETE FROM documentos WHERE iddocumento=?",[idseleccionado]);
					});
					apprise('El documento ha sido borrado'); //alert("doc borrado: "+ idseleccionado);
				};
				setTimeout('mostrarDOCsREGs(intProceso, intEstado)',500);
				$(":text").val("");
			};
		
		});

	}
	
//=========================================================================================================					
/*NUEVO REGISTRO*/
	function addReg(txtcodregistro, txtregistro, txtrevreg, txtfchpublicreg, txtlinkreg, txtanos, txtlugar, txtestado) {
		var db;
        db = openDatabase("DBIW1", "0.1", "Database Isowin One", 200000);
		if(db){	
		  db.transaction( function(tx) {
			tx.executeSql("INSERT INTO registros(codregistro, registro, revision, fchpublic, link, anos, lugar, estado, proceso) VALUES(?,?,?,?,?,?,?,?,?)", 
									[txtcodregistro, txtregistro, txtrevreg, txtfchpublicreg, txtlinkreg, txtanos, txtlugar, txtestado,  intProceso]);
			apprise('El registro ha sido guardado');//alert("doc guardado: "+ txtregistro);
		});
		setTimeout('mostrarDOCsREGs(intProceso, intEstado)',500);
		};
		
		//Incluyo el documento en la tabla
		//$('#example2').dataTable().fnAddData( ["Nuevo",txtcodregistro, txtregistro, txtrevreg, txtfchpublicreg, txtlinkreg, txtanos, textlugar] );

		 $(":text").val("");
		 //$("#updateuserreg").toggle(200);
	}
/*ACTUALIZAR REGISTRO*/
	function updateReg(txtcodregistro, txtregistro, txtrevreg, txtfchpublicreg, txtlinkreg, txtanos, txtlugar, txtestado) {
		var db;
		db = openDatabase("DBIW1", "0.1", "Database Isowin One", 200000);
		if(db){	
			db.transaction( function(tx) {
			tx.executeSql("UPDATE registros SET codregistro=?, registro=?, revision=?, fchpublic=?, link=?, anos=?, lugar=?, estado=?  WHERE idregistro=?", 
									[txtcodregistro, txtregistro, txtrevreg, txtfchpublicreg, txtlinkreg, txtanos, txtlugar, txtestado, idseleccionado2]);
			apprise('El registro ha sido modificado');//alert("doc cambiado: "+ txtdocumento + " - " + idseleccionado2);
			});
		};
		setTimeout('mostrarDOCsREGs(intProceso, intEstado)',500);
		 $(":text").val("");$(":date").val("");	
	}			

/*BORRAR REGISTRO*/
	function removeReg() {
		apprise('¿Eliminar registro?', {'verify': true}, function(r) {
			if(r) {
				var db;
				db = openDatabase("DBIW1", "0.1", "Database Isowin One", 200000);
				if(db){	
					db.transaction(function(tx) {
					tx.executeSql("DELETE FROM registros WHERE idregistro=?",[idseleccionado2]);
					apprise('El registro ha sido borrado');//alert("doc borrado: "+ idseleccionado2);
					});
				};
				setTimeout('mostrarDOCsREGs(intProceso, intEstado)',500);
				$(":text").val("");
			};
		 });
	}

//VER BOTON SEMAFORO__________________________________________________________________________________________

//Funcion de inicializaci�n de la pesta�a, ocultando el bot�n rojo.
function VbInit() {document.getElementById('botonrojo').style.display = 'none';}
//valor 1 se pone rojo, valor 0 se pone verde.	
function Vb(intColor) {
	if (INTcolor!=intColor) {$("#botonrojo").toggle(200); $("#botonverde").toggle(200); INTcolor=intColor;};
	}


//__________________________________________________________________________________________
