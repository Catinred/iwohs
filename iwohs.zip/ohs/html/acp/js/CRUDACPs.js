//ACCIONES CORRECTIVAS Y PREVENTIVAS (7)

	var idseleccionado7;
	var intEstado7;
	var INTcolor7 = 0; //Color del semaforo en verde
				
				
//TABLA ACPS_____________________________________________________________________________________________________________

function mostrarACPs(intEst7) {
	intEstado7=intEst7;
	sacarACPs (intEstado7);
	setTimeout('listACPs()',500);
	Vb7(intEst7);
	}

function listACPs() {
			$(document).ready(			
			function () {
				$('#dynamic7').html( '<table cellpadding="0" cellspacing="0" border="0" class="display" id="example7"></table>' );
				$('#example7').dataTable( {
					"aaData": aDataSet7,
						
					"aoColumns": [
						{ "sTitle": "Id"/*, "bSearchable": false, "bVisible": false*/ },
						{ "sTitle": "ACP" },
						{ "sTitle": "Cod ACP" },
						{ "sTitle": "Tipo" },
						{ "sTitle": "Origen" },
						{ "sTitle": "F. Alta", "bSearchable": false, "bVisible": false},
						{ "sTitle": "Responsable", "bSearchable": false, "bVisible": false },
						{ "sTitle": "Equipo de trabajo", "bSearchable": false, "bVisible": false  },
						{ "sTitle": "Estado"},
						{ "sTitle": "Acciones", "bSearchable": false, "bVisible": false },
						{ "sTitle": "F. Prevista", "bSearchable": false, "bVisible": false },
						{ "sTitle": "Seguimiento", "bSearchable": false, "bVisible": false },
						{ "sTitle": "F. Cierre", "bSearchable": false, "bVisible": false },
						{ "sTitle": "Eficacia", "bSearchable": false, "bVisible": false },
						{ "sTitle": "F. Eficacia", "bSearchable": false, "bVisible": false }
						],
						
					"sScrollY": "430px",
        			"bPaginate": false,
        			"bScrollCollapse": true,
						
					"sDom": 'lfrtip<"clear spacer">T',
					/*"sDom": 'T<"clear">lfrtip<"clear spacer">T',*/ //Muestra los botones de copy,print...
					"oTableTools": {
						"sRowSelect": "single","aButtons": ["select"], //Solo me muestra el boton select para poder seleccionar las filas.
							
					"aoColumnDefs": [ {
						"sClass": "center",
						"aTargets": [ -1, -2 ]
						} ]
						
				}});
				
			//Cargo el COMBOBOX de responsables del formulario NCs------------
			setTimeout('$("#comboacpresponsable").html(nuevosresponsables);',200);
			//--------------------------------------------------

			});
			
	//Cargar datos de proveedor para editar en formulario	
			$(document).ready(
				function() {
    			$('#example7 tbody td').click( function () {
        		/* Get the position of the current data from the node */
        		var aPos7 = oTable7.fnGetPosition( this );
         
        		/* Get the data array for this row */
        		var aData7 = oTable7.fnGetData( aPos7[0] );
				/*alert("Ok "+aData[0]);*/
				
				idseleccionado7 =  aData7[0];
				document.getElementById("txtacp").value = aData7[1];
				document.getElementById("txtcodacp").value = aData7[2];
				document.getElementById("comboacptipo").value = aData7[3];
				document.getElementById("txtacporigen").value = aData7[4];
				document.getElementById("txtacpfchalta").value = aData7[5];
				document.getElementById("comboacpresponsable").value = aData7[6];
				document.getElementById("txtacpequipo").value = aData7[7];
				document.getElementById("comboacpestado").value = aData7[8];
				document.getElementById("txtacpacciones").value = aData7[9];
				document.getElementById("txtacpfchprevista").value = aData7[10];
				document.getElementById("txtacpseguimiento").value = aData7[11];
				document.getElementById("txtacpfchcierre").value = aData7[12];
				document.getElementById("txtacpeficacia").value = aData7[13];
				document.getElementById("txtacpfcheficacia").value = aData7[14];
         

			//Cargo imagen según sea una AC o una AP------------
			document.getElementById("imgACoAP").innerHTML =	"<div class='spriteA "+aData7[3]+"2' style='width:70px; height:40px'></div>";
			//-----------------------------------
			
			VnVEacp (1);//No ver botones update y delete

    			});
     
   				 /* Init DataTables */
   				 oTable7 = $('#example7').dataTable();
				});
		
	}	

function sacarACPs (intEstado7){
	var db;
        db = openDatabase("DBIWOHS", "0.1", "Database Isowin OHS", 5 * 1024 * 1024);	
		//alert ("Estoy dentro");					
	var estado7="WHERE estado!='Finalizada' AND estado!='Anulada' ";
	if (intEstado7==1) {estado7="WHERE estado='Finalizada' OR estado='Anulada' ";};
	if(db){
		db.transaction( function(tx) {
			tx.executeSql("SELECT * FROM acps " + estado7, [],
				function(tx, result){
					aDataSet7 = [];
					for(var i=0; i < result.rows.length; i++) {	
						aDataSet7.push([result.rows.item(i)['idacp'],
								result.rows.item(i)['acp'],
								result.rows.item(i)['codacp'],
								result.rows.item(i)['tipo'],
								result.rows.item(i)['origen'],
								result.rows.item(i)['fchalta'],
								result.rows.item(i)['responsable'],
								result.rows.item(i)['equipo'],
								result.rows.item(i)['estado'],
								result.rows.item(i)['acciones'],
								result.rows.item(i)['fchprevista'],
								result.rows.item(i)['seguimiento'],
								result.rows.item(i)['fchcierre'],
								result.rows.item(i)['eficacia'],
								result.rows.item(i)['fcheficacia'],
								]);
					}			
				});
		});	
	};
}
	
//=========================================================================================================					
/*NUEVA ACP*/
	function addACP(acp, codacp, tipo, origen, fchalta, responsable, equipo, estado, acciones, fchprevista, seguimiento, fchcierre, eficacia, fcheficacia) {
		var db;
		var nuevoId;
		
		db = openDatabase("DBIWOHS", "0.1", "Database Isowin OHS", 5 * 1024 * 1024);
		if(db){	
		  db.transaction( function(tx) {
			tx.executeSql("INSERT INTO acps (acp, codacp, tipo, origen, fchalta, responsable, equipo, estado, acciones, fchprevista, seguimiento, fchcierre, eficacia, fcheficacia) VALUES(?,?,?,?,?,?,?,?,?,?,?,?,?,?)", [acp, codacp, tipo, origen, fchalta, responsable, equipo, estado, acciones, fchprevista, seguimiento, fchcierre, eficacia, fcheficacia]);
											//Meto la ACP en la PlanificaciÃ³n de Objetivos del proceso de DirecciÃ³n
			tx.executeSql("SELECT * FROM acps ORDER BY idacp DESC", [], function(tx, result){
				nuevoId = result.rows.item(0)["idacp"];
											//alert("Id del ACP que acabo de crear: "+ nuevoId);
				CEXaddObjetivo ("ACP: ", nuevoId, acp, codacp, responsable, equipo, fchalta, fchprevista, "", "", "ganttRed");
											//alert("Nueva cita el dia : "+ fcheficacia);
				CEXaddCita("Valoración ACP" + nuevoId, fcheficacia, fcheficacia, acp, "VACP" + nuevoId);
				});
			apprise('La ACP ha sido guardada'); //alert("ACP guardada: "+ acp);
			});
		};
		setTimeout('mostrarACPs(intEstado7)',500);
	}
	
/*ACTUALIZAR ACP*/
		function updateACP(acp, codacp, tipo, origen, fchalta, responsable, equipo, estado, acciones, fchprevista, seguimiento, fchcierre, eficacia, fcheficacia) {
		var db;
        db = openDatabase("DBIWOHS", "0.1", "Database Isowin OHS", 5 * 1024 * 1024);
		if(db){	
		  db.transaction( function(tx) {
			tx.executeSql("UPDATE acps SET acp=?, codacp=?, tipo=?, origen=?, fchalta=?, responsable=?, equipo=?, estado=?, acciones=?, fchprevista=?, seguimiento=?, fchcierre=?, eficacia=?, fcheficacia=?  WHERE idacp=?", [acp, codacp, tipo, origen, fchalta, responsable, equipo, estado, acciones, fchprevista, seguimiento, fchcierre, eficacia, fcheficacia, idseleccionado7]);
			CEXupdateObjetivo ("ACP: ",  idseleccionado7, acp, codacp, responsable, equipo, fchalta, fchprevista, "", "", "ganttRed");
			CEXupdateCita( "Valoración ACP" + idseleccionado7, fchprevista, fchprevista, acp, "VACP" + idseleccionado7);
			apprise('La ACP ha sido modificada'); //alert("ACP ha cambiado: "+ acp + " > " + idseleccionado7);
		})};
		setTimeout('mostrarACPs(intEstado7)',500);}					

/*BORRAR ACP*/
	function removeACP() {
		apprise('Â¿Eliminar AcciÃ³n Correctiva/Preventiva?', {'verify': true}, function(r) {
			if(r) { 
				var db;
				db = openDatabase("DBIWOHS", "0.1", "Database Isowin OHS", 5 * 1024 * 1024);
				if(db){	
					db.transaction(function(tx) {
						tx.executeSql("DELETE FROM acps WHERE idacp=?",[idseleccionado7]);
						CEXremoveObjetivo("ACP: ", idseleccionado7);
						CEXdeleteCita("VACP" + idseleccionado7);
						apprise('La ACP ha sido borrada'); //alert("ACP borrada: "+ idseleccionado7);
					});
				};
				setTimeout('mostrarACPs(intEstado7)',500);
			};
		});
	}
	
//VER BOTON SEMAFORO_______________________________________________________________________

//Funcion de inicialización de la pestaña, ocultando el botón rojo.
function VbInit7() {document.getElementById('botonrojo7').style.display = 'none';}
//valor 1 se pone rojo, valor 0 se pone verde.	
function Vb7(intColor7) {
	if (INTcolor7!=intColor7) {$("#botonrojo7").toggle(200); $("#botonverde7").toggle(200); INTcolor7=intColor7;};
	}

//__________________________________________________________________________________________
/* VER NO VER EDIT (Update+Delete)*/
var verEACP=0;
function VnVEacp (Veacp) {if (verEACP!=Veacp) {$("#editacp").toggle(200); verEACP=Veacp;};}

//__________________________________________________________________________________________
	
	