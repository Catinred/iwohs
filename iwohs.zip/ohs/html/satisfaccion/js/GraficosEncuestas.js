
// variables globales
var chartB1; var serieB1 =  [{type: 'pie', name: 'Browser share', data: [ ['Firefox',   45.0], ['IE',       26.8],
                    ['Chrome', 12.8], ['Safari',    8.5], ['Opera',     6.2], ['Others',   0.7] ] }]
		    
var chartB2; var serieB2 =  [{name: 'Year 1800', data: [107, 31, 635, 203, 2]}, 
					{name: 'Year 1900',data: [133, 156, 947, 408, 6]}, 
					{name: 'Year 2008',data: [973, 914, 4054, 732, 34]}];

var PreguntasB2 = []; 
	/**
 * Request data from the server, add it to the graph and set a timeout to request again
 */

function showChartEncuestas(){

		chartsB1 = new Highcharts.Chart({
			chart: {renderTo: 'containerB1', plotBackgroundColor: null, plotBorderWidth: null, plotShadow: false},
			title: {text: 'Comparativa de preguntas'},
			tooltip: {pointFormat: '{series.name}: <b>{point.percentage}%</b>', percentageDecimals: 1},
			plotOptions: {pie: 	{allowPointSelect: true, 
							cursor: 'pointer', 
							dataLabels: {enabled: true, color: '#000000', connectorColor: '#000000',
									formatter: function() {return  this.point.name.substring(0,20);}
									}
							}
				},
			credits: {enabled: false},
			series: serieB1
		});
		
		chartB2 = new Highcharts.Chart({
			chart: {renderTo: 'containerB2', type: 'bar'},
			title: {text: 'Comparativa Cliente vs Todos'},
			//subtitle: {text: 'Source: Wikipedia.org'},
			xAxis: {categories: PreguntasB2, title: {text: null}},
			yAxis: {min: 0, title: {text: 'Preguntas', align: 'high'}, labels: {overflow: 'justify'}},
			tooltip: {formatter: function() {return ''+ this.series.name.substring(0,20) +': '+ this.y.toFixed(1);}},
			plotOptions: {bar: {dataLabels: {enabled: false}}},//, formatter: function() {return  this.point.name.toFixed(2);
			legend: {layout: 'vertical',align: 'right',verticalAlign: 'top',x: -100,y: 100,floating: true,borderWidth: 1,backgroundColor: '#FFFFFF',shadow: true},
			credits: {enabled: false},
			series: serieB2
		});
	}
	

function sacarserieB1 (idencuesta){
	var db;
        db = openDatabase("DBIW1", "0.1", "Database Isowin One", 200000);	
		//alert ("Estoy dentro");					
	if(db){
		//alert("conectado");	
		db.transaction( function(tx) {
			tx.executeSql("SELECT * FROM encuestas JOIN estudios ON encuestas.idestudio=estudios.idestudio WHERE idencuesta=?", [idencuesta],
			function(tx, result){
				//alert("Dentro; " + result.rows.length + result.rows.item(0)['eval1'] +" X "+ result.rows.item(0)['resultado']);
				if (result.rows.length == 1 ) {
				
				cociente = result.rows.item(0)['resultado']*10;
				var valor1 = (result.rows.item(0)['eval1']/cociente)*10000;
				var valor2 = (result.rows.item(0)['eval2']/cociente)*10000;
				var valor3 = (result.rows.item(0)['eval3']/cociente)*10000;
				var valor4 = (result.rows.item(0)['eval4']/cociente)*10000;
				var valor5 = (result.rows.item(0)['eval5']/cociente)*10000;
				var valor6 = (result.rows.item(0)['eval6']/cociente)*10000;
				var valor7 = (result.rows.item(0)['eval7']/cociente)*10000;
				var valor8 = (result.rows.item(0)['eval8']/cociente)*10000;
				var valor9 = (result.rows.item(0)['eval9']/cociente)*10000;
				var valor10 = (result.rows.item(0)['eval10']/cociente)*10000;
				//alert(valor1);
					
				serieB1=[{	type: 'pie', 
						name: 'Valor', 
						data: [
						["Pr1: " + result.rows.item(0)['pr1'], valor1],
						["Pr2: " + result.rows.item(0)['pr2'], valor2],
						["Pr3: " + result.rows.item(0)['pr3'], valor3],
						["Pr4: " + result.rows.item(0)['pr4'], valor4],
						["Pr5: " + result.rows.item(0)['pr5'], valor5],
						["Pr6: " + result.rows.item(0)['pr6'], valor6],
						["Pr7: " + result.rows.item(0)['pr7'], valor7],
						["Pr8: " + result.rows.item(0)['pr8'], valor8],
						["Pr9: " + result.rows.item(0)['pr9'], valor9],
						["Pr10: " + result.rows.item(0)['pr10'], valor10]					
						]}];
				
				//El vector con las preguntas lo utilizare en el segundo gr�fico
				PreguntasB2=["Pr1: " + result.rows.item(0)['pr1'].substring(0,15) + "...", 
						"Pr2: " + result.rows.item(0)['pr2'].substring(0,15) + "...",
						"Pr3: " + result.rows.item(0)['pr3'].substring(0,15) + "...",
						"Pr4: " + result.rows.item(0)['pr4'].substring(0,15) + "...",
						"Pr5: " + result.rows.item(0)['pr5'].substring(0,15) + "...",
						"Pr6: " + result.rows.item(0)['pr6'].substring(0,15) + "...",
						"Pr7: " + result.rows.item(0)['pr7'].substring(0,15) + "...",
						"Pr8: " + result.rows.item(0)['pr8'].substring(0,15) + "...",
						"Pr9: " + result.rows.item(0)['pr9'].substring(0,15) + "...",
						"Pr10: " + result.rows.item(0)['pr10'].substring(0,15) + "..."
						];
						
				};
			});
		});
	};
}


function sacarserieB2 (idencuesta, idestudio){
	
	var db;
        db = openDatabase("DBIW1", "0.1", "Database Isowin One", 200000);
	serieB2 = [];
	var valoresB21 = [];
	var valoresB22 = [];
	
		if(db){
		//alert("conectado");	
			db.transaction( function(tx) {
				tx.executeSql("SELECT * FROM encuestas JOIN clientes ON encuestas.idcliente=clientes.idcliente WHERE idencuesta=?", [idencuesta],
					function(tx, result){
							//alert("Logitud del result: "+result.rows.length);
					var nombreClienteEncuesta = result.rows.item(0)['cliente'];
						
					valoresB21 = [result.rows.item(0)['eval1'], result.rows.item(0)['eval2'], result.rows.item(0)['eval3'], 
						result.rows.item(0)['eval4'], result.rows.item(0)['eval5'], result.rows.item(0)['eval6'], 
						result.rows.item(0)['eval7'], result.rows.item(0)['eval8'], result.rows.item(0)['eval9'], 
						result.rows.item(0)['eval10']]; 
					
					serieB2.push({name: nombreClienteEncuesta, data: valoresB21});
							//alert("inside: " + valores1[0]);
				});
				
				tx.executeSql("SELECT * FROM encuestas WHERE idestudio=?", [idestudio],
					function(tx, result2){
					
					var porCriterio = [0,0,0,0,0,0,0,0,0,0];

					for(var i=0; i < result2.rows.length; i++) {	
					porCriterio[0] = porCriterio[0] + parseInt(result2.rows.item(i)['eval1']);
					porCriterio[1] = porCriterio[1] + parseInt(result2.rows.item(i)['eval2']);
					porCriterio[2] = porCriterio[2] + parseInt(result2.rows.item(i)['eval3']);
					porCriterio[3] = porCriterio[3] + parseInt(result2.rows.item(i)['eval4']);
					porCriterio[4] = porCriterio[4] + parseInt(result2.rows.item(i)['eval5']);
					porCriterio[5] = porCriterio[5] + parseInt(result2.rows.item(i)['eval6']);
					porCriterio[6] = porCriterio[6] + parseInt(result2.rows.item(i)['eval7']);
					porCriterio[7] = porCriterio[7] + parseInt(result2.rows.item(i)['eval8']);
					porCriterio[8] = porCriterio[8] + parseInt(result2.rows.item(i)['eval9']);
					porCriterio[9] = porCriterio[9] + parseInt(result2.rows.item(i)['eval10']);					
					};
					porCriterio[0] = porCriterio[0]/result2.rows.length;
					porCriterio[1] = porCriterio[1]/result2.rows.length;
					porCriterio[2] = porCriterio[2]/result2.rows.length;
					porCriterio[3] = porCriterio[3]/result2.rows.length;
					porCriterio[4] = porCriterio[4]/result2.rows.length;
					porCriterio[5] = porCriterio[5]/result2.rows.length;
					porCriterio[6] = porCriterio[6]/result2.rows.length;
					porCriterio[7] = porCriterio[7]/result2.rows.length;
					porCriterio[8] = porCriterio[8]/result2.rows.length;
					porCriterio[9] = porCriterio[9]/result2.rows.length;
						
					valoresB22 = [porCriterio[0], porCriterio[1], porCriterio[2], porCriterio[3], porCriterio[4], porCriterio[5], porCriterio[6], porCriterio[7], porCriterio[8], porCriterio[9]]; 
					
					serieB2.push({name: "Todos", data: valoresB22});
							//alert("inside: " + valores2[0]);
				});	
							//serieAux = [{name : "proveedor", data : valores1},{name : "Todos", data : valores2}];				
			});	
		};
			
						
	}

	
				