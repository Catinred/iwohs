//RECLAMACIONES (19)

	var idseleccionado19;
	var intEstado19;
	var INTcolor19 = 0; //Color del semaforo en verde
				
				
//TABLA RECLAMACIONES_____________________________________________________________________________________________________________
function mostrarReclamaciones(intEst19) {
	intEstado19=intEst19;
	sacarReclamaciones (intEstado19);
	setTimeout('listReclamaciones()',500);
	Vb19(intEst19);
	}


function listReclamaciones() {
			$(document).ready(			
			function () {
				$('#dynamic19').html( '<table cellpadding="0" cellspacing="0" border="0" class="display" id="example19"></table>' );
				$('#example19').dataTable( {
					"aaData": aDataSet19,
						
					"aoColumns": [
						{ "sTitle": "Id"/*, "bSearchable": false, "bVisible": false*/ },
						{ "sTitle": "Cod. Reclamación" },
						{ "sTitle": "Reclamación" },
						{ "sTitle": "Fecha de Alta" },
						{ "sTitle": "Descripción", "bSearchable": false, "bVisible": false },
						{ "sTitle": "Corrección", "bSearchable": false, "bVisible": false },
						{ "sTitle": "F. Cierre" },
						{ "sTitle": "Conforme", "bSearchable": false, "bVisible": false },
						{ "sTitle": "idCliente", "bSearchable": false, "bVisible": false },
						{ "sTitle": "Estado", "bSearchable": false, "bVisible": false }
						],
						
					"sScrollY": "430px",
        			"bPaginate": false,
        			"bScrollCollapse": true,
						
					"sDom": 'lfrtip<"clear spacer">T',
					/*"sDom": 'T<"clear">lfrtip<"clear spacer">T',*/ //Muestra los botones de copy,print...
					"oTableTools": {
						"sRowSelect": "single","aButtons": ["select"], //Solo me muestra el boton select para poder seleccionar las filas.
							
					"aoColumnDefs": [ {
						"sClass": "center",
						"aTargets": [ -1, -2 ]
						} ]
						
				}});
				
				//Cargo el COMBOBOX de clientes ------------
				sacarClientes ();
				setTimeout('$("#comborccliente").html(nuevosclientes);',200);
				//--------------------------------------------------
				//Cargo el COMBOBOX de responsables del formulario NCs------------
				sacarResponsables ();
				setTimeout('$("#comboacpresp3").html(nuevosresponsables);',200);
				//--------------------------------------------------
				
				});
	//Cargar datos de proveedor para editar en formulario	
			$(document).ready(
				function() {
    			$('#example19 tbody td').click( function () {
        		/* Get the position of the current data from the node */
        		var aPos19 = oTable19.fnGetPosition( this );
         
        		/* Get the data array for this row */
        		var aData19 = oTable19.fnGetData( aPos19[0] );
				/*alert("Ok "+aData[0]);*/
				
				idseleccionado19 =  aData19[0];
				document.getElementById("txtrccodrc").value = aData19[1];
				document.getElementById("txtrc").value = aData19[2];
				document.getElementById("txtrcfchalta").value = aData19[3];
				document.getElementById("txtrcdescripcion").value = aData19[4];
				document.getElementById("txtrccorreccion").value = aData19[5];
				document.getElementById("txtrcfchcierre").value = aData19[6];
				document.getElementById("txtrcconforme").value = aData19[7];
				document.getElementById("comborccliente").value = aData19[8];
				document.getElementById("comborcestado").value = aData19[9];
				
				VnV19 (1, 1, 0);
         
    			});
     
   				 /* Init DataTables */
   				 oTable19 = $('#example19').dataTable();
				});
		
	}
	
//DATOS RECLAMACIONES_________________________________________________

function sacarReclamaciones (intEstado19){
	var db;
        db = openDatabase("DBIW1", "0.1", "Database Isowin One", 200000);	
		//alert ("Estoy dentro");					
	var estado19="WHERE estado!='Cerrada' ";
	if (intEstado19==1) {estado19="WHERE estado='Cerrada' ";};	
	
	if(db){
		db.transaction( function(tx) {
			tx.executeSql("SELECT * FROM reclamaciones " + estado19, [],
				function(tx, result){
					aDataSet19 = [];
					for(var i=0; i < result.rows.length; i++) {	
						aDataSet19.push([result.rows.item(i)['idreclamacion'],
								result.rows.item(i)['codreclamacion'],
								result.rows.item(i)['reclamacion'],
								result.rows.item(i)['fchalta'],
								result.rows.item(i)['descripcion'],
								result.rows.item(i)['correccion'],
								result.rows.item(i)['fchcierre'],
								result.rows.item(i)['conforme'],
								result.rows.item(i)['idcliente'],
								result.rows.item(i)['estado'],
								]);
					};			
				});
		});	
	};
}

//=========================================================================================================					
/*NUEVA RECLAMACION*/
	function addRC(codreclamacion, reclamacion, fchalta, descripcion, correccion, fchcierre, conforme, idcliente, estado) {
		var db;
		db = openDatabase("DBIW1", "0.1", "Database Isowin One", 200000);
		if(db){	
		  db.transaction( function(tx) {
			tx.executeSql("INSERT INTO reclamaciones (codreclamacion, reclamacion, fchalta, descripcion, correccion, fchcierre, conforme, idcliente, estado) VALUES(?,?,?,?,?,?,?,?,?)", [codreclamacion, reclamacion, fchalta, descripcion, correccion, fchcierre, conforme, idcliente, estado]);
			apprise('La reclamación ha sido guardada'); //alert("Reclamación guardada: "+ codreclamacion);
		})};
		setTimeout('mostrarReclamaciones(intEstado19)',500);
		VnV19 (1, 1, 0);
	}
	
/*ACTUALIZAR RECLAMACION*/
		function updateRC(codreclamacion, reclamacion, fchalta, descripcion, correccion, fchcierre, conforme, idcliente, estado) {
		var db;
        db = openDatabase("DBIW1", "0.1", "Database Isowin One", 200000);
		if(db){	
		  db.transaction( function(tx) {
			tx.executeSql("UPDATE reclamaciones SET codreclamacion=?, reclamacion=?, fchalta=?, descripcion=?, correccion=?, fchcierre=?, conforme=?, idcliente=?, estado=?  WHERE idreclamacion=?", [codreclamacion, reclamacion, fchalta, descripcion, correccion, fchcierre, conforme, idcliente, estado, idseleccionado19]);
			apprise('La reclamación ha sido modificada'); //alert("La reclamación ha cambiado: "+ codreclamacion + " - " + idseleccionado19);
		})};
		setTimeout('mostrarReclamaciones(intEstado19)',500);
		VnV19 (1, 1, 0);
	}					

/*BORRAR RECLAMACION*/
	function removeRC() {
		apprise('¿Eliminar la reclamación?', {'verify': true}, function(r) {
			if(r) {
			var db;
			db = openDatabase("DBIW1", "0.1", "Database Isowin One", 200000);
			if(db){	
				db.transaction(function(tx) {
					tx.executeSql("DELETE FROM reclamaciones WHERE idreclamacion=?",[idseleccionado19]);
					apprise('La reclamación ha sido borrado'); //alert("NC Prov borrada: "+ idseleccionado19);

				})};};
				setTimeout('mostrarReclamaciones(intEstado19)',500);
				VnV19 (1, 1, 0);
		});
	}
	
//=========================================================================================================					
/*NUEVA APC19*/
	function addACP19 (acp, codacp, tipo, fchalta, responsable, equipo, acciones, fchprevista) {
		var origen = "La Reclamaci�n de Cliente: " +  idseleccionado19;
		var codtrz = "rc"+idseleccionado19;
		addMiniACP(acp, codacp, tipo, origen, fchalta, responsable, equipo, acciones, fchprevista, codtrz);
	}

//=========================================================================================================
/* VER NO VER*/
var verNRC=1; var verLRC= 1; var verNACP3= 0;

function VnV19 (Vnrc, Vlrc, Vnacp3) { 
	if (verNRC!=Vnrc) {$("#newrc").toggle(200); verNRC=Vnrc;};
	if (verLRC!=Vlrc) {$("#listarcs").toggle(200); verLRC=Vlrc;};
	if (verNACP3!=Vnacp3) {$("#newacp3").toggle(200); verNACP3=Vnacp3; $("#txtacp3").focus();};
	}

//VER BOTON SEMAFORO_______________________________________________________________________

//Funcion de inicializaci�n de la pesta�a, ocultando el bot�n rojo.
function VbInit19() {document.getElementById('botonrojo19').style.display = 'none';}
//valor 1 se pone rojo, valor 0 se pone verde.	
function Vb19(intColor19) {
	if (INTcolor19!=intColor19) {$("#botonrojo19").toggle(200); $("#botonverde19").toggle(200); INTcolor19=intColor19;};
	}
//_________________________________________________________________________________________
	
