//ESTUDIOS y ENCUESTAS (18)

	var idseleccionado18;
	var idseleccionado18b;
	var nuevosclientes; //Listado de clientes para COMBOBOX
				
//TABLA ESTUDIOS_____________________________________________________________________________________________________________

function mostrarEstudios() {
	sacarEstudios ();
	setTimeout('listEstudios()',500);
	}

function listEstudios() {
		$(document).ready(			
			function () {
				$('#dynamic18').html( '<table cellpadding="0" cellspacing="0" border="0" class="display" id="example18"></table>' );
				$('#example18').dataTable( {
					"aaData": aDataSet18,
						
					"aoColumns": [
						{ "sTitle": "Id"/*, "bSearchable": false, "bVisible": false*/ },
						{ "sTitle": "Estudio" },
						{ "sTitle": "Fecha Inicio" },
						{ "sTitle": "Fecha  Fin" },
						{ "sTitle": "Objetivos", "bSearchable": false, "bVisible": false },
						{ "sTitle": "Estado" },
						{ "sTitle": "Responsable", "bSearchable": false, "bVisible": false},
						{ "sTitle": "Resultado", "bSearchable": false, "bVisible": false},
						{ "sTitle": "Valoración", "bSearchable": false, "bVisible": false},
						{ "sTitle": "Pregunta1", "bSearchable": false, "bVisible": false},
						{ "sTitle": "Pregunta2", "bSearchable": false, "bVisible": false},
						{ "sTitle": "Pregunta3", "bSearchable": false, "bVisible": false},
						{ "sTitle": "Pregunta4", "bSearchable": false, "bVisible": false},
						{ "sTitle": "Pregunta5", "bSearchable": false, "bVisible": false},
						{ "sTitle": "Pregunta6", "bSearchable": false, "bVisible": false},
						{ "sTitle": "Pregunta7", "bSearchable": false, "bVisible": false},
						{ "sTitle": "Pregunta8", "bSearchable": false, "bVisible": false},
						{ "sTitle": "Pregunta9", "bSearchable": false, "bVisible": false},
						{ "sTitle": "Pregunta10", "bSearchable": false, "bVisible": false}
						],
						
					"sScrollY": "600px",
					"bPaginate": false,
					"bScrollCollapse": true,
						
					"sDom": 'lfrtip<"clear spacer">T',
					/*"sDom": 'T<"clear">lfrtip<"clear spacer">T',*/ //Muestra los botones de copy,print...
					"oTableTools": {
						"sRowSelect": "single","aButtons": ["select"], //Solo me muestra el boton select para poder seleccionar las filas.
							
					"aoColumnDefs": [ {
						"sClass": "center",
						"aTargets": [ -1, -2 ]
						} ]
						
				}});
				
				});
	//Cargar datos del equipo para editar en formulario	
		$(document).ready(
			function() {
    			$('#example18 tbody td').click( function () {
				
			//Cargo el COMBOBOX de clientes ------------
			sacarClientes ();
			setTimeout('$("#comboesencliente").html(nuevosclientes);',200);
			//--------------------------------------------------
				
        		/* Get the position of the current data from the node */
				var aPos18 = oTable18.fnGetPosition( this );
         
        		/* Get the data array for this row */
				var aData18 = oTable18.fnGetData( aPos18[0] );
				/*alert("Ok "+aData[0]);*/
				
				idseleccionado18 =  aData18[0];
				document.getElementById("txtesestudio").value = aData18[1];
				document.getElementById("txtesfchinicio").value = aData18[2];
				document.getElementById("txtesfchfin").value = aData18[3];
				document.getElementById("txtesobjetivos").value = aData18[4];
				document.getElementById("comboesestado").value = aData18[5];
				document.getElementById("txtesresponsable").value = aData18[6];
				document.getElementById("txtesresultado").value = aData18[7];
				document.getElementById("txtesvaloracion").value = aData18[8];
				if (aData18[9]) {document.getElementById("labesenpr1").innerHTML = aData18[9]};
				if (aData18[10]) {document.getElementById("labesenpr2").innerHTML = aData18[10]};
				if (aData18[11]) {document.getElementById("labesenpr3").innerHTML = aData18[11]};
				if (aData18[12]) {document.getElementById("labesenpr4").innerHTML = aData18[12]};
				if (aData18[13]) {document.getElementById("labesenpr5").innerHTML = aData18[13]};
				if (aData18[14]) {document.getElementById("labesenpr6").innerHTML = aData18[14]};
				if (aData18[15]) {document.getElementById("labesenpr7").innerHTML = aData18[15]};
				if (aData18[16]) {document.getElementById("labesenpr8").innerHTML = aData18[16]};
				if (aData18[17]) {document.getElementById("labesenpr9").innerHTML = aData18[17]};
				if (aData18[18]) {document.getElementById("labesenpr10").innerHTML = aData18[18]};
			
			DatosBDencuestas(idseleccionado18);
			setTimeout('listEncuestas();',200);
			sacarserieA1 (idseleccionado18);
			sacarserieA2 (idseleccionado18);
			setTimeout('showChartEstudios();',200);				
			
				VnV18(1, 0, 0, 1, 1, 0);
				
				});
     
   				 /* Init DataTables */
   				 oTable18= $('#example18').dataTable();
			}
		);
		
	}
	
//DATOS ESTUDIOS_________________________________________________

function sacarEstudios (){
	var db;
        db = openDatabase("DBIW1", "0.1", "Database Isowin One", 200000);	
		//alert ("Estoy dentro");					
	if(db){
		db.transaction( function(tx) {
			tx.executeSql("SELECT * FROM estudios", [],
				function(tx, result){
					aDataSet18 = [];
					for(var i=0; i < result.rows.length; i++) {	
						aDataSet18.push([result.rows.item(i)['idestudio'],
								result.rows.item(i)['estudio'],
								result.rows.item(i)['fchinicio'],
								result.rows.item(i)['fchfin'],
								result.rows.item(i)['objetivos'],
								result.rows.item(i)['estado'],
								result.rows.item(i)['responsable'],
								result.rows.item(i)['resultado'],
								result.rows.item(i)['valoracion'],
								result.rows.item(i)['pr1'],
								result.rows.item(i)['pr2'],
								result.rows.item(i)['pr3'],
								result.rows.item(i)['pr4'],
								result.rows.item(i)['pr5'],
								result.rows.item(i)['pr6'],
								result.rows.item(i)['pr7'],
								result.rows.item(i)['pr8'],
								result.rows.item(i)['pr9'],
								result.rows.item(i)['pr10'],
								]);
					};			
				});
		});	
	};
}

	
//TABLA ENCUESTAS_____________________________________________________________________________________________________________

function listEncuestas() {
		$(document).ready(			
			function () {
				$('#dynamic18b').html( '<table cellpadding="0" cellspacing="0" border="0" class="display" id="example18b"></table>' );
				$('#example18b').dataTable( {
					"aaData": aDataSet18b,
						
					"aoColumns": [
						{ "sTitle": "Id"/*, "bSearchable": false, "bVisible": false*/ },
						{ "sTitle": "Id Cliente", "bSearchable": false, "bVisible": false },
						{ "sTitle": "Cliente" },
						{ "sTitle": "Estado" },
						{ "sTitle": "Fecha de alta" },
						{ "sTitle": "eval1", "bSearchable": false, "bVisible": false },
						{ "sTitle": "eval2", "bSearchable": false, "bVisible": false },
						{ "sTitle": "eval3", "bSearchable": false, "bVisible": false },
						{ "sTitle": "eval4", "bSearchable": false, "bVisible": false },
						{ "sTitle": "eval5", "bSearchable": false, "bVisible": false },
						{ "sTitle": "eval6", "bSearchable": false, "bVisible": false },
						{ "sTitle": "eval7", "bSearchable": false, "bVisible": false },
						{ "sTitle": "eval8", "bSearchable": false, "bVisible": false },
						{ "sTitle": "eval9", "bSearchable": false, "bVisible": false },
						{ "sTitle": "eval10", "bSearchable": false, "bVisible": false },
						{ "sTitle": "Resultado" }
						],
						
					"sScrollY": "250px",
        			"bPaginate": false,
        			"bScrollCollapse": true,
						
					"sDom": 'lfrtip<"clear spacer">T',
					/*"sDom": 'T<"clear">lfrtip<"clear spacer">T',*/ //Muestra los botones de copy,print...
					"oTableTools": {
						"sRowSelect": "single","aButtons": ["select"], //Solo me muestra el boton select para poder seleccionar las filas.
							
					"aoColumnDefs": [ {
						"sClass": "center",
						"aTargets": [ -1, -2 ]
						} ]
						
				}});
				
				});
	//Cargar datos de la calibración para editar en formulario	
		$(document).ready(
		function() {
    			$('#example18b tbody td').click( function () {
			
        		/* Get the position of the current data from the node */
        		var aPos18b = oTable18b.fnGetPosition( this );
         
        		/* Get the data array for this row */
        		var aData18b = oTable18b.fnGetData( aPos18b[0] );
				/*alert("Ok "+aData[0]);*/
				
				idseleccionado18b =  aData18b[0];
				document.getElementById("comboesencliente").value = aData18b[1];
				document.getElementById("comboesenestado").value = aData18b[3];
				document.getElementById("txtesenfchalta").value = aData18b[4];
				//document.getElementById("stareseneval1").value[3].checked="checked";
				document.getElementById("labeseneval1").innerHTML = "<div style='position:relative; float:right'> Valoración registrada: "+aData18b[5]+"</div>";
				document.getElementById("labeseneval2").innerHTML = "<div style='position:relative; float:right'> Valoración registrada "+aData18b[6]+"</div>";
				document.getElementById("labeseneval3").innerHTML = "<div style='position:relative; float:right'> Valoración registrada "+aData18b[7]+"</div>";
				document.getElementById("labeseneval4").innerHTML = "<div style='position:relative; float:right'> Valoración registrada "+aData18b[8]+"</div>";
				document.getElementById("labeseneval5").innerHTML = "<div style='position:relative; float:right'> Valoración registrada "+aData18b[9]+"</div>";
				document.getElementById("labeseneval6").innerHTML = "<div style='position:relative; float:right'> Valoración registrada "+aData18b[10]+"</div>";
				document.getElementById("labeseneval7").innerHTML = "<div style='position:relative; float:right'> Valoración registrada "+aData18b[11]+"</div>";
				document.getElementById("labeseneval8").innerHTML = "<div style='position:relative; float:right'> Valoración registrada "+aData18b[12]+"</div>";
				document.getElementById("labeseneval9").innerHTML = "<div style='position:relative; float:right'> Valoración registrada "+aData18b[13]+"</div>";
				document.getElementById("labeseneval10").innerHTML = "<div style='position:relative; float:right'> Valoracion registrada "+aData18b[14]+"</div>";
				document.getElementById("labesenresultado").innerHTML = "<div style='position:relative; float:right'> Resultado de la encuesta: "+aData18b[15]+"</div>";
				
				
				sacarserieB1 (idseleccionado18b);
				sacarserieB2 (idseleccionado18b, idseleccionado18);
				setTimeout('showChartEncuestas();',500);
				
				 VnV18(1, 0, 0, 1, 0, 1);
         
    			});
     
   				 /* Init DataTables */
			oTable18b= $('#example18b').dataTable();
		});
		
	}

//DATOS ENCUESTAS FILTRADAS POR ESTUDIO______________________________________________________________________
		
function DatosBDencuestas(idseleccionado18) {
	var db;
        db = openDatabase("DBIW1", "0.1", "Database Isowin One", 200000);
		if(db){	
		db.transaction( function(tx) {
			tx.executeSql("SELECT * FROM encuestas JOIN clientes ON encuestas.idcliente=clientes.idcliente WHERE idestudio=?", [idseleccionado18],
				function(tx, result){
					aDataSet18b = [];
					for(var i=0; i < result.rows.length; i++) {
								
						aDataSet18b.push([result.rows.item(i)['idencuesta'],
								result.rows.item(i)['idcliente'],
								result.rows.item(i)['cliente'],
								result.rows.item(i)['estado'],
								result.rows.item(i)['fchalta'],
								result.rows.item(i)['eval1'],
								result.rows.item(i)['eval2'],
								result.rows.item(i)['eval3'],
								result.rows.item(i)['eval4'],
								result.rows.item(i)['eval5'],
								result.rows.item(i)['eval6'],
								result.rows.item(i)['eval7'],
								result.rows.item(i)['eval8'],
								result.rows.item(i)['eval9'],
								result.rows.item(i)['eval10'],
								result.rows.item(i)['resultado']]);
												
				}		
   				 /* Init DataTables */
   				 oTable18b = $('#example18b').dataTable();				
				 
				});
				
				
		});
		
	}}
	

//=========================================================================================================					
/*NUEVO ESTUDIO*/
	
	function addEstudio (estudio, fchinicio, fchfin, objetivos, estado, responsable, resultado) {
		
		var db;
		db = openDatabase("DBIW1", "0.1", "Database Isowin One", 200000);
		if(db){	
		  db.transaction( function(tx) {
			tx.executeSql("INSERT INTO estudios (estudio, fchinicio, fchfin, objetivos, estado, responsable, resultado) VALUES(?,?,?,?,?,?,?)", [estudio, fchinicio, fchfin, objetivos, estado, responsable, resultado]);
			tx.executeSql("SELECT * FROM estudios", [], function(tx, result){
				nuevoId = result.rows.item(result.rows.length-1)["idestudio"];
				CEXaddCita( "Estudio de Satisfacción: " + estudio, fchinicio, fchfin, "Estudio de satisfacción " +estudio+ " planificado del " +fchinicio+ " al " +fchfin, "EST" + nuevoId);
				apprise('El estudio ha sido guardado'); //alert("Estudio guardado: "+ estudio);
			});
		  });
		};
		
		setTimeout('mostrarEstudios()',500);
		  VnV18(1, 0, 0, 1, 0, 0);
	}
	
/*ACTUALIZAR ESTUDIO*/
	function updateEstudio (estudio, fchinicio, fchfin, objetivos, estado, responsable, resultado) {
		
		var db;
        db = openDatabase("DBIW1", "0.1", "Database Isowin One", 200000);
		if(db){	
		  db.transaction( function(tx) {
			tx.executeSql("UPDATE estudios SET estudio=?, fchinicio=?, fchfin=?, objetivos=?, estado=?, responsable=?, resultado=?   WHERE idestudio=?", [estudio, fchinicio, fchfin, objetivos, estado, responsable, resultado, idseleccionado18]);
			CEXupdateCita( "Estudio de Satisfacción: " + estudio, fchinicio, fchfin, "Estudio de satisfacción " +estudio+ " planificado del " +fchinicio+ " al " +fchfin,"EST" + idseleccionado18);
			apprise('El estudio ha sido modificado'); //alert("Estudio ha cambiado: "+ estudio + " - " + idseleccionado18);
		})};
		setTimeout('mostrarEstudios()',500);
	}					

/*BORRAR ESTUDIO*/
	function removeEstudio() {
		apprise('¿Eliminar el estudio?', {'verify': true}, function(r) {
			if(r) {
				var db;
				db = openDatabase("DBIW1", "0.1", "Database Isowin One", 200000);
				if(db){	
					db.transaction(function(tx) {
						tx.executeSql("DELETE FROM estudios WHERE idestudio=?",[idseleccionado18]);
						tx.executeSql("DELETE FROM encuestas WHERE idestudio=?",[idseleccionado18]); //limpia calibraciones asociadas.
						CEXdeleteCita("EST" + idseleccionado18);
						apprise('El estudio ha sido borrado'); //alert("Estudio borrado: "+ idseleccionado18);

					});
				};
			};

		setTimeout('mostrarEstudios()',500);
		 VnV18(0, 1, 0, 0, 0, 0);
		});
	}
	
//=========================================================================================================					
/*NUEVA ENCUESTA*/
	
	function addEncuesta (idcliente, estado, fchalta) {
		
		var db;
		var resultadoAUX = (eval1+eval2+eval3+eval4+eval5+eval6+eval7+eval8+eval9+eval10)/10;
		var resultado = resultadoAUX.toFixed(3);
		
		db = openDatabase("DBIW1", "0.1", "Database Isowin One", 200000);
		if(db){
		  db.transaction( function(tx) {
			tx.executeSql("INSERT INTO encuestas (idestudio, idcliente, estado, fchalta, eval1, eval2, eval3, eval4, eval5, eval6, eval7, eval8, eval9, eval10, resultado) VALUES(?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)", [ idseleccionado18, idcliente, estado, fchalta, eval1, eval2, eval3, eval4, eval5, eval6, eval7, eval8, eval9, eval10, resultado]);
			//tx.executeSql("UPDATE estudios SET pr1=?, pr2=?, pr3=?, pr4=?, pr5=?, pr6=?, pr7=?, pr8=?, pr9=?, pr10=?   WHERE idestudio=?", [pr1, pr2, pr3, pr4, pr5, pr6, pr7, pr8, pr9, pr10, idseleccionado18]);
			apprise('Encuesta guardada'); //alert("Encuesta registrada (" +idseleccionado18+")");
		})};
		
		DatosBDencuestas(idseleccionado18);
		setTimeout('listEncuestas()',200);
		 VnV18(1, 0, 0, 1, 0, 1);
	}

	
/*ACTUALIZAR ENCUESTA*/
	function updateEncuesta (idcliente, estado, fchalta) {
		var db;
		var resultadoAUX = (eval1+eval2+eval3+eval4+eval5+eval6+eval7+eval8+eval9+eval10)/10;
		var resultado = resultadoAUX.toFixed(3);
		
		db = openDatabase("DBIW1", "0.1", "Database Isowin One", 200000);
		if(db){	
		  db.transaction( function(tx) {
			tx.executeSql("UPDATE encuestas SET idestudio=?, idcliente=?, estado=?, fchalta=?, eval1=?, eval2=?, eval3=?, eval4=?, eval5=?, eval6=?, eval7=?, eval8=?, eval9=?, eval10=?, resultado=?  WHERE idencuesta=?", [idseleccionado18, idcliente, estado, fchalta, eval1, eval2, eval3, eval4, eval5, eval6, eval7, eval8, eval9, eval10, resultado, idseleccionado18b]);
			//tx.executeSql("UPDATE estudios SET pr1=?, pr2=?, pr3=?, pr4=?, pr5=?, pr6=?, pr7=?, pr8=?, pr9=?, pr10=?   WHERE idestudio=?", [pr1, pr2, pr3, pr4, pr5, pr6, pr7, pr8, pr9, pr10, idseleccionado18]);
			apprise('Encuesta modificada'); //alert("La valoración de la encuesta ha cambiado." + idseleccionado18b);
		});};
		
		DatosBDencuestas(idseleccionado18);
		setTimeout('listEncuestas()',200);
		VnV18(1, 0, 0, 1, 0, 1);
	}

/*BORRAR ENCUESTA*/
	function removeEncuesta () {
		apprise('¿Eliminar encuesta?', {'verify': true}, function(r) {
		if(r) { 
			var db;
			db = openDatabase("DBIW1", "0.1", "Database Isowin One", 200000);
			if(db){	
				db.transaction(function(tx) {
					tx.executeSql("DELETE FROM encuestas WHERE idencuesta=? ",[idseleccionado18b]);
					apprise('Encuesta borrada'); //alert("Encuesta borrada.");
				});
			};
		};
		
		DatosBDencuestas(idseleccionado18);
		setTimeout('listEncuestas()',200);
		VnV18(1, 0, 0, 1, 1, 0);
		});
	}

//=========================================================================================================		
/*VALOR DE LAS STARS*/
	
	var eval1=0; var eval2=0; var eval3=0; var eval4=0; var eval5=0; var eval6=0; var eval7=0; var eval8=0; var eval9=0; var eval10=0;
		
	$(function(){	
		$('.star1').rating({callback: function(value, link){eval1 = parseInt(value);}});
		$('.star2').rating({callback: function(value, link){eval2 = parseInt(value);}});
		$('.star3').rating({callback: function(value, link){eval3 = parseInt(value);}});
		$('.star4').rating({callback: function(value, link){eval4 = parseInt(value);}});
		$('.star5').rating({callback: function(value, link){eval5 = parseInt(value);}});
		$('.star6').rating({callback: function(value, link){eval6 = parseInt(value);}});
		$('.star7').rating({callback: function(value, link){eval7 = parseInt(value);}});
		$('.star8').rating({callback: function(value, link){eval8 = parseInt(value);}});
		$('.star9').rating({callback: function(value, link){eval9 = parseInt(value);}});
		$('.star10').rating({callback: function(value, link){eval10 = parseInt(value);}});
	})
	
		

//=========================================================================================================					
/*CAMBIO DE PREGUNTAS*/
	
$(function() {$(".editable_textarea_Encuesta").editable
	(function(value, settings) { 
			db = openDatabase("DBIW1", "0.1", "Database Isowin One", 200000);
			if(db){
				if (this.id=='labesenpr1') {db.transaction( function(tx) {tx.executeSql ("UPDATE estudios SET pr1=?  WHERE idestudio=?", [value, idseleccionado18])})};
				if (this.id=='labesenpr2') {db.transaction( function(tx) {tx.executeSql ("UPDATE estudios SET pr2=?  WHERE idestudio=?", [value, idseleccionado18])})};
				if (this.id=='labesenpr3') {db.transaction( function(tx) {tx.executeSql ("UPDATE estudios SET pr3=?  WHERE idestudio=?", [value, idseleccionado18])})};
				if (this.id=='labesenpr4') {db.transaction( function(tx) {tx.executeSql ("UPDATE estudios SET pr4=?  WHERE idestudio=?", [value, idseleccionado18])})};
				if (this.id=='labesenpr5') {db.transaction( function(tx) {tx.executeSql ("UPDATE estudios SET pr5=?  WHERE idestudio=?", [value, idseleccionado18])})};
				if (this.id=='labesenpr6') {db.transaction( function(tx) {tx.executeSql ("UPDATE estudios SET pr6=?  WHERE idestudio=?", [value, idseleccionado18])})};
				if (this.id=='labesenpr7') {db.transaction( function(tx) {tx.executeSql ("UPDATE estudios SET pr7=?  WHERE idestudio=?", [value, idseleccionado18])})};
				if (this.id=='labesenpr8') {db.transaction( function(tx) {tx.executeSql ("UPDATE estudios SET pr8=?  WHERE idestudio=?", [value, idseleccionado18])})};
				if (this.id=='labesenpr9') {db.transaction( function(tx) {tx.executeSql ("UPDATE estudios SET pr9=?  WHERE idestudio=?", [value, idseleccionado18])})};
				if (this.id=='labesenpr10') {db.transaction( function(tx) {tx.executeSql ("UPDATE estudios SET pr10=?  WHERE idestudio=?", [value, idseleccionado18])})};

				
				apprise('Pregunta modificada'); //alert("modificado" + this.id + value);
				}
			return(value);
			},
		
		{
		type   : 'textarea', 
		select : true, 
		submit : '<div class="sprite ok">', 
		cancel : '<div class="sprite ko">', 
		height  : "auto",
		cssclass : "editable"}
	);
});

//=========================================================================================================					
/*COMBOBOX DE CLIENTES*/

function sacarClientes (){
	var db;
        db = openDatabase("DBIW1", "0.1", "Database Isowin One", 200000);	
		//alert ("Estoy dentro");					
	if(db){
		db.transaction( function(tx) {
			tx.executeSql("SELECT * FROM clientes", [],
				function(tx, result){
					nuevosclientes = "<option selected></option>";
					for(var i=0; i < result.rows.length; i++) {	
						nuevosclientes = nuevosclientes + "<option value='" +result.rows.item(i)['idcliente']+"'>"+result.rows.item(i)['cliente']+"</option> ";
					}			
				});
		});	
	
	};
}

//=========================================================================================================
/* VER NO VER*/
var verNEN= 0; var verLEN= 0; var verNES= 0; var verLES= 1; var verGEN= 0; var verGES= 0;

function VnV18 (Vnes, Vles, Vnen, Vlen, Vges, Vgen) { 
	if (verNES!=Vnes) {$("#newestudio").toggle(200); verNES=Vnes; $("#txtesestudio").focus();};
	if (verLES!=Vles) {$("#listaestudios").toggle(200); verLES=Vles;};
	if (verNEN!=Vnen) {$("#newencuesta").toggle(200); verNEN=Vnen; $("#comboesencliente").focus();};
	if (verLEN!=Vlen) {$("#listaencuestas").toggle(200); verLEN=Vlen;};
	if (verGES!=Vges) {$("#graficosestudio").toggle(200);verGES=Vges;};
	if (verGEN!=Vgen) {$("#graficosencuesta").toggle(200); verGEN=Vgen;};
	}
