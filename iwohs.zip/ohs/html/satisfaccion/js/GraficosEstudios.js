
// variables globales
var chartA1; var serieA1 =  [{"name" : "Valores", "data" : [3,3,3,2,2,2,2,3,3,3]}]; //Inicializacion de array
var chartA2; var serieA2 =  [{"name" : "Valores", "data" : [3,3,3,2,2,2,2,2,2,3,3,3]}]; //Inicializacion de array
var clientes = []; 


function showChartEstudios(){

		chartsA1 = new Highcharts.Chart({
			chart: {renderTo:  'containerA1', defaultSeriesType: 'column', marginBottom: 25, /*events: {load: sacarseries()}*/},
			title: {text:  'Resultados por Pregunta', x: -20 /* center */},
			subtitle: {text:  'Resultados agrupados para cada Pregunta', x: -20},
			credits: {enabled: false},
			xAxis: {categories: ['Pr1', 'Pr2', 'Pr3', 'Pr4', 'Pr5', 'Pr6', 'Pr7', 'Pr8', 'Pr9', 'Pr10']},
			yAxis: {title: {text: 'Resultado por pregunta'}, plotLines: [{value: 0, width: 1, color: '#808080'}]},
			tooltip: {formatter: function() { return '<b>'+ this.series.name +'</b><br/>'+ this.x +': '+ this.y +''; /* unidades del cada valor de la serie. */}},
			legend: {enabled: false},
			series: serieA1
		});
		
		chartA2 = new Highcharts.Chart({
			chart: {renderTo:  'containerA2', defaultSeriesType: 'column', marginBottom: 25 },
			//events: {load: sacarseries('I1') },
			title: {text:  'Resultados por Cliente', x: -20 /* center */},
			subtitle: {text:  'Resultados en cada encuesta', x: -20},
			credits: {enabled: false},
			xAxis: {categories: clientes},
			yAxis: {title: {text: 'Resultado por cliente'}, plotLines: [{value: 0, width: 1, color: '#808080'}]},
			tooltip: {formatter: function() { return '<b>'+ this.series.name +'</b><br/>'+ this.x +': '+ this.y +''; /* unidades del cada valor de la serie. */}},
			legend: {enabled: false},
			series: serieA2
		});
			
	}
	

function sacarserieA1 (idestudio){
	var db;
        db = openDatabase("DBIW1", "0.1", "Database Isowin One", 200000);	
		//alert ("Estoy dentro");					
		if(db){
		//alert("conectado");	
		db.transaction( function(tx) {
			tx.executeSql("SELECT * FROM encuestas WHERE idestudio=?", [idestudio],
				function(tx, result){
					
					var porPregunta = [0,0,0,0,0,0,0,0,0,0];

					for(var i=0; i < result.rows.length; i++) {	
					porPregunta[0] = porPregunta[0] + parseInt(result.rows.item(i)['eval1']);
					porPregunta[1] = porPregunta[1] + parseInt(result.rows.item(i)['eval2']);
					porPregunta[2] = porPregunta[2] + parseInt(result.rows.item(i)['eval3']);
					porPregunta[3] = porPregunta[3] + parseInt(result.rows.item(i)['eval4']);
					porPregunta[4] = porPregunta[4] + parseInt(result.rows.item(i)['eval5']);
					porPregunta[5] = porPregunta[5] + parseInt(result.rows.item(i)['eval6']);
					porPregunta[6] = porPregunta[6] + parseInt(result.rows.item(i)['eval7']);
					porPregunta[7] = porPregunta[7] + parseInt(result.rows.item(i)['eval8']);
					porPregunta[8] = porPregunta[8] + parseInt(result.rows.item(i)['eval9']);
					porPregunta[9] = porPregunta[9] + parseInt(result.rows.item(i)['eval10']);						
					};
					porPregunta[0] = porPregunta[0]/result.rows.length;
					porPregunta[1] = porPregunta[1]/result.rows.length;
					porPregunta[2] = porPregunta[2]/result.rows.length;
					porPregunta[3] = porPregunta[3]/result.rows.length;
					porPregunta[4] = porPregunta[4]/result.rows.length;
					porPregunta[5] = porPregunta[5]/result.rows.length;
					porPregunta[6] = porPregunta[6]/result.rows.length;
					porPregunta[7] = porPregunta[7]/result.rows.length;
					porPregunta[8] = porPregunta[8]/result.rows.length;
					porPregunta[9] = porPregunta[9]/result.rows.length;
						
					serieA1 = [{"name" : "Valores", "data" : porPregunta}];
				   
				}
			)
		})
		};
						
	}


function sacarserieA2 (idestudio){
	var db;
        db = openDatabase("DBIW1", "0.1", "Database Isowin One", 200000);	
		//alert ("Estoy dentro");					
		if(db){
		//alert("conectado");	
		db.transaction( function(tx) {
			tx.executeSql("SELECT * FROM encuestas JOIN clientes ON encuestas.idcliente=clientes.idcliente WHERE idestudio=?", [idestudio],
				function(tx, result){

					var porCliente = [];
					clientes = []; 

					for(var i=0; i < result.rows.length; i++) {
					clientes[i] = result.rows.item(i)['cliente'];
					//alert(result.rows.item(i)['cliente']);						
					porCliente[i] = parseFloat(result.rows.item(i)['resultado']);					
					};
						
					serieA2 = [{"name" : "Valores", "data" : porCliente}];
				   
				}
			)
		})
		};
						
	}

	
				