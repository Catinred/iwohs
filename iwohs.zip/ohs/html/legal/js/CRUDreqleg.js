//REQUISITOS LEGALES (51)

	var idseleccionado51;
	var intEstado51;
	var INTcolor51; //Color del semaforo en verde
	var atipo = ["GENERAL","MECANICOS","ELECTRICOS","HIGIENICOS","ERGONOMICOS","CONSTRUCCION","QUIMICOS","RUIDO/VIBR.","PRESION","MAQU./INST.","RADIACION","BIOLOGICOS","ALTURAS","VEHICULOS","OTROS..."];
	
		
//TABLA REQUISITOS LEGALES_____________________________________________________________________________________________________________
function mostrarReqLegs(intEst51) {
	intEstado51=intEst51;
	sacarReqLegs (intEstado51);
	setTimeout('listReqLegs()',500);
	Vb51();
	}


function listReqLegs() {
			$(document).ready(			
			function () {
				$('#dynamic51').html( '<table cellpadding="0" cellspacing="0" border="0" class="display" id="example51"></table>' );
				$('#example51').dataTable( {
					"aaData": aDataSet51,
						
					"aoColumns": [
						{ "sTitle": "Estado"},
						{ "sTitle": "Id", "bSearchable": false, "bVisible": false },
						{ "sTitle": "Requisito" },
						{ "sTitle": "Codigo Requisito", "bSearchable": false, "bVisible": false },
						{ "sTitle": "Trazabilidad", "bSearchable": false, "bVisible": false },
						{ "sTitle": "Referencia", "bSearchable": false, "bVisible": false },
						{ "sTitle": "Link documento" },
						{ "sTitle": "fsname", "bSearchable": false, "bVisible": false },
						{ "sTitle": "fslink", "bSearchable": false, "bVisible": false },
						{ "sTitle": "Fecha alta" },
						{ "sTitle": "Vigente", "bSearchable": false, "bVisible": false },
						{ "sTitle": "Revisión", "bSearchable": false, "bVisible": false },
						{ "sTitle": "Id Tipo", "bSearchable": false, "bVisible": false },
						{ "sTitle": "Tipo" },
						{ "sTitle": "Cumplimiento", "bSearchable": false, "bVisible": false },
						{ "sTitle": "Obs", "bSearchable": false, "bVisible": false }
						],
						
					"sScrollY": "350px",
					"sScrollX": "100%",
					
					"sScrollXInner": "100%",
					"bScrollCollapse": false,//Si true: la tabla se reduce para ajustarse al número de datos.
					"bPaginate": false,
					"aaSortingFixed": [[13, 'asc']], //Ordena las filas por el campo de agrupación. Cuenta las visibles como las no visibles.
					"aoColumnDefs": [{ "bVisible": false, "aTargets": [13] }],//Oculto el valor de agrupación de la tabla de las columnas visibles!

					//Para poder seleccionar las filas de la tabla
					"sDom": 'lfrtip<"clear spacer">T',
					"oTableTools": {"sRowSelect": "single","aButtons": ["select"], //Solo me muestra el boton select para poder seleccionar las filas.	
									"aoColumnDefs": [{"sClass": "center", "aTargets": [ -1, -2 ]}]}
			});

				//Cargo el COMBOBOX de responsables del formulario NCs------------
				sacarResponsables ();
				setTimeout('$("#comboacpresp3").html(nuevosresponsables);',200);
				//--------------------------------------------------
				
				});
	//Cargar datos de proveedor para editar en formulario	
			$(document).ready(
				function() {
    			$('#example51 tbody td').click( function () {
        		/* Get the position of the current data from the node */
        		var aPos51 = oTable51.fnGetPosition( this );
         
        		/* Get the data array for this row */
        		var aData51 = oTable51.fnGetData( aPos51[0] );
				/*alert("Ok "+aData[0]);*/
				
				document.getElementById("comborlestado").value = aData51[0];
				idseleccionado51 =  aData51[1];
				document.getElementById("txtrl").value = aData51[2];
				document.getElementById("txtrlcod").value = aData51[3];
				//El 4 es trazabilidad
				document.getElementById("txtrlref").value = aData51[5];
				document.getElementById("txtrlfchalta").value = aData51[9];
				document.getElementById("comborlvigente").value = aData51[10];
				document.getElementById("txtrlrevision").value = aData51[11];
				document.getElementById("comborltipo").value = aData51[12];
				//Descripción del tipo sólo para mostrar en la tabla
				document.getElementById("txtrlcumplimiento").value = aData51[14];
				document.getElementById("txtrlobs").value = aData51[15];

				//File System-----------------------------------------------------------
					if (aData51[8]) {document.getElementById("FSREQ").innerHTML = "<p><a class='doc' href='"+aData51[8]+"' target='_blank'>"+aData51[7]+"</a> <img src='img/miniboton.jpg' style='vertical-align:middle' onclick='deleteFSREQ();' /></p>"; 
							nombreFS=aData51[7]; rutaFS=aData51[8]}
					else {document.getElementById("FSREQ").innerHTML = "<input type='file' id='myREQ' />";};
				//----------------------------------------------------------------------
				
				VnV51 (1, 1, 0);
				VnVEreq (1);//No ver botones update y delete
         
    			});
     
   				 /* Init DataTables */
   				 oTable51 = $('#example51').dataTable();
				});

//AGRUPAR filas de la tabla
$(document).ready(function() {
	new FixedColumns( oTable51, {
		"fnDrawCallback": function ( left, right ) {
			var oSettings = oTable51.fnSettings();
			if ( oSettings.aiDisplay.length == 0 )
			{
				return;
			}

			var nGroup, nCell, iIndex, sGroup;
			var sLastGroup = "", iCorrector=0;
			var nTrs = $('#example51 tbody tr');
			var iColspan = nTrs[0].getElementsByTagName('td').length;

			for ( var i=0 ; i<nTrs.length ; i++ )
			{
				iIndex = oSettings._iDisplayStart + i;
				sGroup = oSettings.aoData[ oSettings.aiDisplay[iIndex] ]._aData[13];//Nº de columna del Valor de agrupación
				
				if ( sGroup != sLastGroup )
				{
					/* Cell to insert into main table */
					nGroup = document.createElement( 'tr' );
					nCell = document.createElement( 'td' );
					nCell.colSpan = iColspan;
					nCell.className = "group";
					nCell.innerHTML = "&nbsp;";
					nGroup.appendChild( nCell );
					nTrs[i].parentNode.insertBefore( nGroup, nTrs[i] );

					/* Cell to insert into the frozen columns */
					nGroup = document.createElement( 'tr' );
					nCell = document.createElement( 'td' );
					nCell.className = "group";
					nCell.innerHTML = sGroup;
					nGroup.appendChild( nCell );
					$(nGroup).insertBefore( $('tbody tr:eq('+(i+iCorrector)+')', left.body)[0] );

					iCorrector++;
					sLastGroup = sGroup;
				}
			}
		} 
	} );});
		
	}
	
//DATOS REQUISITOS LEGALES_________________________________________________

function sacarReqLegs (intEstado51){
	var db;
        db = openDatabase("DBIWOHS", "0.1", "Database Isowin OHS", 5 * 1024 * 1024);	
	
	var estado51="AND vigente!='false' AND estado!='No aplica' ";
	if (intEstado51==1) {estado51="AND vigente!='false' AND estado='No aplica' ";};	
	if (intEstado51==2) {estado51="AND vigente='false' ";};	
							
	if(db){
		db.transaction( function(tx) {
			//La trazabilidad igual a RL, identifica que es un requisito legal y no de cliente entre todos los requisitos
			tx.executeSql("SELECT * FROM requisitos WHERE trazabilidad=? " + estado51, ["RL"],
				function(tx, result){
					aDataSet51 = [];
					for(var i=0; i < result.rows.length; i++) {

						//Extraigo del vector de tipos el tipo correspondiente al id de la base de datos
						tipo = atipo[parseInt(result.rows.item(i)['tipo'])];
						//alert(tipo);

						var linknull = "";//File System
						if (result.rows.item(i)['fsname']) {linknull = result.rows.item(i)['fsname'];};

						aDataSet51.push([
								result.rows.item(i)['estado'],
								result.rows.item(i)['idrequisito'],
								result.rows.item(i)['requisito'],
								result.rows.item(i)['codrequisito'],
								result.rows.item(i)['trazabilidad'],
								result.rows.item(i)['referencia'],
								"<a href='"+result.rows.item(i)['fslink']+"' target='_blank'>"+linknull+"</a>",
								result.rows.item(i)['fsname'],
								result.rows.item(i)['fslink'],
								result.rows.item(i)['fchinicio'],
								result.rows.item(i)['vigente'],
								result.rows.item(i)['revision'],
								result.rows.item(i)['tipo'],
								tipo,
								result.rows.item(i)['cumplimiento'],
								result.rows.item(i)['obs']
								]);
					};			
				});
		});	
	};
}

//=========================================================================================================					
/*NUEVO REQUISITO LEGAL*/
	function addReqLeg (requisito, codrequisito, referencia, fchinicio, vigente, revision, tipo, estado, cumplimiento, obs) {
		var db;
		FSError = false; nombreFS=null; rutaFS=null;//FileSystem 
		addFile("myREQ");//FileSystem
		db = openDatabase("DBIWOHS", "0.1", "Database Isowin OHS", 5 * 1024 * 1024);
		if(db){	
		  db.transaction( function(tx) {
			tx.executeSql("INSERT INTO requisitos (requisito, codrequisito, trazabilidad, referencia, fchinicio, vigente, revision, tipo, estado, cumplimiento, obs) VALUES(?,?,?,?,?,?,?,?,?,?,?)", [requisito, codrequisito, "RL", referencia, fchinicio, vigente, revision, tipo, estado, cumplimiento, obs]);
			tx.executeSql("SELECT * FROM requisitos ORDER BY idrequisito DESC", [], function(tx, result){
					idseleccionado51 = result.rows.item(0)["idrequisito"];
					if (!FSError) {apprise('El requisito legal ha sido guardado');};
				});
			
		})};

		setTimeout('updateFSReqLeg()',300);
		setTimeout('mostrarReqLegs(intEstado51)',500);
		VnV51 (1, 1, 0);
	}
	
/*ACTUALIZO REQUISITO LEGAL*/
		function updateReqLeg (requisito, codrequisito, referencia, fchinicio, vigente, revision, tipo, estado, cumplimiento, obs) {
		var db;
		FSError = false; nombreFS=null; rutaFS=null;//FileSystem 
		addFile("myREQ");//FileSystem
		db = openDatabase("DBIWOHS", "0.1", "Database Isowin OHS", 5 * 1024 * 1024);
		if(db){	
		  db.transaction( function(tx) {
			tx.executeSql("UPDATE requisitos SET requisito=?, codrequisito=?, trazabilidad=?, referencia=?, fchinicio=?, vigente=?, revision=?, tipo=?, estado=?, cumplimiento=?, obs=? WHERE idrequisito=?", [requisito, codrequisito, "RL", referencia, fchinicio, vigente, revision, tipo, estado, cumplimiento, obs, idseleccionado51]);
			if (!FSError) {apprise('El requisito legal ha sido modificado');};
		})};
		
		setTimeout('updateFSReqLeg()',300);
		setTimeout('mostrarReqLegs(intEstado51)',500); 
		VnV51 (1, 1, 0);
	}					

/*ACTUALIZAR ARCHIVOS*/
function updateFSReqLeg() {
var db;
db = openDatabase("DBIWOHS", "0.1", "Database Isowin OHS", 5 * 1024 * 1024);
		if(db){	
		db.transaction( function(tx) {
			if (nombreFS!=null) {tx.executeSql("UPDATE requisitos SET fsname=?, fslink=? WHERE idrequisito=?", [nombreFS, rutaFS, idseleccionado51]);
								document.getElementById("FSREQ").innerHTML = "<a class='doc' href='"+rutaFS+"' target='_blank'>"+nombreFS+"</a> <img src='img/miniboton.jpg' style='vertical-align:middle' onclick='deleteFSREQ();' />";};
			});
		};
}


/*BORRO REQUISITO LEGAL*/
	function removeReqLeg() {
		apprise('¿Eliminar el requisito legal?', {'verify': true}, function(r) {
			if(r) {
			var db;
			deleteFile();//FileSystem
			db = openDatabase("DBIWOHS", "0.1", "Database Isowin OHS", 5 * 1024 * 1024);
			if(db){	
				db.transaction(function(tx) {
					tx.executeSql("DELETE FROM requisitos WHERE idrequisito=?",[idseleccionado51]);
					if (!FSError) {apprise('El requisito legal ha sido borrado');};
				})};};

			setTimeout('mostrarReqLegs(intEstado51);',500);
			VnV51 (1, 1, 0);
		});
	}

	/*BORRAR ARCHIVOS*/
	function deleteFSREQ() {
		deleteLinkFile('requisitos');
		document.getElementById("FSREQ").innerHTML = "<input type='file' id='myREQ' />";
		setTimeout('mostrarReqLegs(intEstado51);',500);
	}
//=========================================================================================================					
/*NUEVA APC51*/
	function addACP51 (acp, codacp, tipo, fchalta, responsable, equipo, acciones, fchprevista) {
		var origen = "El requisito legal: " +  idseleccionado51;
		var codtrz = "rq"+idseleccionado51;
		addMiniACP(acp, codacp, tipo, origen, fchalta, responsable, equipo, acciones, fchprevista, codtrz);
	}
	
//=========================================================================================================
/* VER NO VER*/
var verNRL=1; var verLRL= 1; var verNACP3= 0;

function VnV51 (Vnrl, Vlrl, Vnacp3) { 
	if (verNRL!=Vnrl) {$("#newreqleg").toggle(200); verNRL=Vnrl;};
	if (verLRL!=Vlrl) {$("#listareqlegs").toggle(200); verLRL=Vlrl;};
	if (verNACP3!=Vnacp3) {$("#newacp3").toggle(200); verNACP3=Vnacp3; $("#txtacp3").focus();};
	}

/* VER NO VER EDIT (Update+Delete)*/
var verEREQ=0;
function VnVEreq (Vereq) {if (verEREQ!=Vereq) {$("#editreq").toggle(200); verEREQ=Vereq;};}

//VER BOTON SEMAFORO_______________________________________________________________________

//Funcion de inicialización de la pestaña, ocultando el botón rojo.
function VbInit51() {
	document.getElementById('botonverde51').style.display = 'inherit';
	document.getElementById('botonrojo51').style.display = 'none';
	document.getElementById('botonamar51').style.display = 'none';
	INTcolor51 = 1;
	}
	
//valor 1 se pone rojo, valor 0 se pone verde.	
function Vb51() {
	if (INTcolor51==1) {$("#botonverde51").toggle(200); $("#botonamar51").toggle(200);};
	if (INTcolor51==2) {$("#botonamar51").toggle(200); $("#botonrojo51").toggle(200);};
	if (INTcolor51==3) {$("#botonrojo51").toggle(200); $("#botonverde51").toggle(200); INTcolor51=0;};
	INTcolor51 = INTcolor51 + 1;
	}
//__________________________________________________________________________________________

