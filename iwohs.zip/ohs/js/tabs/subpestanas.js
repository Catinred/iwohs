//Pestañas JQuery

//Subpestañas para poder colocar dos niveles de pestañas en una misma página web

//<![CDATA[
$(document).ready(function(){
  var alltabsA = $('div.tabA');
  var tabsA = $('#tabsA');
  alltabsA.first().show();
  tabsA.find('li:first').addClass('on');
  tabsA.find('a').live('click', function() {
    alltabsA.hide()
    tabsA.find('li').removeClass('on')
    $(this).parent().toggleClass('on')
    var tabrefA = $(this).attr('rel')
    $(tabrefA).fadeIn(500)
    this.blur()
    return false;	
	
  })
})
//]]>
