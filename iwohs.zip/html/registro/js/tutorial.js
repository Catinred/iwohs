$(function() {
//SPIN
var opts = {
  lines: 10, // The number of lines to draw
  length: 10, // The length of each line
  width: 5, // The line thickness
  radius: 10, // The radius of the inner circle
  corners: 1, // Corner roundness (0..1)
  rotate: 0, // The rotation offset
  direction: 1, // 1: clockwise, -1: counterclockwise
  color: '#000', // #rgb or #rrggbb or array of colors
  speed: 1, // Rounds per second
  trail: 60, // Afterglow percentage
  shadow: false, // Whether to render a shadow
  hwaccel: false, // Whether to use hardware acceleration
  className: 'spinner', // The CSS class to assign to the spinner
  zIndex: 2e9, // The z-index (defaults to 2000000000)
  top: 'auto', // Top position relative to parent in px
  left: 'auto' // Left position relative to parent in px
};
var target = document.getElementById('spin_div');


//Oculto las etiquetas de error
  $('.error').hide();
 //indico los campos que son obligatorios cambiando el color de su fondo al seleccionarlos
  $('input.text-input').css({backgroundColor:"#FFFFFF"});
  $('input.text-input').focus(function(){
    $(this).css({backgroundColor:"#CCC"});
  });
  $('input.text-input').blur(function(){
    $(this).css({backgroundColor:"#FFFFFF"});
  });

  $(".button").click(function() {
		// validate and process form
		// first hide any error messages
    $('.error').hide();
	  
	  var nombre = $("input#nombre").val();
		if (nombre == "") {$("label#nombre_error").show();$("input#nombre").focus();return false;}

	  var email = $("input#email").val();
		if (email == "") {$("label#email_error").show();$("input#email").focus();return false;}

	  var password = $("input#password1").val();
		if (password == "") {$("label#password1_error").show();$("input#password1").focus();return false;}

    	var password2 = $("input#password2").val();
		if ((password2 == "")  || (password2 != password)) {
      $("label#password2_error").show();$("input#password2").focus();return false;}
				
	if ($("input#avisoLegal").checked==0)  {$("label#avisoLegal_error").show();$("input#avisoLegal").focus();return false;}
    
	//Extraigo el challenge mostrado y la respuesta del usuario
    var captdes = Recaptcha.get_challenge();
    var captres = Recaptcha.get_response();
    //Creo que la cadena que voy a enviar al PHP
    var dataString =  'nombre=' + nombre + '&email='+ email + '&password=' + password + '&captchachall=' + captdes + '&captcharesp=' +captres;

    //spin
  var spinner = new Spinner(opts).spin(target);
 
//Comunicación AJAX con el PHP	
$.ajax({
      type: "POST",
      url: "html/registro/bin/process.php",
      data: dataString,
      success: function(respuesta) {
        //alert(respuesta);
        if(respuesta != 'success'){
          $('#register_form').html("<div id='messageRegister' style='position:relative; left:20px;'></div>");
          $('#messageRegister').html("<h2>Ya estás registrado!</h2>")
          .append("<p>Ya puedes comenzar a utilizar ISOWIN OHS.</p>")
          .hide()
          .fadeIn(1000, function() {
            $('#messageRegister').append("<img id='checkmark' src='html/registro/img/check.png' />");
          });
	         var is_chrome= navigator.userAgent.toLowerCase().indexOf('chrome/') > -1;
	         if (is_chrome) {setTimeout('window.location.href="ohs/presentacion.html"', 2000);}
	             else {setTimeout('window.location.href="chrome.html"', 2000);};
        } else { 
          //Si no ha escrito bien el captcha (el PHP devuelve "success"), recargo el challenge del chaptcha
          Recaptcha.reload();
          spinner.stop();
        };
      }
     }); //fin Ajax

  return false;
	});//Fin del Botón
});//Fin de la Function

runOnLoad(function(){
  $("input#nombre").select().focus();
});


// Wrapping the Recaptcha create method in a javascript function
  function showRecaptcha(element) {
    Recaptcha.create("6Lf8T-ESAAAAABYkFpqy4gPJJpP9G8Q9kQE0W3sw", element, {
      theme: "clean",
      //callback: Recaptcha.focus_response_field,
      });
    }