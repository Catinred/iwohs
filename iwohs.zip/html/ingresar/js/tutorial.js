$(function() {
//Oculto las etiquetas de error
  $('.error').hide();
 //indico los campos que son obligatorios cambiando el color de su fondo al seleccionarlos
  $('input.text-input').css({backgroundColor:"#FFFFFF"});
  $('input.text-input').focus(function(){
    $(this).css({backgroundColor:"#CCC"});
  });
  $('input.text-input').blur(function(){
    $(this).css({backgroundColor:"#FFFFFF"});
  });

  $(".button").click(function() {
		// validate and process form
		// first hide any error messages
    $('.error').hide();
	  
	var nombre = $("input#nombre").val();
		if (nombre == "") {
      $("label#nombre_error").show();
      $("input#nombre").focus();
      return false;
    }		
	  var email = $("input#email").val();
		if (email == "") {
      $("label#email_error").show();
      $("input#email").focus();
      return false;
    }

	var password = $("input#password1").val();
		if (password == "") {
      $("label#password1_error").show();
      $("input#password1").focus();
      return false;
    }
    	var password2 = $("input#password2").val();
		if ((password2 == "")  || (password2 != password)) {
      $("label#password2_error").show();
      $("input#password2").focus();
      return false;
    }

	var tipoUsuario = 1;
	/*var tipoUsuario;
		if ($("input#tipoUsuario1").checked) {tipoUsuario = 1;} else {
			if ($("input#tipoUsuario2").checked) {tipoUsuario = 2;} else {
				$("label#tipoUsuario_error").show();
				return false;
	}}    	*/ 	
				
	if ($("input#avisoLegal").checked==0)  {
		$("label#avisoLegal_error").show();
		$("input#avisoLegal").focus();
		return false;
	}
    
		
	var dataString =  'nombre=' + nombre + '&email='+ email + '&password=' + password + '&tipoUsuario=' + tipoUsuario;
		//alert (dataString);return false;
		
$.ajax({
      type: "POST",
      url: "html/registro/bin/process.php",
      data: dataString,
      success: function() {
        $('#register_form').html("<div id='messageRegister' style='position:relative; left:20px;'></div>");
        $('#messageRegister').html("<h2>Ya est�s registrado!</h2>")
        .append("<p>Ya puedes comenzar a utilizar ISOWIN ONE.</p>")
        .hide()
        .fadeIn(1000, function() {
          $('#messageRegister').append("<img id='checkmark' src='html/registro/img/check.png' />");
        });
	var is_chrome= navigator.userAgent.toLowerCase().indexOf('chrome/') > -1;
	if (is_chrome) {setTimeout('window.location.href="ohs/gestion.html"', 2000);}
	else {setTimeout('window.location.href="chrome.html"', 2000);};
      }
     });
    return false;
	});
});

runOnLoad(function(){
  $("input#nombre").select().focus();
});
