//Pestañas JQuery

//<![CDATA[
$(document).ready(function(){
  var alltabs = $('div.tab');
  var tabs = $('#tabs');
  alltabs.first().show();
  tabs.find('li:first').addClass('on');
  tabs.find('a').live('click', function() {
    alltabs.hide()
    tabs.find('li').removeClass('on')
    $(this).parent().toggleClass('on')
    var tabref = $(this).attr('rel')
    $(tabref).fadeIn(500)
    this.blur()
    return false;	
	
  })
})
//]]>
