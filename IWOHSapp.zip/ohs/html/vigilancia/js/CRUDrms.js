//VIGILANCIA DE LA SALUD (80, 81 y 82)

	var idseleccionado80;
	var nuevaspersonas; //Listado de personas para COMBOBOX
	var intEstado80;
	var INTcolor80; //Color del semaforo en verde
				
//TABLAS RMS_____________________________________________________________________________________________________________

function mostrarRMs(intEst80) {
	if (intEstado80!=intEst80) {
		intEstado80=intEst80; 
		Vb80();};
	sacarPersonas (); 
	sacarRMs(intEstado80); sacarRMpendientes(); sacarRMprox ();
	setTimeout('listRMs(); listRMpendientes(); listRMprox();',500);
	}
	
//TABLA RMS_____________________________________________________________________________________________________________
function listRMs() {
		$(document).ready(			
			function () {
				$('#dynamic80').html( '<table cellpadding="0" cellspacing="0" border="0" class="display" id="example80"></table>' );
				$('#example80').dataTable( {
					"aaData": aDataSet80,
						
					"aoColumns": [
						{ "sTitle": "Id RM", "bSearchable": false, "bVisible": false },
						{ "sTitle": "Id Persona", "bSearchable": false, "bVisible": false },
						{ "sTitle": "Trabajador" },
						{ "sTitle": "Día" },
						{ "sTitle": "Hora"  },
						{ "sTitle": "Lugar"},
						{ "sTitle": "Estado" },
						{ "sTitle": "Resultado" },
						{ "sTitle": "Certificado" },
						{ "sTitle": "FSname", "bSearchable": false, "bVisible": false },
						{ "sTitle": "FSlink", "bSearchable": false, "bVisible": false },
						{ "sTitle": "Observaciones", "bSearchable": false, "bVisible": false}
						],
					
					"sScrollY": "550px",
					"bPaginate": false,
					"bScrollCollapse": true,
						
					"sDom": 'lfrtip<"clear spacer">T',
					/*"sDom": 'T<"clear">lfrtip<"clear spacer">T',*/ //Muestra los botones de copy,print...
					"oTableTools": {
						"sRowSelect": "single","aButtons": ["select"], //Solo me muestra el boton select para poder seleccionar las filas.
							
					"aoColumnDefs": [ {
						"sClass": "center",
						"aTargets": [ -1, -2 ]
						} ]
						
				}});
				
			//Cargo el COMBOBOX de personas del formulario RMs------------
			//sacarPersonas ();
			setTimeout('$("#combormpersona").html(nuevaspersonas);',200);
			//--------------------------------------------------	

		});

	//Cargo la información en el formulario	

		$(document).ready( function() {
    			$('#example80 tbody td').click( function () {
        		var aPos80 = oTable80.fnGetPosition( this );
        		var aData80 = oTable80.fnGetData( aPos80[0] );
				
				idseleccionado80 =  aData80[0];
				document.getElementById("combormpersona").value = aData80[1];
				//El 2 es la conbinación de apellidos y nombre para presentar en la tabla
				document.getElementById("txtrmfch").value = aData80[3];
				document.getElementById("txtrmhora").value = aData80[4];
				document.getElementById("txtrmlugar").value = aData80[5];
				document.getElementById("combormestado").value = aData80[6];
				document.getElementById("combormresultado").value = aData80[7];
				document.getElementById("txtrmobs").value = aData80[11];

				//File System-----------------------------------------------------------
					if (aData80[10]) {document.getElementById("FSRM").innerHTML = "<a class='doc' href='"+aData80[10]+"' target='_blank'>"+aData80[9]+"</a> <img src='img/miniboton.jpg' style='vertical-align:middle' onclick='deleteFSRM();' />"; 
							nombreFS=aData80[9]; rutaFS=aData80[10]}
					else {document.getElementById("FSRM").innerHTML = "<input type='file' id='myRM' />";};
				//----------------------------------------------------------------------

				VnV86(1);
				VnVErm (1);//No ver botones update y delete

    			});

			oTable80= $('#example80').dataTable();
			
		});
		
	}
	
//DATOS RMS_________________________________________________

function sacarRMs (intEstado80){
	var db;
        db = openDatabase("DBIWOHS", "0.1", "Database Isowin OHS", 500 * 1024 * 1024);	
		//alert ("Estoy dentro");						
	var estado80="WHERE estado!='Realizado' AND estado!='Anulado' AND estado!='Finalizado'";
	if (intEstado80==1) {estado80="WHERE estado='Realizado' OR estado='Anulado' ";};
	if (intEstado80==2) {estado80="WHERE estado='Finalizado' ";};

	if(db){
		db.transaction( function(tx) {
			tx.executeSql("SELECT * FROM rms LEFT JOIN personas ON rms.idpersona=personas.idpersona " + estado80, [],
				function(tx, result){
					aDataSet80 = [];
					for(var i=0; i < result.rows.length; i++) {	

						var linknull = "";//File System
						if (result.rows.item(i)['fsname']) {linknull = result.rows.item(i)['fsname'];};

						aDataSet80.push([result.rows.item(i)['idrm'],
								result.rows.item(i)['idpersona'],
								result.rows.item(i)['nombre'] + " " + result.rows.item(i)['apellidos'],
								result.rows.item(i)['dia'],
								result.rows.item(i)['hora'],
								result.rows.item(i)['lugar'],
								result.rows.item(i)['estado'],
								result.rows.item(i)['resultado'],
								"<a href='"+result.rows.item(i)['fslink']+"' target='_blank'>"+linknull+"</a>",
								result.rows.item(i)['fsname'],
								result.rows.item(i)['fslink'],
								result.rows.item(i)['obs']
								]);
					};			
				});
		});	
	};
}
	

//TABLA RMS PROXIMOS_______________________________________________________________________________________________
function listRMprox() {
		$(document).ready(			
			function () {
				$('#dynamic81').html( '<table cellpadding="0" cellspacing="0" border="0" class="display" id="example81"></table>' );
				$('#example81').dataTable( {
					"aaData": aDataSet81,
						
					"aoColumns": [
						{ "sTitle": "Trabajador" },
						{ "sTitle": "Estado" }
						],
					
					"sScrollY": "250px",
					"bPaginate": false,
					"bScrollCollapse": true,
					"bFilter": false
						
					//"sDom": 'lfrtip<"clear spacer">T',
					/*"sDom": 'T<"clear">lfrtip<"clear spacer">T',*/ //Muestra los botones de copy,print...
					
					});
				});
	}

//TABLA RMS PENDIENTES_______________________________________________________________________________________________
function listRMpendientes() {
		$(document).ready(			
			function () {
				$('#dynamic82').html( '<table cellpadding="0" cellspacing="0" border="0" class="display" id="example82"></table>' );
				$('#example82').dataTable( {
					"aaData": aDataSet82,
						
					"aoColumns": [
						{ "sTitle": "Trabajador" },
						{ "sTitle": "Estado" }
						],
					
					"sScrollY": "250px",
					"bPaginate": false,
					"bScrollCollapse": true,
					"bFilter": false
						
					//"sDom": 'lfrtip<"clear spacer">T',
					/*"sDom": 'T<"clear">lfrtip<"clear spacer">T',*/ //Muestra los botones de copy,print...
					
				});

				});
		
	}
	
//DATOS RMS PROXIMOS Y OBSOLETOS_________________________________________________

function sacarRMprox (){
	var db;
	var apelynom = "Garcia Juste, Manuel";
        db = openDatabase("DBIWOHS", "0.1", "Database Isowin OHS", 500 * 1024 * 1024);	
		//alert ("Estoy dentro");					
	if(db){
		db.transaction( function(tx) {
			tx.executeSql("SELECT * FROM rms LEFT JOIN personas ON rms.idpersona=personas.idpersona WHERE rms.estado!='Finalizado'", [],//
				function(tx, result){
					aDataSet81 = [];
					for(var i=0; i < result.rows.length; i++) {
						var fechacaduca = new Date(changeFch(result.rows.item(i)['dia'])); //Paso la fecha a formato DATE
						fechacaduca.setDate(fechacaduca.getDate() + 365); //Actualizo la fecha sumandole un año
						var diasqfal = (fechacaduca - new Date())/(1000*60*60*24); //Dias que faltan para que caduque
						
						var apelynom = result.rows.item(i)['apellidos'] + ", " + result.rows.item(i)['nombre'];
						var estado = result.rows.item(i)['estado'];

					//LOS RM QUE CADUCAN EN BREVE	
						if (0<diasqfal && diasqfal<60){aDataSet81.push([apelynom,"Caduca en " + parseInt(diasqfal) +" días"]);};
					//LOS RM QUE YA ESTÁN CADUCADOS
						if (diasqfal<1){aDataSet82.push([apelynom,"Caducado"]);};
							
						//alert(i+" el "+result.rows.item(i)['dia']+">>"+diasqfal);
					};			
				});
		});	
	};
}

//DATOS RMS PENDIENTES

function sacarRMpendientes (){
	var db;
        db = openDatabase("DBIWOHS", "0.1", "Database Isowin OHS", 500 * 1024 * 1024);	
		//alert ("Estoy dentro");					
	if(db){
		db.transaction( function(tx) {
			tx.executeSql("SELECT * FROM personas LEFT JOIN rms ON personas.idpersona=rms.idpersona WHERE idrm is null", [],//
				function(tx, result){
					aDataSet82 = [];
					for(var i=0; i < result.rows.length; i++) {
						
						var apelynom = result.rows.item(i)['apellidos'] + ", " + result.rows.item(i)['nombre'];
							
					//LAS PERSONAS QUE NO TIENEN NINGÚN RM
						aDataSet82.push([apelynom,"Pendiente"]);
						
					};			
				});
		});	
	};
}


//=========================================================================================================			
//=========================================================================================================		
//=========================================================================================================					
/*CREAR NUEVO RECONOCIMIENTO MÉDICO*/
	function addRM(idpersona, dia, hora, lugar, estado, resultado, obs) {
		var db;
		FSError = false; nombreFS=null; rutaFS=null;//FileSystem 
		addFile("myRM");//FileSystem
		db = openDatabase("DBIWOHS", "0.1", "Database Isowin OHS", 500 * 1024 * 1024);
		if(db){db.transaction( function(tx) {

			//Lo primero, actualizo todos los reconocimientos médicos para este idpersona al estado de Finalizado.
			tx.executeSql("UPDATE rms SET estado=? WHERE idpersona=?", ["Finalizado", idpersona]);
			//Incluyo el nuevo reconocimiento médico
			tx.executeSql("INSERT INTO rms (idpersona, dia, hora, lugar, estado, resultado, obs) VALUES(?,?,?,?,?,?,?)", [idpersona, dia, hora, lugar, estado, resultado, obs]);
			//CEX incluyo los RMs en el calendario
			tx.executeSql("SELECT * FROM rms LEFT JOIN personas ON rms.idpersona=personas.idpersona ORDER BY rms.idpersona DESC", [], function(tx, result){
					idseleccionado80 = result.rows.item(0)["idrm"];
					CEXaddCita("Reconocimiento médico", dia, dia,
						"Cita del reconocimiento médico de " +result.rows.item(0)["nombre"] + " " + 
						result.rows.item(0)["apellidos"]+ " a las " + hora + " en " + lugar + ".", "RM"+idseleccionado80);
				});
		if (!FSError) {apprise('El Reconocimiento médico ha sido registrado');};
		});};
		setTimeout('updateFSRMs()',300);
		setTimeout('mostrarRMs(intEstado80);',500);
	}

/*ACTUALIZAR RECONOCIMIENTO MÉDICO*/
	function updateRM (idpersona, dia, hora, lugar, estado, resultado, obs) {
	var db;
		FSError = false; nombreFS=null; rutaFS=null;//FileSystem 
		addFile("myRM");//FileSystem
        db = openDatabase("DBIWOHS", "0.1", "Database Isowin OHS", 500 * 1024 * 1024);
		if(db){ db.transaction( function(tx) {
			tx.executeSql("UPDATE rms SET idpersona=?, dia=?, hora=?, lugar=?, estado=?, resultado=?, obs=? WHERE idrm=?", [idpersona, dia, hora, lugar, estado, resultado, obs, idseleccionado80]);
			//Actualizo el RM en el calendario
			tx.executeSql("SELECT * FROM rms LEFT JOIN personas ON rms.idpersona=personas.idpersona WHERE idrm=?", [idseleccionado80], function(tx, result){
					CEXupdateCita("Reconocimiento médico", dia, dia,
						"Cita del reconocimiento médico de " + result.rows.item(0)["nombre"] + " " + 
						result.rows.item(0)["apellidos"]+ " a las " + hora + " en " + lugar + ".", "RM"+idseleccionado80);
			});	
			if (!FSError) {apprise('El reconocimiento médico ha sido modificado');}; 
		});};
		setTimeout('updateFSRMs()',300);
		setTimeout('mostrarRMs(intEstado80);',500);
			
	}

/*ACTUALIZAR ARCHIVOS*/
function updateFSRMs() {
var db;
db = openDatabase("DBIWOHS", "0.1", "Database Isowin OHS", 500 * 1024 * 1024);
		if(db){	
		db.transaction( function(tx) {
			if (nombreFS!=null) {tx.executeSql("UPDATE rms SET fsname=?, fslink=? WHERE idrm=?", [nombreFS, rutaFS, idseleccionado80]);
								document.getElementById("FSRM").innerHTML = "<a class='doc' href='"+rutaFS+"' target='_blank'>"+nombreFS+"</a> <img src='img/miniboton.jpg' style='vertical-align:middle' onclick='deleteFSRM();' />";};
			});
		};
}
	
/*BORRAR RECONOCIMIENTO MÉDICO*/
	function removeRM() {
		if(idseleccionado80) { 
		apprise('¿Eliminar reconocimiento médico?', {'verify': true}, function(r) {
			if(r) { 
				var db;
				deleteFile();//FileSystem
				db = openDatabase("DBIWOHS", "0.1", "Database Isowin OHS", 500 * 1024 * 1024);
				if(db){	
					db.transaction(function(tx) {
					tx.executeSql("DELETE FROM rms WHERE idrm=?",[idseleccionado80]);
					//Borro la cita en el calendario
					CEXdeleteCita("RM"+idseleccionado80);								
					apprise('Reconocimiento médico borrado'); //alert("Persona borrada: "+ idseleccionado15);
					});
				};
				setTimeout('mostrarRMs(intEstado80)',500);
			}
		});
		};
	}

	/*BORRAR ARCHIVOS*/
	function deleteFSRM() {
		deleteLinkFile('rms');
		document.getElementById("FSRM").innerHTML = "<input type='file' id='myRM' />";
		setTimeout('mostrarRMs(intEstado80);',500);
	}
	

//=========================================================================================================
//=========================================================================================================
//=========================================================================================================
//=========================================================================================================					
//=========================================================================================================						
//=========================================================================================================					
/*COMBOBOX DE PERSONAS*/

function sacarPersonas (){
	var db;
        db = openDatabase("DBIWOHS", "0.1", "Database Isowin OHS", 500 * 1024 * 1024);	
		//alert ("Estoy dentro");					
	if(db){
		db.transaction( function(tx) {
			tx.executeSql("SELECT * FROM personas", [],
				function(tx, result){
					nuevaspersonas = "<option selected></option>";
					for(var i=0; i < result.rows.length; i++) {	
						nuevaspersonas = nuevaspersonas + "<option value='" +result.rows.item(i)['idpersona']+"'>"+result.rows.item(i)['apellidos'] + ", " + result.rows.item(i)['nombre'] +"</option> ";
					}			
				});
		});	
	
	};
}
//=========================================================================================================	

//VER BOTON SEMAFORO_______________________________________________________________________

//Funcion de inicialización de la pestaña, ocultando el botón rojo.
function VbInit80() {
	document.getElementById('botonverde80').style.display = 'inherit';
	document.getElementById('botonrojo80').style.display = 'none';
	document.getElementById('botonamar80').style.display = 'none';
	INTcolor80 = 1;
	}
	
//valor 1 se pone rojo, valor 0 se pone verde.	
function Vb80() {
	if (INTcolor80==1) {$("#botonverde80").toggle(200); $("#botonamar80").toggle(200);};
	if (INTcolor80==2) {$("#botonamar80").toggle(200); $("#botonrojo80").toggle(200);};
	if (INTcolor80==3) {$("#botonrojo80").toggle(200); $("#botonverde80").toggle(200); INTcolor80=0;};
	INTcolor80 = INTcolor80 + 1;
	}

//=========================================================================================================
/* VER NO VER*/
var verNRM = 0;

function VnV86 (Vnrm) { 
	if (verNRM!=Vnrm) {$("#nuevorm").toggle(200); verNRM=Vnrm; $("#combormpersona").focus();};
	}

/* VER NO VER EDIT (Update+Delete)*/
var verERM=0;
function VnVErm (Verm) {if (verERM!=Verm) {$("#editrm").toggle(200); verERM=Verm;};}

//__________________________________________________________________________________________
