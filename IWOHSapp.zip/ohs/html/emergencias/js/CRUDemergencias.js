//EMERGENCIAS (57)

	var idseleccionado57;
	var idseleccionado57b;
	var nuevaspersonas; //Listado de personas para COMBOBOX	
	sacarPersonas(); //Cargo el combobox
				
//TABLA EMERGENCIAS_________________________________________________________________________________________________________

function mostrarEmergencias() {
	sacarEmergencias ();
	setTimeout('listEmergencias()', 500);
	}

function listEmergencias() {
			$(document).ready(			
			function () {
				$('#dynamic57').html( '<table cellpadding="0" cellspacing="0" border="0" class="display" id="example57"></table>' );
				$('#example57').dataTable( {
					"aaData": aDataSet57,
						
					"aoColumns": [
						{ "sTitle": "Id"/*, "bSearchable": false, "bVisible": false*/ },
						{ "sTitle": "Emergencia" },
						{ "sTitle": "Resp. Emergencia", "bSearchable": false, "bVisible": false },
						{ "sTitle": "Descripci�n", "bSearchable": false, "bVisible": false },
						{ "sTitle": "Causas", "bSearchable": false, "bVisible": false },
						{ "sTitle": "Gravedad" }
						],
						
				"sScrollY": "500px",
        			"bPaginate": false,
        			"bScrollCollapse": true,
						
					"sDom": 'lfrtip<"clear spacer">T',
					/*"sDom": 'T<"clear">lfrtip<"clear spacer">T',*/ //Muestra los botones de copy,print...
					"oTableTools": {
						"sRowSelect": "single","aButtons": ["select"], //Solo me muestra el boton select para poder seleccionar las filas.
							
					"aoColumnDefs": [ {
						"sClass": "center",
						"aTargets": [ -1, -2 ]
						} ]
						
						}
					});
					
				//Cargo el COMBOBOX de responsables en varios formularios------------
				setTimeout('$("#comborespemerg").html(nuevosresponsables);$("#comboatresp").html(nuevosresponsables); $("#comboauacpresp2").html(nuevosresponsables);',200);
				//Cargo el COMBOBOX de personas en varios formularios------------
				setTimeout('$("#comboatpersona").html(nuevaspersonas);',200);
				//--------------------------------------------------
				
				});
	//Cargar datos de proveedor para editar en formulario	
			$(document).ready(
				function() {
    			$('#example57 tbody td').click( function () {
        		var aPos57 = oTable57.fnGetPosition( this );
        		var aData57 = oTable57.fnGetData( aPos57[0] );
				
				idseleccionado57 =  aData57[0];
				document.getElementById("txtemergencia").value = aData57[1];
				document.getElementById("comborespemerg").value = aData57[2];
				document.getElementById("txtemdescripcion").value = aData57[3];
				document.getElementById("txtemcausas").value = aData57[4];
				document.getElementById("comboemgravedad").value = aData57[5];
				document.getElementById("txtemrespuesta").value = aData57[6];
				document.getElementById("txtemobs").value = aData57[9];

				//File System-----------------------------------------------------------
					if (aData57[8]) {document.getElementById("FSEMER").innerHTML = "<a class='doc' href='"+aData57[8]+"' target='_blank'>"+aData57[7]+"</a> <img src='img/miniboton.jpg' style='vertical-align:middle' onclick='deleteFSEMER();' />"; 
							nombreFS=aData57[7]; rutaFS=aData57[8]}
					else {document.getElementById("FSEMER").innerHTML = "<input type='file' id='myEMER' />";};
				//----------------------------------------------------------------------

				VnVEemer (1);//No ver botones update y delete
				
			DatosBDATs(idseleccionado57);
			setTimeout('listATs();', 500);
			
    			});
     
   				 /* Init DataTables */
   				 oTable57 = $('#example57').dataTable();
				});
		
	}	
	
function sacarEmergencias (){
	var db;
        db = openDatabase("DBIWOHS", "0.1", "Database Isowin OHS", 500 * 1024 * 1024);	
	if(db){
		db.transaction( function(tx) {
			tx.executeSql("SELECT * FROM emergencias", [], function(tx, result){
					aDataSet57 = [];
					for(var i=0; i < result.rows.length; i++) {	

						aDataSet57.push([result.rows.item(i)['idemergencia'],
								result.rows.item(i)['emergencia'],
								result.rows.item(i)['idrespemerg'],
								result.rows.item(i)['descripcion'],
								result.rows.item(i)['causas'],
								result.rows.item(i)['gravedad'],
								result.rows.item(i)['respuesta'],
								result.rows.item(i)['fsname'],
								result.rows.item(i)['fslink'],
								result.rows.item(i)['obs']
								]);
					}			
				 
			});
		});
		
		
	};
}

//=========================================================================================================					
/*NUEVA EMERGENCIA*/
	function addEmergencia(emergencia, idrespemerg, descripcion, causas, gravedad, respuesta, obs) {
		var db;
		FSError = false; nombreFS=null; rutaFS=null;//FileSystem 
		addFile("myEMER");//FileSystem
		db = openDatabase("DBIWOHS", "0.1", "Database Isowin OHS", 500 * 1024 * 1024);
		if(db){	
			db.transaction( function(tx) {
			tx.executeSql("INSERT INTO emergencias (emergencia, idrespemerg, descripcion, causas, gravedad, respuesta, obs) VALUES(?,?,?,?,?,?,?)", [emergencia, idrespemerg, descripcion, causas, gravedad, respuesta, obs]);
			tx.executeSql("SELECT * FROM emergencias ORDER BY idemergencia DESC", [], function(tx, result){
					idseleccionado57 = result.rows.item(0)["idemergencia"];
					if (!FSError) {apprise('La emergencia ha sido guardada');};
				});
			});
		};
		setTimeout('updateFSEmergencia()',300);
		setTimeout('mostrarEmergencias()',500);
	}
	
/*ACTUALIZAR EMERGENCIA*/
		function updateEmergencia(emergencia, idrespemerg, descripcion, causas, gravedad, respuesta, obs) {
		var db;
		FSError = false; nombreFS=null; rutaFS=null;//FileSystem 
		addFile("myEMER");//FileSystem
		db = openDatabase("DBIWOHS", "0.1", "Database Isowin OHS", 500 * 1024 * 1024);
		if(db){	
		db.transaction( function(tx) {
			tx.executeSql("UPDATE emergencias SET emergencia=?, idrespemerg=?, descripcion=?, causas=?, gravedad=?, respuesta=?, obs=?  WHERE idemergencia=?", [emergencia, idrespemerg, descripcion, causas, gravedad, respuesta, obs, idseleccionado57]);
			if (!FSError) {apprise('La emergencia ha sido actualizada');};
			});
		};
		setTimeout('updateFSEmergencia()',300);
		setTimeout('mostrarEmergencias()',500);
	}	

/*ACTUALIZAR ARCHIVOS*/
function updateFSEmergencia() {
var db;
db = openDatabase("DBIWOHS", "0.1", "Database Isowin OHS", 500 * 1024 * 1024);
		if(db){	
		db.transaction( function(tx) {
			if (nombreFS!=null) {tx.executeSql("UPDATE emergencias SET fsname=?, fslink=? WHERE idemergencia=?", [nombreFS, rutaFS, idseleccionado57]);
								document.getElementById("FSEMER").innerHTML = "<a class='doc' href='"+rutaFS+"' target='_blank'>"+nombreFS+"</a> <img src='img/miniboton.jpg' style='vertical-align:middle' onclick='deleteFSEMER();' />";};
			});
		};
}				

/*BORRAR EMERGENCIA*/
	function removeEmergencia() {
		apprise('�Eliminar la emergencia?', {'verify': true}, function(r) {
			if(r) { 
				var db;
				deleteFile();//FileSystem
				db = openDatabase("DBIWOHS", "0.1", "Database Isowin OHS", 500 * 1024 * 1024);
				if(db){	
					db.transaction(function(tx) {
					tx.executeSql("DELETE FROM emergencias WHERE idemergencia=?",[idseleccionado57]); 	//Borro al Padre
					tx.executeSql("DELETE FROM ats WHERE idemergencia=?",[idseleccionado57]); 	// Borro a los hijos							//Borro al espíritu santo
					if (!FSError) {apprise('La emergencia ha sido borrada');};
					});
				};
			setTimeout('mostrarEmergencias()',500);
			};
		});
	}

	/*BORRAR ARCHIVOS*/
	function deleteFSEMER() {
		deleteLinkFile('emergencias');
		document.getElementById("FSEMER").innerHTML = "<input type='file' id='myEMER' />";
		setTimeout('mostrarEmergencias();',500);
	}

//============================================================================================================================================================================			

//TABLA ACCIDENTES de EMERGENCIA_________________________________________________________________________________________________________

function mostrarATs() {
	DatosBDATs(idseleccionado57);
	setTimeout('listATs()', 700);
	}
	
	function listATs() {
			$(document).ready(			
			function () {
				$('#dynamic57b').html( '<table cellpadding="0" cellspacing="0" border="0" class="display" id="example57b"></table>' );
				$('#example57b').dataTable( {
					"aaData": aDataSet57b,
						
					"aoColumns": [
						{ "sTitle": "Id"/*, "bSearchable": false, "bVisible": false*/ },
						{ "sTitle": "Id Persona", "bSearchable": false, "bVisible": false },
						{ "sTitle": "Accidente" },
						{ "sTitle": "Tipo" },
						{ "sTitle": "Persona accidentada" },
						{ "sTitle": "Origen", "bSearchable": false, "bVisible": false },
						{ "sTitle": "F. Creacion", "bSearchable": false, "bVisible": false},
						{ "sTitle": "Fecha" }
						],
						
					"sScrollY": "500px",
        			"bPaginate": false,
        			"bScrollCollapse": true,
						
					"sDom": 'lfrtip<"clear spacer">T',
					/*"sDom": 'T<"clear">lfrtip<"clear spacer">T',*/ //Muestra los botones de copy,print...
					"oTableTools": {
						"sRowSelect": "single","aButtons": ["select"], //Solo me muestra el boton select para poder seleccionar las filas.
							
					"aoColumnDefs": [ {
						"sClass": "center",
						"aTargets": [ -1, -2 ]
						} ]
						
				}});
				
				});
	//Cargar datos de proveedor para editar en formulario	
			$(document).ready(
				function() {
    			$('#example57b tbody td').click( function () {
        		var aPos57b = oTable57b.fnGetPosition( this );
        		var aData57b = oTable57b.fnGetData( aPos57b[0] );

					//idat, idemergencia, idpersona, at, tipo, fchbaja, fchalta, dia, hora, lugar, 
					//formacontacto, partecuerpo, descriplesion, gravedad, idresp, descripcion, 
					//operacion, relato, causas, familia, correcion, linkdocs, obs

				idseleccionado57b =  aData57b[0];
				document.getElementById("comboatpersona").value = aData57b[1];
				document.getElementById("txtat").value = aData57b[2];
				document.getElementById("comboattipo").value = aData57b[3];
				document.getElementById("txtatfchbaja").value = aData57b[5];
				document.getElementById("txtatfchalta").value = aData57b[6];
				document.getElementById("txtatdia").value = aData57b[7];
				document.getElementById("txtathora").value = aData57b[8];
				document.getElementById("txtatlugar").value = aData57b[9];
				document.getElementById("txtatformacontacto").value = aData57b[10];
				document.getElementById("txtatpartecuerpo").value = aData57b[11];
				document.getElementById("txtatdescriplesion").value = aData57b[12];
				document.getElementById("comboatgravedad").value = aData57b[13];
				document.getElementById("comboatresp").value = aData57b[14];
				document.getElementById("txtatdescripcion").value = aData57b[15];
				document.getElementById("txtatoperacion").value = aData57b[16];
				document.getElementById("txtatrelato").value = aData57b[17];
				document.getElementById("txtatcausas").value = aData57b[18];
				document.getElementById("comboatfamilia").value = aData57b[19];
				document.getElementById("txtatcorrecion").value = aData57b[20];
				document.getElementById("txtatobs").value = aData57b[25];
				document.getElementById("etiatdniynss").innerHTML ="DNI: " + aData57b[26] + " N.SS: " + aData57b[27]+ " Fch. Nacimiento: " + aData57b[28];
         
				VnVEat (1);//No ver botones update y delete

				//File System-----------------------------------------------------------
					if (aData57b[22]) {document.getElementById("FSAT").innerHTML = "<a class='doc' href='"+aData57b[22]+"' target='_blank'>"+aData57b[21]+"</a> <img src='img/miniboton.jpg' style='vertical-align:middle' onclick='deleteFSAT();' />"; 
							nombreFS=aData57b[21]; rutaFS=aData57b[22]}
					else {document.getElementById("FSAT").innerHTML = "<input type='file' id='myAT' />";};
					if (aData57b[24]) {document.getElementById("FSINVEST").innerHTML = "<a class='doc' href='"+aData57b[24]+"' target='_blank'>"+aData57b[23]+"</a> <img src='img/miniboton.jpg' style='vertical-align:middle' onclick='deleteFSINVEST();' />"; 
							nombreFS=aData57b[23]; rutaFS=aData57b[24]}
					else {document.getElementById("FSINVEST").innerHTML = "<input type='file' id='myINVEST' />";};
				//----------------------------------------------------------------------

    			});
     
   				 /* Init DataTables */
   				 oTable57b = $('#example57b').dataTable();
				});
		
	}	

//DATOS AT FILTRADOS POR EMERGENCIA______________________________________________________________________
		
function DatosBDATs(idseleccionado57) {
	var db;
        db = openDatabase("DBIWOHS", "0.1", "Database Isowin OHS", 500 * 1024 * 1024);
		if(db){	
		db.transaction( function(tx) {
			tx.executeSql("SELECT * FROM ats LEFT JOIN personas ON ats.idpersona=personas.idpersona WHERE idemergencia=?", [idseleccionado57],
				function(tx, result){
					aDataSet57b = [];
					//idat, idemergencia, idpersona, at, tipo, fchbaja, fchalta, dia, hora, lugar, 
					//formacontacto, partecuerpo, descriplesion, gravedad, idresp, descripcion, 
					//operacion, relato, causas, familia, correcion, linkdocs, obs
					for(var i=0; i < result.rows.length; i++) {

					var apellidosynombre = result.rows.item(i)['apellidos'] + ", " + result.rows.item(i)['nombre'];

						aDataSet57b.push([result.rows.item(i)['idat'],			
								result.rows.item(i)['idpersona'],
								result.rows.item(i)['at'],
								result.rows.item(i)['tipo'],
								apellidosynombre,
								result.rows.item(i)['fchbaja'],
								result.rows.item(i)['fchalta'],
								result.rows.item(i)['dia'],
								result.rows.item(i)['hora'],
								result.rows.item(i)['lugar'],
								result.rows.item(i)['formacontacto'],
								result.rows.item(i)['partecuerpo'],
								result.rows.item(i)['descriplesion'],
								result.rows.item(i)['gravedad'],
								result.rows.item(i)['idresp'],
								result.rows.item(i)['descripcion'],
								result.rows.item(i)['operacion'],
								result.rows.item(i)['relato'],
								result.rows.item(i)['causas'],
								result.rows.item(i)['familia'],
								result.rows.item(i)['correcion'],
								result.rows.item(i)['fsname'],
								result.rows.item(i)['fslink'],
								result.rows.item(i)['fsname2'],
								result.rows.item(i)['fslink2'],
								result.rows.item(i)['obs'],
								result.rows.item(i)['dni'],
								result.rows.item(i)['nss'],
								result.rows.item(i)['fchnac']
								]);
												
				}		
   				 /* Init DataTables */
   				 oTable57b = $('#example57b').dataTable();				
				 
				});
		
		});
		
	}}
	
//=========================================================================================================					
/*NUEV0 AT*/
var nombreFS2=null; var rutaFS2=null;

	function addAT(idpersona, at, tipo, fchbaja, fchalta, dia, hora, lugar, formacontacto, partecuerpo, descriplesion, gravedad, idresp, descripcion, operacion, relato, causas, familia, correcion, obs) {
		var db;
		FSError = false; nombreFS=null; rutaFS=null; nombreFS2=null; rutaFS2=null;//FileSystem 
		addFile("myAT"); add2File("myINVEST", 2);//FileSystem
		db = openDatabase("DBIWOHS", "0.1", "Database Isowin OHS", 500 * 1024 * 1024);
		if(db){	
		  db.transaction( function(tx) {
			tx.executeSql("INSERT INTO ats (idemergencia, idpersona, at, tipo, fchbaja, fchalta, dia, hora, lugar, formacontacto, partecuerpo, descriplesion, gravedad, idresp, descripcion, operacion, relato, causas, familia, correcion, obs) VALUES(?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)", [
				idseleccionado57, idpersona, at, tipo, fchbaja, fchalta, dia, hora, lugar, formacontacto, partecuerpo, descriplesion, gravedad, idresp, descripcion, operacion, relato, causas, familia, correcion, obs]);
			tx.executeSql("SELECT * FROM ats ORDER BY idat DESC", [], function(tx, result){
				idseleccionado57b = result.rows.item(0)["idat"];
				if (!FSError) {apprise('El accidente de trabajo ha sido registrado');};
			});
		})};
		setTimeout('updateFSATs()',300);
		setTimeout('mostrarATs()',500);
	}
	
/*ACTUALIZAR AT*/
	function updateAT(idpersona, at, tipo, fchbaja, fchalta, dia, hora, lugar, formacontacto, partecuerpo, descriplesion, gravedad, idresp, descripcion, operacion, relato, causas, familia, correcion, obs) {
		var db;
		FSError = false; nombreFS=null; rutaFS=null; nombreFS2=null; rutaFS2=null;//FileSystem 
		addFile("myAT"); add2File("myINVEST", 2);//FileSystem
        db = openDatabase("DBIWOHS", "0.1", "Database Isowin OHS", 500 * 1024 * 1024);
		if(db){	
		  db.transaction( function(tx) {
			tx.executeSql("UPDATE ats SET idemergencia=?, idpersona=?, at=?, tipo=?, fchbaja=?, fchalta=?, dia=?, hora=?, lugar=?, formacontacto=?, partecuerpo=?, descriplesion=?, gravedad=?, idresp=?, descripcion=?, operacion=?, relato=?, causas=?, familia=?, correcion=?, obs=? WHERE idat=? ", [
				idseleccionado57, idpersona, at, tipo, fchbaja, fchalta, dia, hora, lugar, formacontacto, partecuerpo, descriplesion, gravedad, idresp, descripcion, operacion, relato, causas, familia, correcion, obs, idseleccionado57b]);
			if (!FSError) {apprise('El Accidente ha sido actualizado');};
		})};
		setTimeout('updateFSATs()',300);
		setTimeout('mostrarATs()',500);
	}

/*ACTUALIZAR ARCHIVOS*/
function updateFSATs() {
var db;
db = openDatabase("DBIWOHS", "0.1", "Database Isowin OHS", 500 * 1024 * 1024);
		if(db){	
		db.transaction( function(tx) {
			if (nombreFS!=null) {tx.executeSql("UPDATE ats SET fsname=?, fslink=? WHERE idat=?", [nombreFS, rutaFS, idseleccionado57b]);};
			if (nombreFS2!=null) {tx.executeSql("UPDATE ats SET fsname2=?, fslink2=? WHERE idat=?", [nombreFS2, rutaFS2, idseleccionado57b]);};
			if (nombreFS!=null) {document.getElementById("FSAT").innerHTML = "<a class='doc' href='"+rutaFS+"' target='_blank'>"+nombreFS+"</a> <img src='img/miniboton.jpg' style='vertical-align:middle' onclick='deleteFSAT();' />";};
			if (nombreFS2!=null) {document.getElementById("FSINVEST").innerHTML = "<a class='doc' href='"+rutaFS2+"' target='_blank'>"+nombreFS2+"</a> <img src='img/miniboton.jpg' style='vertical-align:middle' onclick='deleteFSINVEST();' />";};
			});
		};
}				

/*BORRAR AT*/
	function removeAT() {
		apprise('�Eliminar el Accidente?', {'verify': true}, function(r) {
			if(r) { 
				var db;
				deleteFile(); delete2File(nombreFS2);;//FileSystem
				db = openDatabase("DBIWOHS", "0.1", "Database Isowin OHS", 500 * 1024 * 1024);
				if(db){	
					db.transaction(function(tx) {
					tx.executeSql("DELETE FROM ats WHERE idat=?",[idseleccionado57b]);
					if (!FSError) {apprise('El accidente ha sido borrado');};
					});
				};
			setTimeout('mostrarATs()',1000);	
			};
		});
	}
	
	/*BORRAR ARCHIVOS*/
	function deleteFSAT() {
		deleteLinkFile('ats');
		document.getElementById("FSAT").innerHTML = "<input type='file' id='myAT' />";
		setTimeout('mostrarATs();',500);
	}
	function deleteFSINVEST() {
		delete2LinkFile('ats', 2);
		document.getElementById("FSINVEST").innerHTML = "<input type='file' id='myINVEST' />";
		setTimeout('mostrarATs();',500);
	}

//=========================================================================================================					
/*NUEVA APC57*/
	function addACP57 (acp, codacp, tipo, fchalta, responsable, equipo, acciones, fchprevista) {
		var origen =  "El accidente: " +  idseleccionado57b + " de la emergencia: " +  idseleccionado57;
		var codtrz = "at"+ idseleccionado57b;
		addMiniACP(acp, codacp, tipo, origen, fchalta, responsable, equipo, acciones, fchprevista, codtrz);
	}
	
//=========================================================================================================
/* VER NO VER*/
var verNEM= 1; var verLEM= 1; var verNAT= 0; var verLAT= 0; var verNINV= 0; var verNAC2= 0;

function VnV57 (Vnem, Vlem, Vnat, Vlat, Vninv, Vnac2) { 
	if (verNEM!=Vnem) {$("#newemergencia").toggle(200); verNEM=Vnem; $("#txtemergencia").focus();};
	if (verLEM!=Vlem) {$("#listaemergencias").toggle(200); verLEM=Vlem;};
	if (verNAT!=Vnat) {$("#newat").toggle(200); verNAT=Vnat; $("#txtaunc").focus();};
	if (verLAT!=Vlat) {$("#listaats").toggle(200); verLAT=Vlat;};
	if (verNINV!=Vninv) {$("#newatinvest").toggle(200); verNINV=Vninv; $("#txtaunc").focus();};
	if (verNAC2!=Vnac2) {$("#newatacp").toggle(200); verNAC2=Vnac2; $("#txtatacp2").focus();};
}

/* VER NO VER EDIT (Update+Delete)*/
var verEEMER=0;var verEAT=0;var verESIM=0;
function VnVEemer (Veemer) {if (verEEMER!=Veemer) {$("#editemer").toggle(200); verEEMER=Veemer;};}
function VnVEat (Veat) {if (verEAT!=Veat) {$("#editat").toggle(200); verEAT=Veat;};}
function VnVEsim (Vesim) {if (verESIM!=Vesim) {$("#editsim").toggle(200); verESIM=Vesim;};}
//=========================================================================================================		
/*COMBOBOX DE RESPONSABLES*/

//nuevosresponsables est� definido en CRUDNCs.js
//sacarResponsables() est� definida en CRUDNCs.js

//=========================================================================================================					
/*COMBOBOX DE PERSONAS*/

function sacarPersonas (){
	var db;
        db = openDatabase("DBIWOHS", "0.1", "Database Isowin OHS", 500 * 1024 * 1024);	
		//alert ("Estoy dentro");					
	if(db){
		db.transaction( function(tx) {
			tx.executeSql("SELECT * FROM personas", [],
				function(tx, result){
					nuevaspersonas = "<option selected></option>";
					for(var i=0; i < result.rows.length; i++) {	
						nuevaspersonas = nuevaspersonas + "<option value='" +result.rows.item(i)['idpersona']+"'>"+result.rows.item(i)['apellidos'] + ", " + result.rows.item(i)['nombre'] +"</option> ";
					}			
				});
		});	
	
	};
}
//=========================================================================================================	