//SIMULACROS (22)

	var idseleccionado22;
	var intEstado22;
	var INTcolor22; //Color del semaforo en verde
				
				
//TABLA SIMULACROS_____________________________________________________________________________________________________________
function mostrarSimulacros(intEst22) {
	//alert("Inside");
	intEstado22=intEst22;
	sacarSimulacros (intEstado22);
	setTimeout('listSimulacros()',500);
	Vb22(intEst22);
	}


function listSimulacros() {
			$(document).ready(			
			function () {
				$('#dynamic22').html( '<table cellpadding="0" cellspacing="0" border="0" class="display" id="example22"></table>' );
				$('#example22').dataTable( {
					"aaData": aDataSet22,
						
					"aoColumns": [
						{ "sTitle": "Id Simulacro"/*, "bSearchable": false, "bVisible": false*/ },
						{ "sTitle": "Cod Simulacro", "bSearchable": false, "bVisible": false },
						{ "sTitle": "Simulacro" },
						{ "sTitle": "Descripci�n", "bSearchable": false, "bVisible": false },
						{ "sTitle": "Id Persona", "bSearchable": false, "bVisible": false },
						{ "sTitle": "Fecha" },
						{ "sTitle": "Estado" },
						{ "sTitle": "Resultado"}
						],
						
					"sScrollY": "430px",
        			"bPaginate": false,
        			"bScrollCollapse": true,
						
					"sDom": 'lfrtip<"clear spacer">T',
					/*"sDom": 'T<"clear">lfrtip<"clear spacer">T',*/ //Muestra los botones de copy,print...
					"oTableTools": {
						"sRowSelect": "single","aButtons": ["select"], //Solo me muestra el boton select para poder seleccionar las filas.
							
					"aoColumnDefs": [ {
						"sClass": "center",
						"aTargets": [ -1, -2 ]
						} ]
						
				}});

				//Cargo el COMBOBOX de responsables del formulario NCs y Simulacros------------
				sacarResponsables ();
				setTimeout('$("#combosimresp").html(nuevosresponsables);$("#comboacpresp3").html(nuevosresponsables);',200);
				//--------------------------------------------------
				
				});
	//Cargar datos de proveedor para editar en formulario	
			$(document).ready(
				function() {
    			$('#example22 tbody td').click( function () {
        		/* Get the position of the current data from the node */
        		var aPos22 = oTable22.fnGetPosition( this );
         
        		/* Get the data array for this row */
        		var aData22 = oTable22.fnGetData( aPos22[0] );
				/*alert("Ok "+aData[0]);*/
				
				idseleccionado22 =  aData22[0];
				document.getElementById("txtsimcod").value = aData22[1];
				document.getElementById("txtsim").value = aData22[2];
				document.getElementById("txtsimdesc").value = aData22[3];
				document.getElementById("combosimresp").value = aData22[4];
				document.getElementById("txtsimfch").value = aData22[5];
				document.getElementById("combosimestado").value = aData22[6];
				document.getElementById("txtsimresult").value = aData22[7];
				document.getElementById("txtsimpr").value = aData22[8];
				document.getElementById("txtsimobs").value = aData22[11];

				//File System-----------------------------------------------------------
					if (aData22[10]) {document.getElementById("FSSIM").innerHTML = "<a class='doc' href='"+aData22[10]+"' target='_blank'>"+aData22[9]+"</a> <img src='img/miniboton.jpg' style='vertical-align:middle' onclick='deleteFSSIM();' />"; 
							nombreFS=aData22[9]; rutaFS=aData22[10]}
					else {document.getElementById("FSSIM").innerHTML = "<input type='file' id='mySIM' />";};
				//----------------------------------------------------------------------
				
				
				VnV22 (1, 1, 0);
				VnVEsim (1);//No ver botones update y delete
         
    			});
     
   				 /* Init DataTables */
   				 oTable22 = $('#example22').dataTable();
				});
		
	}
	
//DATOS REQUISITOS LEGALES_________________________________________________

function sacarSimulacros (intEstado22){
	var db;
        db = openDatabase("DBIWOHS", "0.1", "Database Isowin OHS", 500 * 1024 * 1024);	
	
	var estado22;
	if (intEstado22==0) {estado22="!='Finalizado'";};	
	if (intEstado22==1) {estado22="='Finalizado'";};	
							
	if(db){
		db.transaction( function(tx) {
			//La trazabilidad igual a RL, identifica que es un requisito legal y no de cliente entre todos los requisitos
			tx.executeSql("SELECT * FROM simulacros WHERE estado" + estado22, [],
				function(tx, result){
					aDataSet22 = [];
					for(var i=0; i < result.rows.length; i++) {	
						aDataSet22.push([result.rows.item(i)['idsim'],
								result.rows.item(i)['codsim'],
								result.rows.item(i)['simulacro'],
								result.rows.item(i)['descripcion'],
								result.rows.item(i)['idpersona'],
								result.rows.item(i)['fchplan'],
								result.rows.item(i)['estado'],
								result.rows.item(i)['resultado'],
								result.rows.item(i)['procedimiento'],
								result.rows.item(i)['fsname'],
								result.rows.item(i)['fslink'],
								result.rows.item(i)['obs']
								]);
					};			
				});
		});	
	};
}

//=========================================================================================================					
/*NUEVO SIMULACRO*/
	function addSimulacro (sim, cod, fch, estado, desc, pr, resp, result, obs) {
		var db;
		FSError = false; nombreFS=null; rutaFS=null;//FileSystem 
		addFile("mySIM");//FileSystem
		db = openDatabase("DBIWOHS", "0.1", "Database Isowin OHS", 500 * 1024 * 1024);
		if(db){	
		  db.transaction( function(tx) {
			tx.executeSql("INSERT INTO simulacros (codsim, simulacro, descripcion, idpersona, fchplan, estado, resultado, procedimiento, obs) VALUES(?,?,?,?,?,?,?,?,?)", [cod, sim, desc, resp, fch, estado, result, pr, obs]);
			tx.executeSql("SELECT * FROM simulacros ORDER BY idsim DESC", [], function(tx, result){
				idseleccionado22 = result.rows.item(0)["idsim"];
				CEXaddCita("Simulacro " + idseleccionado22, fch, fch, sim, "SIM" + idseleccionado22);
				});
			apprise('El simulacro ha sido guardado'); //alert("Reclamación guardada: "+ codreclamacion);
		})};
		setTimeout('updateFSSimulacros()',300);
		setTimeout('mostrarSimulacros(intEstado22);',500);
		VnV22 (1, 1, 0);
	}
	
/*ACTUALIZO SIMULACRO*/
		function updateSimulacro (sim, cod, fch, estado, desc, pr, resp, result, obs) {
		var db;
		FSError = false; nombreFS=null; rutaFS=null;//FileSystem 
		addFile("mySIM");//FileSystem
		console.log('Contenido del nombreFS: '+nombreFS);
		db = openDatabase("DBIWOHS", "0.1", "Database Isowin OHS", 500 * 1024 * 1024);
		if(db){	
		  db.transaction( function(tx) {
			tx.executeSql("UPDATE simulacros SET codsim=?, simulacro=?, descripcion=?, idpersona=?, fchplan=?, estado=?, resultado=?, procedimiento=?, obs=? WHERE idsim=?", [cod, sim, desc, resp, fch, estado, result, pr, obs, idseleccionado22]);
			CEXupdateCita( "Simulacro" + idseleccionado22, fch, fch, sim, "SIM" + idseleccionado22);
			apprise('El simulacro ha sido modificado'); //alert("La reclamación ha cambiado: "+ codreclamacion + " - " + idseleccionado19);
		})};
		setTimeout('updateFSSimulacros()',300);
		setTimeout('mostrarSimulacros(intEstado22);',500);
		VnV22 (1, 1, 0);
	}	

/*ACTUALIZAR ARCHIVOS*/
function updateFSSimulacros() {
var db;
db = openDatabase("DBIWOHS", "0.1", "Database Isowin OHS", 500 * 1024 * 1024);
		if(db){	
		db.transaction( function(tx) {
			if (nombreFS!=null) {tx.executeSql("UPDATE simulacros SET fsname=?, fslink=? WHERE idsim=?", [nombreFS, rutaFS, idseleccionado22]);
								document.getElementById("FSSIM").innerHTML = "<a class='doc' href='"+rutaFS+"' target='_blank'>"+nombreFS+"</a> <img src='img/miniboton.jpg' style='vertical-align:middle' onclick='deleteFSSIM();' />";};
			});
		};
}				

/*BORRO SIMULACRO*/
	function removeSimulacro() {
		apprise('�Eliminar el requisito legal?', {'verify': true}, function(r) {
			if(r) {
			deleteFile();//FileSystem
			var db;
			db = openDatabase("DBIWOHS", "0.1", "Database Isowin OHS", 500 * 1024 * 1024);
			if(db){	
				db.transaction(function(tx) {
					tx.executeSql("DELETE FROM simulacros WHERE idsim=?",[idseleccionado22]);
					CEXdeleteCita("SIM" + idseleccionado22);
					apprise('El simulacro ha sido borrado');
				})};};

			setTimeout('mostrarSimulacros(intEstado22);',500);
			VnV51 (1, 1, 0);
		});
	}

/*BORRAR ARCHIVOS*/
	function deleteFSSIM() {
		deleteLinkFile('simulacros');
		document.getElementById("FSSIM").innerHTML = "<input type='file' id='mySIM' />";
		setTimeout('mostrarSimulacros(intEstado22);',500);
	}

//=========================================================================================================					
/*NUEVA APC22*/
	function addACP22 (acp, codacp, tipo, fchalta, responsable, equipo, acciones, fchprevista) {
		var origen = "El Simulacro: " +  idseleccionado22;
		var codtrz = "sim"+idseleccionado22;
		addMiniACP(acp, codacp, tipo, origen, fchalta, responsable, equipo, acciones, fchprevista, codtrz);
	}
	
//=========================================================================================================
/* VER NO VER*/
var verNSIM=1; var verLSIM= 1; var verNACP3= 0;

function VnV22 (Vnsim, Vlsim, Vnacp3) { 
	if (verNSIM!=Vnsim) {$("#newsimulacro").toggle(200); verNSIM=Vnsim;};
	if (verLSIM!=Vlsim) {$("#listasimulacros").toggle(200); verLSIM=Vlsim;};
	if (verNACP3!=Vnacp3) {$("#newacp3").toggle(200); verNACP3=Vnacp3; $("#txtacp3").focus();};
	}
/* VER NO VER EDIT (Update+Delete)*/
var verESIM=0;
function VnVEsim (Vesim) {if (verESIM!=Vesim) {$("#editsim").toggle(200); verESIM=Vesim;};}

//=========================================================================================================

//VER BOTON SEMAFORO_______________________________________________________________________

//Funcion de inicializaci�n de la pesta�a, ocultando el bot�n rojo.
function VbInit22() {document.getElementById('botonrojo22').style.display = 'none';}
//valor 1 se pone rojo, valor 0 se pone verde.	
function Vb22(intColor22) {
	if (INTcolor22!=intColor22) {$("#botonrojo22").toggle(200); $("#botonverde22").toggle(200); INTcolor22=intColor22;};
	}
//__________________________________________________________________________________________	
	
