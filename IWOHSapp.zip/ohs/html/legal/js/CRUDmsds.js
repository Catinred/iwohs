//MSDS (52)

	var idseleccionado52;
	var intEstado52;
	var INTcolor52; //Color del semaforo en verde
				
				
//TABLA MSDS_____________________________________________________________________________________________________________
function mostrarMSDSs(intEst52) {
	if (intEstado52!=intEst52) {
		intEstado52=intEst52; 
		Vb52();};
	sacarMSDSs (intEstado52);
	setTimeout('listMSDSs()',500);
	}


function listMSDSs() {
			$(document).ready(			
			function () {
				$('#dynamic52').html( '<table cellpadding="0" cellspacing="0" border="0" class="display" id="example52"></table>' );
				$('#example52').dataTable( {
					"aaData": aDataSet52,
						
					"aoColumns": [
						{ "sTitle": "Id"/*, "bSearchable": false, "bVisible": false*/ },
						{ "sTitle": "MSDS" },
						{ "sTitle": "Marca y modelo" },
						{ "sTitle": "Fabricante", "bSearchable": false, "bVisible": false },
						{ "sTitle": "Distribuidor", "bSearchable": false, "bVisible": false },
						{ "sTitle": "Contacto", "bSearchable": false, "bVisible": false },
						{ "sTitle": "mail", "bSearchable": false, "bVisible": false  },
						{ "sTitle": "Revisión" },
						{ "sTitle": "Estado" },
						{ "sTitle": "Uso", "bSearchable": false, "bVisible": false },
						{ "sTitle": "Documento" },
						{ "sTitle": "FSname", "bSearchable": false, "bVisible": false },
						{ "sTitle": "FSlink", "bSearchable": false, "bVisible": false },
						{ "sTitle": "Obs", "bSearchable": false, "bVisible": false }
						],
						
					"sScrollY": "350px",
					"sScrollX": "100%",
					
        			"bPaginate": false,
        			//"bScrollCollapse": true,
						
					"sDom": 'lfrtip<"clear spacer">T',
					/*"sDom": 'T<"clear">lfrtip<"clear spacer">T',*/ //Muestra los botones de copy,print...
					"oTableTools": {
						"sRowSelect": "single","aButtons": ["select"], //Solo me muestra el boton select para poder seleccionar las filas.
							
					"aoColumnDefs": [ {
						"sClass": "center",
						"aTargets": [ -1, -2 ]
						} ]
						
				}});

				//Cargo el COMBOBOX de responsables del formulario NCs------------
				sacarResponsables ();
				setTimeout('$("#comboacpresp4").html(nuevosresponsables);',200);
				//--------------------------------------------------
				
				});
	//Cargar datos de proveedor para editar en formulario	
			$(document).ready(
				function() {
    			$('#example52 tbody td').click( function () {
        		var aPos52 = oTable52.fnGetPosition( this );
        		var aData52 = oTable52.fnGetData( aPos52[0] );
				
				idseleccionado52 =  aData52[0];
				document.getElementById("txtmsds").value = aData52[1];
				document.getElementById("txtmsmarca").value = aData52[2];
				document.getElementById("txtmsfabricante").value = aData52[3];
				document.getElementById("txtmsdistribuidor").value = aData52[4];
				document.getElementById("txtmscontacto").value = aData52[5];
				document.getElementById("txtmsmail").value = aData52[6];
				document.getElementById("txtmsrevision").value = aData52[7];
				document.getElementById("combomsestado").value = aData52[8];
				document.getElementById("txtmsuso").value = aData52[9];
				document.getElementById("txtmsobs").value = aData52[13];
			
				//File System-----------------------------------------------------------
					if (aData52[12]) {document.getElementById("FSMSDS").innerHTML = "<p><a class='doc' href='"+aData52[12]+"' target='_blank'>"+aData52[11]+"</a> <img src='img/miniboton.jpg' style='vertical-align:middle' onclick='deleteFSMSDS();' /></p>"; 
							nombreFS=aData52[11]; rutaFS=aData52[12]}
					else {document.getElementById("FSMSDS").innerHTML = "<input type='file' id='myMSDS' />";};
				//----------------------------------------------------------------------

				VnV52 (1, 1, 0);
				VnVEmsds (1);//No ver botones update y delete
         
    			});
     
   				 /* Init DataTables */
   				 oTable52 = $('#example52').dataTable();
				});
		
	}
	
//DATOS MSDS_________________________________________________

function sacarMSDSs (intEstado52){
	var db;
        db = openDatabase("DBIWOHS", "0.1", "Database Isowin OHS", 500 * 1024 * 1024);	
	
	var estado52="estado='Vigente' ";
	if (intEstado52==1) {estado52="estado='Pendiente' ";};	
	if (intEstado52==2) {estado52="estado='Sin uso' ";};	
							
	if(db){
		db.transaction( function(tx) {
			//La trazabilidad igual a RL, identifica que es un requisito legal y no de cliente entre todos los requisitos
			tx.executeSql("SELECT * FROM msdss WHERE " + estado52, [],
				function(tx, result){
					aDataSet52 = [];
					for(var i=0; i < result.rows.length; i++) {

						var linknull = "";//File System
						if (result.rows.item(i)['fsname']) {linknull = result.rows.item(i)['fsname'];};

						aDataSet52.push([result.rows.item(i)['idmsds'],
								result.rows.item(i)['msds'],
								result.rows.item(i)['marca'],
								result.rows.item(i)['fabricante'],
								result.rows.item(i)['distribuidor'],
								result.rows.item(i)['contacto'],
								result.rows.item(i)['mail'],
								result.rows.item(i)['revision'],
								result.rows.item(i)['estado'],
								result.rows.item(i)['uso'],
								"<a href='"+result.rows.item(i)['fslink']+"' target='_blank'>"+linknull+"</a>",
								result.rows.item(i)['fsname'],
								result.rows.item(i)['fslink'],
								result.rows.item(i)['obs']
								]);
					};			
				});
		});	
	};
}

//=========================================================================================================					
/*NUEVO REQUISITO LEGAL*/
	function addMSDS (msds, marca, fabricante, distribuidor, contacto, mail, revision, estado, uso, obs) {
		var db;
		FSError = false; nombreFS=null; rutaFS=null;//FileSystem 
		addFile("myMSDS");//FileSystem
		db = openDatabase("DBIWOHS", "0.1", "Database Isowin OHS", 500 * 1024 * 1024);
		if(db){	
		  db.transaction( function(tx) {
			tx.executeSql("INSERT INTO msdss (msds, marca, fabricante, distribuidor, contacto, mail, revision, estado, uso, obs) VALUES(?,?,?,?,?,?,?,?,?,?)", [msds, marca, fabricante, distribuidor, contacto, mail, revision, estado, uso, obs]);
			tx.executeSql("SELECT * FROM msdss ORDER BY idmsds DESC", [], function(tx, result){
				idseleccionado52 = result.rows.item(0)["idmsds"];
				if (!FSError) {apprise('La MSDS ha sido guardada');};
			});
		})};

		setTimeout('updateFSMSDS()',300);
		setTimeout('mostrarMSDSs(intEstado52)',500);
		VnV52 (1, 1, 0);
	}
	
/*ACTUALIZO REQUISITO LEGAL*/
		function updateMSDS (msds, marca, fabricante, distribuidor, contacto, mail, revision, estado, uso, obs) {
		var db;
		FSError = false; nombreFS=null; rutaFS=null;//FileSystem 
		addFile("myMSDS");//FileSystem
		db = openDatabase("DBIWOHS", "0.1", "Database Isowin OHS", 500 * 1024 * 1024);
		if(db){	
		  db.transaction( function(tx) {
			tx.executeSql("UPDATE msdss SET msds=?, marca=?, fabricante=?, distribuidor=?, contacto=?, mail=?, revision=?, estado=?, uso=?, obs=? WHERE idmsds=?", [msds, marca, fabricante, distribuidor, contacto, mail, revision, estado, uso, obs, idseleccionado52]);
			if (!FSError) {apprise('La MSDS ha sido modificada');};

			
		})};
		
		setTimeout('updateFSMSDS()',300);
		setTimeout('mostrarMSDSs(intEstado52)',500);
		VnV52 (1, 1, 0);
	}

/*ACTUALIZAR ARCHIVOS*/
function updateFSMSDS() {
var db;
db = openDatabase("DBIWOHS", "0.1", "Database Isowin OHS", 500 * 1024 * 1024);
		if(db){	
		db.transaction( function(tx) {
			if (nombreFS!=null) {tx.executeSql("UPDATE msdss SET fsname=?, fslink=? WHERE idmsds=?", [nombreFS, rutaFS, idseleccionado52]);
								document.getElementById("FSMSDS").innerHTML = "<a class='doc' href='"+rutaFS+"' target='_blank'>"+nombreFS+"</a> <img src='img/miniboton.jpg' style='vertical-align:middle' onclick='deleteFSMSDS();' />";};
			});
		};
}					

/*BORRO REQUISITO LEGAL*/
	function removeMSDS() {
		apprise('¿Eliminar la MSDS?', {'verify': true}, function(r) {
			if(r) {
			var db;
			deleteFile();//FileSystem
			db = openDatabase("DBIWOHS", "0.1", "Database Isowin OHS", 500 * 1024 * 1024);
			if(db){	
				db.transaction(function(tx) {
					tx.executeSql("DELETE FROM msdss WHERE idmsds=?",[idseleccionado52]);
					if (!FSError) {apprise('La MSDS ha sido borrada');};
				})};};

			setTimeout('mostrarMSDSs(intEstado52)',500);
			VnV52 (1, 1, 0);
		});
	}

	/*BORRAR ARCHIVOS*/
	function deleteFSMSDS() {
		deleteLinkFile('msdss');
		document.getElementById("FSMSDS").innerHTML = "<input type='file' id='myMSDS' />";
		setTimeout('mostrarMSDSs(intEstado52);',500);
	}
//=========================================================================================================					
/*NUEVA APC52*/
	function addACP52 (acp, codacp, tipo, fchalta, responsable, equipo, acciones, fchprevista) {
		var origen = "La MSDS: " +  idseleccionado52;
		var codtrz = "msds"+idseleccionado52;
		addMiniACP(acp, codacp, tipo, origen, fchalta, responsable, equipo, acciones, fchprevista, codtrz);
		//alert("inside2");
	}
	
//=========================================================================================================
/* VER NO VER*/
var verNMSDS=1; var verLMSDS= 1; var verNACP4= 0;

function VnV52 (Vnmsds, Vlmsds, Vnacp4) { 
	if (verNMSDS!=Vnmsds) {$("#newmsds").toggle(200); verNMSDS=Vnmsds;};
	if (verLMSDS!=Vlmsds) {$("#listamsdss").toggle(200); verLMSDS=Vlmsds;};
	if (verNACP4!=Vnacp4) {$("#newacp4").toggle(200); verNACP4=Vnacp4; $("#txtacp4").focus();};
	}

/* VER NO VER EDIT (Update+Delete)*/
var verEMSDS=0;
function VnVEmsds (Vemsds) {if (verEMSDS!=Vemsds) {$("#editmsds").toggle(200); verEMSDS=Vemsds;};}

//VER BOTON SEMAFORO_______________________________________________________________________

//Funcion de inicialización de la pestaña, ocultando el botón rojo.
function VbInit52() {
	document.getElementById('botonverde52').style.display = 'inherit';
	document.getElementById('botonrojo52').style.display = 'none';
	document.getElementById('botonamar52').style.display = 'none';
	INTcolor52 = 1;
	}
	
//valor 1 se pone rojo, valor 0 se pone verde.	
function Vb52() {
	if (INTcolor52==1) {$("#botonverde52").toggle(200); $("#botonamar52").toggle(200);};
	if (INTcolor52==2) {$("#botonamar52").toggle(200); $("#botonrojo52").toggle(200);};
	if (INTcolor52==3) {$("#botonrojo52").toggle(200); $("#botonverde52").toggle(200); INTcolor52=0;};
	INTcolor52 = INTcolor52 + 1;
	}
//__________________________________________________________________________________________

