// "X" INTELIGENCE ________________________________________________________________________________________________

var XData = [];
	
	AddXer (1);
	AddXrm2 (1);
	AddXrm (2);
	AddXfor (3);
	AddXepi (3);

self.addEventListener('message', function(e) {
  self.postMessage(XData);
}, false);

//console.log(XData);

//XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX	

//EVALUACIONES DE RIESGO PENDIENTES________________________
function AddXer (priority) {
	var db; db = openDatabase("DBIWOHS", "0.1", "Database Isowin OHS", 500 * 1024 * 1024);
	if(db){	db.transaction( function(tx) {
			tx.executeSql("SELECT * FROM ersx LEFT JOIN ers ON ersx.idx=ers.idx WHERE ers.ider is null", [],
				function(tx, result){
					//console.log('ERs PENDIENTES: ' + result.rows.length);
					for(var i=0; i < result.rows.length; i++) {
					var apunte = result.rows.item(i)['txt'];
					XData.push([apunte, priority]);
   					//console.log(apunte +'<-'+ idx);
   	};});});};
}			

//RECONOCIMIENTOS MÉDICOS PENDIENTES________________________
function AddXrm2 (priority) {
	var apunte;
	var db; db = openDatabase("DBIWOHS", "0.1", "Database Isowin OHS", 500 * 1024 * 1024);
	if(db){	db.transaction( function(tx) {
			tx.executeSql("SELECT * FROM personas LEFT JOIN rms ON personas.idpersona=rms.idpersona WHERE idrm is null", [],
				function(tx, result){
					//console.log('Reconocimientos médicos PENDIENTES: ' + result.rows.length);
					for(var i=0; i < result.rows.length; i++) {
						var apunte = result.rows.item(i)['nombre'] + " " + result.rows.item(i)['apellidos'] + " tiene pendiente pasar el reconocimiento médico.";
						XData.push([apunte, priority]);
   						//console.log(apunte +'<-'+ idx);
	};});});};
}

//RECONOCIMIENTOS MÉDICOS CADUCADOS________________________
function AddXrm (priority) {
	var apunte; var nomyapel = "Manuel Garcia Juste";
	var db; db = openDatabase("DBIWOHS", "0.1", "Database Isowin OHS", 500 * 1024 * 1024);					
	if(db){
		db.transaction( function(tx) {
			tx.executeSql("SELECT * FROM rms LEFT JOIN personas ON rms.idpersona=personas.idpersona WHERE rms.estado!='Finalizado' AND rms.estado!='Anulado'", [],
				function(tx, result){
					//console.log('Reconocimientos médicos CADUCADOS: ' + result.rows.length);
					for(var i=0; i < result.rows.length; i++) {
						var fechacaduca = new Date(changeFch(result.rows.item(i)['dia'])); //Paso la fecha a formato DATE
						fechacaduca.setDate(fechacaduca.getDate() + 365); //Actualizo la fecha sumandole un año
						var diasqfal = (fechacaduca - new Date())/(1000*60*60*24); //Dias que faltan para que caduque
						var nomyapel = result.rows.item(i)['nombre'] + " " + result.rows.item(i)['apellidos'] ;

					//LOS RM QUE YA ESTÁN CADUCADOS
						if (diasqfal<1){
							var apunte = nomyapel + " tiene el reconocimiento médico caducado.";
							XData.push([apunte, priority]);
						};	
					};			
				});
		});	
	};
}

//FORMACIONES PENDIENTES________________________
function AddXfor (priority) {
	var db; db = openDatabase("DBIWOHS", "0.1", "Database Isowin OHS", 500 * 1024 * 1024);
	if(db){	db.transaction( function(tx) {
			//vista1: Todas las Formacion+Persona que hay que hacer.
			tx.executeSql("CREATE TEMP VIEW vista1 AS SELECT * FROM (((prlpuestoformacion LEFT JOIN formaciones ON prlpuestoformacion.idformacion=formaciones.idformacion) INNER JOIN prlpuestopuesto ON prlpuestoformacion.idprlpuesto=prlpuestopuesto.idprlpuesto) INNER JOIN personas ON prlpuestopuesto.idpuesto=personas.idpuesto)");
				//tx.executeSql("SELECT * FROM vista1", [], function(tx, result){console.log('vista1: ' + result.rows.length);});//Para pruebas
			//vista2: Todas las Formacion+Persona que se han hecho.
			tx.executeSql("CREATE TEMP VIEW vista2 AS SELECT * FROM (cursos INNER JOIN cursospersonas ON cursos.idcurso=cursospersonas.idcurso)");
				//tx.executeSql("SELECT * FROM vista2", [], function(tx, result){console.log('vista2: ' + result.rows.length);});//Para pruebas
			tx.executeSql("SELECT * FROM vista1 LEFT JOIN vista2 ON (vista1.idformacion=vista2.conval AND vista1.idpersona=vista2.idpersona)", [], // 
				function(tx, result){
				//console.log('Formaciones PENDIENTES personas-puestos: ' + result.rows.length);
				if(result.rows.length!=0) {
					for(var i=0; i < result.rows.length; i++) {
						//Muestro sólo aquellas formación+persona que no hay un curso que las convalide.
						if (result.rows.item(i)['conval']==null) {
						var apunte = result.rows.item(i)['nombre'] + " " + result.rows.item(i)['apellidos'] + " tiene pendiente recibir formación de tipo: " + result.rows.item(i)['formacion'];// + " porque ha realizado el curso " + result.rows.item(i)['idcurso'] + " convalidable con la formación " + result.rows.item(i)['conval']
						XData.push([apunte, priority]);
						};
					};
				};
			});
		});
	};
}

//EPIS PENDIENTES________________________
function AddXepi (priority) {
	var db; db = openDatabase("DBIWOHS", "0.1", "Database Isowin OHS", 500 * 1024 * 1024);
	if(db){	db.transaction( function(tx) {
			//vista1: Todas las entregas de EPI+Persona que hay que hacer.
			tx.executeSql("CREATE TEMP VIEW vista1 AS SELECT * FROM (((prlpuestoepi LEFT JOIN epis ON prlpuestoepi.idepi=epis.idepi) INNER JOIN prlpuestopuesto ON prlpuestoepi.idprlpuesto=prlpuestopuesto.idprlpuesto) INNER JOIN personas ON prlpuestopuesto.idpuesto=personas.idpuesto)");
				//tx.executeSql("SELECT * FROM vista1", [], function(tx, result){console.log('vista1: ' + result.rows.length);});//Para pruebas
			tx.executeSql("SELECT * FROM vista1 LEFT JOIN personaepi ON (vista1.idepi=personaepi.idepi AND vista1.idpersona=personaepi.idpersona)", [], // 
				function(tx, result){
				//console.log('Entregas de EPIs PENDIENTES personas-EPI: ' + result.rows.length);
				if(result.rows.length!=0) {
					for(var i=0; i < result.rows.length; i++) {
						//Muestro sólo aquellas formación+persona que no hay un curso que las convalide.
						if (result.rows.item(i)['fchentrega']==null) {
						var apunte = result.rows.item(i)['nombre'] + " " + result.rows.item(i)['apellidos'] + " tiene pendiente recibir el E.P.I.: " + result.rows.item(i)['epi'];// + " porque ha realizado el curso " + result.rows.item(i)['idcurso'] + " convalidable con la formación " + result.rows.item(i)['conval']
						XData.push([apunte, priority]);
						};
					};
				};
			});
		});
	};
}
