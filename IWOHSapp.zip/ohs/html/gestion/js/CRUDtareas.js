//TAREAS
	var idseleccionado5;
	var renderizar = 1;
	var lineaGris = 0;
	var aDataSet5 = [];
	var XData = [];//X Inteligence
				
//TABLA TAREAS_____________________________________________________________________________________________________________
function mostrarTareas() {
	if ( renderizar == 1) {
	sacarTareas ();
	setTimeout('listTareas()',500);
	renderizar = 0; //Renderizo sólo una vez, cuando cargo la página.
	};}


function listTareas() {
		$(document).ready(			
			function () {
				$('#dynamic5').html( '<table cellpadding="0" cellspacing="0" border="0" class="display" id="example5"></table>' );
				$('#example5').dataTable( {
					"aaData": aDataSet5,
					
					//"bJQueryUI": true, //Carga un tema de JQuery UI
					//CAMBIO DE COLOR DEL FONDO DE LAS LINEAS
					"fnRowCallback": function( nRow, aaData, iDisplayIndex ) {	
					 if (lineaGris==0) {$('td:eq(0)', nRow).addClass( 'whiterow' );$('td:eq(1)', nRow).addClass( 'whiterow' );$('td:eq(2)', nRow).addClass( 'whiterow' );$('td:eq(3)', nRow).addClass( 'whiterow' ); lineaGris=1;}
								else{$('td:eq(0)', nRow).addClass( 'greyrow' );$('td:eq(1)', nRow).addClass( 'greyrow' );$('td:eq(2)', nRow).addClass( 'whiterow' );$('td:eq(3)', nRow).addClass( 'whiterow' ); lineaGris=0;}
						 //$('td:eq(0)', nRow).draggable;
						//$('div').addClass( 'external-event' );	
						return nRow;
        				}, 
						
					"aoColumns": [
						{ "sTitle": "Tarea", sWidth: "80%" },
						{ "sTitle": "Prioridad", sWidth: "20%"},
						//{ "sTitle": "Editar"}
						],

					"sDom": 'frtip',
					//lfrtip<"clear spacer">T
					"oTableTools": {
						/*"sRowSelect": "single","aButtons": ["select"],*///Solo me muestra el boton select para poder seleccionar las filas.

					"aoColumnDefs": [ {
						"sClass": "center",
						"aTargets": [ -1, -2 ]
						} ]
				},
				
				//Elimina la ordenaciÃ³n de la tabla
				"bSort": false,
				
				})
				
				
				//.rowReordering(); //Permite reordenar draggable
				
				/* 
				* Example init
				
				$(document).ready(function(){
					$('#example5').dataTable()
						.rowReordering();
				});*/

						
		//EDITAR LINEAS DIRECTAMENTE!!
				
				var oTable5 = $('#example5').dataTable();
				
				var nEditing = null;
				
				//CREAR
				$('#crearTarea').click( function (e) {
				e.preventDefault();
				 
				var aiNew = oTable5.fnAddData( [ '', '' , 
				'<a class="edit" href="">Edit</a>' ] );
				var nRow5 = oTable5.fnGetNodes( aiNew[0] );
				editRow( oTable5, nRow5 );
				$("#txtApunte").focus();
				nEditing = nRow5;
				//document.getElementById("crearTarea").style.display='none';
				} );
				
				//GUARDAR
				$('#example5 select.guardar').live('change', function (e) {
				e.preventDefault();
		
				var nRow5 = $(this).parents('tr')[0];
				if ( nEditing == nRow5 ) {
				
				//This row is being edited and should be saved 
				saveRow( oTable5, nEditing );
				nEditing = null;
				}
				
				} );
	
				//BORRAR
				$('#example5 a.delete').live('click', function (e) {
				e.preventDefault();
				//Selecciono la fila a eliminar
				var nRow5 = $(this).parents('tr')[0];
				//Borrar de la BD
				borrarApunteBD (nRow5);
				//Borrar de la tabla	
				oTable5.fnDeleteRow( nRow5 );
				
				} );
				
 
 				//EDITAR
    			$('#example5 a.edit').live('click', function (e) {
        			e.preventDefault();
         
       			 // Get the row as a parent of the link that was clicked on 
        		var nRow5 = $(this).parents('tr')[0];
         
        		if ( nEditing !== null && nEditing != nRow5 ) {
            	// A different row is being edited - the edit should be cancelled and this row edited 
            	restoreRow( oTable5, nEditing );
            	editRow( oTable5, nRow5 );
            	nEditing = nRow5;
        		}
        		else if ( nEditing == nRow5 && this.innerHTML == "Save" ) {
            	// This row is being edited and should be saved 
            	saveRow( oTable5, nEditing );
            	nEditing = null;
        		}
        		else {
            	// No row currently being edited 
            	editRow( oTable5, nRow5 );
            	nEditing = nRow5;
        		};
			
    			});

    		//CARGAR X INTELIGENCE
				$('#cargarTareas').click( function (e) {
					e.preventDefault();
					for(var i=0; i < XData.length; i++) {
						if ( XData[i][1]==1) {oTable5.fnAddData([XData[i][0], '<a class="delete"><div class="sprite alta"></div></a>']);};
						if ( XData[i][1]==2) {oTable5.fnAddData([XData[i][0], '<a class="delete"><div class="sprite media"></div></a>']);};
						if ( XData[i][1]==3) {oTable5.fnAddData([XData[i][0], '<a class="delete"><div class="sprite baja"></div></a>']);};
						//console.log(XData[i][0]);
					};
					apprise('Tareas pendientes chequeadas');
					document.getElementById('cargarTareas').style.display = 'none';
				});
		});		
				
				
				
//FunciÃ³n de prueba para la revisiÃ³n por direcciÃ³n en pestaÃ±a 3			
/*$(function() {
 $('.selecteditable').editable('', { 
     data   : " {'E':'Letter E','F':'Letter F','G':'Letter G', 'selected':'F'}",
     type   : 'select',
     submit : 'OK'
	  });});*/
				
}

function sacarTareas (){
	var db;
        db = openDatabase("DBIWOHS", "0.1", "Database Isowin OHS", 500 * 1024 * 1024);	
		//alert ("Estoy dentro");					
	if(db){
		db.transaction( function(tx) {
			tx.executeSql("SELECT * FROM apuntes LIMIT 100", [],
				function(tx, result){

					aDataSet5 = [];
					
					var htmlPrioridad;
					
					for(var i=0; i < result.rows.length; i++) {
						
						if (result.rows.item(i)['prioridad']==1) {htmlPrioridad = '<a class="delete" href=""><div class="sprite alta"></div></a>'};
						if (result.rows.item(i)['prioridad']==2) {htmlPrioridad = '<a class="delete" href=""><div class="sprite media"></div></a>'};
						if (result.rows.item(i)['prioridad']==3) {htmlPrioridad = '<a class="delete" href=""><div class="sprite baja"></div></a>'};

						
						aDataSet5.push([result.rows.item(i)['apunte'],
								htmlPrioridad
								]);
					}
					
   				 // Init DataTables
   				 oTable5 = $('#example5').dataTable();				
				
			});
		});	
	};
}			

				

//=========================================================================================================					

//ReStore Node
function restoreRow ( oTable, nRow )
{
	var aData = oTable.fnGetData(nRow);
	var jqTds = $('>td', nRow);
	
	for ( var i=0, iLen=jqTds.length ; i<iLen ; i++ ) {
		oTable.fnUpdate( aData[i], nRow, i, false );
	}
	
	oTable.fnDraw();
}

//EDITAR TAREA
function editRow ( oTable, nRow )
{
    var aData = oTable.fnGetData(nRow);
    var jqTds = $('>td', nRow);

	oTable.fnPageChange( 'last' );
    jqTds[0].innerHTML = '<input id="txtApunte" type="text" value="'+aData[0]+'">';
    jqTds[1].innerHTML = '<select class="guardar"><option value=0>Elegir...<option value=1>Alta<option value=2>Media<option value=3>Baja</select>';
    //jqTds[2].innerHTML = '<a class="edit" href="">Save</a>';
	//alert(document.getElementById(aData[1]).value);
}
//GUARDAR TAREA
function saveRow ( oTable, nRow )
{ 
    var jqInputs = $('input', nRow);
    var jqSelect = $('select', nRow);
	//alert(jqInputs[0].value);
    oTable.fnUpdate( jqInputs[0].value, nRow, 0, false );
    if ( jqSelect[0].value==1) {oTable.fnUpdate('<a class="delete"><div class="sprite alta"></div></a>', nRow, 1, false )};
    if ( jqSelect[0].value==2) {oTable.fnUpdate('<a class="delete"><div class="sprite media"></div></a>', nRow, 1, false )};
    if ( jqSelect[0].value==3) {oTable.fnUpdate('<a class="delete"><div class="sprite baja"></div></a>', nRow, 1, false )};
    //oTable.fnUpdate( '<a class="edit" href="">'+jqInputs[0].value+'</a>', nRow, 2, false );
    //document.getElementById("newTarea").style.display='inherit';
    guardarApunteBD(jqInputs[0].value, jqSelect[0].value);
    //alert(jqInputs[0].value + jqSelect[0].value);
    oTable.fnDraw();
    //alert(document.getElementById(aData[1]).value);
    
}

function guardarApunteBD (apunte, prioridad) {
	var db = openDatabase("DBIWOHS", "0.1", "Database Isowin OHS", 500 * 1024 * 1024);
	if(db){db.transaction( function(tx) {tx.executeSql("INSERT INTO apuntes (apunte, prioridad) VALUES(?,?)", [apunte, prioridad]);});}; 
	}
	
function borrarApunteBD (linea) {
	//Extraigo el texto de la "tarea" o "apunte" que usare como identificador de la linea a eliminar.
	var jqTds2 = $('td', linea);
	apunte = jqTds2[0].innerHTML;
	
	var db = openDatabase("DBIWOHS", "0.1", "Database Isowin OHS", 500 * 1024 * 1024);
	if(db){db.transaction(function(tx) {tx.executeSql("DELETE FROM apuntes WHERE apunte=?",[apunte]);})};

	//setTimeout('mostrarApuntes()',500);
	} 


//XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX
//XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX	
//XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX
// "X" INTELIGENCE ________________________________________________________________________________________________

function AddApuntesX () {
	
	AddXer (1);
	AddXrm2 (1);
	AddXrm (2);
	AddXfor (3);
	AddXepi (3);
	
	}

//XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX	

//EVALUACIONES DE RIESGO PENDIENTES________________________
function AddXer (priority) {
	var db; db = openDatabase("DBIWOHS", "0.1", "Database Isowin OHS", 500 * 1024 * 1024);
	if(db){	db.transaction( function(tx) {
			tx.executeSql("SELECT * FROM ersx LEFT JOIN ers ON ersx.idx=ers.idx WHERE ers.ider is null", [],
				function(tx, result){
					console.log('ERs PENDIENTES: ' + result.rows.length);
					for(var i=0; i < result.rows.length; i++) {
					var apunte = result.rows.item(i)['txt'];
					XData.push([apunte, priority]);
   					//console.log(apunte +'<-'+ idx);
   	};});});};
}			

//RECONOCIMIENTOS MÉDICOS PENDIENTES________________________
function AddXrm2 (priority) {
	var apunte;
	var db; db = openDatabase("DBIWOHS", "0.1", "Database Isowin OHS", 500 * 1024 * 1024);
	if(db){	db.transaction( function(tx) {
			tx.executeSql("SELECT * FROM personas LEFT JOIN rms ON personas.idpersona=rms.idpersona WHERE idrm is null", [],
				function(tx, result){
					console.log('Reconocimientos médicos PENDIENTES: ' + result.rows.length);
					for(var i=0; i < result.rows.length; i++) {
						var apunte = result.rows.item(i)['nombre'] + " " + result.rows.item(i)['apellidos'] + " tiene pendiente pasar el reconocimiento médico.";
						XData.push([apunte, priority]);
   						//console.log(apunte +'<-'+ idx);
	};});});};
}

//RECONOCIMIENTOS MÉDICOS CADUCADOS________________________
function AddXrm (priority) {
	var apunte; var nomyapel = "Manuel Garcia Juste";
	var db; db = openDatabase("DBIWOHS", "0.1", "Database Isowin OHS", 500 * 1024 * 1024);					
	if(db){
		db.transaction( function(tx) {
			tx.executeSql("SELECT * FROM rms LEFT JOIN personas ON rms.idpersona=personas.idpersona WHERE rms.estado!='Finalizado' AND rms.estado!='Anulado'", [],
				function(tx, result){
					console.log('Reconocimientos médicos CADUCADOS: ' + result.rows.length);
					for(var i=0; i < result.rows.length; i++) {
						var fechacaduca = new Date(changeFch(result.rows.item(i)['dia'])); //Paso la fecha a formato DATE
						fechacaduca.setDate(fechacaduca.getDate() + 365); //Actualizo la fecha sumandole un año
						var diasqfal = (fechacaduca - new Date())/(1000*60*60*24); //Dias que faltan para que caduque
						var nomyapel = result.rows.item(i)['nombre'] + " " + result.rows.item(i)['apellidos'] ;

					//LOS RM QUE YA ESTÁN CADUCADOS
						if (diasqfal<1){
							var apunte = nomyapel + " tiene el reconocimiento médico caducado.";
							XData.push([apunte, priority]);
						};	
					};			
				});
		});	
	};
}

//FORMACIONES PENDIENTES________________________
function AddXfor (priority) {
	var db; db = openDatabase("DBIWOHS", "0.1", "Database Isowin OHS", 500 * 1024 * 1024);
	if(db){	db.transaction( function(tx) {
			//vista1: Todas las Formacion+Persona que hay que hacer.
			tx.executeSql("CREATE TEMP VIEW vista1 AS SELECT * FROM (((prlpuestoformacion LEFT JOIN formaciones ON prlpuestoformacion.idformacion=formaciones.idformacion) INNER JOIN prlpuestopuesto ON prlpuestoformacion.idprlpuesto=prlpuestopuesto.idprlpuesto) INNER JOIN personas ON prlpuestopuesto.idpuesto=personas.idpuesto)");
				//tx.executeSql("SELECT * FROM vista1", [], function(tx, result){console.log('vista1: ' + result.rows.length);});//Para pruebas
			//vista2: Todas las Formacion+Persona que se han hecho.
			tx.executeSql("CREATE TEMP VIEW vista2 AS SELECT * FROM (cursos INNER JOIN cursospersonas ON cursos.idcurso=cursospersonas.idcurso)");
				//tx.executeSql("SELECT * FROM vista2", [], function(tx, result){console.log('vista2: ' + result.rows.length);});//Para pruebas
			tx.executeSql("SELECT * FROM vista1 LEFT JOIN vista2 ON (vista1.idformacion=vista2.conval AND vista1.idpersona=vista2.idpersona)", [], // 
				function(tx, result){
				console.log('Formaciones PENDIENTES personas-puestos: ' + result.rows.length);
				if(result.rows.length!=0) {
					for(var i=0; i < result.rows.length; i++) {
						//Muestro sólo aquellas formación+persona que no hay un curso que las convalide.
						if (result.rows.item(i)['conval']==null) {
						var apunte = result.rows.item(i)['nombre'] + " " + result.rows.item(i)['apellidos'] + " tiene pendiente recibir formación de tipo: " + result.rows.item(i)['formacion'];// + " porque ha realizado el curso " + result.rows.item(i)['idcurso'] + " convalidable con la formación " + result.rows.item(i)['conval']
						XData.push([apunte, priority]);
						};
					};
				};
			});
		});
	};
}

//EPIS PENDIENTES________________________
function AddXepi (priority) {
	var db; db = openDatabase("DBIWOHS", "0.1", "Database Isowin OHS", 500 * 1024 * 1024);
	if(db){	db.transaction( function(tx) {
			//vista1: Todas las entregas de EPI+Persona que hay que hacer.
			tx.executeSql("CREATE TEMP VIEW vista1 AS SELECT * FROM (((prlpuestoepi LEFT JOIN epis ON prlpuestoepi.idepi=epis.idepi) INNER JOIN prlpuestopuesto ON prlpuestoepi.idprlpuesto=prlpuestopuesto.idprlpuesto) INNER JOIN personas ON prlpuestopuesto.idpuesto=personas.idpuesto)");
				//tx.executeSql("SELECT * FROM vista1", [], function(tx, result){console.log('vista1: ' + result.rows.length);});//Para pruebas
			tx.executeSql("SELECT * FROM vista1 LEFT JOIN personaepi ON (vista1.idepi=personaepi.idepi AND vista1.idpersona=personaepi.idpersona)", [], // 
				function(tx, result){
				console.log('Entregas de EPIs PENDIENTES personas-EPI: ' + result.rows.length);
				if(result.rows.length!=0) {
					for(var i=0; i < result.rows.length; i++) {
						//Muestro sólo aquellas formación+persona que no hay un curso que las convalide.
						if (result.rows.item(i)['fchentrega']==null) {
						var apunte = result.rows.item(i)['nombre'] + " " + result.rows.item(i)['apellidos'] + " tiene pendiente recibir el E.P.I.: " + result.rows.item(i)['epi'];// + " porque ha realizado el curso " + result.rows.item(i)['idcurso'] + " convalidable con la formación " + result.rows.item(i)['conval']
						XData.push([apunte, priority]);
						};
					};
				};
			});
		});
	};
}
//XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX
//XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX	
//XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX