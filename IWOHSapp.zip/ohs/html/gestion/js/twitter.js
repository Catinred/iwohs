


  new TWTR.Widget({
    version: 2,
    type: 'list',
    rpp: 30,
    interval: 6000,
    title: 'Todo lo que hacemos en',
    subject: 'ISOwin.es',
    width: 'auto',
    height: 400,
    theme: {
      shell: {
        background: '#1582bd',
        color: '#ffffff'
      },
      tweets: {
        background: '#ffffff',
        color: '#07547d',
        links: '#889094'
      }
    },
    features: {
      scrollbar: true,
      loop: false,
      live: true,
      hashtags: true,
      timestamp: true,
      avatars: true,
      behavior: 'all'
    }
  }).render().setList('Isowin1', 'isowin-es').start();