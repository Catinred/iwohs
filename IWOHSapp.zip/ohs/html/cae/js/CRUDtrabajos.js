//TRABAJOS (15)

	var idseleccionado15;
	var intEstado15;
	var INTcolor15 = 0; //Color del semaforo en verde
	var nuevossubsactivos;
				
	
//TABLA TRABAJOS (15)_____________________________________________________________________________________________________________

function mostrarTrabajos(intEst15) {
	intEstado15=intEst15;
	sacarTrabajos (intEstado15);
	setTimeout('listTrabajos()',500);
	Vb15(intEst15);
	}

function listTrabajos() {
		$(document).ready(			
			function () {
				$('#dynamic15').html( '<table cellpadding="0" cellspacing="0" border="0" class="display" id="example15"></table>' );
				$('#example15').dataTable( {
					"aaData": aDataSet15,
						
					"aoColumns": [
						{ "sTitle": "Id"/*, "bSearchable": false, "bVisible": false*/ },
						{ "sTitle": "Trabajo" },
						{ "sTitle": "Descripción", "bSearchable": false, "bVisible": false },
						{ "sTitle": "Fecha Inicio" },
						{ "sTitle": "Fecha Fin" },
						{ "sTitle": "Responsable" , "bSearchable": false, "bVisible": false },
						{ "sTitle": "Estado" }
						],
						
					"sScrollY": "630px",
        			"bPaginate": false,
        			"bScrollCollapse": true,
						
					"sDom": 'lfrtip<"clear spacer">T',
					/*"sDom": 'T<"clear">lfrtip<"clear spacer">T',*/ //Muestra los botones de copy,print...
					"oTableTools": {
						"sRowSelect": "single","aButtons": ["select"], //Solo me muestra el boton select para poder seleccionar las filas.
							
					"aoColumnDefs": [ {
						"sClass": "center",
						"aTargets": [ -1, -2 ]
						} ]
						
				}});

			//Cargo el COMBOBOX de responsables del formulario NCs------------
			sacarResponsables ();
			setTimeout('$("#combotbresponsable").html(nuevosresponsables);',200);
			//--------------------------------------------------		

			}
		);
			
	//Cargar datos del equipo para editar en formulario	
		$(document).ready(
			function() {
    			$('#example15 tbody td').click( function () {
        		var aPos15 = oTable15.fnGetPosition( this );
        		var aData15 = oTable15.fnGetData( aPos15[0] );
				
				idseleccionado15 =  aData15[0];
				document.getElementById("txttbtrabajo").value = aData15[1];
				document.getElementById("txttbdescripcion").value = aData15[2];
				document.getElementById("txttbfchinicio").value = aData15[3];
				document.getElementById("txttbfchfin").value = aData15[4];
				document.getElementById("combotbresponsable").value = parseInt(aData15[5]);
				document.getElementById("combotbestado").value = aData15[6];
				document.getElementById("txttbobs").value = aData15[9];

				//File System-----------------------------------------------------------
					if (aData15[8]) {document.getElementById("FSTRAB").innerHTML = "Evaluación de Riesgos: <a class='doc' href='"+aData15[8]+"' target='_blank'>"+aData15[7]+"</a> <img src='img/miniboton.jpg' style='vertical-align:middle' onclick='deleteFSTRAB();' />"; 
							nombreFS=aData15[7]; rutaFS=aData15[8];}
					else {document.getElementById("FSTRAB").innerHTML = "Evaluación de Riesgos: <input type='file' id='myTRAB' />";};
				//----------------------------------------------------------------------
				
			
			DatosBDSubs (idseleccionado15);
			setTimeout(' listSubs()',200);
		
			
			VnV15 (0, 0, 1, 1, 0, 1);
			VnVEtrab (1);//No ver botones update y delete
         
    			});
     
			/* Init DataTables */
			oTable15= $('#example15').dataTable();
			});
		
	}

function sacarTrabajos (intEstado15){
	var db;
        db = openDatabase("DBIWOHS", "0.1", "Database Isowin OHS", 500 * 1024 * 1024);	
		//alert ("Estoy dentro");					
	var estado15="WHERE estado!='Cerrado' ";
	if (intEstado15==1) {estado15="WHERE estado='Cerrado' ";};
	if(db){
		db.transaction( function(tx) {
			tx.executeSql("SELECT * FROM trabajos " + estado15, [],
				function(tx, result){
					aDataSet15 = [];
					for(var i=0; i < result.rows.length; i++) {	
						aDataSet15.push([result.rows.item(i)['idtrabajo'],
								result.rows.item(i)['trabajo'],
								result.rows.item(i)['descripcion'],
								result.rows.item(i)['fchinicio'],
								result.rows.item(i)['fchfin'],
								result.rows.item(i)['idresponsable'],
								result.rows.item(i)['estado'],
								result.rows.item(i)['fsname'],
								result.rows.item(i)['fslink'],
								result.rows.item(i)['obs']
								]);
					}			
				});
		});	
	};
}
	
//TABLA TRABAJADORES QUE PARTICIPAN EN EL TRABAJO___________________________________________________________________

function mostrarSubs() {
	DatosBDSubs (idseleccionado15);
	setTimeout('listSubs()',600);
	}

function listSubs() {
		$(document).ready(			
			function () {
				$('#dynamic15b').html( '<table cellpadding="0" cellspacing="0" border="0" class="display" id="example15b"></table>' );
				$('#example15b').dataTable( {
					"aaData": aDataSet15b,
						
					"aoColumns": [
						{ "sTitle": "Id", "bSearchable": false, "bVisible": false },
						{ "sTitle": "Id Trabajador", "bSearchable": false, "bVisible": false },
						{ "sTitle": "Trabajador" },
						{ "sTitle": "Subcontrata" },
						{ "sTitle": "Fecha inicio" },
						{ "sTitle": "Fecha fin" },
						{ "sTitle": "Estado", "bSearchable": false, "bVisible": false },
						{ "sTitle": "Obs", "bSearchable": false, "bVisible": false },
						],
						
					"sScrollY": "250px",
					"bPaginate": false,
					"bScrollCollapse": true,
						
					"sDom": 'lfrtip<"clear spacer">T',
					/*"sDom": 'T<"clear">lfrtip<"clear spacer">T',*/ //Muestra los botones de copy,print...
					"oTableTools": {
						"sRowSelect": "single","aButtons": ["select"], //Solo me muestra el boton select para poder seleccionar las filas.
							
					"aoColumnDefs": [ {
						"sClass": "center",
						"aTargets": [ -1, -2 ]
						} ]	
				}
				});
			
			//Cargo el COMBOBOX de Subcontratados ACTIVOS del formulario Subcontratados------------
			sacarSubsActivos ();
			setTimeout('$("#combosubsubcontratado").html(nuevossubsactivos);',200);
			//--------------------------------------------------	

			}
		);

	//Cargar datos del subcontrado seleccionado para editar en formulario	
		$(document).ready(
			function() {
    			$('#example15b tbody td').click( function () {
        		var aPos15b = oTable15b.fnGetPosition( this );
        		var aData15b = oTable15b.fnGetData( aPos15b[0] );
				
				idseleccionado15b =  aData15b[0];
				document.getElementById("combosubsubcontratado").value = aData15b[1];
				//El nombre y el apellido del instalador no lo cargo
				//La subcontrata a la que pertenece no se carga en el formulario
				document.getElementById("txtsubfchinicio").value = aData15b[4];
				document.getElementById("txtsubfchfin").value = aData15b[5];
				document.getElementById("combosubestado").value = aData15b[6];
				document.getElementById("txtsubobs2").value = aData15b[7];
				
				VnV15 (0, 0, 1, 1, 1, 0);
				VnVEsubcon (1);//No ver botones update y delete
         
    			});
     
			/* Init DataTables */
			oTable15b= $('#example15b').dataTable();
			});
		
	}

//DATOS DE TRABAJADORES QUE PARTICIPAN EN EL TRABAJO_________________________________________________________________
		
function DatosBDSubs (idseleccionado15) {
	var db;
        db = openDatabase("DBIWOHS", "0.1", "Database Isowin OHS", 500 * 1024 * 1024);
		if(db){	
		db.transaction( function(tx) {
			tx.executeSql("SELECT * FROM substrabajos LEFT JOIN subcontratados ON substrabajos.idsubcontratado=subcontratados.idsubcontratado JOIN subcontratas ON subcontratados.idsubcontrata=subcontratas.idsubcontrata WHERE idtrabajo=?", [idseleccionado15],
				function(tx, result){

					aDataSet15b = [];
					
					for(var i=0; i < result.rows.length; i++) {

						apellidosnombre=result.rows.item(i)['apellidos']+", "+result.rows.item(i)['nombre'];
		
						aDataSet15b.push([result.rows.item(i)['idsubtrabajo'],
								result.rows.item(i)['idsubcontratado'],
								apellidosnombre,
								result.rows.item(i)['subcontrata'],
								result.rows.item(i)['fchinicio'],
								result.rows.item(i)['fchfin'],
								result.rows.item(i)['estado'],
								result.rows.item(i)['obs']
							]); 
						//alert(result.rows.item(i)['curso']);
						//alert(result.rows.length);
					};	
					//oTable15b = $('#example15b').dataTable();	
				});	
			});
		}; 
	}

	

//=========================================================================================================					
/*NUEVO TRABAJO*/
	
	function addTrabajo (trabajo, descripcion, fchinicio, fchfin, idresponsable, estado, obs) {

		var db;
		FSError = false; nombreFS=null; rutaFS=null;//FileSystem
		addFile("myTRAB");
		db = openDatabase("DBIWOHS", "0.1", "Database Isowin OHS", 500 * 1024 * 1024);
		if(db){	
		  db.transaction( function(tx) {
			tx.executeSql("INSERT INTO trabajos (trabajo, descripcion, fchinicio, fchfin, idresponsable, estado, fsname, fslink, obs) VALUES(?,?,?,?,?,?,?,?,?)", [trabajo, descripcion, fchinicio, fchfin, idresponsable, estado, nombreFS, rutaFS, obs]);
			tx.executeSql("SELECT * FROM trabajos ORDER BY idtrabajo DESC", [], function(tx, result){
				nuevoId = result.rows.item(0)["idtrabajo"];
				CEXaddCita("Trabajo Subcontratado: " + trabajo, fchinicio, fchfin, "Descripción del trabajo subcontratado: " + descripcion, "TRB" + nuevoId);
				});
			if (!FSError) {apprise('Trabajo guardado');};
		})};
		setTimeout('mostrarTrabajos(intEstado15)',500);
	}
	
/*ACTUALIZAR TRABAJO*/
	function updateTrabajo (trabajo, descripcion, fchinicio, fchfin, idresponsable, estado, obs) {
	
		var db;
		FSError = false;//FileSystem
		addFile("myTRAB");
        db = openDatabase("DBIWOHS", "0.1", "Database Isowin OHS", 500 * 1024 * 1024);
		if(db){	
		  db.transaction( function(tx) {
			tx.executeSql("UPDATE trabajos SET trabajo=?, descripcion=?, fchinicio=?, fchfin=?, idresponsable=?, estado=?, fsname=?, fslink=?, obs=?  WHERE idtrabajo=?", [trabajo, descripcion, fchinicio, fchfin, idresponsable, estado, nombreFS, rutaFS, obs, idseleccionado15]);
			CEXupdateCita( "Trabajo Subcontratado: " + trabajo, fchinicio, fchfin, "Descripción del trabajo subcontratado: " + descripcion, "TRB" + idseleccionado15);
			if (!FSError) {apprise('Trabajo modificado');};
		})};
		setTimeout('mostrarTrabajos(intEstado15)',500);
	}					

/*BORRAR TRABAJO*/
	function removeTrabajo() {
		apprise('¿Eliminar trabajo subcontratado?', {'verify': true}, function(r) {
			if(r) { 
				var db;
				deleteFile();//FileSystem
				db = openDatabase("DBIWOHS", "0.1", "Database Isowin OHS", 500 * 1024 * 1024);
				if(db){	
					db.transaction(function(tx) {
					tx.executeSql("DELETE FROM trabajos WHERE idtrabajo=?",[idseleccionado15]);
					CEXdeleteCita("TRB" + idseleccionado15);
					if (!FSError) {apprise('trabajo eliminado');};
					});
				};
				setTimeout('mostrarTrabajos(intEstado15)',500);
			}
		});
	}

	/*BORRAR ARCHIVOS*/
	function deleteFSTRAB() {
		deleteLinkFile('trabajos');
		document.getElementById("FSTRAB").innerHTML = "<input type='file' id='myTRAB' />";
		setTimeout('mostrarTrabajos(intEstado15)',500);
	}

//=========================================================================================================					
/*NUEVO SUBCONTRATADO SELECCIONADO*/
	
	function addSubs (idsubcontratado, fchinicio, fchfin, estado, obs) {
		var db;
		db = openDatabase("DBIWOHS", "0.1", "Database Isowin OHS", 500 * 1024 * 1024);
		if(db){	
		  db.transaction( function(tx) {
			tx.executeSql("INSERT INTO substrabajos (idsubcontratado, idtrabajo, fchinicio, fchfin, estado, obs) VALUES(?,?,?,?,?,?)", [idsubcontratado, idseleccionado15, fchinicio, fchfin, estado, obs]);
			apprise('Trabajador incluido en el trabajo');
		})};
		setTimeout('mostrarSubs()',500);
	}
	
/*ACTUALIZAR SUBCONTRATADO SELECCIONADO*/
	function updateSubs (idsubcontratado, fchinicio, fchfin, estado, obs) {
		var db;
        db = openDatabase("DBIWOHS", "0.1", "Database Isowin OHS", 500 * 1024 * 1024);
		if(db){	
		  db.transaction( function(tx) {
			tx.executeSql("UPDATE substrabajos SET idsubcontratado=?, idtrabajo=?, fchinicio=?, fchfin=?, estado=?, obs=?  WHERE idsubtrabajo=?", [idsubcontratado, idseleccionado15, fchinicio, fchfin, estado, obs, idseleccionado15b]);
			apprise('Trabajador subcontratado modificado');
		})};
		setTimeout('mostrarSubs()',500);
	}					

/*BORRAR SUBCONTRATADO SELECCIONADO*/
	function removeSubs() {
		apprise('¿Eliminar asignación de trabajador subcontratado?', {'verify': true}, function(r) {
			if(r) { 
				var db;
				db = openDatabase("DBIWOHS", "0.1", "Database Isowin OHS", 500 * 1024 * 1024);
				if(db){	
					db.transaction(function(tx) {
					tx.executeSql("DELETE FROM substrabajos WHERE idsubtrabajo=?",[idseleccionado15b]);
					apprise('El trabajador ya no participa en el trabajo'); //alert("Persona borrada: "+ idseleccionado15);
					});
				};
				setTimeout('mostrarSubs()',500);
			}
		});
	}

//=========================================================================================================
/* VER NO VER*/
var verNCO= 0; var verLCO= 1; var verNTR= 0; var verLTR= 1; var verNSUB= 0; var verNONSUB= 1;

function VnV15 (Vnco, Vlco, Vntr, Vltr, Vnsub, Vnonsub) { 
	if (verNCO!=Vnco) {$("#newsubcontrata").toggle(200); verNCO=Vnco; $("#txtsubtnombre").focus();};
	if (verLCO!=Vlco) {$("#listasubcontratas").toggle(200); verLCO=Vlco;};
	if (verNTR!=Vntr) {$("#newtrabajo").toggle(200); verNTR=Vntr; $("#txttbtrabajo").focus();};
	if (verLTR!=Vltr) {$("#listatrabajos").toggle(200); verLTR=Vltr;};
	if (verNSUB!=Vnsub) {$("#newsubs").toggle(200); verNSUB=Vnsub; $("#combosubsubcontratado").focus();};
	if (verNONSUB!=Vnonsub) {$("#nonewsubs").toggle(200); verNONSUB=Vnonsub;};
}

//__________________________________________________________________________________________
/* VER NO VER EDIT (Update+Delete)*/
var verESUBCON=0;var verESUBS=0;var verETRAB=0;
function VnVEsubcon (Vesubcon) {if (verESUBCON!=Vesubcon) {$("#editsubcon").toggle(200); verESUBCON=Vesubcon;};}
function VnVEsubs (Vesubs) {if (verESUBS!=Vesubs) {$("#editsubs").toggle(200); $("#editsubs2").toggle(200); verESUBS=Vesubs;};}
function VnVEtrab (Vetrab) {if (verETRAB!=Vetrab) {$("#edittrab").toggle(200); $("#edittrab1").toggle(200); verETRAB=Vetrab;};}

//=========================================================================================================
	
//VER BOTON SEMAFORO_______________________________________________________________________

//Funcion de inicialización de la pestaña, ocultando el botón rojo.
function VbInit15() {document.getElementById('botonrojo15').style.display = 'none';}
//valor 1 se pone rojo, valor 0 se pone verde.	
function Vb15(intColor15) {
	if (INTcolor15!=intColor15) {$("#botonrojo15").toggle(200); $("#botonverde15").toggle(200); INTcolor15=intColor15;};
	}
//__________________________________________________________________________________________

//=========================================================================================================					
/*COMBOBOX DE SUBCONTRATADOS ACTIVOS*/

function sacarSubsActivos (){
	var db;
        db = openDatabase("DBIWOHS", "0.1", "Database Isowin OHS", 500 * 1024 * 1024);	
		//alert ("Estoy dentro");					
	if(db){
		db.transaction( function(tx) {
			tx.executeSql("SELECT * FROM subcontratados WHERE activo=?", ["Si"],
				function(tx, result){
					nuevossubsactivos = "<option selected></option>";
					for(var i=0; i < result.rows.length; i++) {	
						nuevossubsactivos = nuevossubsactivos + "<option value='" +result.rows.item(i)['idsubcontratado']+"'>"+result.rows.item(i)['apellidos'] + ", " + result.rows.item(i)['nombre'] +"</option> ";
					}			
				});
		});	
	
	};
}
//=========================================================================================================		