//COMUNICACIONES EXTERNAS (51)

	var idseleccionado51;
	var intEstado51;
	var INTcolor51; //Color del semaforo en verde
								
//TABLA COMUNICACIONES EXTERNAS_____________________________________________________________________________________________________________
function mostrarComExts(intEst51) {
	if (intEstado51!=intEst51) {
		intEstado51=intEst51; 
		Vb51();};
	sacarComExts (intEstado51);
	setTimeout('listComExts()',500);
	}

function listComExts() {
			$(document).ready(			
			function () {
				$('#dynamic51').html( '<table cellpadding="0" cellspacing="0" border="0" class="display" id="example51"></table>' );
				$('#example51').dataTable( {
					"aaData": aDataSet51,
						
					"aoColumns": [
						{ "sTitle": "Id"/*, "bSearchable": false, "bVisible": false*/ },
						{ "sTitle": "Comunicación" },
						{ "sTitle": "Emisor" },
						{ "sTitle": "Descripción", "bSearchable": false, "bVisible": false },
						{ "sTitle": "Fecha entrada" },
						{ "sTitle": "Aprobado" },
						{ "sTitle": "Respuesta", "bSearchable": false, "bVisible": false },
						{ "sTitle": "Fecha respuesta", "bSearchable": false, "bVisible": false },
						{ "sTitle": "Estado" }
						],
						
					"sScrollY": "430px",
        			"bPaginate": false,
        			"bScrollCollapse": true,
						
					"sDom": 'lfrtip<"clear spacer">T',
					/*"sDom": 'T<"clear">lfrtip<"clear spacer">T',*/ //Muestra los botones de copy,print...
					"oTableTools": {
						"sRowSelect": "single","aButtons": ["select"], //Solo me muestra el boton select para poder seleccionar las filas.
							
					"aoColumnDefs": [ {
						"sClass": "center",
						"aTargets": [ -1, -2 ]
						} ]
						
				}});

				//Cargo el COMBOBOX de responsables del formulario NCs------------
				sacarResponsables ();
				setTimeout('$("#comboacpresp3").html(nuevosresponsables);',200);
				//--------------------------------------------------
				
				});
	//Cargar datos de proveedor para editar en formulario	
			$(document).ready(
				function() {
    			$('#example51 tbody td').click( function () {
        		/* Get the position of the current data from the node */
        		var aPos51 = oTable51.fnGetPosition( this );
         
        		/* Get the data array for this row */
        		var aData51 = oTable51.fnGetData( aPos51[0] );
				/*alert("Ok "+aData[0]);*/
					
				idseleccionado51 =  aData51[0];
				document.getElementById("txtcomext").value = aData51[1];
				document.getElementById("txcetemisor").value = aData51[2];
				document.getElementById("txtcedescripcion").value = aData51[3];
				document.getElementById("txtcefchcomext").value = aData51[4];
				document.getElementById("comboceaprobacion").value = aData51[5];
				document.getElementById("txtcerespuesta").value = aData51[6];
				document.getElementById("txtcefchrespuesta").value = aData51[7];
				document.getElementById("comboceestado").value = aData51[8];
				document.getElementById("txtceobs").value = aData51[11];
				
				//File System-----------------------------------------------------------
					if (aData51[10]) {document.getElementById("FSCOM").innerHTML = "<a class='doc' href='"+aData51[10]+"' target='_blank'>"+aData51[9]+"</a> <img src='img/miniboton.jpg' style='vertical-align:middle' onclick='deleteFSCOM();' />"; 
							nombreFS=aData51[9]; rutaFS=aData51[10]}
					else {document.getElementById("FSCOM").innerHTML = "<input type='file' id='myCOM' />";};
				//----------------------------------------------------------------------

				VnV51 (1, 1, 0);
				VnVEcomext (1);//No ver botones update y delete
         
    			});
     
   				 /* Init DataTables */
   				 oTable51 = $('#example51').dataTable();
				});
		
	}
	
//DATOS COMUNICACIONES EXTERNAS_________________________________________________

function sacarComExts (intEstado51){
	var db;
        db = openDatabase("DBIWOHS", "0.1", "Database Isowin OHS", 500 * 1024 * 1024);	
	
	var estado51="estado='Abierta' ";
	if (intEstado51==1) {estado51="estado='Cerrada' ";};	
	if (intEstado51==2) {estado51="estado='Anulada' ";};	
							
	if(db){
		db.transaction( function(tx) {
			//La trazabilidad igual a RL, identifica que es un requisito legal y no de cliente entre todos los requisitos
			tx.executeSql("SELECT * FROM comexts WHERE " + estado51, [],
				function(tx, result){
					aDataSet51 = [];
					for(var i=0; i < result.rows.length; i++) {	
						
						aDataSet51.push([result.rows.item(i)['idcomext'],
								result.rows.item(i)['comext'],
								result.rows.item(i)['emisor'],
								result.rows.item(i)['descripcion'],
								result.rows.item(i)['fchcomext'],
								result.rows.item(i)['aprobacion'],
								result.rows.item(i)['respuesta'],
								result.rows.item(i)['fchrespuesta'],
								result.rows.item(i)['estado'],
								result.rows.item(i)['fsname'],
								result.rows.item(i)['fslink'],
								result.rows.item(i)['obs']
								]);
					};			
				});
		});	
	};
}

//=========================================================================================================					
/*NUEVA COMUNICACIÓN EXTERNA*/
	function addComExt (comext, emisor, descripcion, fchcomext, aprobacion, respuesta, fchrespuesta, estado, obs) {
		var db;
		FSError = false; nombreFS=null; rutaFS=null;//FileSystem
		addFile("myCOM");
		db = openDatabase("DBIWOHS", "0.1", "Database Isowin OHS", 500 * 1024 * 1024);
		if(db){	
		  db.transaction( function(tx) {
			tx.executeSql("INSERT INTO comexts (comext, emisor, descripcion, fchcomext, aprobacion, respuesta, fchrespuesta, estado, obs) VALUES(?,?,?,?,?,?,?,?,?)", [comext, emisor, descripcion, fchcomext, aprobacion, respuesta, fchrespuesta, estado, obs]);
			tx.executeSql("SELECT * FROM comexts ORDER BY idcomext DESC", [], function(tx, result){
				idseleccionado51 = result.rows.item(0)["idcomext"];
				if (!FSError) {apprise('La comunicación externa ha sido registrada');};
			});
			
		})};

		setTimeout('updateFSComExt()',300);
		setTimeout('mostrarComExts(intEstado51)',500);
		//VnV51 (1, 1, 0);
	}
	
/*ACTUALIZO COMUNICACION EXTERNA*/
		function updateComExt (comext, emisor, descripcion, fchcomext, aprobacion, respuesta, fchrespuesta, estado, obs) {
		var db;
		FSError = false; nombreFS=null; rutaFS=null;//FileSystem
		addFile("myCOM");
		db = openDatabase("DBIWOHS", "0.1", "Database Isowin OHS", 500 * 1024 * 1024);
		if(db){	
		  db.transaction( function(tx) {
			tx.executeSql("UPDATE comexts SET comext=?, emisor=?, descripcion=?, fchcomext=?, aprobacion=?, respuesta=?, fchrespuesta=?, estado=?, obs=? WHERE idcomext=?", [comext, emisor, descripcion, fchcomext, aprobacion, respuesta, fchrespuesta, estado, obs, idseleccionado51]);
			if (!FSError) {apprise('La comunicación externa ha sido modificada');};
		})};
		
		setTimeout('updateFSComExt()',300);
		setTimeout('mostrarComExts(intEstado51)',500);
		//VnV51 (1, 1, 0);
	}

/*ACTUALIZAR ARCHIVOS*/
function updateFSComExt() {
var db;
db = openDatabase("DBIWOHS", "0.1", "Database Isowin OHS", 500 * 1024 * 1024);
		if(db){	
		db.transaction( function(tx) {
			if (nombreFS!=null) {tx.executeSql("UPDATE comexts SET fsname=?, fslink=? WHERE idcomext=?", [nombreFS, rutaFS, idseleccionado51]);
								document.getElementById("FSCOM").innerHTML = "<a class='doc' href='"+rutaFS+"' target='_blank'>"+nombreFS+"</a> <img src='img/miniboton.jpg' style='vertical-align:middle' onclick='deleteFSCOM();' />";};
			});
		};
}					

/*BORRO COMUNICACIÓN EXTERNA*/
	function removeComExt() {
		apprise('¿Eliminar la comunicación externa?', {'verify': true}, function(r) {
			if(r) {
			var db;
			deleteFile();//FileSystem
			db = openDatabase("DBIWOHS", "0.1", "Database Isowin OHS", 500 * 1024 * 1024);
			if(db){	
				db.transaction(function(tx) {
					tx.executeSql("DELETE FROM comexts WHERE idcomext=?",[idseleccionado51]);
					if (!FSError) {apprise('La comunicación externa ha sido borrada');};
				})};};

				setTimeout('mostrarComExts(intEstado51)',500);
				//VnV51 (1, 1, 0);
		});
	}

	/*BORRAR ARCHIVOS*/
	function deleteFSCOM() {
		deleteLinkFile('comexts');
		document.getElementById("FSCOM").innerHTML = "<input type='file' id='myCOM' />";
		setTimeout('mostrarComExts(intEstado51)',500);
	}

//=========================================================================================================					
/*NUEVA APC51*/
	function addACP51 (acp, codacp, tipo, fchalta, responsable, equipo, acciones, fchprevista) {
		var origen = "La comunicación externa: " +  idseleccionado51;
		var codtrz = "ce"+idseleccionado51;
		addMiniACP(acp, codacp, tipo, origen, fchalta, responsable, equipo, acciones, fchprevista, codtrz);
	}
	
//=========================================================================================================
/* VER NO VER*/
var verNRL=1; var verLRL= 1; var verNACP3= 0;

function VnV51 (Vnrl, Vlrl, Vnacp3) { 
	if (verNRL!=Vnrl) {$("#newcomext").toggle(200); verNRL=Vnrl;};
	if (verLRL!=Vlrl) {$("#listacomexts").toggle(200); verLRL=Vlrl;};
	if (verNACP3!=Vnacp3) {$("#newacp3").toggle(200); verNACP3=Vnacp3; $("#txtacp3").focus();};
	}

//VER BOTON SEMAFORO_______________________________________________________________________

//Funcion de inicialización de la pestaña, ocultando el botón rojo.
function VbInit51() {
	document.getElementById('botonverde51').style.display = 'inherit';
	document.getElementById('botonrojo51').style.display = 'none';
	document.getElementById('botonamar51').style.display = 'none';
	INTcolor51 = 1;
	}
	
//valor 1 se pone rojo, valor 0 se pone verde.	
function Vb51() {
	if (INTcolor51==1) {$("#botonverde51").toggle(200); $("#botonamar51").toggle(200);};
	if (INTcolor51==2) {$("#botonamar51").toggle(200); $("#botonrojo51").toggle(200);};
	if (INTcolor51==3) {$("#botonrojo51").toggle(200); $("#botonverde51").toggle(200); INTcolor51=0;};
	INTcolor51 = INTcolor51 + 1;
	}

/* VER NO VER EDIT (Update+Delete)*/
var verECOMEXT=0;
function VnVEcomext(Vecomext) {if (verECOMEXT!=Vecomext) {$("#editcomext").toggle(200); verECOMEXT=Vecomext;};}

//__________________________________________________________________________________________

