//CURSOS (12)

	var idseleccionado12;
	var idseleccionado12b;
	var intEstado12;
	var INTcolor12 = 0; //Color del semaforo en verde
	var nuevasformaciones; //Listado de formaciones para COMBOBOX
				
				
//TABLA CURSOS_____________________________________________________________________________________________________________

function mostrarCursos(intEst12) {
	intEstado12=intEst12;
	sacarCursos (intEstado12);
	setTimeout('listCursos()',500);
	Vb12(intEst12);
	}

function listCursos() {
		$(document).ready(			
			function () {
				$('#dynamic12').html( '<table cellpadding="0" cellspacing="0" border="0" class="display" id="example12"></table>' );
				$('#example12').dataTable( {
					"aaData": aDataSet12,
						
					"aoColumns": [
						{ "sTitle": "Id"/*, "bSearchable": false, "bVisible": false*/ },
						{ "sTitle": "Curso" },
						{ "sTitle": "Cod. Curso" },
						{ "sTitle": "Objetivos", "bSearchable": false, "bVisible": false },
						{ "sTitle": "Estado" },
						{ "sTitle": "Alumnos", "bSearchable": false, "bVisible": false },
						{ "sTitle": "Fecha Inicio" },
						{ "sTitle": "Fecha Fin" },
						{ "sTitle": "Horario" },
						{ "sTitle": "Nº Horas" }
						],
						
					"sScrollY": "600px",
					"bPaginate": false,
					"bScrollCollapse": true,
						
					"sDom": 'lfrtip<"clear spacer">T',
					/*"sDom": 'T<"clear">lfrtip<"clear spacer">T',*/ //Muestra los botones de copy,print...
					"oTableTools": {
						"sRowSelect": "single","aButtons": ["select"], //Solo me muestra el boton select para poder seleccionar las filas.
							
					"aoColumnDefs": [ {
						"sClass": "center",
						"aTargets": [ -1, -2 ]
						} ]
						
				}});

				//Cargo el COMBOBOX de formaciones del formulario------------
				sacarFormaciones();
				setTimeout('$("#combocuconval").html(nuevasformaciones);',200);
				//--------------------------------------------------	
				
				});
	//Cargar datos del equipo para editar en formulario	
		$(document).ready(
			function() {
    			$('#example12 tbody td').click( function () {
        		/* Get the position of the current data from the node */
				var aPos12 = oTable12.fnGetPosition( this );
         
        		/* Get the data array for this row */
				var aData12 = oTable12.fnGetData( aPos12[0] );
				/*alert("Ok "+aData[0]);*/
				
				idseleccionado12 =  aData12[0];
				document.getElementById("txtcucodcurso").value = aData12[1];
				document.getElementById("txtcucurso").value = aData12[2];
				document.getElementById("txtcuobjetivos").value = aData12[3];
				document.getElementById("combocuestado").value = aData12[4];
				document.getElementById("txtcualumnos").value = aData12[5];
				document.getElementById("txtcufchinicio").value = aData12[6];
				document.getElementById("txtcufchfin").value = aData12[7];
				document.getElementById("txtcuhorario").value = aData12[8];
				document.getElementById("txtcunhoras").value = aData12[9];
				document.getElementById("txtcuvalalumnos").value = aData12[10];
				document.getElementById("txtcuvalformador").value = aData12[11];
				document.getElementById("txtcuvaljefe").value = aData12[12];
				document.getElementById("txtcufchvaljefe").value = aData12[13];
				document.getElementById("combocuconval").value = aData12[14];
				document.getElementById("txtcuobs").value = aData12[17];

				//File System-----------------------------------------------------------
					if (aData12[16]) {document.getElementById("FSCUR").innerHTML = "<a class='doc' href='"+aData12[16]+"' target='_blank'>"+aData12[15]+"</a> <img src='img/miniboton.jpg' style='vertical-align:middle' onclick='deleteFSCUR();' />"; 
							nombreFS=aData12[15]; rutaFS=aData12[16]}
					else {document.getElementById("FSCUR").innerHTML = "<input type='file' id='myCUR' />";};
				//----------------------------------------------------------------------
			
			DatosBDalumnos(idseleccionado12);
			setTimeout('listAlumnos();',200);				
			
				VnV12 (1, 0, 1, 0, 0);
				VnVEfor (1);//No ver botones update y delete

         
				});
     
   				 /* Init DataTables */
   				 oTable12= $('#example12').dataTable();
			}
		);
		
	}
	
function sacarCursos (intEstado12){
	var db;
        db = openDatabase("DBIWOHS", "0.1", "Database Isowin OHS", 500 * 1024 * 1024);	
		//alert ("Estoy dentro");					
	var estado12="WHERE estado!='Finalizado' AND estado!='Anulado' ";
	if (intEstado12==1) {estado12="WHERE estado='Finalizado' OR estado='Anulado' ";};
	if(db){
		db.transaction( function(tx) {
			tx.executeSql("SELECT * FROM cursos " + estado12, [],
				function(tx, result){
					aDataSet12 = [];
					for(var i=0; i < result.rows.length; i++) {	
						aDataSet12.push([result.rows.item(i)['idcurso'],
								result.rows.item(i)['codcurso'],
								result.rows.item(i)['curso'],
								result.rows.item(i)['objetivos'],
								result.rows.item(i)['estado'],
								result.rows.item(i)['alumnos'],
								result.rows.item(i)['fchinicio'],
								result.rows.item(i)['fchfin'],
								result.rows.item(i)['horario'],
								result.rows.item(i)['nhoras'],
								result.rows.item(i)['valalumnos'],
								result.rows.item(i)['valformador'],
								result.rows.item(i)['valjefe'],
								result.rows.item(i)['fchvaljefe'],
								result.rows.item(i)['conval'],
								result.rows.item(i)['fsname'],
								result.rows.item(i)['fslink'],
								result.rows.item(i)['obs'],
								]);
					}			
				});
		});	
	};
}
	
//TABLA ALUMNOS_____________________________________________________________________________________________________________

function listAlumnos() {
		$(document).ready(			
			function () {
				$('#dynamic12b').html( '<table cellpadding="0" cellspacing="0" border="0" class="display" id="example12b"></table>' );
				$('#example12b').dataTable( {
					"aaData": aDataSet12b,
						
					"aoColumns": [
						{ "sTitle": "Id"/*, "bSearchable": false, "bVisible": false*/ },
						{ "sTitle": "Nombre" },
						{ "sTitle": "Apellidos" },
						{ "sTitle": "DNI" },
						{ "sTitle": "Valoración", "bSearchable": false, "bVisible": false },
						{ "sTitle": "Fecha valoración", "bSearchable": false, "bVisible": false },
						{ "sTitle": "Diploma" }
						],
						
					"sScrollY": "250px",
        			"bPaginate": false,
        			"bScrollCollapse": true,
						
					"sDom": 'lfrtip<"clear spacer">T',
					/*"sDom": 'T<"clear">lfrtip<"clear spacer">T',*/ //Muestra los botones de copy,print...
					"oTableTools": {
						"sRowSelect": "single","aButtons": ["select"], //Solo me muestra el boton select para poder seleccionar las filas.
							
					"aoColumnDefs": [ {
						"sClass": "center",
						"aTargets": [ -1, -2 ]
						} ]
						
				}});
				
				});
	//Cargar datos de la calibración para editar en formulario	
		$(document).ready(
				function() {
    			$('#example12b tbody td').click( function () {
        		/* Get the position of the current data from the node */
        		var aPos12b = oTable12b.fnGetPosition( this );
         
        		/* Get the data array for this row */
        		var aData12b = oTable12b.fnGetData( aPos12b[0] );
				/*alert("Ok "+aData[0]);*/
				
				idseleccionado12b =  aData12b[0];
				//el aData9[1] es el idDiseno
				document.getElementById("eticupenombreyapellidos").innerHTML ="<h3>" + aData12b[1] +" "+ aData12b[2] +" ("+ aData12b[3]+ ")</h3>";
				document.getElementById("txtcupevaloracion").value = aData12b[4];
				document.getElementById("txtcupefchvaloracion").value = aData12b[5];
				document.getElementById("txtcupeobs").value = aData12b[9];

				//File System-----------------------------------------------------------
					if (aData12b[8]) {document.getElementById("FSALUM").innerHTML = "<a class='doc' href='"+aData12b[8]+"' target='_blank'>"+aData12b[7]+"</a> <img src='img/miniboton.jpg' style='vertical-align:middle' onclick='deleteFSALUM();' />"; 
							nombreFS=aData12b[7]; rutaFS=aData12b[8]}
					else {document.getElementById("FSALUM").innerHTML = "<input type='file' id='myALUM' />";};
				//----------------------------------------------------------------------
				
			VnV12 (1, 0, 1, 1, 0);
         
    			});
     
   				 /* Init DataTables */
   				 oTable12b= $('#example12b').dataTable();
				});
		
	}

//DATOS ALUMNOS FILTRADAS POR CURSO______________________________________________________________________
		
function DatosBDalumnos(idseleccionado12) {
	var db;
        db = openDatabase("DBIWOHS", "0.1", "Database Isowin OHS", 500 * 1024 * 1024);
		if(db){	
		db.transaction( function(tx) {
			tx.executeSql("SELECT * FROM personas JOIN cursospersonas ON personas.idpersona=cursospersonas.idpersona WHERE idcurso=?", [idseleccionado12],
				function(tx, result){
					aDataSet12b = [];
					for(var i=0; i < result.rows.length; i++) {

						var linknull = "";//File System
						if (result.rows.item(i)['fsname']) {linknull = result.rows.item(i)['fsname'];};
								
						aDataSet12b.push([result.rows.item(i)['idpersona'],
								result.rows.item(i)['nombre'],
								result.rows.item(i)['apellidos'],
								result.rows.item(i)['dni'],
								result.rows.item(i)['valoracion'],
								result.rows.item(i)['fchvaloracion'],
								"<a href='"+result.rows.item(i)['fslink']+"' target='_blank'>"+linknull+"</a>",
								result.rows.item(i)['fsname'],
								result.rows.item(i)['fslink'],
								result.rows.item(i)['obs']]);
												
				}		
   				 /* Init DataTables */
   				 oTable11 = $('#example12b').dataTable();				
				 
				});
				
				
		});
		
	}}

//TABLA POSIBLES ALUMNOS_____________________________________________________________________________________________________________

function mostrarPosiblesAlumnos() {
	setTimeout('listPosiblesAlumnos()',200);
	VnV12 (1, 0, 1, 0, 1);
	}
	
function listPosiblesAlumnos() {
		$(document).ready(			
			function () {
				$('#dynamic12c').html( '<table cellpadding="0" cellspacing="0" border="0" class="display" id="example12c"></table>' );
				$('#example12c').dataTable( {
					"aaData": aDataSet15,
						
					"aoColumns": [
						{ "sTitle": "Id"/*, "bSearchable": false, "bVisible": false*/ },
						{ "sTitle": "Nombre" },
						{ "sTitle": "Apelllidos" },
						{ "sTitle": "dni" },
						{ "sTitle": "Fecha Nacimiento", "bSearchable": false, "bVisible": false },
						{ "sTitle": "Fecha de Alta" },
						{ "sTitle": "Link CV", "bSearchable": false, "bVisible": false},
						{ "sTitle": "Puesto de Trabajo", "bSearchable": false, "bVisible": false }
						],
						
					"sScrollY": "250px",
					"bPaginate": false,
					"bScrollCollapse": true,
						
					"sDom": 'lfrtip<"clear spacer">T',
					/*"sDom": 'T<"clear">lfrtip<"clear spacer">T',*/ //Muestra los botones de copy,print...
					"oTableTools": {
						"sRowSelect": "single","aButtons": ["select"], //Solo me muestra el boton select para poder seleccionar las filas.
							
					"aoColumnDefs": [ {
						"sClass": "center",
						"aTargets": [ -1, -2 ]
						} ]
						
				}});
				
			}
		);
	
	//Cargar datos de la calibración para editar en formulario	
		$(document).ready(
			function() {
				$('#example12c tbody td').click( function () {
					/* Get the position of the current data from the node */
					var aPos12c = oTable12c.fnGetPosition( this );
					/* Get the data array for this row */
					var aData12c = oTable12c.fnGetData( aPos12c[0] );
					/*alert("Ok "+aData[0]);*/
					idseleccionado12c =  aData12c[0];
				});
   				 /* Init DataTables */
   				 oTable12c= $('#example12c').dataTable();
			}
		);
		
	}	

//=========================================================================================================					
/*NUEVO CURSO*/
	
	function addCurso(curso, codcurso, objetivos, estado, alumnos, fchinicio, fchfin, horario, nhoras, valalumnos, valformador, valjefe, fchvaljefe, conval, obs) {
		var db;
		FSError = false; nombreFS=null; rutaFS=null;//FileSystem 
		addFile("myCUR");//FileSystem
		db = openDatabase("DBIWOHS", "0.1", "Database Isowin OHS", 500 * 1024 * 1024);
		if(db){	
		  db.transaction( function(tx) {
			tx.executeSql("INSERT INTO cursos (curso, codcurso, objetivos, estado, alumnos, fchinicio, fchfin, horario, nhoras, valalumnos, valformador, valjefe, fchvaljefe, conval, obs) VALUES(?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)", [curso, codcurso, objetivos, estado, alumnos, fchinicio, fchfin, horario, nhoras, valalumnos, valformador, valjefe, fchvaljefe, conval, obs]);
			tx.executeSql("SELECT * FROM cursos ORDER BY idcurso DESC", [], function(tx, result){
				idseleccionado12 = result.rows.item(0)["idcurso"];
				CEXaddCita("Curso: " + curso, fchinicio, fchfin, "Curso: "+ curso +" del " + fchinicio + " al " + fchfin + " (" + horario + ")", "RHC" + idseleccionado12);
				CEXaddCita("Eficacia curso: " + curso, fchvaljefe, fchvaljefe, "Valoración de la eficacia del curso: "+ curso + " (" + idseleccionado12 + ")", "RHE" + idseleccionado12);
				});
			if (!FSError) {apprise('El curso ha sido guardado');};
		});
		};
		
		setTimeout('updateFSCursos()',300);
		setTimeout('mostrarCursos(intEstado12)',500);
		 VnV12 (0, 1, 0, 0, 0);
	}
	
/*ACTUALIZAR CURSO*/
	function updateCurso (curso, codcurso, objetivos, estado, alumnos, fchinicio, fchfin, horario, nhoras, valalumnos, valformador, valjefe, fchvaljefe, conval, obs) {
		var db;
		FSError = false; nombreFS=null; rutaFS=null;//FileSystem 
		addFile("myCUR");//FileSystem
        db = openDatabase("DBIWOHS", "0.1", "Database Isowin OHS", 500 * 1024 * 1024);
		if(db){	
		  db.transaction( function(tx) {
			tx.executeSql("UPDATE cursos SET curso=?, codcurso=?, objetivos=?, estado=?, alumnos=?, fchinicio=?, fchfin=?, horario=?, nhoras=?, valalumnos=?, valformador=?, valjefe=?, fchvaljefe=?, conval=?, obs=? WHERE idcurso=?", [curso, codcurso, objetivos, estado, alumnos, fchinicio, fchfin, horario, nhoras, valalumnos, valformador, valjefe, fchvaljefe, conval, obs, idseleccionado12]);
			});
			CEXupdateCita("Curso: " + curso, fchinicio, fchfin, "Curso: "+ curso +" del " + fchinicio + " al " + fchfin + " (" + horario + ")", "RHC" + idseleccionado12);
			CEXupdateCita("Eficacia curso: " + curso, fchvaljefe, fchvaljefe, "Valoración de la eficacia del curso: "+ curso + " (" + idseleccionado12 + ")", "RHE" + idseleccionado12);
			if (!FSError) {apprise('El curso ha sido modificado');};
		};
		setTimeout('updateFSCursos()',300);
		setTimeout('mostrarCursos(intEstado12)',500);
	}					

/*ACTUALIZAR ARCHIVOS*/
function updateFSCursos() {
var db;
db = openDatabase("DBIWOHS", "0.1", "Database Isowin OHS", 500 * 1024 * 1024);
		if(db){	
		db.transaction( function(tx) {
			if (nombreFS!=null) {tx.executeSql("UPDATE cursos SET fsname=?, fslink=? WHERE idcurso=?", [nombreFS, rutaFS, idseleccionado12]);
								document.getElementById("FSCUR").innerHTML = "<a class='doc' href='"+rutaFS+"' target='_blank'>"+nombreFS+"</a> <img src='img/miniboton.jpg' style='vertical-align:middle' onclick='deleteFSCUR();' />";};
			});
		};
}

/*BORRAR CURSO*/
	function removeCurso() {
		apprise('¿Eliminar curso?', {'verify': true}, function(r) {
			if(r) { 
				var db;
				deleteFile();//FileSystem
				db = openDatabase("DBIWOHS", "0.1", "Database Isowin OHS", 500 * 1024 * 1024);
				if(db){	
				db.transaction(function(tx) {
					tx.executeSql("DELETE FROM cursos WHERE idcurso=?", [idseleccionado12]);
					tx.executeSql("DELETE FROM cursospersonas WHERE idcurso=?", [idseleccionado12]); //limpia alumnos asociados a este curso de formaciÃ³n.
				});
				CEXdeleteCita("RHC" + idseleccionado12);
				CEXdeleteCita("RHE" + idseleccionado12);
				if (!FSError) {apprise('El curso ha sido borrado');};
				};
			setTimeout('mostrarCursos(intEstado12)',500);
			};
		});
		
		 VnV12 (0, 1, 0, 0, 0);
	}

	/*BORRAR ARCHIVOS*/
	function deleteFSCUR() {
		deleteLinkFile('cursos');
		document.getElementById("FSCUR").innerHTML = "<input type='file' id='myCUR' />";
		setTimeout('mostrarCursos(intEstado12);',500);
	}

	
//=========================================================================================================					
/*NUEVO ALUMNO*/
	
	function addAlumno () {
		var db;
		db = openDatabase("DBIWOHS", "0.1", "Database Isowin OHS", 500 * 1024 * 1024);
		if(db){
		  db.transaction( function(tx) {
			tx.executeSql("INSERT INTO cursospersonas (idcurso, idpersona) VALUES(?,?)", [ idseleccionado12, idseleccionado12c]);
			apprise('Alumno seleccionado');
		})};
		
		DatosBDalumnos(idseleccionado12);
		setTimeout('listAlumnos()',200);
		VnV12 (1, 0, 1, 0, 0);
	}
	
/*ACTUALIZAR ALUMNO*/
	function updateValoracion (valoracion, fchvaloracion, obs) {
		var db;
		FSError = false; nombreFS=null; rutaFS=null;//FileSystem 
		addFile("myALUM");//FileSystem
		db = openDatabase("DBIWOHS", "0.1", "Database Isowin OHS", 500 * 1024 * 1024);
		if(db){	
		  db.transaction( function(tx) {
			tx.executeSql("UPDATE cursospersonas SET valoracion=?, fchvaloracion=?, obs=? WHERE idcurso=? AND idpersona=?", [valoracion, fchvaloracion, obs, idseleccionado12, idseleccionado12b]);
			if (!FSError) {apprise('La valoración del alumno ha cambiado');};
		})};
		
		DatosBDalumnos(idseleccionado12);
		setTimeout('updateFSAlumnos()',200);
		setTimeout('listAlumnos()',400);
		VnV12 (1, 0, 1, 0, 0);
	}

/*ACTUALIZAR ARCHIVOS*/
function updateFSAlumnos() {
var db;
db = openDatabase("DBIWOHS", "0.1", "Database Isowin OHS", 500 * 1024 * 1024);
		if(db){	
		db.transaction( function(tx) {
			if (nombreFS!=null) {tx.executeSql("UPDATE cursospersonas SET fsname=?, fslink=? WHERE idcurso=? AND idpersona=?", [nombreFS, rutaFS, idseleccionado12, idseleccionado12b]);
								document.getElementById("FSALUM").innerHTML = "<a class='doc' href='"+rutaFS+"' target='_blank'>"+nombreFS+"</a> <img src='img/miniboton.jpg' style='vertical-align:middle' onclick='deleteFSALUM();' />";};
			});
		};
}

/*BORRAR ALUMNO*/
	function removeAlumno () {
		apprise('¿Eliminar alumno?', {'verify': true}, function(r) {
			if(r) { 
				var db;
				//deleteFile();//FileSystem
				db = openDatabase("DBIWOHS", "0.1", "Database Isowin OHS", 500 * 1024 * 1024);
				if(db){	
					db.transaction(function(tx) {
					tx.executeSql("DELETE FROM cursospersonas WHERE idcurso=? AND idpersona=?",[idseleccionado12, idseleccionado12b]);
					apprise('El alumno ha sido borrado');
					});
				};
			DatosBDalumnos(idseleccionado12); //No recuerdo si esto sirve para algo
			setTimeout('listAlumnos()',200);				
			};
		VnV12 (1, 0, 1, 0, 0);
		});
	}
	
	/*BORRAR ARCHIVOS*/
	function deleteFSALUM() {
		deleteLinkFile('cursospersonas');
		document.getElementById("FSALUM").innerHTML = "<input type='file' id='myALUM' />";
		setTimeout('listAlumnos();',500);
	}

//=========================================================================================================
/* VER NO VER*/
var verNCU= 0; var verLCU= 1; var verLAL= 0; var verVAL= 0; var verLNAL= 0;

function VnV12 (Vncu, Vlcu, Vlal, Vval, Vlnal) { 
	if (verNCU!=Vncu) {$("#newcurso").toggle(200); verNCU=Vncu; $("#txtcucurso").focus();};
	if (verLCU!=Vlcu) {$("#listacursos").toggle(200); verLCU=Vlcu;};
	if (verLAL!=Vlal) {$("#listaalumnos").toggle(200); verLAL=Vlal;};
	if (verVAL!=Vval) {$("#infoalumno").toggle(200); verVAL=Vval;};
	if (verLNAL!=Vlnal) {$("#newalumno").toggle(200); verLNAL=Vlnal;};
}

/* VER NO VER EDIT (Update+Delete)*/
var verEFOR=0;
function VnVEfor (Vefor) {if (verEFOR!=Vefor) {$("#editfor").toggle(200); verEFOR=Vefor;};}

//=========================================================================================================

//VER BOTON SEMAFORO_______________________________________________________________________

//Funcion de inicialización de la pestaña, ocultando el botón rojo.
function VbInit12() {document.getElementById('botonrojo12').style.display = 'none';}
//valor 1 se pone rojo, valor 0 se pone verde.	
function Vb12(intColor12) {
	if (INTcolor12!=intColor12) {$("#botonrojo12").toggle(200); $("#botonverde12").toggle(200); INTcolor12=intColor12;};
	}
//__________________________________________________________________________________________	
	
//=========================================================================================================					
/*COMBOBOX DE FORMACIONES*/

function sacarFormaciones (){
	var db;
        db = openDatabase("DBIWOHS", "0.1", "Database Isowin OHS", 500 * 1024 * 1024);						
	if(db){
		db.transaction( function(tx) {
			tx.executeSql("SELECT * FROM formaciones", [],
				function(tx, result){
					nuevasformaciones = "<option selected></option>";
					for(var i=0; i < result.rows.length; i++) {	
						nuevasformaciones = nuevasformaciones + "<option value='" +result.rows.item(i)['idformacion']+"'>"+result.rows.item(i)['formacion']+"</option> ";
					}			
				});
		});	
	
	};
}
//=========================================================================================================		
