//PERSONAS (15)

	var idseleccionado15;
	var idseleccionado15a;
	var idseleccionado15d;
	var intEstado15;
	var intEstado15a;
	var INTcolor15 = 0; //Color del semaforo en verde
	var INTcolor15a = 0; //Color del semaforo en verde
	var nuevosepis = "{0:'Please select...', 1:'hola', 2:'due', 3:'traix'}"; //Listado de epis para COMBOBOX de la tabla de entrega de epis
	
	
//TABLA PERSONAS (15)_____________________________________________________________________________________________________________

function mostrarPersonas(intEst15) {
	intEstado15=intEst15;
	sacarPersonas (intEstado15);
	setTimeout('listPersonas()',500);
	Vb15(intEst15);
	}

function listPersonas() {
		$(document).ready(			
			function () {
				$('#dynamic15').html( '<table cellpadding="0" cellspacing="0" border="0" class="display" id="example15"></table>' );
				$('#example15').dataTable( {
					"aaData": aDataSet15,
						
					"aoColumns": [
						{ "sTitle": "Id"/*, "bSearchable": false, "bVisible": false*/ },
						{ "sTitle": "Nombre" },
						{ "sTitle": "Apelllidos" },
						{ "sTitle": "DNI" },
						{ "sTitle": "N.SS" },
						{ "sTitle": "F. Nac." }
						],
						
					"sScrollY": "600px",
        			"bPaginate": false,
        			"bScrollCollapse": true,
						
					"sDom": 'lfrtip<"clear spacer">T',
					/*"sDom": 'T<"clear">lfrtip<"clear spacer">T',*/ //Muestra los botones de copy,print...
					"oTableTools": {
						"sRowSelect": "single","aButtons": ["select"], //Solo me muestra el boton select para poder seleccionar las filas.
							
					"aoColumnDefs": [ {
						"sClass": "center",
						"aTargets": [ -1, -2 ]
						} ]
						
				}});
			
			//Rellenar el combo de la tabla de entrega de EPIs
			sacarEpis2();

			});
			
	//Cargar datos del equipo para editar en formulario	
		$(document).ready(
			function() {
    			$('#example15 tbody td').click( function () {
        		/* Get the position of the current data from the node */
        		var aPos15 = oTable15.fnGetPosition( this );
         
        		/* Get the data array for this row */
        		var aData15 = oTable15.fnGetData( aPos15[0] );
				/*alert("Ok "+aData[0]);*/
				
				idseleccionado15 =  aData15[0];
				document.getElementById("txtpnombre").value = aData15[1];
				document.getElementById("txtpapellidos").value = aData15[2];
				document.getElementById("txtpdni").value = aData15[3];
				document.getElementById("txtpnss").value = aData15[4];
				document.getElementById("txtpfchnac").value = aData15[5];
				document.getElementById("txtpfchalta").value = aData15[6];
				document.getElementById("txtpfchbaja").value = aData15[7];
				document.getElementById("comboidpuesto").value = aData15[10];
				document.getElementById("comboesresp").value = aData15[11];
				document.getElementById("txtptlf").value = aData15[12];
				document.getElementById("txtpmovil").value = aData15[13];
				document.getElementById("txtpmail").value = aData15[14];
				document.getElementById("txtpdireccion").value = aData15[15];
				document.getElementById("txtpcp").value = aData15[16];
				document.getElementById("txtppoblacion").value = aData15[17];
				document.getElementById("txtpprovincia").value = aData15[18];
				document.getElementById("txtpcontactourg").value = aData15[19];
				document.getElementById("txtptlfurg").value = aData15[20];
				document.getElementById("comboesminus").value = aData15[21];
				document.getElementById("txtpobs").value = aData15[22];

				//File System-----------------------------------------------------------
					if (aData15[9]) {document.getElementById("FSCV").innerHTML = "<a class='doc' href='"+aData15[9]+"' target='_blank'>"+aData15[8]+"</a> <img src='img/miniboton.jpg' style='vertical-align:middle' onclick='deleteFSCV();' />"; 
							nombreFS=aData15[8]; rutaFS=aData15[9]}
					else {document.getElementById("FSCV").innerHTML = "<input type='file' id='myCV' />";};
				//----------------------------------------------------------------------
				
			
			DatosBDCursosPersona (idseleccionado15);
			DatosBDRMsPersona (idseleccionado15);
			DatosBDPersonaEpis (idseleccionado15);
			DatosBDautorizaciones (idseleccionado15, 0);
			setTimeout('listCursosPersona();listRMsPersona();listEPIsPersona();listAutorizaciones();',300);				
			
			VnV15 (0, 0, 1, 0);
			VnVEper (1);//No ver botones update y delete
         
    			});
     
			/* Init DataTables */
			oTable15= $('#example15').dataTable();
			});
		
	}

function sacarPersonas (intEstado15){
	var db;
        db = openDatabase("DBIWOHS", "0.1", "Database Isowin OHS", 500 * 1024 * 1024);	
		//alert ("Estoy dentro");					
	var estado15="WHERE fchbaja='' ";
	if (intEstado15==1) {estado15="WHERE fchbaja!='' ";};
	if(db){
		db.transaction( function(tx) {
			tx.executeSql("SELECT * FROM personas JOIN personas2 ON personas.idpersona=personas2.idpersona  " + estado15, [],
				function(tx, result){
					aDataSet15 = [];
					for(var i=0; i < result.rows.length; i++) {	
						aDataSet15.push([result.rows.item(i)['idpersona'],
								result.rows.item(i)['nombre'],
								result.rows.item(i)['apellidos'],
								result.rows.item(i)['dni'],
								result.rows.item(i)['nss'],
								result.rows.item(i)['fchnac'],
								result.rows.item(i)['fchalta'],
								result.rows.item(i)['fchbaja'],
								result.rows.item(i)['fsname'],
								result.rows.item(i)['fslink'],
								result.rows.item(i)['idpuesto'],
								result.rows.item(i)['esresp'],
								result.rows.item(i)['tlf'],
								result.rows.item(i)['movil'],
								result.rows.item(i)['mail'],
								result.rows.item(i)['direccion'],
								result.rows.item(i)['cp'],
								result.rows.item(i)['poblacion'],
								result.rows.item(i)['provincia'],
								result.rows.item(i)['contactourg'],
								result.rows.item(i)['tlfurg'],
								result.rows.item(i)['esminus'],
								result.rows.item(i)['obs']
								]);
					}			
				});
		});	
	};
}	

	
//TABLA AUTORIZACIONES_____________________________________________________________________________________________________________

function mostrarAutorizaciones(intEst15a) {
	intEstado15a=intEst15a;
	DatosBDautorizaciones(idseleccionado15, intEstado15a);
	setTimeout('listAutorizaciones()',200);
	Vb15a(intEst15a);
	}


function listAutorizaciones() {
		$(document).ready(			
			function () {
				$('#dynamic15a').html( '<table cellpadding="0" cellspacing="0" border="0" class="display" id="example15a"></table>' );
				$('#example15a').dataTable( {
					"aaData": aDataSet15a,
						
					"aoColumns": [
						{ "sTitle": "Id", "bSearchable": false, "bVisible": false },
						{ "sTitle": "Autorización" },
						{ "sTitle": "Descripción", "bSearchable": false, "bVisible": false },
						{ "sTitle": "Fecha Inicio" },
						{ "sTitle": "Fecha Fin" },
						{ "sTitle": "Estado" }
						],
						
					"sScrollY": "250px",
        			"bPaginate": false,
        			"bScrollCollapse": true,
						
					"sDom": 'lfrtip<"clear spacer">T',
					/*"sDom": 'T<"clear">lfrtip<"clear spacer">T',*/ //Muestra los botones de copy,print...
					"oTableTools": {
						"sRowSelect": "single","aButtons": ["select"], //Solo me muestra el boton select para poder seleccionar las filas.
							
					"aoColumnDefs": [ {
						"sClass": "center",
						"aTargets": [ -1, -2 ]
						} ]
						
				}});
				
				});
	//Cargar datos de la calibración para editar en formulario	
		$(document).ready(
				function() {
    			$('#example15a tbody td').click( function () {
        		/* Get the position of the current data from the node */
        		var aPos15a = oTable15a.fnGetPosition( this );
         
        		/* Get the data array for this row */
        		var aData15a = oTable15a.fnGetData( aPos15a[0] );
				/*alert("Ok "+aData[0]);*/
				
				idseleccionado15a =  aData15a[0];
				document.getElementById("comboatautorizacion").value = aData15a[1];
				document.getElementById("txtatdescripcion").value = aData15a[2];
				document.getElementById("txtatfchinicio").value = aData15a[3];
				document.getElementById("txtatfchfin").value = aData15a[4];
				document.getElementById("comboatestado").value = aData15a[5];

				//File System-----------------------------------------------------------
					if (aData15a[7]) {document.getElementById("FSNOT").innerHTML = "<a class='doc' href='"+aData15a[7]+"' target='_blank'>"+aData15a[6]+"</a> <img src='img/miniboton.jpg' style='vertical-align:middle' onclick='deleteFSNOT();' />"; 
							nombreFS=aData15a[6]; rutaFS=aData15a[7]}
					else {document.getElementById("FSNOT").innerHTML = "<input type='file' id='myNOT' />";};
				//----------------------------------------------------------------------

				VnVEaut (1);//No ver botones update y delete

    			});
     
   				 /* Init DataTables */
   				 oTable15a= $('#example15a').dataTable();
				});
		
	}

//DATOS AUTORIZACIONES FILTRADAS POR PERSONA______________________________________________________________________
		
function DatosBDautorizaciones(idseleccionado15, intEstado15a) {
	var db;
        db = openDatabase("DBIWOHS", "0.1", "Database Isowin OHS", 500 * 1024 * 1024);

        var estado15a="AND estado='Vigente' ";
		if (intEstado15a==1) {estado15a="AND estado!='Vigente' ";};

		if(db){	
		db.transaction( function(tx) {
			tx.executeSql("SELECT * FROM autorizaciones WHERE idpersona=? " + estado15a, [idseleccionado15],
				function(tx, result){
					aDataSet15a = [];
					for(var i=0; i < result.rows.length; i++) {

						aDataSet15a.push([result.rows.item(i)['id'],
								result.rows.item(i)['autorizacion'],
								result.rows.item(i)['descripcion'],
								result.rows.item(i)['fchinicio'],
								result.rows.item(i)['fchfin'],
								result.rows.item(i)['estado'],
								result.rows.item(i)['fsname'],
								result.rows.item(i)['fslink']]);
												
				}		
   				 /* Init DataTables */
   				 oTable15a = $('#example15a').dataTable();				
				 
				});
		
		});
		
	}}

//=========================================================================================================					
/*NUEVA PERSONA*/
	
	function addPersona (nombre, apellidos, dni, fchnac, nss, fchalta, fchbaja, idpuesto, esresp, tlf, movil, mail, direccion, cp, poblacion, provincia, contactourg, tlfurg, esminus, obs) {

		var db;
		FSError = false; nombreFS=null; rutaFS=null;//FileSystem 
		addFile("myCV");//FileSystem
		db = openDatabase("DBIWOHS", "0.1", "Database Isowin OHS", 500 * 1024 * 1024);
		if(db){	
		  db.transaction( function(tx) {
			tx.executeSql("INSERT INTO personas (nombre, apellidos, dni, fchnac, nss, fchalta, fchbaja, idpuesto, esresp) VALUES(?,?,?,?,?,?,?,?,?)", [nombre, apellidos, dni, fchnac, nss, fchalta, fchbaja, idpuesto, esresp]);
			tx.executeSql("SELECT * FROM personas ORDER BY idpersona DESC", [], function(tx, result){
				idseleccionado15 = result.rows.item(0)["idpersona"];
				tx.executeSql("INSERT INTO personas2 (idpersona, tlf, movil, mail, direccion, cp, poblacion, provincia, contactourg, tlfurg, esminus, obs) VALUES(?,?,?,?,?,?,?,?,?,?,?,?)", [idseleccionado15, tlf, movil, mail, direccion, cp, poblacion, provincia, contactourg, tlfurg, esminus, obs]);
				CEXaddCita("Nueva incorporación: " + nombre, fchalta, fchalta, "Nueva incorporación: " + nombre + " " + apellidos + " (" + dni + ")", "RHP" + idseleccionado15);
				});
			if (!FSError) {apprise('Persona guardada');}; //alert("Trabajador guardado: "+ dni);
		})};
		//DatosBDpersonas();
		setTimeout('updateFSPersonas()',300);
		setTimeout('mostrarPersonas(intEstado15)',500);
		
	}
	
/*ACTUALIZAR PERSONA*/
	function updatePersona (nombre, apellidos, dni, fchnac, nss, fchalta, fchbaja, idpuesto, esresp, tlf, movil, mail, direccion, cp, poblacion, provincia, contactourg, tlfurg, esminus, obs) {
	
		var db;
		FSError = false; nombreFS=null; rutaFS=null;//FileSystem 
		addFile("myCV");//FileSystem
        db = openDatabase("DBIWOHS", "0.1", "Database Isowin OHS", 500 * 1024 * 1024);
		if(db){	
		  db.transaction( function(tx) {
			tx.executeSql("UPDATE personas SET nombre=?, apellidos=?, dni=?, fchnac=?, nss=?, fchalta=?, fchbaja=?, idpuesto=?, esresp=?  WHERE idpersona=?", [nombre, apellidos, dni, fchnac, nss, fchalta, fchbaja, idpuesto, esresp, idseleccionado15]);
			tx.executeSql("UPDATE personas2 SET tlf=?, movil=?, mail=?, direccion=?, cp=?, poblacion=?, provincia=?, contactourg=?, tlfurg=?, esminus=?, obs=?  WHERE idpersona=?", [tlf, movil, mail, direccion, cp, poblacion, provincia, contactourg, tlfurg, esminus, obs, idseleccionado15]);
			CEXupdateCita( "Nuevo trabajador: " + nombre, fchalta, fchalta, "Nueva incorporación: " + nombre + " " + apellidos + " (" + dni + ")", "RHP" + idseleccionado15);
			if (!FSError) {apprise('Persona modificada');}; //alert("Trabajador ha cambiado: "+dni + " - " + idseleccionado15);
		})};
		//DatosBDpersona();
		setTimeout('updateFSPersonas()',300);
		setTimeout('mostrarPersonas(intEstado15)',500);
	}

/*ACTUALIZAR ARCHIVOS*/
function updateFSPersonas() {
var db;
db = openDatabase("DBIWOHS", "0.1", "Database Isowin OHS", 500 * 1024 * 1024);
		if(db){	
		db.transaction( function(tx) {
			if (nombreFS!=null) {tx.executeSql("UPDATE personas SET fsname=?, fslink=? WHERE idpersonas=?", [nombreFS, rutaFS, idseleccionado15]);
								document.getElementById("FSCV").innerHTML = "<a class='doc' href='"+rutaFS+"' target='_blank'>"+nombreFS+"</a> <img src='img/miniboton.jpg' style='vertical-align:middle' onclick='deleteFSCV();' />";};
			});
		};
}					

/*BORRAR PERSONA*/
	function removePersona() {
		apprise('¿Eliminar persona?', {'verify': true}, function(r) {
			if(r) { 
				var db;
				deleteFile();//FileSystem
				db = openDatabase("DBIWOHS", "0.1", "Database Isowin OHS", 500 * 1024 * 1024);
				if(db){	
					db.transaction(function(tx) {
					tx.executeSql("DELETE FROM personas WHERE idpersona=?",[idseleccionado15]);
					tx.executeSql("DELETE FROM personas2 WHERE idpersona=?",[idseleccionado15]);
					tx.executeSql("DELETE FROM autorizaciones WHERE idpersona=?",[idseleccionado15]);
					tx.executeSql("DELETE FROM cursospersonas WHERE idpersona=?",[idseleccionado15]);
					tx.executeSql("DELETE FROM personaepi WHERE idpersona=?",[idseleccionado15]);
					tx.executeSql("DELETE FROM rms WHERE idpersona=?",[idseleccionado15]);
					//INCLUDAS todas las eliminaciones en todas las tablas con idpersona (excepto ATS y Simulacros)!!!!
					CEXdeleteCita("RHP" + idseleccionado15);
					if (!FSError) {apprise('Persona borrada');};
					});
				};
				setTimeout('mostrarPersonas(intEstado15)',500);
			}
		});
		
	}

	/*BORRAR ARCHIVOS*/
	function deleteFSCV() {
		deleteLinkFile('personas');
		document.getElementById("FSCV").innerHTML = "<input type='file' id='myCV' />";
		setTimeout('mostrarPersonas(intEstado15);',500);
	}

//=========================================================================================================					
/*NUEVA AUTORIZACIÓN*/
	
	function addAutorizacion (autorizacion, descripcion, fchinicio, fchfin, estado) {

		var db;
		FSError = false; nombreFS=null; rutaFS=null;//FileSystem 
		addFile("myNOT");//FileSystem
		db = openDatabase("DBIWOHS", "0.1", "Database Isowin OHS", 500 * 1024 * 1024);
		if(db){	
		  db.transaction( function(tx) {
			tx.executeSql("INSERT INTO autorizaciones (idpersona, autorizacion, descripcion, fchinicio, fchfin, estado) VALUES(?,?,?,?,?,?)", [idseleccionado15, autorizacion, descripcion, fchinicio, fchfin, estado]);
			tx.executeSql("SELECT * FROM autorizaciones ORDER BY id DESC", [], function(tx, result){
					idseleccionado15a = result.rows.item(0)["id"];
					if (!FSError) {apprise('Autorización registrada');};
				});
		})};
		//DatosBDpersonas();
		setTimeout('updateFSAutorizaciones()',200);
		setTimeout('mostrarAutorizaciones(intEstado15a)',400);
		
	}
	
/*ACTUALIZAR AUTORIZACIÓN*/
	function updateAutorizacion (autorizacion, descripcion, fchinicio, fchfin, estado) {
	
		var db;
		FSError = false; nombreFS=null; rutaFS=null;//FileSystem 
		addFile("myNOT");//FileSystem
        db = openDatabase("DBIWOHS", "0.1", "Database Isowin OHS", 500 * 1024 * 1024);
		if(db){	
		  db.transaction( function(tx) {
			tx.executeSql("UPDATE autorizaciones SET autorizacion=?, descripcion=?, fchinicio=?, fchfin=?, estado=? WHERE id=?", [autorizacion, descripcion, fchinicio, fchfin, estado, idseleccionado15a]);
			if (!FSError) {apprise('Autorización modificada');};
		})};
		//DatosBDpersona();
		setTimeout('updateFSAutorizaciones()',200);
		setTimeout('mostrarAutorizaciones(intEstado15a)',400);
	}	

/*ACTUALIZAR ARCHIVOS*/
function updateFSAutorizaciones() {
var db;
db = openDatabase("DBIWOHS", "0.1", "Database Isowin OHS", 500 * 1024 * 1024);
		if(db){	
		db.transaction( function(tx) {
			if (nombreFS!=null) {tx.executeSql("UPDATE autorizaciones SET fsname=?, fslink=? WHERE id=?", [nombreFS, rutaFS, idseleccionado15a]);
								document.getElementById("FSNOT").innerHTML = "<a class='doc' href='"+rutaFS+"' target='_blank'>"+nombreFS+"</a> <img src='img/miniboton.jpg' style='vertical-align:middle' onclick='deleteFSNOT();' />";};
			});
		};
}				

/*BORRAR AUTORIZACIÓN*/
	function removeAutorizacion() {
		apprise('¿Eliminar autorización?', {'verify': true}, function(r) {
			if(r) { 
				var db;
				deleteFile();//FileSystem
				db = openDatabase("DBIWOHS", "0.1", "Database Isowin OHS", 500 * 1024 * 1024);
				if(db){	
					db.transaction(function(tx) {
					tx.executeSql("DELETE FROM autorizaciones WHERE id=?",[idseleccionado15a]);
					if (!FSError) {apprise('Autorización borrada');}; 
					});
				};
				setTimeout('mostrarAutorizaciones(intEstado15a)',500);
			}
		});
	}

	/*BORRAR ARCHIVOS*/
	function deleteFSNOT() {
		deleteLinkFile('autorizaciones');
		document.getElementById("FSNOT").innerHTML = "<input type='file' id='myNOT' />";
		setTimeout('mostrarAutorizaciones(intEstado15a);',500);
	}

//=========================================================================================================
/* VER NO VER PERSONAS */
var vernewpersona = 0;
var verlistapersonas= 1;
function Vnewpersona() { if (vernewpersona==0) {$("#newpersona").toggle(200); vernewpersona=1; $("#txtpnombre").focus();};}
function NVnewpersona() { if (vernewpersona==1) {$("#newpersona").toggle(200); vernewpersona=0;};}
function Vlistapersonas () {if (verlistapersonas==0) {$("#listapersonas").toggle(200); verlistapersonas=1;};}
function NVlistapersonas () {if (verlistapersonas==1) {$("#listapersonas").toggle(200); verlistapersonas=0;};}	

//=========================================================================================================
/* VER NO VER*/
var verNPU= 0; var verLPU= 1; var verNPE= 0; var verLPE= 1;

function VnV15 (Vnpu, Vlpu, Vnpe, Vlpe) { 
	if (verNPU!=Vnpu) {$("#newpuesto").toggle(200);$("#listapersonasenpuesto").toggle(200); verNPU=Vnpu; $("#txtpupuesto").focus();};
	if (verLPU!=Vlpu) {$("#listapuestos").toggle(200); verLPU=Vlpu;};
	if (verNPE!=Vnpe) {$("#newpersona").toggle(200); verNPE=Vnpe; $("#txtpnombre").focus();};
	if (verLPE!=Vlpe) {$("#listapersonas").toggle(200); verLPE=Vlpe;};
}

/* VER NO VER EDIT (Update+Delete)*/
var verEPER=0; var verEAUT=0; var verEPUE=0;
function VnVEper (Veper) {if (verEPER!=Veper) {$("#editper").toggle(200);$("#newper1").toggle(200); $("#newper2").toggle(200); verEPER=Veper;};}
function VnVEaut (Veaut) {if (verEAUT!=Veaut) {$("#editaut").toggle(200);verEAUT=Veaut;};}
function VnVEpue (Vepue) {if (verEPUE!=Vepue) {$("#editpue").toggle(200);$("#newpue1").toggle(200);$("#newpue2").toggle(200);verEPUE=Vepue;};}

//=========================================================================================================
	
//VER BOTON SEMAFORO_______________________________________________________________________

//Funcion de inicialización de la pestaña, ocultando el botón rojo.
function VbInit15() {if(document.getElementById('botonverde15').style.display!="none") {document.getElementById('botonrojo15').style.display = 'none';}}
//valor 1 se pone rojo, valor 0 se pone verde.	
function Vb15(intColor15) {
	if (INTcolor15!=intColor15) {$("#botonrojo15").toggle(200); $("#botonverde15").toggle(200); INTcolor15=intColor15;};
	}

//Funcion de inicialización de la pestaña, ocultando el botón rojo.
function VbInit15a() {if(document.getElementById('botonverde15a').style.display!="none") {document.getElementById('botonrojo15a').style.display = 'none';}}
//valor 1 se pone rojo, valor 0 se pone verde.	
function Vb15a(intColor15a) {
	if (INTcolor15a!=intColor15a) {$("#botonrojo15a").toggle(200); $("#botonverde15a").toggle(200); INTcolor15a=intColor15a;};
	}
//_______________________________________________________________________________________________________
//_______________________________________________________________________________________________________
//_______________________________________________________________________________________________________

	
//TABLA CURSOS __________________________________________________________________________________________

function listCursosPersona() {
		$(document).ready(			
			function () {
				$('#dynamic15b').html( '<table cellpadding="0" cellspacing="0" border="0" class="display" id="example15b"></table>' );
				$('#example15b').dataTable( {
					"aaData": aDataSet15b,
						
					"aoColumns": [
						{ "sTitle": "Id"/*, "bSearchable": false, "bVisible": false*/ },
						{ "sTitle": "Codigo Curso", "bSearchable": false, "bVisible": false },
						{ "sTitle": "Curso" },
						{ "sTitle": "Estado" },
						{ "sTitle": "Diploma" }
						],
						
					"sScrollY": "250px",
					"bPaginate": false,
					"bScrollCollapse": true,
						
					"oTableTools": {
							
					"aoColumnDefs": [{
						"sClass": "center",
						"aTargets": [ -1, -2 ]
						}]		
					}
				});
				
			}
		);
		
	}

//DATOS CURSOS______________________________________________________________________
		
function DatosBDCursosPersona (idseleccionado15) {
	var db;
        db = openDatabase("DBIWOHS", "0.1", "Database Isowin OHS", 500 * 1024 * 1024);
		if(db){	
		db.transaction( function(tx) {
			tx.executeSql("SELECT * FROM cursos JOIN cursospersonas ON cursos.idcurso=cursospersonas.idcurso WHERE idpersona=?", [idseleccionado15],
				function(tx, result){
					aDataSet15b = [];
					for(var i=0; i < result.rows.length; i++) {

						var linknull = "";//File System
						if (result.rows.item(i)['fsname']) {linknull = result.rows.item(i)['fsname'];};

						aDataSet15b.push([result.rows.item(i)['idcurso'],
								result.rows.item(i)['codcurso'],
								result.rows.item(i)['curso'],
								result.rows.item(i)['estado'],
								"<a href='"+result.rows.item(i)['fslink']+"' target='_blank'>"+linknull+"</a>"
							]); 
						//alert(result.rows.item(i)['curso']);
						//alert(result.rows.length);
					};	
					//oTable15b = $('#example15b').dataTable();	
				});	
			});
		}; 
	}

	
//TABLA RMS__________________________________________________________________________________________

function listRMsPersona() {
		$(document).ready(			
			function () {
				$('#dynamic15c').html( '<table cellpadding="0" cellspacing="0" border="0" class="display" id="example15c"></table>' );
				$('#example15c').dataTable( {
					"aaData": aDataSet15c,
						
					"aoColumns": [
						{ "sTitle": "Id" },
						{ "sTitle": "Fecha" },
						{ "sTitle": "Estado" },
						{ "sTitle": "Resultado" },
						{ "sTitle": "Certificado" }
						],
						
					"sScrollY": "250px",
					"bPaginate": false,
					"bScrollCollapse": true,
						
					"oTableTools": {
							
					"aoColumnDefs": [{
						"sClass": "center",
						"aTargets": [ -1, -2 ]
						}]		
					}
				});
				
			}
		);
		
	}

//DATOS RMS______________________________________________________________________
		
function DatosBDRMsPersona (idseleccionado15) {
	var db;
        db = openDatabase("DBIWOHS", "0.1", "Database Isowin OHS", 500 * 1024 * 1024);
		if(db){	
		db.transaction( function(tx) {
			tx.executeSql("SELECT * FROM rms WHERE idpersona=?", [idseleccionado15],
				function(tx, result){
					aDataSet15c = [];
					for(var i=0; i < result.rows.length; i++) {

						var linknull = "";//File System
						if (result.rows.item(i)['fsname']) {linknull = result.rows.item(i)['fsname'];};

						aDataSet15c.push([result.rows.item(i)['idrm'],
								result.rows.item(i)['dia'],
								result.rows.item(i)['estado'],
								result.rows.item(i)['resultado'],
								"<a href='"+result.rows.item(i)['fslink']+"' target='_blank'>"+linknull+"</a>"
							]); 
						//alert(result.rows.item(i)['curso']);
						//alert(result.rows.length);
					};	
					//oTable15b = $('#example15b').dataTable();	
				});	
			});
		}; 
	}

	
//TABLA EPIS__________________________________________________________________________________________

function listEPIsPersona() {
		$(document).ready(			
			function () {
				$('#dynamic15d').html( '<table cellpadding="0" cellspacing="0" border="0" class="display" id="example15d"></table>' );
				$('#example15d').dataTable( {
					"aaData": aDataSet15d,
						
					"aoColumns": [
						{ "sTitle": "Id", "bSearchable": false, "bVisible": false },
						{ "sTitle": "EPI" },
						{ "sTitle": "Fecha entrega" },
						{ "sTitle": "registro entrega" }
						],
						
					"sScrollY": "300px",
					"bPaginate": false,
					"bScrollCollapse": true,
						
					"oTableTools": {
							
					"aoColumnDefs": [{
						"sClass": "center",
						"aTargets": [ -1, -2 ]
						}]		
					}
				})
				//EDITAR DIRECTAMENTE LA TABLA DE ENTREGA DE EPIS
				.makeEditable ({
                    		"aoColumns": [
                    {event: 'click', indicator: 'Saving CSS Grade...', tooltip: 'Click to select CSS Grade', loadtext: 'loading...',
						type: 'select', onblur: 'submit', data: nuevosepis,
						sUpdateURL: function(value, settings){updatePersonaEpi (value); return value;}
					},
					{onblur: 'submit',
						sUpdateURL: function(value, settings){updatePersonaEpi (); return value;}
					},
					{onblur: 'submit',
						sUpdateURL: function(value, settings){updatePersonaEpi (); return value;}
					}
					]									
				});
				;
				
			});
	
		//Obtengo el ID de la fila que estoy editando	
		$(document).ready( function() {
    			$('#example15d tbody td').click( function () {
				var aPos15d = oTable15d.fnGetPosition( this );
				var aData15d = oTable15d.fnGetData(aPos15d[0]);
				idseleccionado15d =  aData15d[0];
				aseleccionado15d = aData15d;
			});
			oTable15d= $('#example15d').dataTable();	
		});

	}

//DATOS DE EPIS______________________________________________________________________
		
function DatosBDPersonaEpis (idseleccionado15) {
	var db;
        db = openDatabase("DBIWOHS", "0.1", "Database Isowin OHS", 500 * 1024 * 1024);
		if(db){	
		db.transaction( function(tx) {
			tx.executeSql("SELECT * FROM personaepi JOIN epis ON personaepi.idepi=epis.idepi WHERE idpersona=?", [idseleccionado15],
				function(tx, result){
					aDataSet15d = [];
					for(var i=0; i < result.rows.length; i++) {		
						aDataSet15d.push([result.rows.item(i)['id'],
								result.rows.item(i)['epi'],
								result.rows.item(i)['fchentrega'],
								result.rows.item(i)['registro']
							]); 
						//alert(result.rows.item(i)['curso']);
						//alert(result.rows.length);
					};	
					//oTable15b = $('#example15b').dataTable();	
				});
			tx.executeSql("SELECT * FROM personaepi WHERE idpersona=? AND idepi is null", [idseleccionado15],
				function(tx, result){
					for(var i=0; i < result.rows.length; i++) {		
						aDataSet15d.push([result.rows.item(i)['id'],
								null,
								result.rows.item(i)['fchentrega'],
								result.rows.item(i)['registro']
							]); 
						//alert(result.rows.item(i)['curso']);
						//alert(result.rows.length);
					};	
					//oTable15b = $('#example15b').dataTable();	
				});
			});
		}; 
	}

//=========================================================================================================					

function mostrarPersonaEpis() {
	DatosBDPersonaEpis (idseleccionado15);
	setTimeout('listEPIsPersona()',300);
	}

//=========================================================================================================					
/*ENTREGAR UN NUEVO EPI A UNA PERSONA*/
	function addPersonaEpi() {

		var db;
		var hoy = new Date();
		var hoy2 = changeFch2(hoy);

		db = openDatabase("DBIWOHS", "0.1", "Database Isowin OHS", 500 * 1024 * 1024);
		if(db){ db.transaction( function(tx) {
			tx.executeSql("INSERT INTO personaepi (idpersona, fchentrega) VALUES(?,?)", [idseleccionado15, hoy2]);
			});
			setTimeout('mostrarPersonaEpis();',500);
			apprise('Haz doble click sobre los campos para introducir la información'); 
		};
	}

/*ACTUALIZAR EL EPI ENTREGADO A UNA PERSONA*/
	function updatePersonaEpi (value) {
		//alert("dentrode: " + aseleccionado25[2]);
	var db;
        db = openDatabase("DBIWOHS", "0.1", "Database Isowin OHS", 500 * 1024 * 1024);
		if(db){ db.transaction( function(tx) {
			if (value) {tx.executeSql("UPDATE personaepi SET idepi=? WHERE id=? ", [value, idseleccionado15d])}
			else{tx.executeSql("UPDATE personaepi SET fchentrega=?, registro=? WHERE id=? ", [aseleccionado15d[2], aseleccionado15d[3], idseleccionado15d])};
			apprise('Entrega de EPI actualizada'); //alert("Estudio ha cambiado: "+ estudio + " - " + idseleccionado18);
		});
	};
		//alert("Guardado");
		//setTimeout('mostrarPRLPuestosPuestos()',500);
	}
	
/*BORRAR LA ENTREGA DE UN EPI A UNA PERSONA*/
	function removePersonaEpi() {
		if(idseleccionado15d) { 
		apprise('¿Eliminar el EPI entregado?', {'verify': true}, function(r) {
			if(r) { 
				var db;
				db = openDatabase("DBIWOHS", "0.1", "Database Isowin OHS", 500 * 1024 * 1024);
				if(db){	
					db.transaction(function(tx) {
					tx.executeSql("DELETE FROM personaepi WHERE id=?",[idseleccionado15d]);
					apprise('Entrega de EPI borrada'); //alert("Persona borrada: "+ idseleccionado15);
					});
				};
				setTimeout('mostrarPersonaEpis()',500);
			}
		});
		};
	}
//=========================================================================================================					
/*COMBOBOX DE PRL PUESTOS*/

function sacarEpis2 (){
	var db;
    db = openDatabase("DBIWOHS", "0.1", "Database Isowin OHS", 500 * 1024 * 1024);					
	if(db){
		db.transaction( function(tx) {
			tx.executeSql("SELECT * FROM epis", [], function(tx, result){
				nuevosepis = "{0:'' ";
				for(var i=0; i < result.rows.length; i++) {nuevosepis = nuevosepis +", " + parseInt(result.rows.item(i)['idepi']) + ":'" + result.rows.item(i)['epi'] + "' ";};
				nuevosepis = nuevosepis + "}";
			});
		});	
	};
	//setTimeout('alert(nuevosepis);', 500);
}

//=========================================================================================================