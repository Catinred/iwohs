//CONSULTA INICIAL A BD

var nuevosresponsables; //Listado de clientes para COMBOBOX
sacarResponsables (); //Cargo el COMBOBOX de responsables
var idProcess; //Indico el proceso al que pertenece la información que voy a incluir.

//DATOS FICHA PROCESO__________________________________________________________________________________________	

	function datosFicha(idProceso) {
		var db;
		idProcess = idProceso;
		db = openDatabase("DBIWOHS", "0.1", "Database Isowin OHS", 500 * 1024 * 1024);
		if(db){
			//alert("Inside");
			db.transaction( function(tx) {
				tx.executeSql("SELECT * FROM procesos WHERE idproceso=?", [idProceso],
				function(tx, result){
					
					if (idProceso != 1){//En el proceso de GESTION no hay ficha de proceso
					if (result.rows.item(0)['mision'] != "") {document.getElementById('P1').innerHTML = result.rows.item(0)['mision']} 
					 else {document.getElementById('P1').innerHTML = "Describe cual es la misión y los objetivos del proceso. Y recuerda que deben estar alineados con los objetivos de calidad de la organización"};
					if (result.rows.item(0)['alcance'] != "") {document.getElementById('P2').innerHTML = result.rows.item(0)['alcance']} 
					 else {document.getElementById('P2').innerHTML = "Marca cuando empieza y cuando termina el proceso. Hasta donde llega, que no incluye..."};
					if (result.rows.item(0)['entradas'] != "") {document.getElementById('P3').innerHTML = result.rows.item(0)['entradas']} 
					 else {document.getElementById('P3').innerHTML = "Indica los elementos de entrada del proceso, de que proceso proceden, así como los requisitos que deben cumplir cada uno de ellos."};
					if (result.rows.item(0)['salidas'] != "") {document.getElementById('P4').innerHTML = result.rows.item(0)['salidas']} 
					 else {document.getElementById('P4').innerHTML = "Indica los elementos de salida del proceso, a que proceso van destinados, así como los requisitos que deben cumplir cada uno de ellos."};
					if (result.rows.item(0)['responsable'] != "") {document.getElementById('P5').innerHTML = result.rows.item(0)['responsable']} 
					 else {document.getElementById('P5').innerHTML = "Fija quien es el propietario del proceso, debe ser una persona única identificada a través de su nombre o su puesto de trabajo."};
					if (result.rows.item(0)['recursos'] != "") {document.getElementById('P6').innerHTML = result.rows.item(0)['recursos']} 
					 else {document.getElementById('P6').innerHTML = "Indica los recursos humanos y materiales con los que cuenta el propietario del proceso para lograr los objetivos del proceso."};
					if (result.rows.item(0)['requisitos'] != "") {document.getElementById('P7').innerHTML = result.rows.item(0)['requisitos']} 
					 else {document.getElementById('P7').innerHTML = "Indica los requisitos internos, legales o reglamentarios que el proceso debe cumplir. Puedes referenciar requisitos del cliente o documentación interna."};
					if (result.rows.item(0)['controles'] != "") {document.getElementById('P8').innerHTML = result.rows.item(0)['controles']} 
					 else {document.getElementById('P8').innerHTML = "Fija los controles de calidad, indicadores del proceso y las variables de control que manejas, para garantizar que se cumple la misión del proceso."};
					};
					
					 //INDICADORES
					 if (result.rows.item(0)['i1'] != "") {document.getElementById('I1').innerHTML = result.rows.item(0)['i1']} 
					 else {document.getElementById('I1').innerHTML = "Indicador 1"};
					if (result.rows.item(0)['i2'] != "") {document.getElementById('I2').innerHTML = result.rows.item(0)['i2']} 
					 else {document.getElementById('I2').innerHTML = "Indicador 2"};
					if (result.rows.item(0)['i3'] != "") {document.getElementById('I3').innerHTML = result.rows.item(0)['i3']} 
					 else {document.getElementById('I3').innerHTML = "Indicador 3"};
					if (result.rows.item(0)['i4'] != "") {document.getElementById('I4').innerHTML = result.rows.item(0)['i4']} 
					 else {document.getElementById('I4').innerHTML = "Indicador 4"};
					
					//alert("holac");	

				});
			});

		};
	}		
	
//=========================================================================================================					
/*COMBOBOX DE RESPONSABLES*/

function sacarResponsables (){
	var db;
        db = openDatabase("DBIWOHS", "0.1", "Database Isowin OHS", 500 * 1024 * 1024);	
		//alert ("Estoy dentro");					
	if(db){
		db.transaction( function(tx) {
			tx.executeSql("SELECT * FROM personas WHERE esresp=?", ["Si"],
				function(tx, result){
					nuevosresponsables = "<option selected></option>";
					for(var i=0; i < result.rows.length; i++) {	
						nuevosresponsables = nuevosresponsables + "<option value='" +result.rows.item(i)['idpersona']+"'>"+result.rows.item(i)['apellidos'] + ", " + result.rows.item(i)['nombre'] +"</option> ";
					}			
				});
		});	
	
	};
}
//=========================================================================================================		
			
$(function() {$(".editable_textarea").editable
	(function(value, settings) { 
			db = openDatabase("DBIWOHS", "0.1", "Database Isowin OHS", 500 * 1024 * 1024);

			if(db){
				if (this.id=='P1') {db.transaction( function(tx) {tx.executeSql ("UPDATE procesos SET mision=?  WHERE idproceso=?", [value, idProcess])})};
				if (this.id=='P2') {db.transaction( function(tx) {tx.executeSql ("UPDATE procesos SET alcance=?  WHERE idproceso=?", [value, idProcess])})};
				if (this.id=='P3') {db.transaction( function(tx) {tx.executeSql ("UPDATE procesos SET entradas=?  WHERE idproceso=?", [value, idProcess])})};
				if (this.id=='P4') {db.transaction( function(tx) {tx.executeSql ("UPDATE procesos SET salidas=?  WHERE idproceso=?", [value, idProcess])})};
				if (this.id=='P5') {db.transaction( function(tx) {tx.executeSql ("UPDATE procesos SET responsable=?  WHERE idproceso=?", [value, idProcess])})};
				if (this.id=='P6') {db.transaction( function(tx) {tx.executeSql ("UPDATE procesos SET recursos=?  WHERE idproceso=?", [value, idProcess])})};
				if (this.id=='P7') {db.transaction( function(tx) {tx.executeSql ("UPDATE procesos SET requisitos=?  WHERE idproceso=?", [value, idProcess])})};
				if (this.id=='P8') {db.transaction( function(tx) {tx.executeSql ("UPDATE procesos SET controles=?  WHERE idproceso=?", [value, idProcess])})};
				if (this.id=='I1') {db.transaction( function(tx) {tx.executeSql ("UPDATE procesos SET i1=?  WHERE idproceso=?", [value, idProcess])})};
				if (this.id=='I2') {db.transaction( function(tx) {tx.executeSql ("UPDATE procesos SET i2=?  WHERE idproceso=?", [value, idProcess])})};
				if (this.id=='I3') {db.transaction( function(tx) {tx.executeSql ("UPDATE procesos SET i3=?  WHERE idproceso=?", [value, idProcess])})};
				if (this.id=='I4') {db.transaction( function(tx) {tx.executeSql ("UPDATE procesos SET i4=?  WHERE idproceso=?", [value, idProcess])})};

				apprise('El cambio se ha guardado');//alert("modificado" + this.id + value);
				
				};
			return(value);
			},
		
		{
		type   : 'textarea', 
		select : true, 
		submit : '<div class="sprite ok">', 
		cancel : '<div class="sprite ko">',
		height  : "auto",
		cssclass : "editable"}
	);
});


