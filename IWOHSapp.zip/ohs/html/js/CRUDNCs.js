//NO CONFORMIDADES (6)

	var idseleccionado6;
	var intProceso6; var intEstado6;
	var INTcolor6 = 0; //Color del semaforo en verde
				
//TABLA NCS_____________________________________________________________________________________________________________

function mostrarNCs(intProc6, intEst6) {
	intProceso6=intProc6; intEstado6=intEst6;
	sacarNCs (intProceso6, intEstado6);
	setTimeout('listNCs()',500);
	Vb6(intEst6);
	}

function listNCs() {
			$(document).ready(			
			function () {
				$('#dynamic6').html( '<table cellpadding="0" cellspacing="0" border="0" class="display" id="example6"></table>' );
				$('#example6').dataTable( {
					"aaData": aDataSet6,
						
					"aoColumns": [
						{ "sTitle": "Id"/*, "bSearchable": false, "bVisible": false*/ },
						{ "sTitle": "No Conformidad" },
						{ "sTitle": "Cod N.C." },
						{ "sTitle": "Proceso", "bSearchable": false, "bVisible": false },
						{ "sTitle": "Origen" },
						{ "sTitle": "F. Creacion" },
						{ "sTitle": "F. Cierre" }
						],
						
					"sScrollY": "400px",
        			"bPaginate": false,
        			"bScrollCollapse": true,
						
					"sDom": 'lfrtip<"clear spacer">T',
					/*"sDom": 'T<"clear">lfrtip<"clear spacer">T',*/ //Muestra los botones de copy,print...
					"oTableTools": {
						"sRowSelect": "single","aButtons": ["select"], //Solo me muestra el boton select para poder seleccionar las filas.
							
					"aoColumnDefs": [ {
						"sClass": "center",
						"aTargets": [ -1, -2 ]
						} ]
						
				}});
				
			//Cargo el COMBOBOX de responsables del formulario NCs------------
			setTimeout('$("#comboncresp").html(nuevosresponsables); $("#comboacpresp6").html(nuevosresponsables);',200);
			//--------------------------------------------------	
				
			});
	//Cargar datos de proveedor para editar en formulario	
			$(document).ready(
				function() {
    			$('#example6 tbody td').click( function () {
        		/* Get the position of the current data from the node */
        		var aPos6 = oTable6.fnGetPosition( this );
         
        		/* Get the data array for this row */
        		var aData6 = oTable6.fnGetData( aPos6[0] );
				/*alert("Ok "+aData[0]);*/
				
				idseleccionado6 =  aData6[0];
				document.getElementById("txtnc").value = aData6[1];
				document.getElementById("txtcodnc").value = aData6[2];
				//El 3 es el proceso
				document.getElementById("txtncorigen").value = aData6[4];
				document.getElementById("txtncfchinicio").value = aData6[5];
				document.getElementById("txtncfchfin").value = aData6[6];
				document.getElementById("comboncresp").value = aData6[7];
				document.getElementById("txtncdescripcion").value = aData6[8];
				document.getElementById("txtnccausas").value = aData6[9];
				document.getElementById("txtnccorreccion").value = aData6[10];
				document.getElementById("txtnccodacp").value = aData6[11];

				VnVEnc (1);//No ver botones update y delete
				
				});
     
   				 /* Init DataTables */
   				 oTable6 = $('#example6').dataTable();
			});
	}

function sacarNCs (intProceso6, intEstado6){
	var db;
        db = openDatabase("DBIWOHS", "0.1", "Database Isowin OHS", 500 * 1024 * 1024);	
									//alert ("Proceso: " + intProceso2);					
	var estado6="WHERE fchfin='' AND proceso=" + parseInt(intProceso6);
	if (intEstado6==1) {estado6="WHERE fchfin!='' AND proceso=" + parseInt(intProceso6);};
	if(db){
		db.transaction( function(tx) {
			tx.executeSql("SELECT * FROM ncs " + estado6, [],
				function(tx, result){
					aDataSet6 = [];
					for(var i=0; i < result.rows.length; i++) {	
						aDataSet6.push([result.rows.item(i)['idnc'],
								result.rows.item(i)['nc'],
								result.rows.item(i)['codnc'],
								result.rows.item(i)['proceso'],
								result.rows.item(i)['origen'],
								result.rows.item(i)['fchinicio'],
								result.rows.item(i)['fchfin'],
								result.rows.item(i)['responsable'],
								result.rows.item(i)['descripcion'],
								result.rows.item(i)['causas'],
								result.rows.item(i)['correccion'],
								result.rows.item(i)['codacp']
								]);
								//alert(result.rows.item(i)['causas']);
					}				 
				});
		});	
	};
}	

//=========================================================================================================					
/*NUEVA NC*/
	function addNC(nc, codnc, origen, fchinicio, fchfin, responsable, descripcion, causas, correccion, codacp) {
		var db;
		db = openDatabase("DBIWOHS", "0.1", "Database Isowin OHS", 500 * 1024 * 1024);
		if(db){	
		  db.transaction( function(tx) {
			tx.executeSql("INSERT INTO ncs(nc, codnc, proceso, origen, fchinicio, fchfin, responsable, descripcion, causas, correccion, codacp) VALUES(?,?,?,?,?,?,?,?,?,?,?)", [nc, codnc,  intProceso6, origen, fchinicio, fchfin, responsable, descripcion, causas, correccion, codacp]);
			apprise('La NC ha sido guardada');//alert("NC guardada: "+ nc);
		})};
		setTimeout('mostrarNCs(intProceso6, intEstado6)',500);
	}
	
/*ACTUALIZAR NC*/
	function updateNC(nc, codnc, origen, fchinicio, fchfin, responsable, descripcion, causas, correccion, codacp) {
		var db;
        db = openDatabase("DBIWOHS", "0.1", "Database Isowin OHS", 500 * 1024 * 1024);
		if(db){	
		  db.transaction( function(tx) {
			tx.executeSql("UPDATE ncs SET nc=?, codnc=?, proceso=?, origen=?, fchinicio=?, fchfin=?, responsable=?, descripcion=?, causas=?, correccion=?, codacp=?  WHERE idnc=?", [nc, codnc,  intProceso6, origen, fchinicio, fchfin, responsable, descripcion, causas, correccion, codacp, idseleccionado6]);
			apprise('La NC ha sido modificada');//alert("NC ha cambiado: "+ nc + " - " + idseleccionado6);
		})};
		setTimeout('mostrarNCs(intProceso6, intEstado6)',500);
	}					

/*BORRAR NC*/
	function removeNC() {
		apprise('¿Eliminar la No Conformidad?', {'verify': true}, function(r) {
			if(r) { 
				var db;
				db = openDatabase("DBIWOHS", "0.1", "Database Isowin OHS", 500 * 1024 * 1024);
				if(db){	
					db.transaction(function(tx) {
					tx.executeSql("DELETE FROM ncs WHERE idnc=?",[idseleccionado6]);
					});
					apprise('La NC ha sido borrada');//alert("NC borrada: "+ idseleccionado6);
				};
			setTimeout('mostrarNCs(intProceso6, intEstado6)',500);
			};
		});
	}
	
//=========================================================================================================					
/*NUEVA APC6*/
	function addACP6 (acp, codacp, tipo, fchalta, responsable, equipo, acciones, fchprevista) {
		var origen = "La No Conformidad: " +  idseleccionado6;
		var codtrz = "nc"+idseleccionado6;
		addMiniACP(acp, codacp, tipo, origen, fchalta, responsable, equipo, acciones, fchprevista, codtrz);
		VnV6 (1, 1, 0);
	}
	
//Las funciones "addACPXX" est�n definidas en "XXXXXXX.js" de cada uno de los procesos, llaman a AddMiniACP.
	
//=========================================================================================================					
/*NUEVA Mini APC*/
	function addMiniACP(acp, codacp, tipo, origen, fchalta, responsable, equipo, acciones, fchprevista, codtrz) {
		var db;
		var nuevoId;
		var estado = "Pendiente";
		//alert("Inside");
		db = openDatabase("DBIWOHS", "0.1", "Database Isowin OHS", 500 * 1024 * 1024);
		if(db){	
		  db.transaction( function(tx) {
			tx.executeSql("INSERT INTO acps (acp, codacp, tipo, origen, fchalta, responsable, equipo, estado, acciones, fchprevista, seguimiento, fchcierre, eficacia, fcheficacia, codtrz) VALUES(?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)", [acp, codacp, tipo, origen, fchalta, responsable, equipo, estado, acciones, fchprevista, "Pendiente", "", "Pendiente","", codtrz]);
											//Meto la ACP en la Planificación de Objetivos del proceso de Dirección
			tx.executeSql("SELECT * FROM acps ORDER BY idacp DESC", [], function(tx, result){
				nuevoId = result.rows.item(0)["idacp"];
											//alert("Id del ACP que acabo de crear: "+ nuevoId);
				CEXaddObjetivo ("ACP: ", nuevoId, acp, codacp, responsable, equipo, fchalta, fchprevista, "", "", "ganttRed");
				});
			apprise('La ACP ha sido registrada'); //alert("ACP guardada: "+ acp);
			});
		};
		
	}
	
//=========================================================================================================
/* VER NO VER*/
var verNNOC=1; var verLNOC= 1; var verNACO= 0;

function VnV6 (Vnnoc, Vlnoc, Vnaco) { 
	if (verNNOC!=Vnnoc) {$("#newnc").toggle(200); verNNOC=Vnnoc;};
	if (verLNOC!=Vlnoc) {$("#listancs").toggle(200); verLNOC=Vlnoc;};
	if (verNACO!=Vnaco) {$("#newacp").toggle(200); verNACO=Vnaco; $("#txtacp2").focus();};
	}

/* VER NO VER EDIT (Update+Delete)*/
var verENC=0;
function VnVEnc (Venc) {if (verENC!=Venc) {$("#editnc").toggle(200); verENC=Venc;};}

//=========================================================================================================
	
//VER BOTON SEMAFORO_______________________________________________________________________

//Funcion de inicializaci�n de la pesta�a, ocultando el bot�n rojo.
function VbInit6() {document.getElementById('botonrojo6').style.display = 'none';}
//valor 1 se pone rojo, valor 0 se pone verde.	
function Vb6(intColor6) {
	if (INTcolor6!=intColor6) {$("#botonrojo6").toggle(200); $("#botonverde6").toggle(200); INTcolor6=intColor6;};
	}


//__________________________________________________________________________________________
	
