
// variables globales
var chart1; var serie1 =  [{"name" : "HolaMajox", "data" : [3,2,1,2,2,2,1,2,3,2,3,5]}]; var serieAux1 = []; //Inicializacion de array
var chart2; var serie2 =  [{"name" : "HolaMajox", "data" : [3,5,3,2,1,1,2,3,2,2,4,2]}]; var serieAux2 = [];//Inicializacion de array
var chart3; var serie3 =  [{"name" : "HolaMajox", "data" : [3,5,3,2,1,1,2,3,1,2,2,2]}]; var serieAux3 = [];//Inicializacion de array
var chart4; var serie4 =  [{"name" : "HolaMajox", "data" : [3,5,3,2,1,1,2,3,2,3,2,2]}]; var serieAux4 = [];//Inicializacion de array

var unaSerie3 = [{"name" : "HolaMajox", "data" : [1,2,3,2,3,5,3,2,1,2,2,2]}]; //Array de prueba


function sacarseries (nombreserie, serieAux){
	var db;
	
        db = openDatabase("DBIWOHS", "0.1", "Database Isowin OHS", 500 * 1024 * 1024);	
		//alert ("Estoy dentro");					
		if(db){
		//alert("conectado");	
		db.transaction( function(tx) {
			tx.executeSql("SELECT * FROM indicadores WHERE idindicador=? ORDER BY mes", [nombreserie],
				function(tx, result){
					//alert (result.rows.item(0)['serie']);
					//alert (result.rows.length);
					
					var valores2 = [null, null, null, null, null, null, null, null, null, null, null, null];
					var valores1 = [null, null, null, null, null, null, null, null, null, null, null, null]; 
					var valores0 = [null, null, null, null, null, null, null, null, null, null, null, null];
					var objetivo = [null, null, null, null, null, null, null, null, null, null, null, null];
					var limite = [null, null, null, null, null, null, null, null, null, null, null, null];
					var p=0; //Posici�n en el vector que corresponde al mes.
					for(var i=0; i < result.rows.length; i++) {
						p = parseInt(result.rows.item(i)['mes'])-1;
						//alert(p);
						if (result.rows.item(i)['serie'] == "2014") {valores2[p]=result.rows.item(i)['valor'];};
						if (result.rows.item(i)['serie'] == "2013") {valores1[p]=result.rows.item(i)['valor'];};
						if (result.rows.item(i)['serie'] == "2012") {valores0[p]=result.rows.item(i)['valor'];};
						if (result.rows.item(i)['serie'] == "Objetivo") {objetivo[p]=result.rows.item(i)['valor'];};
						if (result.rows.item(i)['serie'] == "Limite") {limite[p]=result.rows.item(i)['valor'];};
					};
						
					//serieAux=[]; //No funciona y no se porque?
					
						serieAux.push({"name" : "2014","data" : valores2, color: 'blue'});	//result.rows.item(0)['serie'], 					
						serieAux.push({ "name" : "2013", "data" : valores1, color: 'grey'});	
						serieAux.push({"name" : "2012", "data" : valores0, color: 'orange'});
						serieAux.push({"name" : "Objetivo", "data" : objetivo, color: 'green', dashStyle: 'dash', marker: {enabled: false}});	
						serieAux.push({"name" : "Limite", "data" : limite, color: 'red', dashStyle: 'dash', marker: {enabled: false}});								   
						})})};
						
					return serieAux;
					
	}
	
		
function mostrarGrafico (I1,I2,I3,I4) {
	
	
	
	serie1 = sacarseries(I1,  serieAux1);
	serie2 = sacarseries(I2,  serieAux2);
	serie3 = sacarseries(I3,  serieAux3);
	serie4 = sacarseries(I4,  serieAux4);
	
	//setTimeout('alert("Esperando...")',5000);
	
	showChart();
	
	serie1.splice(0,5); serie2.splice(0,5); serie3.splice(0,5); serie4.splice(0,5);

	}

function showChart(){
	
		//chart1.destroy();
		chart1 = new Highcharts.Chart({
			chart: {renderTo:  'container1', defaultSeriesType: 'line', marginRight: 130, marginBottom: 25, /*events: {load: sacarseries()}*/},
			title: {text:  '', x: -20 /* center */},
			//subtitle: {text:  'Número de No conformidades', x: -20},
			credits: {enabled: false},
			xAxis: {categories: ['Ene', 'Feb', 'Mar', 'Abr', 'May', 'Jun', 'Jul', 'Ago', 'Sep', 'Oct', 'Nov', 'Dec']},
			yAxis: {title: {text: 'Valor'}, plotLines: [{value: 0, width: 1, color: '#808080'}]},
			tooltip: {formatter: function() { return '<b>'+ this.series.name +'</b><br/>'+ this.x +': '+ this.y +''; /* unidades del cada valor de la serie. */}},
			legend: {layout: 'vertical', align: 'right', verticalAlign: 'top', x: -10, y: 100, borderWidth: 0},
			series: serie1
		});
		
		chart2 = new Highcharts.Chart({
			chart: {renderTo:  'container2', defaultSeriesType: 'line', marginRight: 130, marginBottom: 25 },
			//events: {load: sacarseries('I1') },
			title: {text:  '', x: -20 /* center */},
			//subtitle: {text:  'Accidentes con baja', x: -20},
			credits: {enabled: false},
			xAxis: {categories: ['Ene', 'Feb', 'Mar', 'Abr', 'May', 'Jun', 'Jul', 'Ago', 'Sep', 'Oct', 'Nov', 'Dec']},
			yAxis: {title: {text: 'Valor'}, plotLines: [{value: 0, width: 1, color: '#808080'}]},
			tooltip: {formatter: function() { return '<b>'+ this.series.name +'</b><br/>'+ this.x +': '+ this.y +''; /* unidades del cada valor de la serie. */}},
			legend: {layout: 'vertical', align: 'right', verticalAlign: 'top', x: -10, y: 100, borderWidth: 0},
			series: serie2
		});
		
		chart3 = new Highcharts.Chart({
			chart: {renderTo:  'container3', defaultSeriesType: 'line', marginRight: 130, marginBottom: 25 },
			//events: {load: sacarseries('I1') },
			title: {text:  '', x: -20 },   /* center */
			//subtitle: {text:  'Accidentes con baja', x: -20},
			credits: {enabled: false},
			xAxis: {categories: ['Ene', 'Feb', 'Mar', 'Abr', 'May', 'Jun', 'Jul', 'Ago', 'Sep', 'Oct', 'Nov', 'Dec']},
			yAxis: {title: {text: 'Valor'}, plotLines: [{value: 0, width: 1, color: '#808080'}]},
			tooltip: {formatter: function() { return '<b>'+ this.series.name +'</b><br/>'+ this.x +': '+ this.y +''; }},/* unidades del cada valor de la serie. */
			legend: {layout: 'vertical', align: 'right', verticalAlign: 'top', x: -10, y: 100, borderWidth: 0},
			series: serie3
		});
		
		
		chart4 = new Highcharts.Chart({
			chart: {renderTo:  'container4', defaultSeriesType: 'line', marginRight: 130, marginBottom: 25 },
			//events: {load: sacarseries('I1') },
			title: {text:  '', x: -20 /* center */},
			//subtitle: {text:  'Accidentes con baja', x: -20},
			credits: {enabled: false},
			xAxis: {categories: ['Ene', 'Feb', 'Mar', 'Abr', 'May', 'Jun', 'Jul', 'Ago', 'Sep', 'Oct', 'Nov', 'Dec']},
			yAxis: {title: {text: 'Valor'}, plotLines: [{value: 0, width: 1, color: '#808080'}]},
			tooltip: {formatter: function() { return '<b>'+ this.series.name +'</b><br/>'+ this.x +': '+ this.y +''; /* unidades del cada valor de la serie. */}},
			legend: {layout: 'vertical', align: 'right', verticalAlign: 'top', x: -10, y: 100, borderWidth: 0},
			series: serie4
		});
		
	}

/*NUEVO DATO*/
	function addData(txtindicador, nchart, txtserie, txtmes, txtvalor) {
		var db;
		var encontrado="false";
		var floatvalor = parseFloat (txtvalor);
		//alert(floatvalor + " <- " + txtvalor);
		var intmes = parseInt (txtmes);
        db = openDatabase("DBIWOHS", "0.1", "Database Isowin OHS", 500 * 1024 * 1024);
		if(db){
			if (intmes == 13)
				{db.transaction( function(tx) {
					tx.executeSql("DELETE FROM indicadores WHERE idindicador=? AND serie=?", [txtindicador, txtserie]);
					tx.executeSql("INSERT INTO indicadores (idindicador, serie, mes, valor) VALUES(?,?,?,?)", [txtindicador, txtserie,1, floatvalor]);
					tx.executeSql("INSERT INTO indicadores (idindicador, serie, mes, valor) VALUES(?,?,?,?)", [txtindicador, txtserie,2, floatvalor]);
					tx.executeSql("INSERT INTO indicadores (idindicador, serie, mes, valor) VALUES(?,?,?,?)", [txtindicador, txtserie,3, floatvalor]);
					tx.executeSql("INSERT INTO indicadores (idindicador, serie, mes, valor) VALUES(?,?,?,?)", [txtindicador, txtserie,4, floatvalor]);
					tx.executeSql("INSERT INTO indicadores (idindicador, serie, mes, valor) VALUES(?,?,?,?)", [txtindicador, txtserie,5, floatvalor]);
					tx.executeSql("INSERT INTO indicadores (idindicador, serie, mes, valor) VALUES(?,?,?,?)", [txtindicador, txtserie,6, floatvalor]);
					tx.executeSql("INSERT INTO indicadores (idindicador, serie, mes, valor) VALUES(?,?,?,?)", [txtindicador, txtserie,7, floatvalor]);
					tx.executeSql("INSERT INTO indicadores (idindicador, serie, mes, valor) VALUES(?,?,?,?)", [txtindicador, txtserie,8, floatvalor]);
					tx.executeSql("INSERT INTO indicadores (idindicador, serie, mes, valor) VALUES(?,?,?,?)", [txtindicador, txtserie,9, floatvalor]);
					tx.executeSql("INSERT INTO indicadores (idindicador, serie, mes, valor) VALUES(?,?,?,?)", [txtindicador, txtserie,9, floatvalor]);
					tx.executeSql("INSERT INTO indicadores (idindicador, serie, mes, valor) VALUES(?,?,?,?)", [txtindicador, txtserie,10, floatvalor]);
					tx.executeSql("INSERT INTO indicadores (idindicador, serie, mes, valor) VALUES(?,?,?,?)", [txtindicador, txtserie,11, floatvalor]);
					tx.executeSql("INSERT INTO indicadores (idindicador, serie, mes, valor) VALUES(?,?,?,?)", [txtindicador, txtserie,12, floatvalor]);
					});
				for(var i=1; i < 13; i++) {actualizarJson(txtindicador, nchart, txtserie, i, floatvalor);};
				}
			else	
				{db.transaction( function(tx) {
					tx.executeSql("SELECT * FROM indicadores WHERE idindicador=? AND serie=? AND mes=?", [txtindicador, txtserie, intmes],
					function(tx, result){
						if(result.rows.length>0){encontrado="true"};	
						//alert(result.rows.length);
						if (encontrado == "true")
							{db.transaction( function(tx) {
							tx.executeSql("UPDATE indicadores SET valor=?  WHERE idindicador=? AND serie=? AND mes=?", [floatvalor, txtindicador, txtserie, intmes]);});
							actualizarJson(txtindicador, nchart, txtserie, intmes, floatvalor);
							//alert("modificado" +"/"+txtserie+"/"+intmes+"/"+floatvalor);
							}
						else
							{db.transaction( function(tx) {
							tx.executeSql("INSERT INTO indicadores (idindicador, serie, mes, valor) VALUES(?,?,?,?)", [txtindicador, txtserie, intmes, floatvalor]);});
							actualizarJson(txtindicador, nchart, txtserie, intmes, floatvalor);
							//alert("incluido" +"/"+txtserie+"/"+intmes+"/"+floatvalor);	
						};
					//alert(encontrado);
					
					})});

			
		//if(db){alert('sigo conectado');}
				}
			};
		setTimeout('showChart()',1000);
		//setTimeout('chart1.redraw()',1000);
			
	}
	
	function actualizarJson(txtindicador, nchart, txtserie, intmes, newvalor){
		if (nchart == 1) {for(var i=0; i < serie1.length; i++) {if (serie1[i].name==txtserie) {serie1[i].data[intmes-1]=newvalor;};};};
		if (nchart == 2) {for(var i=0; i < serie2.length; i++) {if (serie2[i].name==txtserie) {serie2[i].data[intmes-1]=newvalor;};};};
		if (nchart == 3) {for(var i=0; i < serie3.length; i++) {if (serie3[i].name==txtserie) {serie3[i].data[intmes-1]=newvalor;};};};
		if (nchart == 4) {for(var i=0; i < serie4.length; i++) {if (serie4[i].name==txtserie) {serie4[i].data[intmes-1]=newvalor;};};};
	}
				