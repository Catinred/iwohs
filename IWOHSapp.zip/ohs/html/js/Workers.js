
function iniciarWorker (proceso) {

if (proceso==1) {var worker = new Worker('html/gestion/js/worker1.js');}

worker.addEventListener('message', function(e) {
  console.log('XData: ', e.data);
  XData = e.data;
}, false);

worker.postMessage('Hello'); // Send data to our worker.	
}
