//MAQUINAS (17 y 18)

	var idseleccionado17; //Maquina
	var idseleccionado17b; //Tipo
	var idseleccionado18; //Mantenimiento
	var idseleccionado19; //Revisión
	var nuevosman; //Lista de mantenimientos disponibles - Combobox
	var intEstado17;
	var INTcolor17 = 0; //Color del semaforo en verde		
				
//TABLA MAQUINAS_____________________________________________________________________________________________________________

function mostrarMaquinas(intEst17) {
	intEstado17=intEst17;
	sacarMaquinas (intEstado17);
	setTimeout('listMaquinas()',500);
	Vb17(intEst17);
	}

function mostrarMansyRevs() {
			DatosBDmans(idseleccionado17b);
			DatosBDrevs(idseleccionado17);
			setTimeout('listMans(); listRevs()',500);	
		}

function listMaquinas() {
		$(document).ready(			
			function () {
				$('#dynamic17').html( '<table cellpadding="0" cellspacing="0" border="0" class="display" id="example17"></table>' );
				$('#example17').dataTable( {
					"aaData": aDataSet17,
						
					
					"aoColumns": [
						{ "sTitle": "Id"/*, "bSearchable": false, "bVisible": false*/ },
						{ "sTitle": "Maquina" },
						{ "sTitle": "Codigo" },
						{ "sTitle": "Marca" },
						{ "sTitle": "Modelo" },
						{ "sTitle": "S/N" },
						{ "sTitle": "idtipo", "bSearchable": false, "bVisible": false },
						{ "sTitle": "fch fabricación", "bSearchable": false, "bVisible": false},
						{ "sTitle": "Fecha de compra", "bSearchable": false, "bVisible": false },
						{ "sTitle": "Estado" }
						],
						
					"sScrollY": "650px",
        			"bPaginate": false,
        			"bScrollCollapse": true,
						
					"sDom": 'lfrtip<"clear spacer">T',
					/*"sDom": 'T<"clear">lfrtip<"clear spacer">T',*/ //Muestra los botones de copy,print...
					"oTableTools": {
						"sRowSelect": "single","aButtons": ["select"], //Solo me muestra el boton select para poder seleccionar las filas.
							
					"aoColumnDefs": [ {
						"sClass": "center",
						"aTargets": [ -1, -2 ]
						} ]
						
				}});
				//Combo TIPO_________________________
				livedata("#combomqidtipo");

				});
	//Cargar datos del equipo para editar en formulario	
			$(document).ready(
				function() {
    			$('#example17 tbody td').click( function () {
        		var aPos17 = oTable17.fnGetPosition( this );
        		var aData17 = oTable17.fnGetData( aPos17[0] );
				
				idseleccionado17 =  aData17[0];
				document.getElementById("txtmaquina").value = aData17[1];
				document.getElementById("txtmqcodmaq").value = aData17[2];
				document.getElementById("txtmqmarca").value = aData17[3];
				document.getElementById("txtmqmodelo").value = aData17[4];
				document.getElementById("txtmqsn").value = aData17[5];
				document.getElementById("combomqidtipo").value = aData17[6];
				idseleccionado17b = aData17[6];
				document.getElementById("txtmqfchfabr").value = aData17[7];
				document.getElementById("txtmqfchcompra").value = aData17[8];
				document.getElementById("combomqestado").value = aData17[9];
				document.getElementById("combomqce").value = aData17[10];
				document.getElementById("txtmqnormas").value = aData17[17];
				document.getElementById("txtmqobs").value = aData17[18];

				var data1="1txt1";var data2="1txt2";var data3="1txt3";var data4="1txt4";var data5="1txt5";
				var data6="1txt6";var data7="1txt7";var data8="1txt8";var data9="1txt9";var data10="1txt10";
				//if (idseleccionado17b==4) {data1="txt1";data2="txt2";data3="txt3";data4="txt4";data5="txt5";data6="txt6";data7="txt7";data8="txt8";data9="txt9";data10="txt10";};
				if (idseleccionado17b==1) {data1="1txt1";data2="1txt2";data3="1txt3";data4="1txt4";data5="1txt5";data6="1txt6";};
				if (idseleccionado17b==2) {data1="2txt1";data2="2txt2";data3="2txt3";data4="2txt4";};
				if (idseleccionado17b==3) {data1="3txt1";data2="3txt2";data3="3txt3";data4="3txt4";};
				if (idseleccionado17b==4) {data1="4txt1";data2="4txt2";data3="4txt3";};
				if (idseleccionado17b==5) {data1="5txt1";data2="5txt2";data3="5txt3";data4="5txt4";data5="5txt5";data6="5txt6";};
				if (idseleccionado17b==6) {data1="6txt1";data2="6txt2";data3="6txt3";data4="6txt4";};
				if (idseleccionado17b==11) {data1="11txt1";data2="11txt2";data3="11txt3";data4="11txt4";};
				if (idseleccionado17b==12) {data1="12txt1";data2="12txt2";};
				if (idseleccionado17b==13) {data1="13txt1";data2="13txt2";data3="13txt3";};
				if (idseleccionado17b==14) {data1="14txt1";data2="14txt2";data3="14txt3";data4="15txt4";data4="15txt4";};
				if (idseleccionado17b==15) {data1="15txt1";data2="15txt2";data3="15txt3";};
				
				document.getElementById(data1).value = aData17[19];
				document.getElementById(data2).value = aData17[20];
				document.getElementById(data3).value = aData17[21];
				document.getElementById(data4).value = aData17[22];
				document.getElementById(data5).value = aData17[23];
				//document.getElementById(data6).value = aData17[24];
				//document.getElementById(data7).value = aData17[25];
				//document.getElementById(data8).value = aData17[26];
				//document.getElementById(data9).value = aData17[27];
				//document.getElementById(data10).value = aData17[28];

				//File System-----------------------------------------------------------
					if (aData17[12]) {document.getElementById("FSMAQinst").innerHTML = "<a class='doc' href='"+aData17[12]+"' target='_blank'>"+aData17[11]+"</a> <img src='img/miniboton.jpg' style='vertical-align:middle' onclick='deleteFSMAQ(1);' />"; 
							nombreFS=aData17[11]; rutaFS=aData17[12]}
					else {document.getElementById("FSMAQinst").innerHTML = "<input type='file' id='myMAQinst' />";};
					if (aData17[14]) {document.getElementById("FSMAQsecur").innerHTML = "<a class='doc' href='"+aData17[14]+"' target='_blank'>"+aData17[13]+"</a> <img src='img/miniboton.jpg' style='vertical-align:middle' onclick='deleteFSMAQ(2);' />"; 
							nombreFS2=aData17[13]; rutaFS2=aData17[14]}
					else {document.getElementById("FSMAQsecur").innerHTML = "<input type='file' id='myMAQsecur' />";};
					if (aData17[16]) {document.getElementById("FSMAQ1215").innerHTML = "<a class='doc' href='"+aData17[16]+"' target='_blank' >"+aData17[15]+"</a> <img src='img/miniboton.jpg' style='vertical-align:middle' onclick='deleteFSMAQ(3);' />"; 
							nombreFS3=aData17[15]; rutaFS3=aData17[16]}
					else {document.getElementById("FSMAQ1215").innerHTML = "<input type='file' id='myMAQ1215' />";};
				//----------------------------------------------------------------------


			//Tablas MANTENIMIENTOS y REVISIONES
			mostrarMansyRevs();
			
			//Cargo el COMBOBOX de responsables del formulario Mantenimientos------------
			sacarResponsables ();
			setTimeout('$("#combomnresp").html(nuevosresponsables);',200);
			//Cargo el COMBOBOX de mantenimientos seleccionables------------
			sacarMans ();
			setTimeout('$("#combomrvidman").html(nuevosman);',200);
			
			//Muestro el subformulario indicado por la base de datos
			InitVnV17B ();

			VnV17 (1, 0, 0, 1, 0, 1);
			VnVEmaq (1);//No ver botones update y delete
         
    		});
     
   		/* Init DataTables */
   		oTable17= $('#example17').dataTable();
		});
		
	}

//Combo de selección de TIPO de maquina ________________________
 function livedata(a){$(a).change(function(event){
	if (combomqidtipo.value==1) {VnV17B (1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0); 
		document.getElementById("tituloequipo").innerHTML ="Máquina"; 
		document.getElementById("txtmqnormas").value ="Real Decreto 1215/1997,Disposiciones mínimas de seguridad y salud de los equipos de trabajo. Real Decreto 1644/2008,Normas para la comercialización y puesta en servicio de las máquinas.";};
	if (combomqidtipo.value==2) {VnV17B (0, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0); 
		document.getElementById("tituloequipo").innerHTML ="Aparato a presión"; 
		document.getElementById("txtmqnormas").value ="Real Decreto 2060/2008, Reglamento de equipos a presión y sus instrucciones técnicas complementarias";};
	if (combomqidtipo.value==3) {VnV17B (0, 0, 1, 0, 0, 0, 0, 0, 0, 0, 0); 
		document.getElementById("tituloequipo").innerHTML ="Instalación eléctrica"; 
		document.getElementById("txtmqnormas").value =" Real Decreto 842/2002 Reglamento electrotécnico para baja tensión (REBT). Real Decreto 3275/1982, Condiciones Técnicas y Garantías en Centrales Eléctricas y Centros de Transformación.";};
	if (combomqidtipo.value==4) {VnV17B (0, 0, 0, 1, 0, 0, 0, 0, 0, 0, 0); 
		document.getElementById("tituloequipo").innerHTML ="Equipo de medida"; 
		document.getElementById("txtmqnormas").value ="";};
	if (combomqidtipo.value==5) {VnV17B (0, 0, 0, 0, 1, 0, 0, 0, 0, 0, 0); 
		document.getElementById("tituloequipo").innerHTML ="Instalación térmica"; 
		document.getElementById("txtmqnormas").value ="Real Decreto 1027/2007, Reglamento de Instalaciones Térmicas en los Edificios (RITE). REAL DECRETO 1826/2009, Modificación del RITE.";};
	if (combomqidtipo.value==6) {VnV17B (0, 0, 0, 0, 0, 1, 0, 0, 0, 0, 0); 
		document.getElementById("tituloequipo").innerHTML ="Instalación Aire Acondicinado"; 
		document.getElementById("txtmqnormas").value ="Real Decreto 865/2003, criterios higiénico-sanitarios para la prevención y control de la legionelosis. Norma UNE 100030 IN.";};
	if (combomqidtipo.value==11) {VnV17B (0, 0, 0, 0, 0, 0, 1, 0, 0, 0, 0); 
		document.getElementById("tituloequipo").innerHTML ="Extintor/es de incendios"; 
		document.getElementById("txtmqnormas").value ="Real Decreto 1942/1993, Reglamento de instalaciones de protección contra incendios.";};
	if (combomqidtipo.value==12) {VnV17B (0, 0, 0, 0, 0, 0, 0, 1, 0, 0, 0); 
		document.getElementById("tituloequipo").innerHTML ="Boca/s de Incendio Equipada/s"; 
		document.getElementById("txtmqnormas").value ="Real Decreto 1942/1993, Reglamento de instalaciones de protección contra incendios.";};
	if (combomqidtipo.value==13) {VnV17B (0, 0, 0, 0, 0, 0, 0, 0, 1, 0, 0); 
		document.getElementById("tituloequipo").innerHTML ="Detección y Alarma"; 
		document.getElementById("txtmqnormas").value ="Real Decreto 1942/1993, Reglamento de instalaciones de protección contra incendios.";};
	if (combomqidtipo.value==14) {VnV17B (0, 0, 0, 0, 0, 0, 0, 0, 0, 1, 0); 
		document.getElementById("tituloequipo").innerHTML ="Hidrantes, Columnas Secas y Grupos"; 
		document.getElementById("txtmqnormas").value ="Real Decreto 1942/1993, Reglamento de instalaciones de protección contra incendios.";};
	if (combomqidtipo.value==15) {VnV17B (0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1); 
		document.getElementById("tituloequipo").innerHTML ="Rociador/es automáticos"; 
		document.getElementById("txtmqnormas").value ="Real Decreto 1942/1993, Reglamento de instalaciones de protección contra incendios.";};
 });}


//DATOS MAQUINAS_________________________________________________

function sacarMaquinas (intEstado17){
	var db;
        db = openDatabase("DBIWOHS", "0.1", "Database Isowin OHS", 500 * 1024 * 1024);	
	
	var estado17="WHERE estado='Activo' ";
	if (intEstado17==1) {estado17="WHERE estado!='Activo' ";};

	if(db){
		db.transaction( function(tx) {
			tx.executeSql("SELECT * FROM maquinas " + estado17, [],
				function(tx, result){
					//Creo un array
					/*var output = [];*/
					//Guardo en cada elemento i del vector, un objeto documento.
					aDataSet17 = [];
					for(var i=0; i < result.rows.length; i++) {
/*						output.push([result.rows.item(i)['iddocumento'],
								result.rows.item(i)['documento'],
								result.rows.item(i)['revision']]);*/		
						aDataSet17.push([result.rows.item(i)['idmaquina'],
								result.rows.item(i)['maquina'],
								result.rows.item(i)['codmaq'],
								result.rows.item(i)['marca'],
								result.rows.item(i)['modelo'],
								result.rows.item(i)['sn'],
								result.rows.item(i)['idtipo'],
								result.rows.item(i)['fchfabr'],
								result.rows.item(i)['fchcompra'],
								result.rows.item(i)['estado'],
								result.rows.item(i)['ce'],
								result.rows.item(i)['fsname'],
								result.rows.item(i)['fslink'],
								result.rows.item(i)['fsname2'],
								result.rows.item(i)['fslink2'],
								result.rows.item(i)['fsname3'],
								result.rows.item(i)['fslink3'],
								result.rows.item(i)['normas'],
								result.rows.item(i)['obs'],
								result.rows.item(i)['data1'],
								result.rows.item(i)['data2'],
								result.rows.item(i)['data3'],
								result.rows.item(i)['data4'],
								result.rows.item(i)['data5'],
								result.rows.item(i)['data6'],
								result.rows.item(i)['data7'],
								result.rows.item(i)['data8'],
								result.rows.item(i)['data9'],
								result.rows.item(i)['data10']
								]);
					};						
				});
		});	
	};
}
//TABLA MANTENIMIENTOS____________________________________________________________________________________________________

function listMans() {
		$(document).ready(			
			function () {
				$('#dynamic18').html( '<table cellpadding="0" cellspacing="0" border="0" class="display" id="example18"></table>' );
				$('#example18').dataTable( {
					"aaData": aDataSet18,
						
					"aoColumns": [
						{ "sTitle": "Id"/*, "bSearchable": false, "bVisible": false*/ },
						{ "sTitle": "Mantenimiento" },
						{ "sTitle": "Aplicación", "bSearchable": false, "bVisible": false },
						{ "sTitle": "Periodicidad" },
						{ "sTitle": "Operaciones", "bSearchable": false, "bVisible": false },
						{ "sTitle": "Responsable", "bSearchable": false, "bVisible": false },
						{ "sTitle": "Prioridad" },
						{ "sTitle": "Link", "bSearchable": false, "bVisible": false },
						{ "sTitle": "Observaciones", "bSearchable": false, "bVisible": false }
						],
						
					"sScrollY": "250px",
        			"bPaginate": false,
        			"bScrollCollapse": true,
						
					"sDom": 'lfrtip<"clear spacer">T',
					/*"sDom": 'T<"clear">lfrtip<"clear spacer">T',*/ //Muestra los botones de copy,print...
					"oTableTools": {
						"sRowSelect": "single","aButtons": ["select"], //Solo me muestra el boton select para poder seleccionar las filas.
							
					"aoColumnDefs": [ {
						"sClass": "center",
						"aTargets": [ -1, -2 ]
						} ]
						
				}});
				
				});
	//Cargar datos de la calibraciÃ³n para editar en formulario	
		$(document).ready(
				function() {
    			$('#example18 tbody td').click( function () {

        		var aPos18 = oTable18.fnGetPosition( this );
        		var aData18 = oTable18.fnGetData( aPos18[0] );
        		//Es de aplicación a todos los elementos de este tipo o sólo a este.
        		var aplica = 0;
        		if (aData18[2]!=null){aplica = 1};
				
				idseleccionado18 =  aData18[0];
				document.getElementById("txtmantenimiento").value = aData18[1];
				document.getElementById("combomnaplica").value = aplica;
				document.getElementById("txtmnperiodicidad").value = aData18[3];
				document.getElementById("txtmnoperaciones").value = aData18[4];
				document.getElementById("combomnresp").value = aData18[5];
				document.getElementById("combomnprioridad").value = aData18[6];
				document.getElementById("txtmnlinkdocs").value = aData18[7];
				document.getElementById("txtmnobs").value = aData18[8];
				
				VnV17 (1, 0, 0, 0, 1, 1);
				VnVEman (1);//No ver botones update y delete
         
    			});
     
   				 /* Init DataTables */
   				 oTable18= $('#example18').dataTable();
				});
		
	}

//DATOS MANTENIMIENTOS FILTRADOS POR MAQUINA______________________________________________________________________
		
function DatosBDmans(idseleccionado17b) {
	var db;
        db = openDatabase("DBIWOHS", "0.1", "Database Isowin OHS", 500 * 1024 * 1024);
		if(db){	
		db.transaction( function(tx) {
			tx.executeSql("SELECT * FROM mantenimientos WHERE idmaquina=? OR idtipo=? ", [idseleccionado17, idseleccionado17b],
				function(tx, result){
					aDataSet18 = [];
					for(var i=0; i < result.rows.length; i++) {

						aDataSet18.push([result.rows.item(i)['idman'],
								result.rows.item(i)['mantenimiento'],
								result.rows.item(i)['idmaquina'],
								result.rows.item(i)['periodicidad'],
								result.rows.item(i)['operaciones'],
								result.rows.item(i)['idresponsable'],
								result.rows.item(i)['prioridad'],
								result.rows.item(i)['linkdocs'],
								result.rows.item(i)['obs']]);						
				}		
   				 /* Init DataTables */
   				 oTable18 = $('#example18').dataTable();
   				 //alert(result.rows.length);		
				});
		});
		
	}}

	
//TABLA REVISIONES______________________________________________________________________________________________________

function listRevs() {
		$(document).ready(			
			function () {
				$('#dynamic19').html( '<table cellpadding="0" cellspacing="0" border="0" class="display" id="example19"></table>' );
				$('#example19').dataTable( {
					"aaData": aDataSet19,
						
					"aoColumns": [
						{ "sTitle": "Id"/*, "bSearchable": false, "bVisible": false*/ },
						{ "sTitle": "Id Man", "bSearchable": false, "bVisible": false },
						{ "sTitle": "Mantenimiento" },
						{ "sTitle": "Fecha revisión" },
						{ "sTitle": "Resultado" },
						{ "sTitle": "Por", "bSearchable": false, "bVisible": false },
						{ "sTitle": "fsname", "bSearchable": false, "bVisible": false },
						{ "sTitle": "fslink", "bSearchable": false, "bVisible": false },
						{ "sTitle": "Fecha próxima revisión" }
						],
						
					"sScrollY": "250px",
        			"bPaginate": false,
        			"bScrollCollapse": true,
						
					"sDom": 'lfrtip<"clear spacer">T',
					/*"sDom": 'T<"clear">lfrtip<"clear spacer">T',*/ //Muestra los botones de copy,print...
					"oTableTools": {
						"sRowSelect": "single","aButtons": ["select"], //Solo me muestra el boton select para poder seleccionar las filas.
							
					"aoColumnDefs": [ {
						"sClass": "center",
						"aTargets": [ -1, -2 ]
						} ]
						
				}});
				
				});
	//Cargar datos de la calibración para editar en formulario	
		$(document).ready(
				function() {
    			$('#example19 tbody td').click( function () {
        		/* Get the position of the current data from the node */
        		var aPos19 = oTable19.fnGetPosition( this );
         
        		/* Get the data array for this row */
        		var aData19 = oTable19.fnGetData( aPos19[0] );
				/*alert("Ok "+aData[0]);*/
				
				idseleccionado19 =  aData19[0];
				document.getElementById("combomrvidman").value = aData19[1];
				//el aData9[2] es la descripción del mantenimiento para la tabla
				document.getElementById("txtmrvfchrev").value = aData19[3];
				document.getElementById("txtmrvresultado").value = aData19[4];
				document.getElementById("txtmrvpor").value = aData19[5];
				document.getElementById("txtmrvfchprox").value = aData19[8];
				document.getElementById("txtmrvobs").value = aData19[9];

				//File System-----------------------------------------------------------
					if (aData19[7]) {document.getElementById("FSMANREV").innerHTML = "<a class='doc' href='"+aData19[7]+"' target='_blank'>"+aData19[6]+"</a> <img src='img/miniboton.jpg' style='vertical-align:middle' onclick='deleteFSMANREV();' />"; 
							nombreFS=aData19[6]; rutaFS=aData19[7]}
					else {document.getElementById("FSMANREV").innerHTML = "<input type='file' id='myMANREV' />";};
				//----------------------------------------------------------------------
				
				VnV17 (1, 0, 1, 1, 0, 0);
				VnVErev (1);//No ver botones update y delete
         
    			});
     
   				 /* Init DataTables */
   				 oTable19= $('#example19').dataTable();
				});
		
	}

//DATOS REVISIONES FILTRADAS POR MAQUINA______________________________________________________________________
		
function DatosBDrevs(idseleccionado17) {
	var db;
	//alert("inside: " + idseleccionado17);
        db = openDatabase("DBIWOHS", "0.1", "Database Isowin OHS", 500 * 1024 * 1024);
		if(db){	
		db.transaction( function(tx) {
			tx.executeSql("SELECT * FROM manrevs LEFT JOIN mantenimientos ON manrevs.idman=mantenimientos.idman WHERE manrevs.idmaquina=?", [idseleccionado17],
				function(tx, result){
					aDataSet19 = [];
					for(var i=0; i < result.rows.length; i++) {
								
						aDataSet19.push([result.rows.item(i)['idmanrev'],
								result.rows.item(i)['idman'],
								result.rows.item(i)['mantenimiento'],
								result.rows.item(i)['fchrev'],
								result.rows.item(i)['resultado'],
								result.rows.item(i)['por'],
								result.rows.item(i)['fsname'],
								result.rows.item(i)['fslink'],
								result.rows.item(i)['fchprox'],
								result.rows.item(i)['obs']]);
												
				}		
   				 /* Init DataTables */
   				 oTable19 = $('#example19').dataTable();
   				 //alert(result.rows.length);				
				 
				});
				
				
		});
		
	}}

//=========================================================================================================					
/*NUEVA MAQUINA*/
var nombreFS2=null; var rutaFS2=null; var nombreFS3=null; var rutaFS3=null;//FileSystem
	
	function addMaq() {

		var maquina = document.getElementById("txtmaquina").value; 
		var codmaq = document.getElementById("txtmqcodmaq").value; 
		var marca = document.getElementById("txtmqmarca").value; 
		var modelo = document.getElementById("txtmqmodelo").value; 
		var sn = document.getElementById("txtmqsn").value; 
		var idtipo = document.getElementById("combomqidtipo").value; 
		var fchfabr = document.getElementById("txtmqfchfabr").value; 
		var fchcompra = document.getElementById("txtmqfchcompra").value; 
		var estado = document.getElementById("combomqestado").value; 
		var ce = document.getElementById("combomqce").value; 
		var normas = document.getElementById("txtmqnormas").value; 
		var obs = document.getElementById("txtmqobs").value;

		var db;
		FSError = false; nombreFS=null; rutaFS=null;nombreFS2=null; rutaFS2=null;nombreFS3=null; rutaFS3=null;//FileSystem
		addFile("myMAQinst"); add2File("myMAQsecur", 2); add2File("myMAQ1215", 3); //FileSystem
		db = openDatabase("DBIWOHS", "0.1", "Database Isowin OHS", 500 * 1024 * 1024);
		if(db){	
		  db.transaction( function(tx) {
			tx.executeSql("INSERT INTO maquinas (maquina, codmaq, marca, modelo, sn, idtipo, fchfabr, fchcompra, estado, ce, normas, obs) VALUES(?,?,?,?,?,?,?,?,?,?,?,?)", [maquina, codmaq, marca, modelo, sn, idtipo, fchfabr, fchcompra, estado, ce, normas, obs]);
			
			tx.executeSql("SELECT * FROM maquinas ORDER BY idmaquina DESC", [], function(tx, result){
				idseleccionado17 = result.rows.item(0)["idmaquina"];
				idseleccionado17b = result.rows.item(0)["idtipo"];
				guardarDatas ();
				if (!FSError) {apprise('La máquina ha sido registrada');};
			});

		  });
		};
		
		setTimeout('updateFSMaquinas()',300);
		setTimeout('mostrarMansyRevs(); mostrarMaquinas(intEstado17);',500);
		//VnV17 (0, 1, 0, 0, 0, 0);
	}
	
/*ACTUALIZAR MAQUINA*/
	function updateMaq () {
		
		var maquina = document.getElementById("txtmaquina").value; 
		var codmaq = document.getElementById("txtmqcodmaq").value; 
		var marca = document.getElementById("txtmqmarca").value; 
		var modelo = document.getElementById("txtmqmodelo").value; 
		var sn = document.getElementById("txtmqsn").value; 
		var idtipo = document.getElementById("combomqidtipo").value; 
		var fchfabr = document.getElementById("txtmqfchfabr").value; 
		var fchcompra = document.getElementById("txtmqfchcompra").value;  
		var estado = document.getElementById("combomqestado").value; 
		var ce = document.getElementById("combomqce").value; 
		var normas = document.getElementById("txtmqnormas").value; 
		var obs = document.getElementById("txtmqobs").value;

		var db;
		FSError = false; nombreFS=null; rutaFS=null;nombreFS2=null; rutaFS2=null;nombreFS3=null; rutaFS3=null;//FileSystem
		addFile("myMAQinst"); add2File("myMAQsecur", 2); add2File("myMAQ1215", 3); //FileSystem
		db = openDatabase("DBIWOHS", "0.1", "Database Isowin OHS", 500 * 1024 * 1024);
		if(db){	
			db.transaction( function(tx) {
				tx.executeSql("UPDATE maquinas SET maquina=?, codmaq=?, marca=?, modelo=?, sn=?, idtipo=?, fchfabr=?, fchcompra=?, estado=?, ce=?, normas=?, obs=? WHERE idmaquina=?", [maquina, codmaq, marca, modelo, sn, idtipo, fchfabr, fchcompra, estado, ce, normas, obs, idseleccionado17]);
				guardarDatas ();
				if (!FSError) {apprise('La máquina ha sido modificada');};
			});
		};
		
		setTimeout('updateFSMaquinas()',300);
		setTimeout('mostrarMansyRevs(); mostrarMaquinas(intEstado17)',500);
	}

/*ACTUALIZAR ARCHIVOS*/
function updateFSMaquinas() {
var db;
db = openDatabase("DBIWOHS", "0.1", "Database Isowin OHS", 500 * 1024 * 1024);
		if(db){	
		db.transaction( function(tx) {
			if (nombreFS!=null) {tx.executeSql("UPDATE maquinas SET fsname=?, fslink=? WHERE idmaquina=?", [nombreFS, rutaFS, idseleccionado17]);};
			if (nombreFS2!=null) {tx.executeSql("UPDATE maquinas SET fsname2=?, fslink2=? WHERE idmaquina=?", [nombreFS2, rutaFS2, idseleccionado17]);};
			if (nombreFS3!=null) {tx.executeSql("UPDATE maquinas SET fsname3=?, fslink3=? WHERE idmaquina=?", [nombreFS3, rutaFS3, idseleccionado17]);};
			if (nombreFS!=null) {document.getElementById("FSMAQinst").innerHTML = "<a class='doc' href='"+rutaFS+"' target='_blank'>"+nombreFS+"</a> <img src='img/miniboton.jpg' style='vertical-align:middle' onclick='deleteFSMAQ(1);' />";};
			if (nombreFS2!=null) {document.getElementById("FSMAQsecur").innerHTML = "<a class='doc' href='"+rutaFS2+"' target='_blank'>"+nombreFS2+"</a> <img src='img/miniboton.jpg' style='vertical-align:middle' onclick='deleteFSMAQ(2);' />";};
			if (nombreFS3!=null) {document.getElementById("FSMAQ1215").innerHTML = "<a class='doc' href='"+rutaFS3+"' target='_blank'>"+nombreFS3+"</a> <img src='img/miniboton.jpg' style='vertical-align:middle' onclick='deleteFSMAQ(3);' />";};
			});
		};
}					

/*BORRAR MAQUINA*/
	function removeMaq() {
		apprise('¿Eliminar la máquina?', {'verify': true}, function(r) {
			if(r) { 
				var db;
				deleteFile(); delete2File(nombreFS2); delete2File(nombreFS3);//FileSystem
				db = openDatabase("DBIWOHS", "0.1", "Database Isowin OHS", 500 * 1024 * 1024);
				if(db){	
					db.transaction(function(tx) {
						tx.executeSql("DELETE FROM maquinas WHERE idmaquina=?",[idseleccionado17]);
						tx.executeSql("DELETE FROM mantenimientos WHERE idmaquina=?",[idseleccionado17]); //limpia chequeos individuales asociados.
						tx.executeSql("DELETE FROM manrevs WHERE idmaquina=?",[idseleccionado17]); //limpia revisiones asociadas.
						});
					if (!FSError) {apprise('La maquina ha sido borrada');};
				};
			setTimeout('mostrarMaquinas(intEstado17)',500);
			};
		});
		 VnV17 (0, 1, 0, 0, 0, 0);
	}

	/*BORRAR ARCHIVOS*/
	function deleteFSMAQ(ndoc) {
		delete2LinkFile('maquinas', ndoc);
		if (ndoc==1) {document.getElementById("FSMAQinst").innerHTML = "<input type='file' id='myMAQinst' />";};
		if (ndoc==2) {document.getElementById("FSMAQsecur").innerHTML = "<input type='file' id='myMAQsecur' />";};
		if (ndoc==3) {document.getElementById("FSMAQ1215").innerHTML = "<input type='file' id='myMAQ1215' />";};

	}
	
//=========================================================================================================					
/*Guardar DATAs*/

function guardarDatas (){

	var data1=null;var data2=null;var data3=null;var data4=null;var data5=null;
	var data6=null;var data7=null;var data8=null;var data9=null;var data10=null;
	
	//if (idseleccionado17b==6) {data1="txt1";data2="txt2";data3="txt3";data4="txt4";data5="txt5";data6="txt6";data7="txt7";data8="txt8";data9="txt9";data10="txt10";};
	if (idseleccionado17b==1) {data1="1txt1";data2="1txt2";data3="1txt3";data4="1txt4";data5="1txt5";};
	if (idseleccionado17b==2) {data1="2txt1";data2="2txt2";data3="2txt3";data4="2txt4";};
	if (idseleccionado17b==3) {data1="3txt1";data2="3txt2";data3="3txt3";data4="3txt4";};
	if (idseleccionado17b==4) {data1="4txt1";data2="4txt2";data3="4txt3";};
	if (idseleccionado17b==5) {data1="5txt1";data2="5txt2";data3="5txt3";data4="5txt4";data5="5txt5";data6="5txt6";};
	if (idseleccionado17b==6) {data1="6txt1";data2="6txt2";data3="6txt3";data4="6txt4";};
	if (idseleccionado17b==11) {data1="11txt1";data2="11txt2";data3="11txt3";data4="11txt4";};
	if (idseleccionado17b==12) {data1="12txt1";data2="12txt2";};
	if (idseleccionado17b==13) {data1="13txt1";data2="13txt2";data3="13txt3";};
	if (idseleccionado17b==14) {data1="14txt1";data2="14txt2";data3="14txt3";data4="15txt4";data4="15txt4";};
	if (idseleccionado17b==15) {data1="15txt1";data2="15txt2";data3="15txt3";};

	//alert(document.getElementById(data1).value);
	if (data1!=null) {var dt1 = document.getElementById(data1).value;};
	if (data2!=null) {var dt2 = document.getElementById(data2).value;};
	if (data3!=null) {var dt3 = document.getElementById(data3).value;};
	if (data4!=null) {var dt4 = document.getElementById(data4).value;};
	if (data5!=null) {var dt5 = document.getElementById(data5).value;};
	if (data6!=null) {var dt6 = document.getElementById(data6).value;};
	if (data7!=null) {var dt7 = document.getElementById(data7).value;};
	if (data8!=null) {var dt8 = document.getElementById(data8).value;};
	if (data9!=null) {var dt9 = document.getElementById(data9).value;};
	if (data10!=null) {var dt10 = document.getElementById(data10).value;};

		var db;
		db = openDatabase("DBIWOHS", "0.1", "Database Isowin OHS", 500 * 1024 * 1024);
		if(db){	
			db.transaction( function(tx) {
			tx.executeSql("UPDATE maquinas SET data1=?, data2=?, data3=?, data4=?, data5=?, data6=?, data7=?, data8=?, data9=?, data10=? WHERE idmaquina=?", [dt1, dt2, dt3, dt4, dt5, dt6, dt7, dt8, dt9, dt10, idseleccionado17]);
			});
		};
}

//=========================================================================================================					
/*NUEVO MANTENIMIENTO*/
	
	function addMan (mantenimiento, periodicidad, operaciones, idresponsable, prioridad, aplica, linkdocs, obs) {
		var db;

		var idmaquina=null;var idtipo=null;
		if (aplica==1) {idmaquina=idseleccionado17} else {idtipo=idseleccionado17b};
		
		db = openDatabase("DBIWOHS", "0.1", "Database Isowin OHS", 500 * 1024 * 1024);
		if(db){	
		  db.transaction( function(tx) {
			tx.executeSql("INSERT INTO mantenimientos (mantenimiento, idmaquina, idtipo, periodicidad, operaciones, idresponsable, prioridad, linkdocs, obs) VALUES(?,?,?,?,?,?,?,?,?)", [mantenimiento, idmaquina, idtipo, periodicidad, operaciones, idresponsable, prioridad, linkdocs, obs]);
			apprise('Mantenimiento registrado'); //alert("CalibraciÃ³n guardada: "+ fchcal);
		});
		
		DatosBDmans(idseleccionado17b);
		setTimeout('listMans()',500);
	};
	}
	
/*ACTUALIZAR MANTENIMIENTO*/
	function updateMan (mantenimiento, periodicidad, operaciones, idresponsable, prioridad, aplica, linkdocs, obs) {
		var db;

		var idmaquina=null;var idtipo=null;
		if (aplica==1) {idmaquina=idseleccionado17} else {idtipo=idseleccionado17b};

		db = openDatabase("DBIWOHS", "0.1", "Database Isowin OHS", 500 * 1024 * 1024);
		if(db){	
		  db.transaction( function(tx) {
			tx.executeSql("UPDATE mantenimientos SET mantenimiento=?, idmaquina=?, idtipo=?, periodicidad=?, operaciones=?, idresponsable=?, prioridad=?, linkdocs=?, obs=?  WHERE idman=?", [mantenimiento, idmaquina, idtipo, periodicidad, operaciones, idresponsable, prioridad, linkdocs, obs, idseleccionado18]);
			apprise('El mantenimiento ha sido modificado'); //alert("La calibraciÃ³n ha cambiado: "+ fchcal + " - " + idseleccionado18);
		});
		
		DatosBDmans(idseleccionado17b);
		setTimeout('listMans()',500);
	};	
	}

/*BORRAR MANTENIMIENTO*/
	function removeMan () {
		apprise('¿Eliminar el mantenimiento?', {'verify': true}, function(r) {
		if(r) { 
			var db;
			db = openDatabase("DBIWOHS", "0.1", "Database Isowin OHS", 500 * 1024 * 1024);
			if(db){	
				db.transaction(function(tx) {
					tx.executeSql("DELETE FROM mantenimientos WHERE idman=?",[idseleccionado18]);
					tx.executeSql("DELETE FROM manrevs WHERE idman=?",[idseleccionado18]);
					apprise('El mantenimiento ha sido borrado'); //alert("CalibraciÃ³n borrada: "+ idseleccionado18);
				});
			};
		
		DatosBDmans(idseleccionado17b);
		setTimeout('listMans()',500);
	};
	});
	}
//=========================================================================================================					
/*NUEVA REVISION*/
	
	function addRev (idman, fchrev, resultado, por, fchprox, obs) {
		
		var db;
		FSError = false; nombreFS=null; rutaFS=null;//FileSystem 
		addFile("myMANREV");//FileSystem
		db = openDatabase("DBIWOHS", "0.1", "Database Isowin OHS", 500 * 1024 * 1024);
		if(db){	
		  db.transaction( function(tx) {
			tx.executeSql("INSERT INTO manrevs (idmaquina, idman, fchrev, resultado, por, fchprox, obs) VALUES(?,?,?,?,?,?,?)", [idseleccionado17, idman, fchrev, resultado, por, fchprox, obs]);
			//CEX
			tx.executeSql("SELECT * FROM manrevs LEFT JOIN maquinas ON manrevs.idmaquina = maquinas.idmaquina ORDER BY idmanrev DESC", [], function(tx, result){
					idseleccionado19 = result.rows.item(0)["idmanrev"];
					codmaquina = result.rows.item(0)["codmaq"];
					maquina = result.rows.item(0)["maquina"];
				CEXaddCita("Revisión máquina/instalación: " + codmaquina, fchprox, fchprox, maquina, "MAN" + idseleccionado19);
				});

			if (!FSError) {apprise('La revisión ha sido guardada');};
		})};
		
		DatosBDrevs(idseleccionado17);
		setTimeout('updateFSRevs()',300);
		setTimeout('mostrarMansyRevs()',500);
	}
	
/*ACTUALIZAR REVISION*/
	function updateRev (idman, fchrev, resultado, por, fchprox, obs) {
		var db;
		FSError = false; nombreFS=null; rutaFS=null;//FileSystem 
		addFile("myMANREV");//FileSystem
		db = openDatabase("DBIWOHS", "0.1", "Database Isowin OHS", 500 * 1024 * 1024);
		if(db){	
		  db.transaction( function(tx) {
			tx.executeSql("UPDATE manrevs SET idmaquina=?, idman=?, fchrev=?, resultado=?, por=?, fchprox=?, obs=?  WHERE idmanrev=?", [idseleccionado17, idman, fchrev, resultado, por, fchprox, obs, idseleccionado19]);
			//CEX
			tx.executeSql("SELECT * FROM manrevs LEFT JOIN maquinas ON manrevs.idmaquina = maquinas.idmaquina WHERE idmanrev=?", [idseleccionado19], function(tx, result){
				codmaquina = result.rows.item(0)["codmaq"];
				maquina = result.rows.item(0)["maquina"];
				CEXupdateCita("Revisión máquina/instalación: " + codmaquina, fchprox, fchprox, maquina, "MAN" + idseleccionado19);
				if (!FSError) {apprise('La revisión ha sido modificada');};
			});
			
		})};
		
		DatosBDrevs(idseleccionado17);
		setTimeout('updateFSRevs()',300);
		setTimeout('mostrarMansyRevs()',500);	
	}

/*ACTUALIZAR ARCHIVOS*/
function updateFSRevs() {
var db;
db = openDatabase("DBIWOHS", "0.1", "Database Isowin OHS", 500 * 1024 * 1024);
		if(db){	
		db.transaction( function(tx) {
			if (nombreFS!=null) {tx.executeSql("UPDATE manrevs SET fsname=?, fslink=? WHERE idmanrev=?", [nombreFS, rutaFS, idseleccionado19]);
								document.getElementById("FSMANREV").innerHTML = "<a class='doc' href='"+rutaFS+"' target='_blank'>"+nombreFS+"</a> <img src='img/miniboton.jpg' style='vertical-align:middle' onclick='deleteFSMANREV();' />";};
			});
		};
}

/*BORRAR REVISION*/
	function removeRev () {
		apprise('¿Eliminar la revisión?', {'verify': true}, function(r) {
		if(r) { 
			var db;
			db = openDatabase("DBIWOHS", "0.1", "Database Isowin OHS", 500 * 1024 * 1024);
			if(db){
				//deleteFile();//FileSystem	
				db.transaction(function(tx) {
					tx.executeSql("DELETE FROM manrevs WHERE idmanrev=?",[idseleccionado19]);
					CEXdeleteCita("MAN" + idseleccionado19);
					if (!FSError) {apprise('La revisión ha sido borrada');};
				});
			};
		};
		DatosBDrevs(idseleccionado17);
		setTimeout('mostrarMansyRevs();',500);
	});
	}

	/*BORRAR ARCHIVO*/
	function deleteFSMANREV() {
		deleteLinkFile('manrevs');
		document.getElementById("FSMANREV").innerHTML = "<input type='file' id='myFSMANREV' />";
	}
//=========================================================================================================
/* VER NO VER*/
var verNMQ= 0; var verLMQ= 1; var verNMN= 0; var verLMN= 0; var verNMR= 0; var verLMR= 0;

function VnV17 (Vnmq, Vlmq, Vnmn, Vlmn, Vnmr, Vlmr) { 
	if (verNMQ!=Vnmq) {$("#newmaquina").toggle(200); verNMQ=Vnmq; $("#txtmaquina").focus();};
	if (verLMQ!=Vlmq) {$("#listamaquinas").toggle(200); verLMQ=Vlmq;};
	if (verNMN!=Vnmn) {$("#newmanrev").toggle(200); verNMN=Vnmn; $("#txtman").focus(); sacarMans(); setTimeout('$("#combomrvidman").html(nuevosman);',200);};
	if (verLMN!=Vlmn) {$("#listamanrevs").toggle(200); verLMN=Vlmn;};
	if (verNMR!=Vnmr) {$("#newman").toggle(200); verNMR=Vnmr; $("#txtmanrev").focus();};
	if (verLMR!=Vlmr) {$("#listamans").toggle(200); verLMR=Vlmr;};
}

/* VER NO VER EDIT (Update+Delete)*/
var verEMAQ=0;var verEMAN=0;var verEREV=0;
function VnVEmaq (Vemaq) {if (verEMAQ!=Vemaq) {$("#editmaq").toggle(200); verEMAQ=Vemaq;};}
function VnVEman (Veman) {if (verEMAN!=Veman) {$("#editman").toggle(200); verEMAN=Veman;};}
function VnVErev (Verev) {if (verEREV!=Verev) {$("#editrev").toggle(200); verEREV=Verev;};}
//=========================================================================================================	

//VER BOTON SEMAFORO_______________________________________________________________________

//Funcion de inicialización de la pestaña, ocultando el botón rojo.
function VbInit17() {document.getElementById('botonrojo17').style.display = 'none';}
//valor 1 se pone rojo, valor 0 se pone verde.	
function Vb17(intColor17) {
	if (INTcolor17!=intColor17) {$("#botonrojo17").toggle(200); $("#botonverde17").toggle(200); INTcolor17=intColor17;};
	}
//__________________________________________________________________________________________

/* VER NO VER*/

var verI1= 0; var verI2= 0; var verI3= 0; var verI4= 0; var verI5= 0; var verI6= 0;
var verI11= 0; var verI12= 0; var verI13= 0; var verI14= 0; var verI15= 0;

function VnV17B (Vi1, Vi2, Vi3, Vi4, Vi5, Vi6, Vi11, Vi12, Vi13, Vi14, Vi15) { 
	if (verI1!=Vi1) {$("#info1").toggle(200); verI1=Vi1;};
	if (verI2!=Vi2) {$("#info2").toggle(200); verI2=Vi2;};
	if (verI3!=Vi3) {$("#info3").toggle(200); verI3=Vi3;};
	if (verI4!=Vi4) {$("#info4").toggle(200); verI4=Vi4;};
	if (verI5!=Vi5) {$("#info5").toggle(200); verI5=Vi5;};
	if (verI6!=Vi6) {$("#info6").toggle(200); verI6=Vi6;};
	if (verI11!=Vi11) {$("#info11").toggle(200); verI11=Vi11;};
	if (verI12!=Vi12) {$("#info12").toggle(200); verI12=Vi12;};
	if (verI13!=Vi13) {$("#info13").toggle(200); verI13=Vi13;};
	if (verI14!=Vi14) {$("#info14").toggle(200); verI14=Vi14;};
	if (verI15!=Vi15) {$("#info15").toggle(200); verI15=Vi15;};
}

function InitVnV17B () {
	//Todo este lio es porque dentro del ".ready" no acepta leer variables globales. Lo que me obliga a inicializar todo.
	document.getElementById('info1').style.display = 'none';document.getElementById('info2').style.display = 'none';
	document.getElementById('info3').style.display = 'none';document.getElementById('info4').style.display = 'none';
	document.getElementById('info5').style.display = 'none'; document.getElementById('info6').style.display = 'none';
	document.getElementById('info11').style.display = 'none';document.getElementById('info12').style.display = 'none';
	document.getElementById('info13').style.display = 'none';document.getElementById('info14').style.display = 'none';
	document.getElementById('info15').style.display = 'none';

	verI1= 0; verI2= 0; verI3= 0; verI4= 0; verI5= 0; verI6= 0; verI11= 0; verI12= 0; verI13= 0; verI14= 0; verI15= 0;	

	if (idseleccionado17b==1) {VnV17B (1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0); document.getElementById("tituloequipo").innerHTML ="Máquina general";};
	if (idseleccionado17b==2) {VnV17B (0, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0); document.getElementById("tituloequipo").innerHTML ="Aparato a presión";};
	if (idseleccionado17b==3) {VnV17B (0, 0, 1, 0, 0, 0, 0, 0, 0, 0, 0); document.getElementById("tituloequipo").innerHTML ="Instalación eléctrica";};
	if (idseleccionado17b==4) {VnV17B (0, 0, 0, 1, 0, 0, 0, 0, 0, 0, 0); document.getElementById("tituloequipo").innerHTML ="Equipo de medida";};
	if (idseleccionado17b==5) {VnV17B (0, 0, 0, 0, 1, 0, 0, 0, 0, 0, 0); document.getElementById("tituloequipo").innerHTML ="Instalación térmica";};
	if (idseleccionado17b==6) {VnV17B (0, 0, 0, 0, 0, 1, 0, 0, 0, 0, 0); document.getElementById("tituloequipo").innerHTML ="Instalación Aire Acondicinado";};
	if (idseleccionado17b==11) {VnV17B (0, 0, 0, 0, 0, 0, 1, 0, 0, 0, 0); document.getElementById("tituloequipo").innerHTML ="Extintor/es de incendios";};
	if (idseleccionado17b==12) {VnV17B (0, 0, 0, 0, 0, 0, 0, 1, 0, 0, 0); document.getElementById("tituloequipo").innerHTML ="Boca/s de Incendio Equipada/s";};
	if (idseleccionado17b==13) {VnV17B (0, 0, 0, 0, 0, 0, 0, 0, 1, 0, 0); document.getElementById("tituloequipo").innerHTML ="Detección y Alarma";};
	if (idseleccionado17b==14) {VnV17B (0, 0, 0, 0, 0, 0, 0, 0, 0, 1, 0); document.getElementById("tituloequipo").innerHTML ="Hidrantes, Columnas Secas y Grupos";};
	if (idseleccionado17b==15) {VnV17B (0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1); document.getElementById("tituloequipo").innerHTML ="Rociador/es automáticos";};

}


//=========================================================================================================					
/*COMBOBOX DE MANTENIMIENTOS*/

function sacarMans (){
	var db;
        db = openDatabase("DBIWOHS", "0.1", "Database Isowin OHS", 500 * 1024 * 1024);	
		//alert ("Estoy dentro");					
	if(db){
		db.transaction( function(tx) {
			tx.executeSql("SELECT * FROM mantenimientos WHERE idmaquina=? OR idtipo=? ", [idseleccionado17, idseleccionado17b],
				function(tx, result){
					nuevosman = "<option selected></option>";
					for(var i=0; i < result.rows.length; i++) {	
						nuevosman = nuevosman + "<option value='" +result.rows.item(i)['idman']+"'>"+result.rows.item(i)['mantenimiento'] + "</option> ";
					}			
				});
		});	
	
	};
}
//=========================================================================================================		