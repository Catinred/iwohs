
			
function Mensaje() { 
	       
	apprise('<p><h2>Bienvenido al Consultor!</h2></p><p> En esta ventana te iremos indicando los pasos que tienes que seguir para implantar tu sistema de gestion de calidad, o comenzar a utilizar ISOWIN ONE. No solo dispones de esta ayuda, en LinkedIn  (www.linkedin.com) dispones de un grupo exclusivo donde te resolveremos todas tus dudas.</p><p>Cuando hayas leido cada mensaje puedes pulsar el boton "Ok". Pero si quieres leer la instruccion anterior, deberas presionar "Anterior"</p>', {'verify':true, 'textYes':'Ok', 'textNo':'Anterior'});
	    
    }
	
