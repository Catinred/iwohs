    var db;	
		
 //CUIDADO CON LOS ALERT NO FUNCIONAN LOS EXECUTESQL!!!
					
function crearBD() {
	    var db;
        db = openDatabase("DBIW1", "0.1", "Database Isowin One", 500 * 1024 * 1024);
		if(!db)     alert("Failed to connect to database.");
        if (db) {
            // Database opened
			db.transaction( function(tx) {
tx.executeSql("CREATE TABLE IF NOT EXISTS documentos(iddocumento integer primary key autoincrement, coddocumento text, documento text, revision text, fchpublic datetime, link longtext, estado text, proceso integer)");
tx.executeSql("CREATE TABLE IF NOT EXISTS registros(idregistro integer primary key autoincrement, codregistro text, registro text, revision text, fchpublic datetime, link longtext, anos text, lugar longtext, estado text, proceso integer)");
tx.executeSql("CREATE TABLE IF NOT EXISTS tareas(idtarea integer primary key autoincrement, tarea text, fchinicio datetime, fchfin datetime, descripcion longtext, prioridad integer, trazabilidad text)");
tx.executeSql("CREATE TABLE IF NOT EXISTS indicadores(idindicador text, serie text, mes integer, valor double)");
tx.executeSql("CREATE TABLE IF NOT EXISTS proveedores(idproveedor integer primary key autoincrement, proveedor text, cif text, fchinicial datetime, fcheval datetime, eval1 integer, eval2 integer, eval3 integer, eval4 integer, eval5 integer, valoracion double)");
tx.executeSql("CREATE TABLE IF NOT EXISTS ncprovs(idncprov integer primary key autoincrement, ncprov text, codncprov text, fchinicio datetime, fchfin datetime, responsable text, idproveedor integer, descripcion text, correccion text, codacp text)");
tx.executeSql("CREATE TABLE IF NOT EXISTS ncs(idnc integer primary key autoincrement, nc text, codnc text, proceso text, origen text, fchinicio datetime, fchfin datetime, responsable text, descripcion text, correccion text, codacp text)");

tx.executeSql("CREATE TABLE IF NOT EXISTS acps(idacp integer primary key autoincrement, acp text, codacp text, tipo text, origen text, fchalta datetime, responsable text, equipo text, estado text, acciones text, fchprevista datetime, seguimiento text, fchcierre datetime, eficacia text, fcheficacia datetime, codtrz text)");

tx.executeSql("CREATE TABLE IF NOT EXISTS puestos(idpuesto integer primary key autoincrement, puesto text, requisitos text, funciones text, idpadre integer)");
tx.executeSql("CREATE TABLE IF NOT EXISTS personas(idpersona integer primary key autoincrement, nombre text, apellidos text, dni text, fchnac text, fchalta text, linkcv text, idpuesto integer)");
tx.executeSql("CREATE TABLE IF NOT EXISTS cursospersonas(idcurso integer, idpersona integer, valoracion text, fchvaloracion datetime, linkdiploma text, obs text)");
tx.executeSql("CREATE TABLE IF NOT EXISTS cursos(idcurso integer primary key autoincrement, curso text, codcurso text, objetivos text, estado text, alumnos text, fchinicio datetime, fchfin datetime, horario text, nhoras integer, valalumnos text, valformador text, valjefe text, fchvaljefe datetime, linkdocs text, obs text)");
tx.executeSql("CREATE TABLE IF NOT EXISTS equipos(idequipo integer primary key autoincrement, equipo text, marca text, modelo text, sn text, rango text, escalon text, uso text, umax double, fchprox datetime, obs text)");
tx.executeSql("CREATE TABLE IF NOT EXISTS calibraciones(idcal integer primary key autoincrement, idequipo integer, tipo text, u double, fchcal datetime, linkcert text, obs text)");

tx.executeSql("CREATE TABLE IF NOT EXISTS maquinas (idmaquina integer primary key autoincrement, maquina text, marca text, modelo text, sn text, fchfabricacion datetime, valor text, linkdocs text, fchprox datetime, obs text)");
tx.executeSql("CREATE TABLE IF NOT EXISTS mantenimientos (idman integer primary key autoincrement, idmaquina integer, mantenimiento text, periodicidad text, operaciones text, responsable text, prioridad text, linkdocs text, fchprox datetime, obs text)");
tx.executeSql("CREATE TABLE IF NOT EXISTS marevs (idmarev integer primary key autoincrement, idman integer, fchrev datetime, resultado text, por text, linkdocs text, obs text)");
tx.executeSql("CREATE TABLE IF NOT EXISTS propcliente (idpc integer primary key autoincrement, material text, cliente text, ubicacion text, uso text, responsable text, vulnerabilidad text, proteccion text, caducidad text, obs text)");

tx.executeSql("CREATE TABLE IF NOT EXISTS disenos (iddiseno integer primary key autoincrement, diseno text, responsable text, equipotrabajo text, linkplan text, cambiosplan text, reqlegal text, reqfuncion text, linkrequisitos text, criteriosacept text, resultados text, obs text)");
tx.executeSql("CREATE TABLE IF NOT EXISTS direvs (iddirev integer primary key autoincrement, iddiseno integer, tipo text, fchplan datetime, fchreal datetime, resultados text, acciones text)");

tx.executeSql("CREATE TABLE IF NOT EXISTS reclamaciones (idreclamacion integer primary key autoincrement, codreclamacion text, reclamacion text, fchalta datetime, descripcion text, correccion text, fchcierre datetime, conforme text, idcliente integer, idacp integer)");
tx.executeSql("CREATE TABLE IF NOT EXISTS estudios (idestudio integer primary key autoincrement, estudio text, fchinicio datetime, fchfin datetime, objetivos text, responsable text, resultado double, valoracion text, pr1 text, pr2 text, pr3 text, pr4 text, pr5 text, pr6 text, pr7 text, pr8 text, pr9 text, pr10 text)");
tx.executeSql("CREATE TABLE IF NOT EXISTS encuestas (idencuesta integer primary key autoincrement, idestudio integer, idcliente integer, estado text, fchalta datetime, eval1 integer, eval2 integer, eval3 integer, eval4 integer, eval5 integer, eval6 integer, eval7 integer, eval8 integer, eval9 integer, eval10 integer, resultado double)");

tx.executeSql("CREATE TABLE IF NOT EXISTS clientes (idcliente integer primary key autoincrement, cliente text, cif text, direccion text, tlf text, fchalta datetime, contacto text, tlfcontacto text, satisfaccion text)");

tx.executeSql("CREATE TABLE IF NOT EXISTS objetivos(idobjetivo integer primary key autoincrement, objetivo text, descripcion text, responsable text, recursos text )");
tx.executeSql("CREATE TABLE IF NOT EXISTS acciones(idaccion integer primary key autoincrement, accion text, adescripcion text, aresponsable text, arecursos text, fchinicio datetime, fchfin datetime, valorultrev text, fchultrev datetime, idobjetivo integer, color text)");

tx.executeSql("CREATE TABLE IF NOT EXISTS apuntes(apunte text, prioridad integer)");
tx.executeSql("CREATE TABLE IF NOT EXISTS requisitos(idrequisito integer primary key autoincrement, requisito text, cliente text, pedido text, responsable text, implantacion text, valorultrev text, fchultrev datetime)");
tx.executeSql("CREATE TABLE IF NOT EXISTS procesos(idproceso integer, proceso text, mision text, alcance text, entradas text, salidas text, recursos text, responsable text, requisitos text, controles text)");
//tx.executeSql("CREATE TABLE IF NOT EXISTS auditorias(idtarea primary key, alcance text, estado text, nncs text, linkinforme text, linkpac text, FOREIGN KEY (idtarea) REFERENCES tareas (idtarea) ON UPDATE CASCADE ON DELETE CASCADE)");
			
			});
			
		
			}
	  }	
	  
function ingresarBD () {
	    var db;
        db = openDatabase("DBIW1", "0.1", "Database Isowin One", 500 * 1024 * 1024);
		if(db){	
		db.transaction( function(tx) {
tx.executeSql("INSERT INTO documentos(coddocumento, documento, revision, fchpublic, link, estado, proceso) VALUES(?,?,?,?,?,?,?)", ["PR001","DocPrueba", "1.5","2012-02-12","c:/docs", "Aprobado", 2]);
tx.executeSql("INSERT INTO registros(codregistro, registro, revision, fchpublic, link, anos, lugar, estado, proceso) VALUES(?,?,?,?,?,?,?,?,?)", ["REG001", "RegPrueba", "1.5","2012-02-12","c:/regs",3,"c:/docs/obsoletos", "Obsoleto", 3]);
tx.executeSql("INSERT INTO indicadores(idindicador, serie, mes, valor) VALUES(?,?,?,?)",["I1", "2012", 2, 5]);	
tx.executeSql("INSERT INTO proveedores(proveedor, cif, fchinicial, fcheval, eval1, eval2, eval3, eval4, eval5, valoracion) VALUES(?,?,?,?,?,?,?,?,?,?)",["Telnet", "A50608295", "01/03/2010", "11/08/2011", 2, 5, 7, 6, 8, 4]);	
tx.executeSql("INSERT INTO ncprovs(ncprov, codncprov, fchinicio, fchfin, responsable, idproveedor, descripcion, correccion, codacp) VALUES(?,?,?,?,?,?,?,?,?)",["Retraso en entrega", "NCP-01", "01/03/2012", "14/04/2012", "Tomas Misser", 1, "Ha retrasado la entrega del material en dos semanas", "Penalización económica", "AC-57"]);	
tx.executeSql("INSERT INTO ncs(nc, codnc, proceso, origen, fchinicio, fchfin, responsable, descripcion, correccion, codacp) VALUES(?,?,?,?,?,?,?,?,?,?)",["Falta aprobaci�n","NC-2","Compras","N/A","2012-01-06","2012-01-06","Daniel Monreal","-","Se firma","ACP-22"]);

tx.executeSql("INSERT INTO acps(acp, codacp, tipo, origen, fchalta, responsable, equipo, estado, acciones, fchprevista, seguimiento, fchcierre, eficacia, fcheficacia, codtrz) VALUES(?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)",["Sistema de Seguridad intrusi�n","AC-12","AC","NC-1214","'2012-1-1'","David Santamaria","Javier Sanchez, Francisco Lera","En proceso","Varias","'2012-12-1'","Vamos en tiempo","'2012-11-1'","Eficacia probada","'2012-1-1'","rc1"]);

tx.executeSql("INSERT INTO puestos(puesto, requisitos, funciones, idpadre) VALUES(?,?,?,?)",["Operario","EGB","Colocar un tornillo",0]);
tx.executeSql("INSERT INTO personas(nombre, apellidos, dni, fchnac, fchalta, linkcv, idpuesto) VALUES(?,?,?,?,?,?,?)",["David","Santolaria Bellosta","252423123Z","28-09-1982", "14-09-2010", "c:/cvs/personal", 2]);
tx.executeSql("INSERT INTO cursos(curso, codcurso, objetivos, estado, alumnos, fchinicio, fchfin, horario, nhoras, valalumnos, valformador, valjefe, fchvaljefe, linkdocs, obs) VALUES(?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)",["PVDs","F-01", "Reducir problemas musculares","Finalizado","Administrativos","2012-03-08","2012-03-21","8:00 a 14:00",20,"8","7","6","2012-05-20", "c:/formaci�n/cursos", "-"]);
tx.executeSql("INSERT INTO cursospersonas (idcurso, idpersona, valoracion, fchvaloracion, linkdiploma, obs) VALUES(?,?,?,?,?,?)",[2,2,"Aprovechado","2012-03-08","c:/diplomas","Sin comentarios"]);

tx.executeSql("INSERT INTO equipos(equipo, marca, modelo, sn, rango, escalon, uso, umax, fchprox, obs) VALUES(?,?,?,?,?,?,?,?,?,?)",["OTDR","EXFO","B-300","1232-tr12","1-100","0,1","en campo",0.1,"2012-03-04","fue reparado"]);
tx.executeSql("INSERT INTO calibraciones(idequipo, tipo, u, fchcal, linkcert, obs) VALUES(?,?,?,?,?,?)",["2", "Calibraci�n","0,01","05-07-2012","c/certificados de calibraci�n","No coments"]);

tx.executeSql("INSERT INTO maquinas (maquina, marca, modelo, sn, fchfabricacion, valor, linkdocs, obs) VALUES(?,?,?,?,?,?,?,?)",["Extrusora","Mainfer","JFK","1232-tr12","01-05-2005","5.000 euros","c:/mantenimientos","Sin comentarios"]);
tx.executeSql("INSERT INTO mantenimientos (idmaquina, mantenimiento, periodicidad, operaciones, responsable, prioridad, linkdocs, fchprox, obs) VALUES(?,?,?,?,?,?,?,?,?)",[2,"Engrasado general","1/mes","engrasar partes m�viles","Depto Mantenimiento","Media","c:/mantenimientos","09-11-2012","Sin comentarios"]);
tx.executeSql("INSERT INTO marevs (idman, fchrev, resultado, por, linkdocs, obs) VALUES(?,?,?,?,?,?)",[1, "10-07-2012","Todo ok","Daniel Sena","c:/resultados de mantenimiemto/","No more coments"]);
tx.executeSql("INSERT INTO propcliente ( material, cliente, ubicacion, uso, responsable, vulnerabilidad, proteccion, caducidad, obs) VALUES(?,?,?,?,?,?,?,?,?)",["Fibra �ptica especial", "Telef�nica","Sala de Ultravioleta","Curado de fibra","Gabriel Ordovas","Golpes, agua, sol, fuego","Armario RF90","1-1-2015","en palet europeo"]);

tx.executeSql("INSERT INTO disenos (diseno, responsable, equipotrabajo, linkplan, cambiosplan, reqlegal, reqfuncion, linkrequisitos, criteriosacept, resultados, obs) VALUES(?,?,?,?,?,?,?,?,?,?,?)",["Monoposte","Ignacio Mesa","Antonio gil, Alejandro sanchis","c:/planificaciones","Sin cambios","Ley del viento","UNE-12-32EX","c:/requisitos","H>6.2","Montaje correcto","Sin comentarios"]);
tx.executeSql("INSERT INTO direvs (iddiseno, tipo, fchplan, fchreal, resultados, acciones) VALUES(?,?,?,?,?,?)",[2,"rev","2012-02-28","2012-03-01","Todo correcto","ninguna"]);

tx.executeSql("INSERT INTO reclamaciones (codreclamacion, reclamacion, fchalta, descripcion, correccion, fchcierre, conforme, idcliente, idacp) VALUES(?,?,?,?,?,?,?,?,?)",["RC-023","Producto mal estado","2011-02-03","El equipo ha llegado mojado","cambio del equipo","2012-1-1","El cliente est� conforme",1,5]);
tx.executeSql("INSERT INTO estudios (estudio, fchinicio, fchfin, objetivos, responsable, resultado, valoracion, pr1, pr2, pr3, pr4, pr5, pr6, pr7, pr8, pr9, pr10) VALUES(?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)",["Encuestas anuales","01-12-2012","31-01-2013","Aumentar la satisfacci�n de los clientes","Depto. Comercial",8.3,"Mejor que 2012","�Pregunta 1?","�Pregunta 2?","�Pregunta 4?","�Pregunta 3?","�Pregunta 5?","�Pregunta 6?","�Pregunta 7?","�Pregunta 8?","�Pregunta 9?","�Pregunta 10?"]);
tx.executeSql("INSERT INTO encuestas (idestudio, idcliente, estado, fchalta, eval1, eval2, eval3, eval4, eval5, eval6, eval7, eval8, eval9, eval10, resultado) VALUES(?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)",[1,1,"En proceso","12-02-2012",3,2,3,6,5,1,2,3,4,5,6.1]);

tx.executeSql("INSERT INTO clientes (cliente, cif, direccion, tlf, fchalta, contacto, tlfcontacto, satisfaccion) VALUES(?,?,?,?,?,?,?,?)",["Orange","A50324456","Moraleja 43","912002030","2012-05-12","Mariano Alierta","912003454","Est� satisfecho"]);

tx.executeSql("INSERT INTO objetivos(objetivo, descripcion, responsable, recursos) VALUES(?,?,?,?)",["Optimizaci�n de la producci�n", "detalle...", "Emilio Lisbona", "Depto. Producci�n"]);
tx.executeSql("INSERT INTO acciones(accion, adescripcion, aresponsable, arecursos, fchinicio, fchfin, valorultrev, fchultrev, idobjetivo, color) VALUES(?,?,?,?,?,?,?,?,?,?)",["Analisis fuentes de consumo","Analizar principales fuentes de consumo", "Daniel Monreal", "Depto. Administraci�n","05/18/2012", "09/10/2012", "13%", "01/08/2012", 1, "ganttRed"]);

tx.executeSql("INSERT INTO tareas(tarea, fchinicio, fchfin, descripcion, prioridad, trazabilidad) VALUES(?,?,?,?,?,?)",["TareaPrueba", "2012-05-30", "2012-10-31", "Descripcion de la tarea de prueba",0,""]);	
tx.executeSql("INSERT INTO apuntes(apunte, prioridad) VALUES(?,?)",["Comprar pan", 2]);
tx.executeSql("INSERT INTO requisitos(requisito, cliente, pedido, responsable, implantacion, valorultrev, fchultrev) VALUES(?,?,?,?,?,?,?)",["Plazo de entrega una semana", "Telef�nica", "TEL-12162-2012", "Quinon", "Hecha", "OK", "2012-04-11"]);

//Tablas conectadas
//tx.executeSql("INSERT INTO auditorias(idtarea, alcance, estado, nncs, linkinforme, linkpac) VALUES(?,?,?,?,?,?)",[25, "ISO 9001", "Planificada", "0 NCs", "c:/informes/auditorias",  "c:/auditorias/PACs"]);
			
		});
		}; 
		}
				
		
//__________________________________________________________________________________________			
			
function desplegarBD () {
	
	//CREACI�N DE BD	
	crearBD();	
	
	//CREACI�N DE PROCESOS
	var db;
        db = openDatabase("DBIW1", "0.1", "Database Isowin One", 500 * 1024 * 1024);
		if(db){	
		db.transaction( function(tx) {

tx.executeSql("INSERT INTO procesos(idproceso, proceso, mision, alcance, entradas, salidas, recursos, responsable, requisitos, controles) VALUES(?,?,?,?,?,?,?,?,?,?)",[1, "Control Documentaci�n y Registros", "", "", "", "", "", "", "", ""]);
tx.executeSql("INSERT INTO procesos(idproceso, proceso, mision, alcance, entradas, salidas, recursos, responsable, requisitos, controles) VALUES(?,?,?,?,?,?,?,?,?,?)",[2, "Compras", "", "", "", "", "", "", "", ""]);
tx.executeSql("INSERT INTO procesos(idproceso, proceso, mision, alcance, entradas, salidas, recursos, responsable, requisitos, controles) VALUES(?,?,?,?,?,?,?,?,?,?)",[3, "Dise�o", "", "", "", "", "", "", "", ""]);
tx.executeSql("INSERT INTO procesos(idproceso, proceso, mision, alcance, entradas, salidas, recursos, responsable, requisitos, controles) VALUES(?,?,?,?,?,?,?,?,?,?)",[4, "NC, AC/P y Auditor�as", "", "", "", "", "", "", "", ""]);
tx.executeSql("INSERT INTO procesos(idproceso, proceso, mision, alcance, entradas, salidas, recursos, responsable, requisitos, controles) VALUES(?,?,?,?,?,?,?,?,?,?)",[5, "Satisfacci�n, reclamaciones y postventa", "", "", "", "", "", "", "", ""]);
tx.executeSql("INSERT INTO procesos(idproceso, proceso, mision, alcance, entradas, salidas, recursos, responsable, requisitos, controles) VALUES(?,?,?,?,?,?,?,?,?,?)",[6, "Ofertas y pedidos", "", "", "", "", "", "", "", ""]);
tx.executeSql("INSERT INTO procesos(idproceso, proceso, mision, alcance, entradas, salidas, recursos, responsable, requisitos, controles) VALUES(?,?,?,?,?,?,?,?,?,?)",[7, "Producci�n / Fabricaci�n", "", "", "", "", "", "", "", ""]);
tx.executeSql("INSERT INTO procesos(idproceso, proceso, mision, alcance, entradas, salidas, recursos, responsable, requisitos, controles) VALUES(?,?,?,?,?,?,?,?,?,?)",[8, "Log�stica", "", "", "", "", "", "", "", ""]);
tx.executeSql("INSERT INTO procesos(idproceso, proceso, mision, alcance, entradas, salidas, recursos, responsable, requisitos, controles) VALUES(?,?,?,?,?,?,?,?,?,?)",[9, "Calibraci�n y Mantenimiento", "", "", "", "", "", "", "", ""]);
tx.executeSql("INSERT INTO procesos(idproceso, proceso, mision, alcance, entradas, salidas, recursos, responsable, requisitos, controles) VALUES(?,?,?,?,?,?,?,?,?,?)",[10, "RR.HH. y Formaci�n", "", "", "", "", "", "", "", ""]);
tx.executeSql("INSERT INTO procesos(idproceso, proceso, mision, alcance, entradas, salidas, recursos, responsable, requisitos, controles) VALUES(?,?,?,?,?,?,?,?,?,?)",[11, "Planificaci�n y objetivos", "", "", "", "", "", "", "", ""]);
tx.executeSql("INSERT INTO procesos(idproceso, proceso, mision, alcance, entradas, salidas, recursos, responsable, requisitos, controles) VALUES(?,?,?,?,?,?,?,?,?,?)",[12, "Revisi�n de SG", "", "", "", "", "", "", "", ""]);

			});
			
		
			}
	  }

			