//DISENOS (8 y 9)

	var idseleccionado8;
	var idseleccionado9;
				
//TABLA DISE�OS_____________________________________________________________________________________________________________

function mostrarDisenos() {
	sacarDisenos ();
	setTimeout('listDisenos()',500);
	}

function listDisenos() {
		$(document).ready(			
			function () {
				$('#dynamic8').html( '<table cellpadding="0" cellspacing="0" border="0" class="display" id="example8"></table>' );
				$('#example8').dataTable( {
					"aaData": aDataSet8,
						
					"aoColumns": [
						{ "sTitle": "Id"/*, "bSearchable": false, "bVisible": false*/ },
						{ "sTitle": "Dise�o" },
						{ "sTitle": "Responsable" },
						{ "sTitle": "Participantes" },
						{ "sTitle": "Planificaci�n" },
						{ "sTitle": "Cambios planificaci�n", "bSearchable": false, "bVisible": false },
						{ "sTitle": "Requisitos legales", "bSearchable": false, "bVisible": false},
						{ "sTitle": "Requisitos funcionales", "bSearchable": false, "bVisible": false },
						{ "sTitle": "Requisitos" },
						{ "sTitle": "Criterios aceptaci�n", "bSearchable": false, "bVisible": false },
						{ "sTitle": "Resultados", "bSearchable": false, "bVisible": false },
						{ "sTitle": "Observaciones", "bSearchable": false, "bVisible": false }
						],
						
					"sScrollY": "600px",
        			"bPaginate": false,
        			"bScrollCollapse": true,
						
					"sDom": 'lfrtip<"clear spacer">T',
					/*"sDom": 'T<"clear">lfrtip<"clear spacer">T',*/ //Muestra los botones de copy,print...
					"oTableTools": {
						"sRowSelect": "single","aButtons": ["select"], //Solo me muestra el boton select para poder seleccionar las filas.
							
					"aoColumnDefs": [ {
						"sClass": "center",
						"aTargets": [ -1, -2 ]
						} ]
						
				}});
				
				});
	//Cargar datos de proveedor para editar en formulario	
			$(document).ready(
				function() {
    			$('#example8 tbody td').click( function () {
        		/* Get the position of the current data from the node */
        		var aPos8 = oTable8.fnGetPosition( this );
         
        		/* Get the data array for this row */
        		var aData8 = oTable8.fnGetData( aPos8[0] );
				/*alert("Ok "+aData[0]);*/
				
				idseleccionado8 =  aData8[0];
				document.getElementById("txtdiseno").value = aData8[1];
				document.getElementById("txtdsresp").value = aData8[2];
				document.getElementById("txtdsequipo").value = aData8[3];
				document.getElementById("txtdslinkplan").value = aData8[4];
				document.getElementById("txtdscambiosplan").value = aData8[5];
				document.getElementById("txtdsreqlegal").value = aData8[6];
				document.getElementById("txtdsreqfuncion").value = aData8[7];
				document.getElementById("txtdslinkreq").value = aData8[8];
				document.getElementById("txtdscriterios").value = aData8[9];
				document.getElementById("txtdsresultados").value = aData8[10];
				document.getElementById("txtdsobs").value = aData8[11];
			
			
			DatosBDrevs(idseleccionado8);
			setTimeout('listRevs()', 200);
			//alert("Hola");			
			
			VnV8 (1, 0, 0, 1);
         
    			});
     
   				 /* Init DataTables */
   				 oTable8= $('#example8').dataTable();
				});
		
	}
//DATOS DISENOS_________________________________________________

function sacarDisenos (){
	var db;
        db = openDatabase("DBIW1", "0.1", "Database Isowin One", 200000);	
		//alert ("Estoy dentro");					
	if(db){
		db.transaction( function(tx) {
			tx.executeSql("SELECT * FROM disenos", [],
				function(tx, result){
					//Creo un array
					/*var output = [];*/
					//Guardo en cada elemento i del vector, un objeto documento.
					aDataSet8 = [];
					for(var i=0; i < result.rows.length; i++) {		
						aDataSet8.push([result.rows.item(i)['iddiseno'],
								result.rows.item(i)['diseno'],
								result.rows.item(i)['responsable'],
								result.rows.item(i)['equipotrabajo'],
								result.rows.item(i)['linkplan'],
								result.rows.item(i)['cambiosplan'],
								result.rows.item(i)['reqlegal'],
								result.rows.item(i)['reqfuncion'],
								result.rows.item(i)['linkrequisitos'],
								result.rows.item(i)['criteriosacept'],
								result.rows.item(i)['resultados'],
								result.rows.item(i)['obs'],
								]);
					};			
				});
		});	
	};
}	


//TABLA REVISIONES DISEñOS_____________________________________________________________________________________________________________

function listRevs() {
	$(document).ready( 
		function () {
				$('#dynamic9').html( '<table cellpadding="0" cellspacing="0" border="0" class="display" id="example9"></table>' );
				$('#example9').dataTable( {
					"aaData": aDataSet9,
						
					"aoColumns": [
						{ "sTitle": "Id"/*, "bSearchable": false, "bVisible": false*/ },
						{ "sTitle": "IdDiseno", "bSearchable": false, "bVisible": false },
						{ "sTitle": "Tipo" },
						{ "sTitle": "Fecha Planificada" },
						{ "sTitle": "Fecha Real" },
						{ "sTitle": "Resultados", "bSearchable": false, "bVisible": false },
						{ "sTitle": "Acciones", "bSearchable": false, "bVisible": false }
						],
						
					"sScrollY": "250px",
        			"bPaginate": false,
        			"bScrollCollapse": true,
						
					"sDom": 'lfrtip<"clear spacer">T',
					/*"sDom": 'T<"clear">lfrtip<"clear spacer">T',*/ //Muestra los botones de copy,print...
					"oTableTools": {
						"sRowSelect": "single","aButtons": ["select"], //Solo me muestra el boton select para poder seleccionar las filas.
							
					"aoColumnDefs": [ {
						"sClass": "center",
						"aTargets": [ -1, -2 ]
						} ]
						
				}});
				
				});
	//Cargar datos de proveedor para editar en formulario	
		$(document).ready(
				function() {
    			$('#example9 tbody td').click( function () {
        		/* Get the position of the current data from the node */
        		var aPos9 = oTable9.fnGetPosition( this );
         
        		/* Get the data array for this row */
        		var aData9 = oTable9.fnGetData( aPos9[0] );
				/*alert("Ok "+aData[0]);*/
				
				idseleccionado9 =  aData9[0];
				//el aData9[1] es el idDiseno
				document.getElementById("txtrevtipo").value = aData9[2];
				document.getElementById("txtrevfchplan").value = aData9[3];
				document.getElementById("txtrevfchreal").value = aData9[4];
				document.getElementById("txtrevresultados").value = aData9[5];
				document.getElementById("txtrevacciones").value = aData9[6];
				
			VnV8 (1, 0, 1, 1);
         
    			});
     
   				 /* Init DataTables */
   				 oTable9= $('#example9').dataTable();
		});
		
	}

	//DATOS REVS FILTRADOS POR DISEñO______________________________________________________________________
		
function DatosBDrevs(idseleccionado8) {
	var db;
        db = openDatabase("DBIW1", "0.1", "Database Isowin One", 200000);
		if(db){	
		db.transaction( function(tx) {
			tx.executeSql("SELECT * FROM direvs WHERE iddiseno=?", [idseleccionado8],
				function(tx, result){
					//Creo un array
					/*var output = [];*/
					//Guardo en cada elemento i del vector, un objeto documento.
					aDataSet9 = [];
					for(var i=0; i < result.rows.length; i++) {
/*						output.push([result.rows.item(i)['iddocumento'],
								result.rows.item(i)['documento'],
								result.rows.item(i)['revision']]);*/
								
						aDataSet9.push([result.rows.item(i)['iddirev'],
								result.rows.item(i)['iddiseno'],
								result.rows.item(i)['tipo'],
								result.rows.item(i)['fchplan'],
								result.rows.item(i)['fchreal'],
								result.rows.item(i)['resultados'],
								result.rows.item(i)['acciones']]);
												
				}		
   				 /* Init DataTables */
   				 oTable9 = $('#example9').dataTable();				
				 
				});
				
				
		});
		
	};}

	

//=========================================================================================================					
/*NUEVO DISEÑO*/
	
	function addDiseno(diseno, responsable, equipotrabajo, linkplan, cambiosplan, reqlegal, reqfuncion, linkrequisitos, criteriosacept, resultados, obs) {
		var db;
		db = openDatabase("DBIW1", "0.1", "Database Isowin One", 200000);
		if(db){	
		  db.transaction( function(tx) {
			tx.executeSql("INSERT INTO disenos (diseno, responsable, equipotrabajo, linkplan, cambiosplan, reqlegal, reqfuncion, linkrequisitos, criteriosacept, resultados, obs) VALUES(?,?,?,?,?,?,?,?,?,?,?)", [diseno, responsable, equipotrabajo, linkplan, cambiosplan, reqlegal, reqfuncion, linkrequisitos, criteriosacept, resultados, obs]);
			apprise('El diseño ha sido guardado'); //alert("Diseño guardado: "+ diseno);
		})};
		setTimeout('mostrarDisenos()',500);
	}
	
/*ACTUALIZAR DISEÑO*/
		function updateDiseno (diseno, responsable, equipotrabajo, linkplan, cambiosplan, reqlegal, reqfuncion, linkrequisitos, criteriosacept, resultados, obs) {
		var db;
        db = openDatabase("DBIW1", "0.1", "Database Isowin One", 200000);
		if(db){	
		  db.transaction( function(tx) {
			tx.executeSql("UPDATE disenos SET diseno=?, responsable=?, equipotrabajo=?, linkplan=?, cambiosplan=?, reqlegal=?, reqfuncion=?, linkrequisitos=?, criteriosacept=?, resultados=?, obs=?   WHERE iddiseno=?", [diseno, responsable, equipotrabajo, linkplan, cambiosplan, reqlegal, reqfuncion, linkrequisitos, criteriosacept, resultados, obs, idseleccionado8]);
			apprise('El diseño ha sido modificado'); //alert("Diseño ha cambiado: "+ diseno + " - " + idseleccionado8);
		})};
		setTimeout('mostrarDisenos()',500);}					

/*BORRAR DISEÑO*/
	function removeDiseno() {
		apprise('¿Eliminar el diseño?', {'verify': true}, function(r) {
			if(r) {
		var db;
        db = openDatabase("DBIW1", "0.1", "Database Isowin One", 200000);
		if(db){	
		  db.transaction(function(tx) {
			tx.executeSql("DELETE FROM disenos WHERE iddiseno=?",[idseleccionado8]);
			  tx.executeSql("DELETE FROM revs WHERE iddiseno=?",[idseleccionado8]); //Elimina revisiones asociadas a este equipo.
			apprise('El diseño ha sido borrado'); //alert("Diseño borrado: "+ idseleccionado8);

		});};};
		setTimeout('mostrarDisenos()',500);
		});
	}
	
//=========================================================================================================					
/*NUEVA REVISIóN DE DISEñO*/
	
	function addRev(tipo, fchplan, fchreal, resultados, acciones) {
		//alert('Holaxx');
		//alert(idseleccionado8 + "/" + idseleccionado9);
		var db;
		db = openDatabase("DBIW1", "0.1", "Database Isowin One", 200000);
		if(db){	
		  db.transaction( function(tx) {
			tx.executeSql("INSERT INTO direvs (iddiseno, tipo, fchplan, fchreal, resultados, acciones) VALUES(?,?,?,?,?,?)", [ idseleccionado8, tipo, fchplan, fchreal, resultados, acciones]);
			apprise('La revisi�n ha sido guardada'); //alert("Revisión del diseño guardado: "+ tipo);
		})};
		DatosBDrevs(idseleccionado8);
		setTimeout('listRevs()',500);
	}
	
/*ACTUALIZAR REVISI�N DE DISE�O*/
	function updateRev (tipo, fchplan, fchreal, resultados, acciones) {
		var db;
		db = openDatabase("DBIW1", "0.1", "Database Isowin One", 200000);
		if(db){	
		  db.transaction( function(tx) {
			tx.executeSql("UPDATE direvs SET iddiseno=?, tipo=?, fchplan=?, fchreal=?, resultados=?, acciones=?  WHERE iddirev=?", [ idseleccionado8, tipo, fchplan, fchreal, resultados, acciones, idseleccionado9]);
			apprise('La revisi�n ha sido modificada'); //alert("Revision de diseño ha cambiado: "+ tipo + " - " + idseleccionado9);
		})};
		DatosBDrevs(idseleccionado8);
		setTimeout('listRevs()',500);}					

/*BORRAR REVISI�N DE DISE�O*/
	function removeRev() {
		apprise('�Eliminar la revisi�n?', {'verify': true}, function(r) {
			if(r) {
		var db;
		db = openDatabase("DBIW1", "0.1", "Database Isowin One", 200000);
		if(db){	
		  db.transaction(function(tx) {
			tx.executeSql("DELETE FROM direvs WHERE iddirev=?",[idseleccionado9]);
			apprise('La revisi�n ha sido eliminada'); //alert("Revisi�n de diseño borrado: "+ idseleccionado9);

		});};};
		DatosBDrevs(idseleccionado8);
		setTimeout('listRevs()',500);
		});
	}
	
//=========================================================================================================
/* VER NO VER*/
var verNDI= 0; var verLDI= 1; var verNRE= 0; var verLRE= 0;

function VnV8 (Vndi, Vldi, Vnre, Vlre) { 
	if (verNDI!=Vndi) {$("#newdiseno").toggle(200); verNDI=Vndi; $("#txtdiseno").focus();};
	if (verLDI!=Vldi) {$("#listadisenos").toggle(200); verLDI=Vldi;};
	if (verNRE!=Vnre) {$("#newrev").toggle(200); verNRE=Vnre; $("#txtrevtipo").focus();};
	if (verLRE!=Vlre) {$("#listarevs").toggle(200); verLRE=Vlre;};
	}