var js = document.createElement("apprise-1.5.full.js"); 
js.type = "text/javascript"; js.src = jsFilePath; document.body.appendChild(js);

$(document).ready(function() {
	
	$("#botonConsultor").click(function() {
	
		var cookies_data = {
			usuario: getCookie('usEmail'),
			is_ajax: 1
		};
		alert("Dentro del js! ");
		$.ajax({
			type: "POST",
			url: "php/consultor.php",
			data: cookies_data,
			success: function(response)
			{
			alert("La ayuda es... ");
			apprise(response);
			}
		});
		
		return false;
	});
	
});

function getCookie(name) {
	var dc = document.cookie;
	var prefix = name + "=";
	var begin = dc.indexOf("; " + prefix);
	if (begin == -1) {
		begin = dc.indexOf(prefix);
		if (begin != 0) return null;
	} else {
		begin += 2;
	};
	var end = document.cookie.indexOf(";", begin);
	if (end == -1) {
		end = dc.length;
	};
	return unescape(dc.substring(begin + prefix.length, end));
}