<?php
//echo "Hola";

	//$is_ajax = $_REQUEST['is_ajax'];
	//if(isset($is_ajax) && $is_ajax)
	//{
		$usuario = $_REQUEST['usuario'];
		//echo $usuario;
		
		$con = mysql_connect("www.isowin.es", "isowin", "david181");
		if (!$con){die('Error de conexi�n: ' . mysql_error());}
		mysql_select_db("isowinusers", $con);
		//echo "Conectado";
		
		
		//Consulto el nconsultor del usuario
		$sql="SELECT nconsultor FROM users WHERE email='".$usuario."'";
		$result = mysql_query($sql);
		if($row = mysql_fetch_array($result)){
			//echo "1 consulta";
			//echo $row["nconsultor"];
			//extraigo la ayuda del usuario
			$sql2="SELECT ayuda, link FROM consultor WHERE nayuda='".$row["nconsultor"]."'";
			$result2 = mysql_query($sql2);	
			if($row2 = mysql_fetch_array($result2)){
				//echo "2 consulta";
				$respuesta = "<div style=' width:600px;'><h4 style='left: 200px;'>El consultor dice...</h4> ";
				$respuesta .=  "<div style=' position: relative; float: left;width:100px;'><img src='img/fotoConsultor.jpg' ></div> ";
				$respuesta .= "<div style=' position: relative; float: right;width:480px;'> ";
				$respuesta .= $row2["ayuda"];
				$respuesta .= " <br /></div></div>";
				 
				 echo $respuesta;

				//Actualizo el número de ayuda en la Base de Datos
				$nuevonayuda = $row["nconsultor"] + 1;
				//echo $nuevonayuda;
				$sql3 = "UPDATE users SET nconsultor = ". $nuevonayuda ." WHERE email='".$usuario."'";
				mysql_query($sql3);
				
				//echo "success";
			} else {echo "Falla 2 consulta";};
		} else {echo "Falla 1 consulta";};

		mysql_free_result($result); 
		mysql_close($con);
	//}
	
?>