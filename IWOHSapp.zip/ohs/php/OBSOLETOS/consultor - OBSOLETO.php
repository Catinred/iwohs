
<?php

$con = mysql_connect("www.isowin.es", "isowin", "david181");
if (!$con)
  {
  die('Could not connect: ' . mysql_error());
  }
echo "Conectado! *" . $_COOKIE["usEmail"];

//Consulto el nconsultor del usuario
mysql_select_db("isowinusers", $con);
$sql="SELECT nconsultor FROM users WHERE email='".$_COOKIE["usEmail"]."'";
$result = mysql_query($sql);
if($row = mysql_fetch_array($result))
{
//extraigo la ayuda del usuario
$sql2="SELECT ayuda, link FROM consultor WHERE nayuda='".$row["nconsultor"]."'";
$result2 = mysql_query($sql2);	
if($row2 = mysql_fetch_array($result2))
{
echo $row2["ayuda"];

//Actualizo el número de ayuda en la Base de Datos
$nuevonayuda=$row["nconsultor"] + 1;
echo $nuevonayuda;
$sql3 = "UPDATE users SET nconsultor = ". $nuevonayuda ." WHERE email='".$_COOKIE["usEmail"]."'";
mysql_query($sql3);


//header('Location: /'.'Gestion.html');

}
else
{
echo "Error de transmisión";
}}

mysql_close($con);
?> 
