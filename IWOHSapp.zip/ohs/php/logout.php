<?php

	/*$is_ajax = $_REQUEST['is_ajax'];
	if(isset($is_ajax) && $is_ajax)
	{*/	
	
	//GUARDO EL NCONSULTOR para saber en que paso del consultor me he quedado.
		$username = $_COOKIE['usEmail'];
		$nconsultor = $_COOKIE['usNConsultor'];
		
		$con = mysql_connect("TU_SERVIDOR", "TU_USUARIO", "TU_PASSWORD");
		if (!$con){die('Error de conexi�n: ' . mysql_error());}
		mysql_select_db("iwohs", $con);
		
		$sql="UPDATE users SET nconsultor=".$nconsultor." WHERE email=".$username."'";
		//"UPDATE nconsultor FROM users WHERE email='".$username."'";
		
		mysql_query($sql, $con);
	
	//ELIMINO LAS COOKIES

			setcookie("usEmail",  "NULL", time() - 3600,"/");
			setcookie("usNombre",  "NULL", time() - 3600,"/");
			setcookie("usNConsultor",  "NULL", time() - 3600,"/");

	//CIERRO LA VENTANA DESDE HTML
			
			echo "success";

		mysql_close($con);
	//}
	
?>